import argparse, json, os, threading, time
from pathlib import Path
import uvicorn
import searchpilot
from searchpilot.bootstrap import build_default_app
p=argparse.ArgumentParser(); p.add_argument('--port',type=int); p.add_argument('--stop'); p.add_argument('--state'); a=p.parse_args()
t=time.monotonic(); app=build_default_app()
Path(a.state).write_text(json.dumps({'pid':os.getpid(),'source_path':searchpilot.__file__,'factory_seconds':time.monotonic()-t}),encoding='utf-8')
server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=a.port,access_log=False))
def stop_watch():
 while not Path(a.stop).exists(): time.sleep(0.1)
 server.should_exit=True
threading.Thread(target=stop_watch,daemon=True).start()
server.run()
