import hashlib,json,time
from pathlib import Path
import numpy as np
from searchpilot.search.vector_index import SentenceTransformerQueryEncoder,DEFAULT_MODEL_NAME,DEFAULT_QUERY_PREFIX
st=time.perf_counter(); e=SentenceTransformerQueryEncoder(DEFAULT_MODEL_NAME,DEFAULT_QUERY_PREFIX); times=[]
for text in ['microsoft','microsoft']:
 t=time.perf_counter(); a=e(text); times.append(time.perf_counter()-t)
result={'first_seconds':times[0],'second_seconds':times[1],'dimension':len(a),'finite':bool(np.isfinite(a).all()),'norm':float(np.linalg.norm(a)),'vector_sha256':hashlib.sha256(a.tobytes()).hexdigest()}
Path('artifacts/vector-startup-2026-10-22/encoder-probe.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
