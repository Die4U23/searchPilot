"""Bounded local ABBA cold-process experiment; never reads .env."""
import asyncio
import hashlib
import json
import os
import platform
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')

async def run(label, warmup):
    folder = ROOT / label
    folder.mkdir(exist_ok=False)
    env = {k: v for k, v in os.environ.items() if not k.startswith(('SEARCHPILOT_', 'OPENAI_', 'ARCBENCH_'))}
    env.update(SEARCHPILOT_DATABASE_URL='', SEARCHPILOT_API_TOKEN='', SEARCHPILOT_DATA_DIR=str(Path('data').resolve()), SEARCHPILOT_ARTIFACT_DIR=str(Path('artifacts').resolve()), SEARCHPILOT_DATA_VERSION='d3a904f41240', SEARCHPILOT_VECTOR_WARMUP=str(warmup).lower(), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', PYTHONPATH=str(Path('src').resolve()))
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    stop, state = folder / 'stop', folder / 'state.json'
    result = dict(label=label, warmup=warmup, status='running', requests=[], port=port)
    save(folder / 'summary.json', result)
    started = time.perf_counter()
    with (folder / 'server.log').open('w', encoding='utf-8') as log:
        process = subprocess.Popen([sys.executable, str(ROOT / 'server.py'), '--port', str(port), '--stop', str(stop), '--state', str(state)], env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            async with httpx.AsyncClient(base_url=f'http://127.0.0.1:{port}', trust_env=False) as client:
                async with asyncio.timeout(120):
                    while True:
                        if process.poll() is not None:
                            raise RuntimeError('server exited before ready')
                        try:
                            async with asyncio.timeout(1):
                                res = await client.get('/health/ready')
                            if res.status_code == 200:
                                break
                        except (httpx.HTTPError, TimeoutError):
                            pass
                        await asyncio.sleep(0.2)
                result.update(ready_seconds=time.perf_counter()-started, ready=res.json(), server=json.loads(state.read_text(encoding='utf-8')))
                assert all(result['ready']['checks'].get(k) is True for k in ('search', 'vector_index', 'ltr', 'recommend', 'feedback'))
                assert (await client.get('/health/live')).status_code == 200
                for query, mode in [('microsoft', 'vector'), ('weather', 'vector'), ('microsoft', 'bm25'), ('microsoft', 'hybrid'), ('microsoft', 'ltr')]:
                    record = dict(query=query, mode=mode, status='pending')
                    result['requests'].append(record)
                    save(folder / 'summary.json', result)
                    before = time.perf_counter()
                    try:
                        async with asyncio.timeout(60):
                            response = await client.post('/search', json=dict(query=query, mode=mode, limit=5), timeout=60)
                            body = response.json()
                        record.update(seconds=time.perf_counter()-before, http_status=response.status_code, response=body)
                        assert response.status_code == 200 and len(body['results']) == 5
                        record['status'] = 'completed'
                    except Exception as exc:
                        record.update(status='failed', error=type(exc).__name__, seconds=time.perf_counter()-before)
                        raise
                    finally:
                        save(folder / 'summary.json', result)
                result['status'] = 'completed'
        except Exception as exc:
            result.update(status='failed', error=type(exc).__name__)
        finally:
            stop.touch()
            try:
                result.update(exit_code=process.wait(timeout=20), shutdown='graceful')
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
                result.update(exit_code=process.wait(), shutdown='forced')
            with socket.socket() as sock:
                result['port_closed'] = sock.connect_ex(('127.0.0.1', port)) != 0
            save(folder / 'summary.json', result)
    print(json.dumps({k: v for k, v in result.items() if k not in ('requests', 'ready')}, ensure_ascii=False), flush=True)
    return result

async def main():
    files = [p for base in ('src/searchpilot', 'artifacts/search') for p in Path(base).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    manifest = {str(p).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    save(ROOT / 'manifest.json', dict(base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), platform=platform.platform(), python=sys.version, sha256=manifest))
    results = []
    for label, flag in [('a1', False), ('b1', True), ('b2', True), ('a2', False)]:
        results.append(await run(label, flag))
    save(ROOT / 'results.json', results)
    if any(r['status'] != 'completed' or r['exit_code'] != 0 or not r['port_closed'] for r in results):
        raise SystemExit(1)

asyncio.run(main())
