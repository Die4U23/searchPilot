"""Offline descriptive plots for completed cases; never changes acceptance decisions."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import re
import statistics
import textwrap
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIB = 1024**2
METRICS = {
    "pid_rss_bytes": ("smaps_rollup", "Rss_bytes"),
    "pid_pss_bytes": ("smaps_rollup", "Pss_bytes"),
    "pid_anonymous_bytes": ("smaps_rollup", "Anonymous_bytes"),
    "pid_vmdata_bytes": ("status", "VmData_bytes"),
    "pid_swap_bytes": ("smaps_rollup", "Swap_bytes"),
    "pid_vmswap_bytes": ("status", "VmSwap_bytes"),
    "cgroup_current_bytes": ("cgroup_memory_current", "bytes"),
    "cgroup_peak_bytes": ("cgroup_memory_peak", "bytes"),
}


def timestamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Timestamp must include a timezone")
    return parsed


def number(value):
    return value if type(value) in (int, float) and math.isfinite(value) and value >= 0 else None


def source(owner, name):
    item = owner.get("sources", {}).get(name, {})
    return item.get("data", {}) if item.get("available") is True else {}


def identity(server):
    if server.get("available") is not True or server.get("identity_consistent") is not True:
        return None
    before, after = source(server, "stat"), source(server, "stat_after")
    pid, ticks = before.get("pid"), before.get("start_time_ticks")
    if not (type(pid) is int and pid > 0 and type(ticks) is int and ticks >= 0):
        return None
    if (
        type(server.get("pid")) is not int
        or type(after.get("pid")) is not int
        or type(after.get("start_time_ticks")) is not int
        or server.get("pid") != pid
        or after.get("pid") != pid
        or after.get("start_time_ticks") != ticks
    ):
        return None
    return [pid, ticks]


def flatten_samples(rows, anchor):
    result = []
    for row in rows:
        server, client = row.get("server", {}), row.get("client", {})
        process = identity(server)
        metrics = {
            key: number(source(server, name).get(field)) for key, (name, field) in METRICS.items()
        }
        memory_stat = source(server, "cgroup_memory_stat").get("bytes", {})
        metrics.update(
            {
                "cgroup_anon_bytes": number(memory_stat.get("anon")),
                "cgroup_file_bytes": number(memory_stat.get("file")),
            }
        )
        if process is None:
            # An unreadable/restarted identity must not create a falsely low process curve.
            for key in metrics:
                if key.startswith("pid_"):
                    metrics[key] = None
        if server.get("available") is not True:
            for key in metrics:
                metrics[key] = None
        client_pid = client.get("pid")
        client_valid = (
            client.get("available") is True and type(client_pid) is int and client_pid > 0
        )
        metrics["client_rss_bytes"] = (
            number(source(client, "memory").get("rss_bytes")) if client_valid else None
        )
        result.append(
            {
                "at": row["at"],
                "elapsed_seconds": (timestamp(row["at"]) - anchor).total_seconds(),
                "phase": row["phase"],
                "process_identity": process,
                "client_pid": client_pid if client_valid else None,
                "server_observed_at": server.get("at"),
                "client_observed_at": client.get("at"),
                "source_availability": {
                    name: item.get("available") is True
                    for name, item in server.get("sources", {}).items()
                },
                "metrics": metrics,
            }
        )
    require_order(result)
    return result


def require_order(rows):
    if any(
        b["elapsed_seconds"] <= a["elapsed_seconds"] for a, b in zip(rows, rows[1:], strict=False)
    ):
        raise ValueError("Observation timestamps must be strictly increasing")


def docker_memory(value):
    if not isinstance(value, str):
        return None
    match = re.fullmatch(
        r"\s*([0-9]+(?:\.[0-9]+)?)\s*(B|kB|KB|MB|GB|TB|KiB|MiB|GiB|TiB)\s*", value.split("/")[0]
    )
    if not match:
        return None
    units = {
        "B": 1,
        "kB": 1000,
        "KB": 1000,
        "MB": 1000**2,
        "GB": 1000**3,
        "TB": 1000**4,
        "KiB": 1024,
        "MiB": MIB,
        "GiB": 1024**3,
        "TiB": 1024**4,
    }
    return number(float(match[1]) * units[match[2]])


def docker_cpu(value):
    if not isinstance(value, str) or not value.endswith("%"):
        return None
    try:
        return number(float(value[:-1]))
    except ValueError:
        return None


def flatten_background(rows, anchor, harness):
    own_names = {str(item["Name"]).lstrip("/") for item in harness.get("initial_state", [])}
    own_ids = {str(item["Id"]) for item in harness.get("initial_state", [])}
    if not own_names or not own_ids:
        raise ValueError("Initial container identities are required to classify other containers")
    result, containers = [], {}
    for row in rows:
        poll = row.get("containers", {})
        observations = {}
        unresolved = []
        if poll.get("available") is True:
            if not isinstance(poll.get("data"), list):
                raise ValueError("Available Docker stats must contain a list")
            for item in poll["data"]:
                name, cid = item.get("Name"), item.get("ID")
                if not name or name == "--" or not cid or cid == "--":
                    # Docker can emit an identity-less placeholder during container churn.
                    # Keep its raw evidence, but never assign its values to a known container.
                    unresolved.append({"reason": "missing_container_name_or_id", "raw": item})
                    continue
                own = name.lstrip("/") in own_names or any(oid.startswith(cid) for oid in own_ids)
                key = f"{cid}:{name}"
                containers[key] = {
                    "id": cid,
                    "name": name,
                    "role": "case_container" if own else "other_container",
                }
                observations[key] = {
                    "cpu_percent": docker_cpu(item.get("CPUPerc")),
                    "memory_used_bytes": docker_memory(item.get("MemUsage")),
                    "raw_cpu": item.get("CPUPerc"),
                    "raw_memory": item.get("MemUsage"),
                }
        result.append(
            {
                "at": row["at"],
                "elapsed_seconds": (timestamp(row["at"]) - anchor).total_seconds(),
                "available": poll.get("available") is True,
                "identity_complete": poll.get("available") is True and not unresolved,
                "containers": observations,
                "unresolved_container_records": unresolved,
                "linux_loadavg": row.get("linux_loadavg"),
            }
        )
    require_order(result)
    return result, containers


def describe(points):
    valid = [(t, value) for t, value in points if value is not None]
    report = {
        "observations": len(points),
        "available": len(valid),
        "missing": len(points) - len(valid),
    }
    if not valid:
        return {
            **report,
            "first": None,
            "last": None,
            "minimum": None,
            "maximum": None,
            "mean": None,
            "median": None,
            "endpoint_delta": None,
            "ols_per_minute": None,
        }
    times, values = zip(*valid, strict=True)
    report.update(
        first=values[0],
        last=values[-1],
        minimum=min(values),
        maximum=max(values),
        mean=statistics.mean(values),
        median=statistics.median(values),
        first_observed_seconds=times[0],
        last_observed_seconds=times[-1],
        observed_span_seconds=times[-1] - times[0],
        maximum_observed_gap_seconds=max(
            (b - a for a, b in zip(times, times[1:], strict=False)), default=None
        ),
    )
    # Missing endpoints cannot silently become substituted endpoints of a trend.
    complete = len(valid) == len(points) and len(valid) >= 2
    report["endpoint_delta"] = values[-1] - values[0] if complete else None
    xbar, ybar = statistics.mean(times), statistics.mean(values)
    denominator = sum((t - xbar) ** 2 for t in times)
    report["ols_per_minute"] = (
        60 * sum((t - xbar) * (v - ybar) for t, v in valid) / denominator
        if complete and denominator
        else None
    )
    return report


def recovery_bounds(harness, anchor):
    start = (timestamp(harness["soak_finished_at"]) - anchor).total_seconds()
    stops = [
        item
        for item in harness.get("commands", [])
        if item.get("argv", [])[-4:] == ["stop", "-t", "30", "api"]
    ]
    if len(stops) != 1:
        return {
            "available": False,
            "reason": "Cannot identify unique recorded restart-stop command",
        }
    end = (timestamp(stops[0]["started_at"]) - anchor).total_seconds()
    if end <= start:
        raise ValueError("Invalid recovery interval")
    return {
        "available": True,
        "start_seconds": start,
        "end_seconds_exclusive": end,
        "boundary_source": "harness soak_finished_at to compose stop command started_at",
        "boundary_precision": "Recorded events bracket phase changes; not exact "
        "scheduler transition timestamps",
    }


def window_report(spec, samples, background, containers):
    if spec.get("available") is False:
        return spec
    left, right = spec["start_seconds"], spec["end_seconds_exclusive"]
    selected = [
        r for r in samples if left <= r["elapsed_seconds"] < right and r["phase"] == spec["phase"]
    ]
    polls = [r for r in background if left <= r["elapsed_seconds"] < right]
    identities = sorted(
        {tuple(r["process_identity"]) for r in selected if r["process_identity"] is not None}
    )
    metrics = {}
    for key in [*METRICS, "cgroup_anon_bytes", "cgroup_file_bytes", "client_rss_bytes"]:
        stats = describe([(r["elapsed_seconds"], r["metrics"][key]) for r in selected])
        ids = (
            {r["client_pid"] for r in selected}
            if key.startswith("client_")
            else {tuple(i) for i in identities}
        )
        if (key.startswith("pid_") or key.startswith("client_")) and len(ids) != 1:
            stats.update(
                endpoint_delta=None,
                ols_per_minute=None,
                trend_unavailable_reason="multiple/no process identities",
            )
        metrics[key] = stats
    other = {}
    for key, info in containers.items():
        if info["role"] == "other_container":
            other[key] = {
                **info,
                **{
                    metric: describe(
                        [
                            (r["elapsed_seconds"], r["containers"].get(key, {}).get(metric))
                            for r in polls
                        ]
                    )
                    for metric in ("cpu_percent", "memory_used_bytes")
                },
            }
    return {
        **spec,
        "sample_count": len(selected),
        "process_identities": identities,
        "metrics": metrics,
        "background_poll_count": len(polls),
        "background_unavailable_poll_count": sum(not r["available"] for r in polls),
        "background_unresolved_record_count": sum(
            len(r["unresolved_container_records"]) for r in polls
        ),
        "other_containers": other,
    }


def assemble(case, harness, bench, analysis, acceptance, raw_samples, raw_background):
    runs = bench.get("runs", [])
    if len(runs) != 1:
        raise ValueError("Expected exactly one benchmark run")
    run = runs[0]
    anchor = timestamp(run["started_at"])
    duration = number(run.get("dispatch_window_seconds"))
    if duration is None or duration <= 0:
        raise ValueError("Missing actual benchmark dispatch duration")
    samples = flatten_samples(raw_samples, anchor)
    background, containers = flatten_background(raw_background, anchor, harness)
    recovery = recovery_bounds(harness, anchor)
    specs = [
        {
            "name": f"five_minute_{left // 300 + 1}",
            "phase": "load",
            "start_seconds": left,
            "end_seconds_exclusive": min(left + 300, duration),
        }
        for left in range(0, math.ceil(duration), 300)
    ]
    for minutes in (10, 20):
        specs.append(
            {
                "name": f"last_{minutes}_minutes",
                "phase": "load",
                "start_seconds": duration - minutes * 60,
                "end_seconds_exclusive": duration,
            }
            if duration >= minutes * 60
            else {
                "name": f"last_{minutes}_minutes",
                "available": False,
                "reason": "Dispatch shorter than requested full window",
            }
        )
    specs.append({"name": "recovery", "phase": "recovery", **recovery})
    phases = []
    for row in samples:
        if not phases or phases[-1]["phase"] != row["phase"]:
            phases.append(
                {"phase": row["phase"], "first_sample_seconds": row["elapsed_seconds"], "count": 0}
            )
        phases[-1].update(last_sample_seconds=row["elapsed_seconds"], count=phases[-1]["count"] + 1)
    report = {
        "schema_version": 1,
        "case": case,
        "purpose": "DESCRIPTIVE_ONLY",
        "benchmark_started_at": run["started_at"],
        "dispatch_duration_seconds": duration,
        "benchmark_finished_at": run.get("finished_at"),
        "recovery_bounds": recovery,
        "existing_decisions": {
            "analysis_status": analysis.get("status"),
            "acceptance_status": acceptance.get("status"),
            "memory_gate": acceptance.get("memory_gate"),
            "acceptance_checks": acceptance.get("checks"),
        },
        "sample_phase_counts": dict(Counter(r["phase"] for r in samples)),
        "observed_phase_segments": phases,
        "source_availability_counts": {
            name: dict(Counter(str(r["source_availability"].get(name, False)) for r in samples))
            for name in sorted({k for r in samples for k in r["source_availability"]})
        },
        "windows": [window_report(spec, samples, background, containers) for spec in specs],
        "container_catalog": containers,
        "samples": samples,
        "background": background,
        "limitations": [
            "Descriptive offline evidence; acceptance files remain authoritative and "
            "unchanged. Finite sampled data cannot establish leak freedom.",
            "Memory values are bytes; plots use MiB. PID, cgroup and client scopes "
            "overlap or differ and must not be added together. VmData is virtual data "
            "size.",
            "All intervals are half-open relative to runs[0].started_at, after warmup; "
            "sample selection uses harness at and phase. Per-source actual timestamps "
            "are retained.",
            "Recovery uses recorded boundary events and recovery-phase samples, "
            "including recovery business checks; it is not wholly idle.",
            "Missing values remain null/plot gaps. Trends require every selected row to "
            "be available; they do not prove complete temporal coverage.",
            "Docker stats memory is rounded CLI used-memory output, not cgroup current; "
            "CPU can exceed 100 percent. Background observations are not time-aligned to "
            "server samples.",
            "A container absent from a poll is unobserved, not zero. Container names and "
            "IDs are retained. Plot lines break on gaps over 15 seconds or process "
            "identity changes.",
            "Docker identity-less placeholder records are retained as unresolved raw "
            "observations; their metrics are not assigned to any named container.",
            "All identified other-container series are plotted. Each background legend "
            "names only its five highest observed peaks to remain readable; the JSON "
            "catalog retains every full name and ID. Dots include singleton observations.",
        ],
    }
    return report


def plot_series(ax, rows, getter, label, scale=1, identity_key=None):
    x, y, previous = [], [], None
    for row in rows:
        t, value = row["elapsed_seconds"], getter(row)
        if previous is not None and (
            t - previous["elapsed_seconds"] > 15
            or (identity_key and row.get(identity_key) != previous.get(identity_key))
        ):
            x.append(t / 60)
            y.append(float("nan"))
        x.append(t / 60)
        y.append(value / scale if value is not None else float("nan"))
        previous = row
    ax.plot(x, y, label=label, linewidth=1.1, marker=".", markersize=2)


def render_png(report):
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    fig, axes = plt.subplots(6, 1, figsize=(15, 19), sharex=True)
    fig.subplots_adjust(top=0.91, bottom=0.045, left=0.12, right=0.98, hspace=0.24)
    panels = [
        ("PID physical memory (MiB)", ["pid_rss_bytes", "pid_pss_bytes", "pid_anonymous_bytes"]),
        ("PID virtual data (MiB)", ["pid_vmdata_bytes"]),
        (
            "API cgroup memory (MiB)",
            ["cgroup_current_bytes", "cgroup_anon_bytes", "cgroup_file_bytes", "cgroup_peak_bytes"],
        ),
        ("Benchmark client RSS (MiB)", ["client_rss_bytes"]),
    ]
    for ax, (title, metrics) in zip(axes, panels, strict=False):
        for metric in metrics:
            owner = (
                "process_identity"
                if metric.startswith("pid_")
                else "client_pid"
                if metric.startswith("client_")
                else None
            )
            plot_series(
                ax,
                report["samples"],
                lambda r, key=metric: r["metrics"][key],
                metric.removesuffix("_bytes"),
                MIB,
                owner,
            )
        ax.set_ylabel(title)
    for ax, metric, title in zip(
        axes[4:],
        ("cpu_percent", "memory_used_bytes"),
        ("Other container CPU (%)", "Other container memory (MiB)"),
        strict=True,
    ):
        others = {
            key: info
            for key, info in report["container_catalog"].items()
            if info["role"] == "other_container"
        }
        peaks = {
            key: max(
                (
                    row["containers"].get(key, {}).get(metric)
                    for row in report["background"]
                    if row["containers"].get(key, {}).get(metric) is not None
                ),
                default=-1,
            )
            for key in others
        }
        named = set(sorted(others, key=lambda key: (-peaks[key], key))[:5])
        for key, info in others.items():
            plot_series(
                ax,
                report["background"],
                lambda r, key=key, metric=metric: r["containers"].get(key, {}).get(metric),
                textwrap.fill(info["name"], width=64) if key in named else "_nolegend_",
                MIB if metric.endswith("bytes") else 1,
            )
        ax.set_title(
            f"All {len(others)} identified other containers; legend: five highest observed peaks",
            fontsize=8,
        )
        ax.set_ylabel(title)
    boundaries = [(0, "measured start"), (report["dispatch_duration_seconds"] / 60, "dispatch end")]
    recovery = report["recovery_bounds"]
    if recovery.get("available"):
        boundaries.extend(
            [
                (recovery["start_seconds"] / 60, "recovery"),
                (recovery["end_seconds_exclusive"] / 60, "restart"),
            ]
        )
    for segment in report["observed_phase_segments"]:
        if segment["phase"] in ("startup", "baseline"):
            boundaries.append(
                (segment["first_sample_seconds"] / 60, segment["phase"] + " first sample")
            )
    for ax in axes:
        ax.grid(alpha=0.25)
        for position, _ in boundaries:
            ax.axvline(position, color="grey", alpha=0.4, linewidth=0.8, linestyle="--")
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(handles, labels, fontsize=7, loc="best")
    for index, (position, label) in enumerate(boundaries):
        axes[0].text(
            position,
            0.98 - 0.07 * (index % 3),
            label,
            transform=axes[0].get_xaxis_transform(),
            fontsize=7,
            rotation=90,
            va="top",
        )
    axes[-1].set_xlabel(
        "Minutes since actual measured benchmark start; dashed lines mark recorded boundaries"
    )
    decisions = report["existing_decisions"]
    fig.suptitle(
        f"{report['case']} — descriptive resources\n"
        f"Existing acceptance: {decisions['acceptance_status']}; "
        f"analysis: {decisions['analysis_status']}\n"
        "Missing observations stay gaps; sampled evidence is not proof of leak freedom",
        fontsize=13,
    )
    output = io.BytesIO()
    try:
        fig.savefig(output, format="png", dpi=130)
    finally:
        plt.close(fig)
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", help="Existing completed case directory directly below this helper")
    args = parser.parse_args()
    folder = (ROOT / args.case).resolve()
    if folder.parent != ROOT or not folder.is_dir():
        parser.error("case must be an existing direct child directory")
    targets = [folder / "descriptive-resources.json", folder / "resources.png"]
    if any(path.exists() for path in targets):
        raise FileExistsError("Refuse to overwrite descriptive outputs")
    names = [
        "summary.json",
        "soak.json",
        "analysis.json",
        "acceptance.json",
        "samples.jsonl",
        "background.jsonl",
    ]
    raw = {name: (folder / name).read_bytes() for name in names}
    docs = {name: json.loads(raw[name]) for name in names if name.endswith(".json")}
    for name in ("summary.json", "soak.json"):
        if docs[name].get("status") != "COMPLETED":
            raise ValueError(f"{name} is not COMPLETED")
    launcher_path = ROOT / (folder.name + "-launcher.json")
    launcher_raw = launcher_path.read_bytes()
    launcher = json.loads(launcher_raw)
    if launcher.get("status") != "COMPLETED" or launcher.get("observer_stopped") is not True:
        raise ValueError("Launcher/observer not completed")
    lines = {}
    for name in ("samples.jsonl", "background.jsonl"):
        if not raw[name] or not raw[name].endswith(b"\n"):
            raise ValueError(f"Empty or incomplete JSONL: {name}")
        lines[name] = [json.loads(line) for line in raw[name].splitlines()]
    report = assemble(
        folder.name,
        docs["summary.json"],
        docs["soak.json"],
        docs["analysis.json"],
        docs["acceptance.json"],
        lines["samples.jsonl"],
        lines["background.jsonl"],
    )
    report["input_sha256"] = {name: hashlib.sha256(data).hexdigest() for name, data in raw.items()}
    report["launcher_sha256"] = hashlib.sha256(launcher_raw).hexdigest()
    report["renderer_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    png = render_png(report)
    payload = (json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode(
        "utf-8"
    )
    if (
        any((folder / name).read_bytes() != data for name, data in raw.items())
        or launcher_path.read_bytes() != launcher_raw
    ):
        raise RuntimeError("Inputs changed while rendering; no output written")
    with targets[0].open("xb") as sink:
        sink.write(payload)
    with targets[1].open("xb") as sink:
        sink.write(png)
    print(
        json.dumps(
            {
                "case": folder.name,
                "outputs": [str(path) for path in targets],
                "existing_decisions": report["existing_decisions"],
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
