"""Remove only the completed validation case's verified Compose resources."""
import argparse
import json
import subprocess
from pathlib import Path
from scripts.validate_container_soak import clean_environment

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DOCKER = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'


def command(args):
    return subprocess.run([DOCKER, *args], cwd=REPO, env=clean_environment(),
                          capture_output=True, text=True, encoding='utf-8',
                          timeout=60, check=True).stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('expanded-c4', 'expanded-c16', 'expanded-c32-hour'))
    case = parser.parse_args().case
    out = ROOT/f'cleanup-{case}.json'
    if out.exists():
        raise FileExistsError(out)
    summary = json.loads((ROOT/case/'summary.json').read_text())
    if summary['status'] != 'COMPLETED' or not (ROOT/case/'acceptance.json').is_file():
        raise ValueError('Completed and audited case required')
    project = 'sp-'+case+'-20261025'
    if summary['config']['project'] != project:
        raise ValueError('Project identity mismatch')
    volume = project+'_pgdata'
    owned = json.loads(command(['volume', 'inspect', volume]))[0]
    assert owned['Name'] == volume and owned['Labels']['com.docker.compose.project'] == project
    before = json.loads(command(['volume', 'inspect', 'searchpilot_pgdata']))[0]
    for role in ('api', 'db'):
        name = project+'-'+role+'-1'
        c = json.loads(command(['inspect', name]))[0]
        assert c['Name'] == '/'+name and c['Config']['Labels']['com.docker.compose.project'] == project
        assert c['Config']['Labels']['com.docker.compose.service'] == role
    names = command(['ps', '-a', '--filter', 'label=com.docker.compose.project='+project,
                     '--format', '{{.Names}}']).splitlines()
    assert set(names) == {project+'-api-1', project+'-db-1'}
    output = command(['compose', '--env-file', str(REPO/'.env.example'), '-p', project,
                      '-f', str(REPO/'docker-compose.yml'), '-f', str(ROOT/case/'compose.override.yml'),
                      'down', '--volumes'])
    after = json.loads(command(['volume', 'inspect', 'searchpilot_pgdata']))[0]
    assert before == after
    assert volume not in command(['volume', 'ls', '--format', '{{.Name}}']).splitlines()
    assert not command(['ps', '-aq', '--filter', 'label=com.docker.compose.project='+project]).strip()
    record = {'removed_project': project, 'removed_volume': volume,
              'original_volume_metadata_unchanged': True, 'output': output}
    with out.open('x', encoding='utf-8') as sink:
        json.dump(record, sink, indent=2)
    print(json.dumps(record))


if __name__ == '__main__':
    main()
