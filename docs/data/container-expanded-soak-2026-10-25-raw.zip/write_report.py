"""Publish completed expanded-soak evidence, exclusively and only after archive verification.

Offline: no service calls or private environment access. Root invokes after all final gates.
"""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PREFIX = "container-expanded-soak-2026-10-25"
DEST = REPO / "docs/data"
CASES = ("expanded-c4", "expanded-c16", "expanded-c32-hour")
USED: dict[str, bytes] = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def raw(name):
    if name not in USED:
        path = ROOT / name
        require(path.resolve().is_relative_to(ROOT), "Out-of-root report evidence")
        USED[name] = path.read_bytes()
    return USED[name]


def read(name):
    return json.loads(raw(name).decode("utf-8-sig"))


def passed(name):
    value = read(name)
    require(
        value.get("status") == "PASSED" or value.get("passed") is True,
        "Final gate not passed: " + name,
    )
    require(
        value.get("status") not in {"FAILED", "RUNNING", "INTERRUPTED"},
        "Conflicting gate status: " + name,
    )
    return value


def num(value, digits=3, signed=False):
    if value is None:
        return "不可用"
    return format(value, ("+" if signed else "") + f".{digits}f")


def table(headers, rows):
    return "\n".join(
        [
            "| " + " | ".join(headers) + " |",
            "|" + "|".join("---" for _ in headers) + "|",
            *("| " + " | ".join(str(cell) for cell in row) + " |" for row in rows),
        ]
    )


def repeat_text(histogram):
    return "；".join(
        f"{count} 组×{repeat}次"
        for repeat, count in sorted(histogram.items(), key=lambda item: int(item[0]))
    )


def case_data(case):
    names = (
        "summary.json",
        "soak.json",
        "analysis.json",
        "acceptance.json",
        "independent-audit.json",
        "descriptive-resources.json",
    )
    h, b, a, acceptance, independent, resource = [read(case + "/" + name) for name in names]
    require(h.get("status") == b.get("status") == "COMPLETED", "Incomplete case: " + case)
    require(
        a.get("status") == acceptance.get("status") == independent.get("status") == "PASSED",
        "Case audit not passed: " + case,
    )
    require(
        acceptance.get("checks") and all(v is True for v in acceptance["checks"].values()),
        "Nonpassing case checks: " + case,
    )
    require(h.get("external_llm_calls") == 0, "Unexpected external LLM call count")
    require(a["coverage"]["verified"] is True, "Query coverage not verified")
    return {
        "case": case,
        "h": h,
        "b": b,
        "a": a,
        "accept": acceptance,
        "independent": independent,
        "resource": resource,
    }


def render(cases, archive):
    manifest, build = read("fixture/manifest.json"), read("build-summary.json")
    hour = cases[-1]
    gate = hour["accept"]["memory_gate"]
    require(gate.get("status") == "PASSED", "Hour memory gate did not pass")
    require(
        gate.get("growth_limit_mib") == 2 and gate.get("slope_limit_mib_per_minute") == 0.1,
        "Hour memory thresholds changed",
    )
    semantics = {case["accept"]["semantic_sha256"] for case in cases}
    require(len(semantics) == 1, "Cross-case semantic hashes differ")
    family = {k: v for k, v in manifest["family_counts"].items() if k != "reference"}
    lengths = list(map(int, manifest["char_length_histogram"]))
    checks = raw("unit-final.txt").decode("utf-8-sig")
    unit = re.search(
        r"(\d+) passed, (\d+) skipped, (\d+) deselected.*?(\d+) subtests passed", checks
    )
    integration = re.search(
        r"(\d+) passed, (\d+) deselected", raw("integration-final.txt").decode("utf-8-sig")
    )
    quality = raw("quality-final.txt").decode("utf-8-sig")
    fmt = re.search(r"(\d+) files already formatted", quality)
    mypy = re.search(r"no issues found in (\d+) source files", quality)
    require(
        unit and integration and fmt and mypy and "All checks passed!" in quality,
        "Cannot establish saved local-check results",
    )
    observed = gate["observed"]
    sections = [
        "# 扩大查询与并发：容器持续验证",
        f"日期：2026-10-25。三档正常容器运行均完成，严格账本、查询覆盖与业务检查通过。"
        "c32 一小时预设末二十分钟 RSS 门槛通过："
        f"首末增长 **{num(observed['growth_mib'], 6)} MiB**，"
        f"OLS **{num(observed['ols_mib_per_minute'], 6)} MiB/分钟**。这是固定负载下的有限验证；"
        "CI 与合并状态见对应 PR，本文不预先宣称通过。",
        "## 本轮改动与输入",
        "本轮新增确定性负载查询生成器、不可变查询字节快照，以及查询覆盖/重复/顺序和实际客户端"
        "在途并发审计。没有新增服务请求路径修复，沿用进程 THP 关闭及 `MALLOC_ARENA_MAX=2`。"
        "Docker stats 无身份占位记录的处理修复属于离线绘图 helper，不是服务内存修复。"
        "历史分配器原因与 c4 小时证据见[上一轮报告](container-memory-arena-2026-10-25.md)。",
        f"查询从原 {manifest['reference_count']} 条扩展到 **{manifest['query_count']} 条**："
        f"保留原文、顺序及来源，另生成 {manifest['synthetic_count']} 条，"
        f"分为 {len(family)} 个 family、"
        f"覆盖 {len(manifest['category_counts_synthetic'])} 个内容 category；"
        f"长度 {min(lengths)}–{max(lengths)} 字符。"
        "这些查询来自冻结物品及确定性变换，不是真实用户流量、人工标注或检索质量评测。",
        table(["合成 family", "条数"], sorted(family.items())),
        f"fixture SHA-256：`{manifest['queries_sha256']}`。生成器 seed：`{manifest['seed']}`。"
        "实际每轮使用字节均单独保存并校验；fixture CSV/manifest 只随原始证据 ZIP 发布，"
        "不替换或提交原 queries/labels、私有 `.env`、原始数据和模型。",
        "## 持续请求与正确性",
        "三档顺序运行，各用独立 Compose 项目、全新 PostgreSQL 卷和 API 进程；四模式混合轮转，"
        "limit=10、总超时 10 秒、顺序预热 16 次、闭环无重试。以下吞吐分母为实际测量时长（含排空），"
        "延迟为成功请求的 nearest-rank 分位数；所有已发请求保留在成功/失败/未知分母中。",
    ]
    request_rows, repeat_rows, health_rows, timing_rows = [], [], [], []
    for case in cases:
        label, a, acceptance = case["case"], case["a"], case["accept"]
        run, h = case["b"]["runs"][0], case["h"]
        summary = run["summary"]
        measured, warmup = a["phases"]["measured"], a["phases"]["warmup"]
        request_rows.append(
            [
                label,
                acceptance["duration_seconds"],
                f"{measured['success']}/{measured['issued']}",
                f"{warmup['success']}/{warmup['issued']}",
                a["inflight"]["peak"],
                num(summary["elapsed_seconds"], 6),
                num(summary["successful_requests_per_second"], 6),
                num(summary["success_latency"]["p95_ms"]),
                num(summary["success_latency"]["p99_ms"]),
            ]
        )
        repeat_rows.append(
            [
                label,
                a["coverage"]["expected_group_count"],
                a["coverage"]["observed_group_count"],
                a["coverage"]["min_repeats"],
                repeat_text(acceptance["group_repeat_histogram"]),
            ]
        )
        health = case["independent"]["load_health"]
        health_rows.append(
            [
                label,
                f"{health['live_success']}/{health['samples']}",
                f"{health['ready_success']}/{health['samples']}",
                acceptance["inside_load_samples"],
                acceptance["outside_load_samples"],
                f"{num(health['first_seconds'], 6)}→{num(health['last_seconds'], 6)}",
                num(health["max_gap_seconds"], 6),
            ]
        )
        timing_rows.append(
            [label, run["started_at"], run["finished_at"], num(run["drain_seconds"], 6)]
        )
        require(
            measured["failed"] == measured["unknown"] == measured["empty_successes"] == 0,
            "Nonzero request failure/unknown/empty success",
        )
        require(a["inflight"]["pending_events_at_end"] == 0, "Pending requests remain")
        require(len(h["requests"]) == 17, "Business request count differs")
    sections += [
        table(
            [
                "case",
                "调度秒",
                "正式成功/发出",
                "预热",
                "实际在途峰值",
                "总分母秒",
                "成功 req/s",
                "p95 ms",
                "p99 ms",
            ],
            request_rows,
        ),
        table(["case", "预期组", "实际组", "至少重复", "实际正式重复分布"], repeat_rows),
        "各档零失败、零未知、零遗留、零空成功；查询文件哈希与轮转顺序一致。每个查询×模式的"
        "结果、排名及模型三元组在轮内稳定，且三档全部组跨轮一致。实际在途峰值来自客户端"
        "pending/result 顺序，不代表服务端实际同时执行线程数，也不证明超时后服务端已取消计算。",
        f"跨档语义 SHA-256：`{next(iter(semantics))}`。",
        table(["case", "正式开始 UTC", "排空结束 UTC", "排空秒"], timing_rows),
        "## 健康、业务与来源",
        table(
            [
                "case",
                "load live",
                "load ready",
                "正式窗内点",
                "窗外 load 点",
                "load 首末相对秒",
                "最大间隔秒",
            ],
            health_rows,
        ),
        "正式窗使用 `[0,duration)`；phase=load 可能覆盖启动和排空边界，因此逐项披露实际计数，"
        "不强填每小时 360 次。全部 load ready 组件为真，数据源可用、PID1 身份一致，"
        "THP、AnonHugePages、swap 与三项 OOM 计数均为零，无意外重启。启动/计划重启阶段"
        "的不可用记录保留在原始账本，不混入负载成功分母。每档 17 项业务/重启检查通过，"
        "反馈创建、幂等回放与重启后读取为同一记录，最终只新增一条反馈。",
    ]
    source_rows = []
    for case in cases:
        h = case["h"]
        api = next(s for s in h["final_state"] if s["Name"].endswith("-api-1"))
        source_rows.append(
            [
                case["case"],
                len(h["container_source_sha256"]),
                len(h["imported_source"]["sha256"]),
                api["native_env"]["SEARCHPILOT_DISABLE_THP"],
                api["native_env"]["MALLOC_ARENA_MAX"],
                api["State"].get("Health", {}).get("Status", "不可用"),
            ]
        )
    sections += [
        table(
            [
                "case",
                "容器源码数",
                "安装源码数",
                "THP disable",
                "arena max",
                "末快照 Docker Health",
            ],
            source_rows,
        ),
        "HTTP restart_ready 与反馈持久性用于重启业务验收；末快照 Docker Health 单独披露。"
        "正常入口为 `python scripts/docker_entrypoint.py`；白名单环境在多个容器状态快照中直接记录，"
        "其他 native override 未设置。无诊断 wrapper、tracing、定时 GC 或 malloc_trim。",
        f"镜像：`{build['tag']}`，ID：`{build['image']}`。"
        f"冻结输入 {build['frozen_input_count']} 个、"
        f"源码 {build['source_count']} 个，容器及安装源码均核对；依赖与模型未重建。",
        "## 内存",
        "PID RSS 的全 phase-load、严格正式窗、严格末十/二十分钟及恢复期如下。"
        "各端点差仅覆盖实际采到的时间跨度，不等同完整窗口首尾瞬时值；短档不存在完整末二十分钟。",
    ]
    memory_rows, five_rows = [], []
    labels = {
        "phase_load": "全部 phase-load",
        "strict_dispatch": "严格正式窗",
        "last_ten": "严格末十分钟",
        "last_twenty": "严格末二十分钟",
        "recovery": "恢复期",
    }
    for case in cases:
        for key, label in labels.items():
            win = case["accept"]["memory"][key]
            if not win.get("available"):
                memory_rows.append([case["case"], label, "不适用", "—", "—", "—", "—"])
                continue
            memory_rows.append(
                [
                    case["case"],
                    label,
                    win["count"],
                    num(win["span_seconds"]),
                    f"{num(win['first_rss_mib'])}→{num(win['last_rss_mib'])}",
                    num(win["growth_mib"], 6, True),
                    num(win["ols_mib_per_minute"], 6, True),
                ]
            )
        for win in case["accept"]["windows"]:
            require(win.get("available"), "Unavailable five-minute memory window")
            left = win["start_seconds"] / 60
            five_rows.append(
                [
                    case["case"],
                    f"[{left:g},{left + 5:g})",
                    win["count"],
                    num(win["median_rss_mib"]),
                    num(win["growth_mib"], 6, True),
                    num(win["ols_mib_per_minute"], 6, True),
                ]
            )
    sections += [
        table(
            ["case", "范围", "点数", "跨度秒", "RSS首→末 MiB", "差 MiB", "OLS MiB/min"], memory_rows
        ),
        "c16 的严格末十分钟仍增长 "
        f"**{num(cases[1]['accept']['memory']['last_ten']['growth_mib'], 6)} MiB**；"
        "两个 900 秒短档是功能、覆盖及资源筛查，不据此宣称内存收敛。",
        f"c32 小时预设门槛保持 OLS ≤0.1 MiB/min、增长 ≤2 MiB；严格 `[2400,3600)` 至少 118 点、"
        f"跨度≥1180秒、间隔≤15秒。实际 {observed['count']} 点、"
        f"跨度 {num(observed['span_seconds'], 6)} 秒、"
        f"最大间隔 {num(observed['max_gap_seconds'], 6)} 秒，同进程完整数据，原门槛通过。",
        "全部五分钟闭开窗口：",
        table(["case", "分钟窗", "点数", "RSS中位 MiB", "差 MiB", "OLS MiB/min"], five_rows),
    ]
    scope_rows = []
    metrics = {
        "pid_pss_bytes": "PID PSS",
        "pid_anonymous_bytes": "PID anonymous",
        "pid_vmdata_bytes": "PID VmData",
        "cgroup_current_bytes": "cgroup current",
        "client_rss_bytes": "客户端 RSS",
    }
    for case in cases:
        samples = [
            s
            for s in case["resource"]["samples"]
            if s["phase"] == "load"
            and 0 <= s["elapsed_seconds"] < case["accept"]["duration_seconds"]
        ]
        for key, label in metrics.items():
            values = [s["metrics"].get(key) for s in samples if s["metrics"].get(key) is not None]
            require(values, "Missing descriptive metric: " + key)
            scope_rows.append(
                [
                    case["case"],
                    label,
                    f"{len(values)}/{len(samples)}",
                    f"{num(values[0] / 1048576)}→{num(values[-1] / 1048576)}",
                    num(max(values) / 1048576),
                ]
            )
    sections += [
        table(
            ["case", "独立范围（严格正式窗）", "有效点", "首→末 MiB", "采样最大 MiB"], scope_rows
        ),
        "PID RSS/PSS、匿名页、VmData、cgroup 和客户端内存不相加，也不互相替代；VmData 是虚拟"
        "数据区大小。十秒离散采样最大值不是连续真实峰值。完整指标、缺失值及来源见原始 JSON。",
        f"![三档内存与资源曲线]({PREFIX}-memory.png)",
        "## 背景负载与解释边界",
    ]
    background_rows = []
    for case in cases:
        for key, label in (("strict_dispatch", "严格正式窗"), ("whole_capture", "完整捕获")):
            bg = case["independent"]["background"][key]
            background_rows.append(
                [
                    case["case"],
                    label,
                    bg["polls"],
                    bg["polls_with_identified_others"],
                    bg["distinct_other_ids"],
                    bg["max_identified_others_in_one_poll"],
                    bg["polls"] - bg["available_polls"],
                    bg["unresolved_records"],
                    bg["linux_loadavg_missing_polls"],
                ]
            )
    sections += [
        table(
            [
                "case",
                "范围",
                "polls",
                "有其他容器",
                "累计其他ID",
                "单次最多其他容器",
                "stats缺失轮",
                "无身份记录",
                "loadavg缺失轮",
            ],
            background_rows,
        ),
        "累计 ID 不等于同时运行数；单次最多值也仅限采样时刻。c16 正式窗未采到其他容器"
        "不证明宿主无争用；这里只采 Docker stats 与容器内 `/proc/loadavg`，未完整监测 Windows"
        "宿主 CPU。不同档的背景负载、请求量及排队成本不同，不将吞吐差异称为因果加速，"
        "不据此给出容量 SLA、真实流量代表性、检索相关性或无限运行无泄漏结论。",
        "## 本地检查与复现",
        f"保存的本地记录：单元 **{unit[1]} passed、{unit[2]} skipped、{unit[3]} deselected、"
        f"{unit[4]} subtests passed**；真实 PostgreSQL 集成 **{integration[1]} passed**。"
        f"Ruff、{fmt[1]} 文件格式检查与 {mypy[1]} 源文件 Mypy 通过。"
        "跳过和未选测试不计为通过；日志包含既有弃用警告。CI/合并状态由对应 PR 核实。",
        "本轮 `external_llm_calls=0`；[历史外部 LLM 验证](agent-llm-live-2026-10-14.md)"
        "的 100 次调用属于独立历史记录，不覆盖为本轮调用，也不被本轮零调用抹除。",
        "从仓库根目录执行以下参数；先解压原始 ZIP 到独立目录，重跑更换项目、端口与输出目录。"
        "保持模型、数据与查询字节一致，顺序完成短档后再运行小时档：",
        "```powershell\n"
        ".venv/Scripts/python.exe -m scripts.build_load_queries "
        "--data-version d3a904f41240 --out artifacts/expanded-repro/fixture\n"
        ".venv/Scripts/python.exe -m scripts.validate_container_soak "
        "--out artifacts/expanded-repro/c32 --project sp-expanded-repro-c32 --image "
        + build["tag"]
        + " --api-port 18133 --db-port 15533 --duration-seconds 3600 --concurrency 32 "
        "--baseline-seconds 60 --recovery-seconds 120 "
        "--queries artifacts/expanded-repro/fixture/queries.csv\n"
        ".venv/Scripts/python.exe -m scripts.summarize_soak "
        "--bench artifacts/expanded-repro/c32/soak.json "
        "--ledger artifacts/expanded-repro/c32/soak.requests.jsonl "
        "--samples artifacts/expanded-repro/c32/samples.jsonl "
        "--queries artifacts/expanded-repro/c32/queries.csv --min-repeats 3 "
        "--duration-seconds 3600 --out artifacts/expanded-repro/c32/analysis.json\n"
        "```",
        "以上是核心执行参数；十秒背景观察、独立资源/内存门槛验收、清理和绘图仍按 ZIP 中的"
        " `run_case.py`、`audit_case.py`、`cleanup_owned.py`、`render_evidence.py` 执行，"
        "不能用核心命令的退出码替代全部验收。",
        "## 可核查证据",
        f"- [机器可读摘要]({PREFIX}-summary.json)：与 `aggregate.json` 原字节一致。\n"
        f"- [原始证据 ZIP]({PREFIX}-raw.zip)：{archive['files']} 个证据文件，"
        f"{archive['zip_members']} 个 ZIP 成员（含 SHA 清单），{archive['bytes']:,} 字节；"
        "CRC 与全部成员 SHA-256 回读通过。\n"
        f"- ZIP SHA-256：`{archive['sha256']}`。",
        "凭据模式/结构化扫描范围以归档核验记录为准，不将模式扫描等同任意未知私密值检查。"
        "私有 `.env` 不归档；公开配置副本仅保存为 `public-env.txt`。",
    ]
    return "\n\n".join(sections) + "\n"


def main():
    targets = [DEST / (PREFIX + suffix) for suffix in (".md", "-summary.json", "-memory.png")]
    require(not any(p.exists() for p in targets), "Refuse existing publication output")
    for name in ("aggregate.json", "independent-final-audit.json", "final-integrity.json"):
        passed(name)
    archive = read("archive-verification.json")
    require(
        archive.get("status") == "VERIFIED"
        and archive.get("crc_verified") is True
        and archive.get("every_member_hash_verified") is True,
        "Archive verification incomplete",
    )
    path = REPO / archive["path"]
    require(path.resolve() == (DEST / (PREFIX + "-raw.zip")).resolve(), "Unexpected archive path")
    require(
        path.stat().st_size == archive["bytes"]
        and hashlib.sha256(path.read_bytes()).hexdigest() == archive["sha256"],
        "Archive changed",
    )
    cases = [case_data(case) for case in CASES]
    report = render(cases, archive).encode("utf-8")
    image = raw("memory-matrix.png")
    require(image.startswith(b"\x89PNG\r\n\x1a\n"), "Matrix is not PNG")
    with zipfile.ZipFile(path) as zipped:
        manifest = json.loads(zipped.read("SHA256SUMS.json"))
        require(
            len(manifest) == archive["files"] and len(zipped.namelist()) == archive["zip_members"],
            "Archive count mismatch",
        )
        for name, data in USED.items():
            if name == "archive-verification.json":
                continue  # Generated after archive closure; archive identity already checked above.
            require(
                name in manifest
                and hashlib.sha256(data).hexdigest() == manifest[name]["sha256"]
                and len(data) == manifest[name]["bytes"],
                "Report evidence differs from archive: " + name,
            )
    for name, data in USED.items():
        require(
            (ROOT / name).read_bytes() == data, "Report evidence changed while rendering: " + name
        )
    for target, data in zip(targets, (report, raw("aggregate.json"), image), strict=True):
        with target.open("xb") as sink:
            sink.write(data)
        require(target.read_bytes() == data, "Publication readback mismatch")
    print(
        json.dumps(
            {
                "status": "WRITTEN",
                "outputs": [str(p) for p in targets],
                "summary_and_image_exact_copies": True,
                "archive_sha256": archive["sha256"],
            }
        )
    )


if __name__ == "__main__":
    main()
