"""Incremental read-only service evidence monitor; cache is not acceptance evidence."""
import argparse
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('case')
args = parser.parse_args()
folder = root / args.case
cache = root / ('monitor-' + args.case + '.json')
state = json.loads(cache.read_text()) if cache.exists() else {'offset': 0, 'counts': {}, 'active': 0}
ledger = folder / 'soak.requests.jsonl'
counts = Counter(state['counts'])
if ledger.exists():
    with ledger.open('rb') as source:
        source.seek(state['offset'])
        while True:
            position = source.tell()
            line = source.readline()
            if not line or not line.endswith(b'\n'):
                state['offset'] = position
                break
            event = json.loads(line)
            if event['event'] == 'pending':
                state['active'] += 1
            else:
                state['active'] -= 1
                counts[event['phase']+':'+event['outcome']] += 1
    state['counts'] = dict(counts)
    cache.write_text(json.dumps(state))
samples = folder / 'samples.jsonl'
rows = []
if samples.exists():
    for line in samples.read_bytes().splitlines(keepends=True):
        if line.endswith(b'\n'):
            rows.append(json.loads(line))
result = {'case': args.case, 'counts': dict(counts), 'active': state['active']}
if rows:
    last = rows[-1]
    data = last.get('server', {}).get('sources', {})
    smaps = data.get('smaps_rollup', {}).get('data', {})
    load = [row for row in rows if row['phase'] == 'load']
    result.update(at=last['at'], phase=last['phase'],
                  rss_mib=round(smaps['Rss_bytes']/1048576, 3) if 'Rss_bytes' in smaps else None,
                  thp_bytes=smaps.get('AnonHugePages_bytes'),
                  live=last.get('live', {}).get('status'), ready=last.get('ready', {}).get('status'))
    if load:
        result['load_sample_minutes'] = round((datetime.fromisoformat(last['at'])-
                                      datetime.fromisoformat(load[0]['at'])).total_seconds()/60, 2)
        result['load_health'] = {kind: dict(Counter(str(r.get(kind, {}).get('status')) for r in load))
                                 for kind in ('live', 'ready')}
summary = folder/'summary.json'
if summary.exists():
    result['harness_status'] = json.loads(summary.read_text())['status']
print(json.dumps(result))
