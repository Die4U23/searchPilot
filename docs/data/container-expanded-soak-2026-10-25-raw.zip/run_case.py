"""Run exactly one declared case and observe background load without extra API traffic."""
import argparse
import json
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from scripts.validate_container_soak import clean_environment

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DOCKER = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
CASES = {'expanded-c4': (4, 900, 30, 60, 18104, 15504),
         'expanded-c16': (16, 900, 30, 60, 18116, 15516),
         'expanded-c32-hour': (32, 3600, 60, 120, 18132, 15532)}


def now():
    return datetime.now(timezone.utc).isoformat()


def observe(out, project, stop, env):
    while not out.exists() and not stop.wait(.2):
        pass
    if not out.exists():
        return
    with (out / 'background.jsonl').open('x', encoding='utf-8') as sink:
        while not stop.is_set():
            began = time.monotonic()
            row = {'at': now()}
            for label, command in (
                    ('containers', [DOCKER, 'stats', '--no-stream', '--format', '{{json .}}']),
                    ('linux_loadavg', [DOCKER, 'exec', project+'-api-1', 'cat', '/proc/loadavg'])):
                try:
                    result = subprocess.run(command, capture_output=True, text=True,
                                            encoding='utf-8', env=env, timeout=8, check=True)
                    data = ([json.loads(line) for line in result.stdout.splitlines()]
                            if label == 'containers' else result.stdout.strip())
                    row[label] = {'available': True, 'data': data}
                except Exception as exc:
                    row[label] = {'available': False, 'error_type': type(exc).__name__}
            sink.write(json.dumps(row) + '\n')
            sink.flush()
            stop.wait(max(.01, 10-(time.monotonic()-began)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', choices=CASES)
    args = parser.parse_args()
    case = args.case
    out = ROOT / case
    record_path = ROOT / (case + '-launcher.json')
    log_path = ROOT / (case + '-console.txt')
    if any(path.exists() for path in (out, record_path, log_path)):
        raise FileExistsError('Refuse to overwrite case evidence')
    concurrency, duration, baseline, recovery, api_port, db_port = CASES[case]
    project = 'sp-' + case + '-20261025'
    build = json.loads((ROOT / 'build-summary.json').read_text())
    env = clean_environment()
    env['PYTHONPATH'] = str(REPO)
    command = [sys.executable, '-m', 'scripts.validate_container_soak', '--out', str(out),
               '--project', project, '--image', build['tag'], '--api-port', str(api_port),
               '--db-port', str(db_port), '--duration-seconds', str(duration),
               '--concurrency', str(concurrency), '--baseline-seconds', str(baseline),
               '--recovery-seconds', str(recovery), '--queries', str(ROOT/'fixture/queries.csv')]
    record = {'case': case, 'started_at': now(), 'command': command, 'status': 'RUNNING',
              'observation': 'Docker stats of all running containers and API /proc/loadavg; no API calls'}
    with record_path.open('x', encoding='utf-8') as sink:
        json.dump(record, sink, indent=2)
    stop = threading.Event()
    observer = threading.Thread(target=observe, args=(out, project, stop, env), daemon=True)
    observer.start()
    try:
        with log_path.open('x', encoding='utf-8') as log:
            result = subprocess.run(command, cwd=REPO, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, check=False)
        record.update(status='COMPLETED' if result.returncode == 0 else 'FAILED',
                      exit_code=result.returncode)
    finally:
        stop.set()
        observer.join(timeout=20)
        record['finished_at'] = now()
        record['observer_stopped'] = not observer.is_alive()
        record_path.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(record))
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
