"""Offline, explicit evidence archive; --check performs read-only preflight only.

Never reads private .env, invokes a service, or overwrites existing publication files.
Pattern/structured credential checks are not an exact private-secret-value scan.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DESTINATION = REPO / "docs/data/container-expanded-soak-2026-10-25-raw.zip"
RECORD = ROOT / "archive-verification.json"
SHA_MANIFEST = ROOT / "archive-sha256.json"
CASES = {
    "expanded-c4": (4, 900, 1),
    "expanded-c16": (16, 900, 1),
    "expanded-c32-hour": (32, 3600, 3),
}
ROOT_REQUIRED = {
    "acceptance-plan.md",
    "build-summary.json",
    "build.txt",
    "inputs-sha256.json",
    "sources-sha256.json",
    "build_candidate.py",
    "run_case.py",
    "audit_case.py",
    "cleanup_owned.py",
    "finalize_evidence.py",
    "plot_matrix.py",
    "memory-matrix.png",
    "memory-matrix-metadata.json",
    "progress.py",
    "render_evidence.py",
    "package_evidence.py",
    "write_report.py",
    "audit-reference-check.json",
    "audit-helper-review.json",
    "unit-final.txt",
    "quality-final.txt",
    "aggregate.json",
    "independent-final-audit.json",
    "final-integrity.json",
}
ROOT_OPTIONAL = {
    "packaging-notes.txt",
    "report-draft.md",
    "integration-final.txt",
    "targeted-tests.txt",
    "quality-checks.json",
    "local-checks.json",
    "independent-final-review.md",
    "simplify-review.md",
    "efficiency-review.md",
    "reuse-review.md",
    "altitude-review.md",
    "cleanup-all.json",
    "cleanup.json",
}
CASE_REQUIRED = {
    "summary.json",
    "soak.json",
    "soak.requests.jsonl",
    "queries.csv",
    "soak.queries.csv",
    "samples.jsonl",
    "background.jsonl",
    "analysis.json",
    "acceptance.json",
    "independent-audit.json",
    "descriptive-resources.json",
    "resources.png",
    "compose.override.yml",
    "soak-console.txt",
    "benchmark.pid",
    "benchmark.start",
}
CASE_OPTIONAL = {"cleanup.json", "independent-review.md"}
FIXTURE_REQUIRED = {
    "queries.csv",
    "manifest.json",
    "generation-verification.json",
    "checks.json",
    "targeted-tests.txt",
    "ruff-check.txt",
    "ruff-format-check.txt",
}
CONFIG_REQUIRED = {"Dockerfile", "docker-compose.yml", "pyproject.toml", "public-env.txt"}
# If a future run fails, explicitly add its directory and exact member names here.
# Failure evidence is preserved, never substituted for a required successful case.
PRESERVED_FAILURES: dict[str, set[str]] = {}
TOKEN_PATTERNS = (
    rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b",
    rb"\bgh[pousr]_[A-Za-z0-9]{20,}\b",
    rb"\bgithub_pat_[A-Za-z0-9_]{30,}\b",
    rb"\bAKIA[A-Z0-9]{16}\b",
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    rb"(?i)\bBearer\s+[A-Za-z0-9._~-]{16,}",
)
SECRET_KEY = re.compile(r"(?:^|_)(?:API_KEY|ACCESS_TOKEN|AUTH_TOKEN|SECRET|PASSWORD)$", re.I)
SAFE_VALUES = {"", "searchpilot", "NOT_SET", "UNKNOWN", "REDACTED", "<redacted>"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(base, name):
    relative = Path(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe evidence path")
    path = base / relative
    require(path.resolve().is_relative_to(base.resolve()), "Out-of-root evidence path")
    for component in (path, *path.parents):
        if component == base.parent:
            break
        require(not component.is_symlink() and not component.is_junction(), "Linked evidence path")
    return path


def read_json(name):
    return json.loads(safe_path(ROOT, name).read_text(encoding="utf-8-sig"))


def check_gate(name):
    value = read_json(name)
    require(
        value.get("status") == "PASSED" or value.get("passed") is True,
        "Required final gate is not PASSED: " + name,
    )
    require(
        value.get("status") not in {"FAILED", "RUNNING", "INTERRUPTED"},
        "Conflicting final gate status: " + name,
    )


def credential_scan(name, data):
    """Raise with member name only, never print matching values or complete lines."""
    for pattern in TOKEN_PATTERNS:
        require(re.search(pattern, data) is None, "Credential pattern found: " + name)
    if name.endswith(".png"):
        return
    text = data.decode("utf-8-sig", errors="replace")
    # Inspect URL userinfo in logs, JSON, configuration and source text.
    for match in re.finditer(r"[a-zA-Z][a-zA-Z0-9+.-]*://[^\s\"'<>]+", text):
        try:
            parsed = urlsplit(match.group())
            password = unquote(parsed.password or "")
        except ValueError:
            continue
        public_db = (
            parsed.scheme in {"postgres", "postgresql"}
            and parsed.username == "searchpilot"
            and password == "searchpilot"
            and parsed.hostname in {"127.0.0.1", "localhost", "db"}
        )
        require(
            not password or public_db or "{" in password or "$" in password,
            "Unexpected URL credential found: " + name,
        )

    def inspect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if SECRET_KEY.search(key) and isinstance(item, str):
                    require(
                        item in SAFE_VALUES or item.startswith("${"),
                        "Credential field found: " + name,
                    )
                inspect(item)
        elif isinstance(value, list):
            for item in value:
                inspect(item)

    if name.endswith(".json"):
        inspect(json.loads(text))
    elif name.endswith(".jsonl"):
        for line in text.splitlines():
            if line.strip():
                inspect(json.loads(line))
    if name.endswith((".txt", ".yml", "Dockerfile")):
        for line in text.splitlines():
            match = re.fullmatch(r"\s*([A-Z][A-Z0-9_]*)\s*[=:]\s*(.*?)\s*", line)
            if match and SECRET_KEY.search(match[1]):
                value = match[2].strip("\"'")
                require(
                    value in SAFE_VALUES or value.startswith("${"),
                    "Credential assignment found: " + name,
                )


def select_members():
    sources = read_json("sources-sha256.json")
    expected = set(ROOT_REQUIRED)
    expected |= {"fixture/" + name for name in FIXTURE_REQUIRED}
    expected |= {"source-config/" + name for name in CONFIG_REQUIRED}
    expected.add("image-context/Dockerfile")
    expected |= {
        "image-context/" + name
        for name in sources
        if re.fullmatch(r"scripts/[A-Za-z0-9_]+\.py", name)
    }
    optional = set(ROOT_OPTIONAL)
    for case in CASES:
        expected |= {case + "/" + name for name in CASE_REQUIRED}
        expected |= {case + suffix for suffix in ("-launcher.json", "-console.txt")}
        project = "sp-" + case + "-20261025"
        expected |= {f"{case}/{project}-{service}-1.log" for service in ("api", "db")}
        optional |= {case + "/" + name for name in CASE_OPTIONAL}
        optional.add(case + "-cleanup.json")
        optional.add("cleanup-" + case + ".json")
    for case, names in PRESERVED_FAILURES.items():
        require(
            case not in CASES and "summary.json" in names, "Invalid preserved failure allowlist"
        )
        expected |= {case + "/" + name for name in names}
        require(
            read_json(case + "/summary.json").get("status") in {"FAILED", "INTERRUPTED"},
            "Preserved failure status is not terminal: " + case,
        )
    found = set()
    excluded = []
    for path in sorted(ROOT.rglob("*")):
        name = path.relative_to(ROOT).as_posix()
        safe_path(ROOT, name)
        if not path.is_file():
            continue
        if name in expected or name in optional:
            require(not path.name.startswith(".env"), "Private environment filename rejected")
            found.add(name)
        else:
            excluded.append(name)
            if path.name == "summary.json" and len(path.relative_to(ROOT).parts) == 2:
                require(
                    read_json(name).get("status") not in {"FAILED", "INTERRUPTED"},
                    "Unlisted failed run requires explicit preservation: " + name,
                )
    missing = sorted(expected - found)
    require(not missing, "Required evidence missing: " + ", ".join(missing))
    return sorted(found), excluded


def validate_runs():
    build = read_json("build-summary.json")
    query_sha = digest(safe_path(ROOT, "fixture/queries.csv").read_bytes())
    require(query_sha == build["query_sha256"], "Fixture hash differs from build")
    for manifest in ("inputs-sha256.json", "sources-sha256.json"):
        for name, expected in read_json(manifest).items():
            require(
                not Path(name).name.startswith(".env") or Path(name).name == ".env.example",
                "Private env in frozen manifest",
            )
            require(
                digest(safe_path(REPO, name).read_bytes()) == expected,
                "Frozen input/source changed: " + name,
            )
    for name, expected in read_json("sources-sha256.json").items():
        if re.fullmatch(r"scripts/[A-Za-z0-9_]+\.py", name):
            require(
                digest(safe_path(ROOT, "image-context/" + name).read_bytes()) == expected,
                "Executed script copy mismatch: " + name,
            )
    public = {
        "Dockerfile": "Dockerfile",
        "docker-compose.yml": "docker-compose.yml",
        "pyproject.toml": "pyproject.toml",
        "public-env.txt": ".env.example",
    }
    for saved, source in public.items():
        require(
            safe_path(ROOT, "source-config/" + saved).read_bytes()
            == safe_path(REPO, source).read_bytes(),
            "Public configuration changed: " + saved,
        )
    statuses = {}
    semantics = set()
    for case, (concurrency, duration, repeats) in CASES.items():
        launcher = read_json(case + "-launcher.json")
        harness, bench, analysis, acceptance = [
            read_json(case + "/" + name)
            for name in ("summary.json", "soak.json", "analysis.json", "acceptance.json")
        ]
        require(
            launcher.get("status") == "COMPLETED"
            and launcher.get("exit_code") == 0
            and launcher.get("observer_stopped") is True,
            "Incomplete launcher: " + case,
        )
        require(
            harness.get("status") == bench.get("status") == "COMPLETED",
            "Incomplete harness/benchmark: " + case,
        )
        require(harness.get("image") == build["image"], "Case image mismatch: " + case)
        require(
            analysis.get("status") == acceptance.get("status") == "PASSED",
            "Case ledger/resource acceptance not PASSED: " + case,
        )
        require(
            acceptance.get("checks") and all(v is True for v in acceptance["checks"].values()),
            "Case acceptance has non-passing checks: " + case,
        )
        for record in (harness, bench):
            require(
                record["config"].get("concurrency") == concurrency
                and record["config"].get("duration_seconds") == duration,
                "Case configuration mismatch: " + case,
            )
            require(
                record["queries"].get("sha256") == query_sha
                and record["queries"].get("count") == 1300,
                "Case query provenance mismatch: " + case,
            )
        for name in ("queries.csv", "soak.queries.csv"):
            require(
                digest(safe_path(ROOT, case + "/" + name).read_bytes()) == query_sha,
                "Case query bytes differ: " + case,
            )
        coverage, inflight = analysis["coverage"], analysis["inflight"]
        require(
            coverage.get("verified") is True
            and coverage.get("expected_group_count") == 5200
            and coverage.get("sha256") == query_sha
            and coverage.get("min_repeats") == repeats
            and len(coverage.get("groups", [])) == 5200
            and all(
                type(g.get("successful")) is int and g["successful"] >= repeats
                for g in coverage["groups"]
            ),
            "Incomplete workload coverage: " + case,
        )
        require(
            inflight.get("peak") == concurrency and inflight.get("pending_events_at_end") == 0,
            "Invalid concurrency evidence: " + case,
        )
        require(analysis.get("issues") == [], "Strict audit contains issues: " + case)
        groups = analysis["fingerprints"]["groups"]
        require(
            len(groups) == 5200 and all(g.get("stable") is True for g in groups),
            "Incomplete stable fingerprints: " + case,
        )
        semantic = [
            {
                k: group[k]
                for k in ("query", "mode", "result_sha256", "ranking_sha256", "model_versions")
            }
            for group in groups
        ]
        computed = digest(json.dumps(semantic, sort_keys=True).encode())
        require(
            computed == acceptance.get("semantic_sha256"),
            "Acceptance fingerprint hash mismatch: " + case,
        )
        semantics.add(computed)
        expected_gate = "PASSED" if duration == 3600 else "NOT_APPLICABLE_SHORT_SCREEN"
        require(
            acceptance["memory_gate"]["status"] == expected_gate, "Memory gate mismatch: " + case
        )
        require(
            bool(read_json(case + "/descriptive-resources.json")),
            "Empty descriptive resources: " + case,
        )
        statuses[case] = {
            "harness": harness["status"],
            "benchmark": bench["status"],
            "ledger": analysis["status"],
            "acceptance": acceptance["status"],
            "memory_gate": expected_gate,
            "semantic_sha256": computed,
        }
    require(len(semantics) == 1, "Cross-case semantic fingerprints differ")
    for name in ("independent-final-audit.json", "final-integrity.json"):
        check_gate(name)
    require(bool(read_json("aggregate.json")), "Missing aggregate summary")
    return statuses


def preflight():
    names, excluded = select_members()
    statuses = validate_runs()
    manifest = {}
    for name in names:
        data = safe_path(ROOT, name).read_bytes()
        credential_scan(name, data)
        manifest[name] = {"bytes": len(data), "sha256": digest(data)}
    return names, excluded, statuses, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check", action="store_true", help="Read-only complete-evidence preflight; writes nothing"
    )
    args = parser.parse_args()
    for path in (DESTINATION, RECORD, SHA_MANIFEST):
        require(not path.exists(), "Refuse to overwrite existing publication output: " + path.name)
    names, excluded, statuses, manifest = preflight()
    if args.check:
        print(
            json.dumps(
                {
                    "status": "PREFLIGHT_PASSED",
                    "files": len(names),
                    "cases": statuses,
                    "excluded_files": excluded,
                    "credential_scan": "patterns_and_structured_fields_only",
                }
            )
        )
        return
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    with zipfile.ZipFile(
        DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for name in names:
            data = safe_path(ROOT, name).read_bytes()
            require(
                len(data) == manifest[name]["bytes"] and digest(data) == manifest[name]["sha256"],
                "Evidence changed during archive write: " + name,
            )
            archive.writestr(name, data)
        archive.writestr("SHA256SUMS.json", manifest_bytes)
    with zipfile.ZipFile(DESTINATION) as archive:
        require(archive.testzip() is None, "Archive CRC verification failed")
        require(
            len(archive.namelist()) == len(names) + 1
            and set(archive.namelist()) == set(names) | {"SHA256SUMS.json"},
            "Archive membership mismatch",
        )
        require(archive.read("SHA256SUMS.json") == manifest_bytes, "Manifest readback mismatch")
        for name in names:
            data = archive.read(name)
            require(
                len(data) == manifest[name]["bytes"] and digest(data) == manifest[name]["sha256"],
                "Archive member hash mismatch: " + name,
            )
            credential_scan(name, data)
            require(
                digest(safe_path(ROOT, name).read_bytes()) == manifest[name]["sha256"],
                "Evidence changed before readback completed: " + name,
            )
    validate_runs()
    with SHA_MANIFEST.open("xb") as sink:
        sink.write(manifest_bytes)
    record = {
        "status": "VERIFIED",
        "path": DESTINATION.relative_to(REPO).as_posix(),
        "files": len(names),
        "zip_members": len(names) + 1,
        "bytes": DESTINATION.stat().st_size,
        "sha256": digest(DESTINATION.read_bytes()),
        "crc_verified": True,
        "every_member_hash_verified": True,
        "cases": statuses,
        "excluded_files": excluded,
        "credential_pattern_matches": 0,
        "private_env_read": False,
        "credential_scan_scope": (
            "patterns, URL userinfo, structured secret fields; not exact private values"
        ),
    }
    with RECORD.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
        sink.write("\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
