"""Freeze the experiment sources and build only the script layer over the verified image."""
import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from scripts.validate_container_soak import clean_environment

root = Path(__file__).resolve().parent
repo = root.parents[1]
docker = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
base = 'searchpilot-validation:2026-10-25-arena2'
expected = 'sha256:a97dc62115f0b617d962423739a45f71dfc7a93ec05c4e055575fe7d65a710d1'
tag = 'searchpilot-validation:2026-10-25-expanded'
env = clean_environment()

def command(args):
    return subprocess.run([docker, *args], cwd=repo, env=env, capture_output=True,
                          text=True, encoding='utf-8', check=True, timeout=180).stdout

assert json.loads(command(['image', 'inspect', base]))[0]['Id'] == expected
fixture = root/'fixture/queries.csv'
assert fixture.is_file() and (root/'fixture/manifest.json').is_file()
old_inputs = json.loads((repo/'artifacts/allocator-2026-10-25/inputs-sha256.json').read_text())
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest() == digest
           for name, digest in old_inputs.items())
inputs = dict(old_inputs)
for name in ('data/processed/d3a904f41240/items.parquet',
             'data/processed/d3a904f41240/user_history.parquet',
             'data/processed/d3a904f41240/manifest.json'):
    inputs[name] = hashlib.sha256((repo/name).read_bytes()).hexdigest()
with (root/'inputs-sha256.json').open('x', encoding='utf-8') as sink:
    json.dump(inputs, sink, indent=2)
context = root/'image-context'
(context/'scripts').mkdir(parents=True, exist_ok=False)
for path in (repo/'scripts').glob('*.py'):
    shutil.copyfile(path, context/'scripts'/path.name)
(context/'Dockerfile').write_text(f'FROM {base}\nCOPY scripts /app/scripts\n', encoding='utf-8')
saved = root/'source-config'
saved.mkdir()
for source, target in (('Dockerfile', 'Dockerfile'), ('docker-compose.yml', 'docker-compose.yml'),
                       ('.env.example', 'public-env.txt'), ('pyproject.toml', 'pyproject.toml')):
    shutil.copyfile(repo/source, saved/target)
sources = {p.relative_to(repo).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
           for pattern in ('src/**/*.py', 'scripts/*.py', 'tests/*.py') for p in sorted(repo.glob(pattern))}
with (root/'sources-sha256.json').open('x', encoding='utf-8') as sink:
    json.dump(sources, sink, indent=2)
result = subprocess.run([docker, 'build', '--pull=false', '-t', tag, str(context)],
                        cwd=repo, env=env, capture_output=True, text=True, encoding='utf-8', timeout=180)
(root/'build.txt').write_text(result.stdout+result.stderr, encoding='utf-8')
result.check_returncode()
actual = json.loads(command(['image', 'inspect', tag]))[0]
settings = dict(item.split('=', 1) for item in actual['Config']['Env'] if '=' in item)
assert settings['MALLOC_ARENA_MAX'] == '2' and settings['SEARCHPILOT_DISABLE_THP'] == 'true'
assert actual['Config']['Cmd'] == ['python', 'scripts/docker_entrypoint.py']
record = {'at': datetime.now(timezone.utc).isoformat(), 'tag': tag, 'image': actual['Id'],
          'base_image': expected, 'dependency_or_model_rebuild': False,
          'query_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
          'frozen_input_count': len(inputs), 'source_count': len(sources),
          'native_env': {k: settings[k] for k in ('MALLOC_ARENA_MAX', 'SEARCHPILOT_DISABLE_THP')},
          'cmd': actual['Config']['Cmd']}
with (root/'build-summary.json').open('x', encoding='utf-8') as sink:
    json.dump(record, sink, indent=2)
print(json.dumps(record))
