"""Plot strict measured-load RSS for three completed, accepted expanded cases."""

from __future__ import annotations

import hashlib
import io
import json
import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = (("expanded-c4", 4, 900), ("expanded-c16", 16, 900), ("expanded-c32-hour", 32, 3600))
MIB = 1024**2


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_cases(helper):
    """Read one immutable snapshot; validate completion before selecting any points."""
    snapshots, cases = {}, []
    for case, concurrency, duration in CASES:
        folder = ROOT / case
        if not folder.is_dir():
            raise ValueError(f"Case directory does not exist: {case}")
        names = ("summary.json", "soak.json", "acceptance.json", "samples.jsonl")
        raw = {name: (folder / name).read_bytes() for name in names}
        snapshots.update({folder / name: data for name, data in raw.items()})
        harness, bench, acceptance = (json.loads(raw[name]) for name in names[:3])
        if harness.get("status") != "COMPLETED" or bench.get("status") != "COMPLETED":
            raise ValueError(f"Case is not completed: {case}")
        if acceptance.get("status") != "PASSED" or acceptance.get("case") != case:
            raise ValueError(f"Case lacks matching PASSED acceptance: {case}")
        if len(bench.get("runs", [])) != 1:
            raise ValueError(f"Expected one measured run: {case}")
        run = bench["runs"][0]
        if (
            run.get("dispatch_window_seconds") != duration
            or bench.get("config", {}).get("concurrency") != concurrency
            or acceptance.get("duration_seconds") != duration
            or acceptance.get("concurrency") != concurrency
        ):
            raise ValueError(f"Case duration/concurrency differ from planned matrix: {case}")
        if duration == 3600 and acceptance.get("memory_gate", {}).get("status") != "PASSED":
            raise ValueError("One-hour case has no PASSED memory gate")
        if not raw["samples.jsonl"] or not raw["samples.jsonl"].endswith(b"\n"):
            raise ValueError(f"Incomplete/empty samples: {case}")
        anchor = helper["timestamp"](run["started_at"])
        rows = [json.loads(line) for line in raw["samples.jsonl"].splitlines()]
        flattened = helper["flatten_samples"](rows, anchor)
        load = [
            row
            for row in flattened
            if row["phase"] == "load" and 0 <= row["elapsed_seconds"] < duration
        ]
        values = [
            row["metrics"]["pid_rss_bytes"]
            for row in load
            if row["metrics"]["pid_rss_bytes"] is not None
        ]
        if len(values) < 2:
            raise ValueError(f"Fewer than two identity-validated RSS points: {case}")
        cases.append(
            {
                "case": case,
                "concurrency": concurrency,
                "duration_seconds": duration,
                "benchmark_started_at": run["started_at"],
                "interval_seconds": [0, duration],
                "interval_convention": "[start, end); phase=load; harness sample at",
                "acceptance_status": acceptance["status"],
                "memory_gate": acceptance.get("memory_gate"),
                "selected_samples": len(load),
                "available_rss_samples": len(values),
                "missing_rss_samples": len(load) - len(values),
                "process_identities": sorted(
                    {
                        tuple(row["process_identity"])
                        for row in load
                        if row["process_identity"] is not None
                    }
                ),
                "first_sample_seconds": load[0]["elapsed_seconds"],
                "last_sample_seconds": load[-1]["elapsed_seconds"],
                "minimum_rss_mib": min(values) / MIB,
                "maximum_rss_mib": max(values) / MIB,
                "tail_window_seconds": [2400, 3600] if duration == 3600 else None,
                "samples": load,
            }
        )
    return cases, snapshots


def render(cases, helper):
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt
    from matplotlib.ticker import ScalarFormatter

    fig, axes = plt.subplots(3, 1, figsize=(12, 11))
    fig.subplots_adjust(left=0.12, right=0.97, bottom=0.08, top=0.88, hspace=0.52)
    for ax, case in zip(axes, cases, strict=True):
        helper["plot_series"](
            ax,
            case["samples"],
            lambda row: row["metrics"]["pid_rss_bytes"],
            "PID RSS (smaps_rollup)",
            MIB,
            "process_identity",
        )
        low, high = case["minimum_rss_mib"], case["maximum_rss_mib"]
        pad = max((high - low) * 0.12, 0.05)
        ax.set_ylim(max(0, low - pad), high + pad)
        ax.set_xlim(0, case["duration_seconds"] / 60)
        formatter = ScalarFormatter(useOffset=False)
        formatter.set_scientific(False)
        ax.yaxis.set_major_formatter(formatter)
        ax.set_ylabel("Absolute PID RSS (MiB)")
        ax.set_xlabel("Measured load elapsed minutes (actual elapsed seconds / 60)")
        scope = "one-hour validation" if case["duration_seconds"] == 3600 else "15-minute screen"
        ax.set_title(
            f"{case['case']} | client concurrency {case['concurrency']} | {scope}\n"
            f"RSS samples {case['available_rss_samples']}/{case['selected_samples']}; "
            f"observed {case['first_sample_seconds']:.3f}–{case['last_sample_seconds']:.3f} s",
            fontsize=10,
        )
        if case["duration_seconds"] == 3600:
            ax.axvspan(
                40, 60, color="gold", alpha=0.18, label="Preset acceptance window [2400, 3600) s"
            )
            ax.axvline(40, color="darkgoldenrod", linewidth=0.8, linestyle="--")
        ax.grid(alpha=0.25)
        ax.legend(fontsize=8, loc="best")
    fig.suptitle(
        "Expanded-query load: process RSS across three completed cases\n"
        "Independent absolute MiB scales expose within-case change; compare ticks carefully",
        fontsize=13,
    )
    fig.text(
        0.12,
        0.018,
        "Only measured load is shown; baseline, warmup and recovery are excluded. "
        "Missing/invalid identity points remain gaps.\n"
        "Existing acceptance is unchanged; short screens do not establish one-hour convergence.",
        fontsize=9,
    )
    output = io.BytesIO()
    try:
        fig.savefig(output, format="png", dpi=150)
    finally:
        plt.close(fig)
    return output.getvalue()


def main():
    targets = [ROOT / "memory-matrix.png", ROOT / "memory-matrix-metadata.json"]
    if any(path.exists() for path in targets):
        raise FileExistsError("Refuse to overwrite memory matrix evidence")
    helper_path = ROOT / "render_evidence.py"
    helper_raw = helper_path.read_bytes()
    helper = runpy.run_path(str(helper_path))
    cases, snapshots = load_cases(helper)
    snapshots[helper_path] = helper_raw
    snapshots[Path(__file__).resolve()] = Path(__file__).read_bytes()
    png = render(cases, helper)
    metadata = {
        "schema_version": 1,
        "purpose": "DESCRIPTIVE_ONLY",
        "memory_unit": "MiB (1024**2 bytes)",
        "cases": cases,
        "input_sha256": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(data)
            for path, data in snapshots.items()
        },
        "png_sha256": sha256(png),
        "selection": "Half-open actual measured dispatch window; load phase only; no time rebasing",
        "identity_validation": "Reuse render_evidence flatten_samples: available server, "
        "consistent PID/stat/stat_after start ticks, available source, finite nonnegative RSS",
        "missing_data": "null values, identity changes and observation gaps over 15 seconds "
        "break lines",
        "axis_policy": "Independent absolute RSS axes; never subtract initial RSS "
        "or use offset ticks",
        "limitations": [
            "No acceptance thresholds or decisions are recomputed or changed.",
            "Finite sampled evidence cannot establish absence of leaks.",
            "Short screens are not one-hour validation; panel slopes have different scales.",
        ],
    }
    payload = (json.dumps(metadata, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode(
        "utf-8"
    )
    if any(path.read_bytes() != data for path, data in snapshots.items()):
        raise RuntimeError("Input changed during rendering; no outputs written")
    with targets[0].open("xb") as sink:
        sink.write(png)
    with targets[1].open("xb") as sink:
        sink.write(payload)
    print(json.dumps({"outputs": [str(path) for path in targets], "png_sha256": sha256(png)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
