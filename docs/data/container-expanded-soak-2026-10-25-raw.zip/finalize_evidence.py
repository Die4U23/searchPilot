"""Create final matrix summary and integrity evidence after all declared cases complete."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CASES = ('expanded-c4', 'expanded-c16', 'expanded-c32-hour')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    outputs = [ROOT/'aggregate.json', ROOT/'final-integrity.json']
    if any(p.exists() for p in outputs):
        raise FileExistsError('Refuse final evidence overwrite')
    build = read(ROOT/'build-summary.json')
    cases = {}
    for name in CASES:
        folder = ROOT/name
        a, b, h = (read(folder/f) for f in ('acceptance.json', 'soak.json', 'summary.json'))
        launch = read(ROOT/(name+'-launcher.json'))
        assert a['status'] == 'PASSED' and h['status'] == b['status'] == 'COMPLETED'
        assert launch['status'] == 'COMPLETED' and launch['observer_stopped'] is True
        assert all(v is True for v in a['checks'].values())
        assert (folder/'descriptive-resources.json').is_file()
        assert (folder/'resources.png').is_file()
        cases[name] = {'concurrency': a['concurrency'], 'duration_seconds': a['duration_seconds'],
            'started_at': b['runs'][0]['started_at'], 'summary': b['runs'][0]['summary'],
            'memory': a['memory'], 'windows': a['windows'], 'memory_gate': a['memory_gate'],
            'health': a['details']['health'], 'inside_load_samples': a['inside_load_samples'],
            'outside_load_samples': a['outside_load_samples'],
            'group_repeat_histogram': a['group_repeat_histogram'],
            'semantic_sha256': a['semantic_sha256'], 'acceptance_sha256': sha(folder/'acceptance.json')}
    same = len({c['semantic_sha256'] for c in cases.values()}) == 1
    assert same, 'Cross-case result/ranking/model fingerprints differ'
    inputs = read(ROOT/'inputs-sha256.json')
    sources = read(ROOT/'sources-sha256.json')
    integrity = {'status': 'PASSED', 'inputs_count': len(inputs), 'sources_count': len(sources),
        'input_mismatch': [n for n,v in inputs.items() if sha(REPO/n) != v],
        'source_mismatch': [n for n,v in sources.items() if sha(REPO/n) != v],
        'script_copy_mismatch': [n for n,v in sources.items() if n.startswith('scripts/') and sha(ROOT/'image-context'/n) != v],
        'public_config_mismatch': [n for n,r in [('Dockerfile','Dockerfile'),('docker-compose.yml','docker-compose.yml'),
            ('pyproject.toml','pyproject.toml'),('public-env.txt','.env.example')] if sha(ROOT/'source-config'/n) != sha(REPO/r)],
        'query_mismatch': [n for n in CASES for f in ('queries.csv','soak.queries.csv') if sha(ROOT/n/f) != build['query_sha256']],
        'cross_case_fingerprints_equal': same, 'container_and_installed_sources_matched': True}
    assert not any(v for k,v in integrity.items() if k.endswith('mismatch')), 'Frozen bytes changed'
    aggregate = {'schema_version': 1, 'status': 'PASSED', 'baseline_commit': '0c2344733937fdda75eb93b0987984bcc3a45b78',
        'image': build['image'], 'query_sha256': build['query_sha256'], 'query_count': 1300,
        'query_mode_groups': 5200, 'cross_case_fingerprints_equal': same,
        'cases': cases, 'external_llm_calls_this_run': 0,
        'limitations': ['Fixed synthetic fixture and finite durations; no leak-free or capacity SLA claim.',
                        'Other projects may share host resources; throughput differences are observational.',
                        'No relevance evaluation or production traffic representativeness claim.']}
    for output, value in zip(outputs, (aggregate, integrity)):
        with output.open('x', encoding='utf-8') as sink:
            json.dump(value, sink, indent=2)
    print(json.dumps({'status':'PASSED', 'cases':list(cases), 'cross_case_fingerprints_equal':same}))


if __name__ == '__main__':
    main()
