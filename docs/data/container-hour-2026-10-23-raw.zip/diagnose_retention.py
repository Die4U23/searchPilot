"""Separate invasive component experiment; not the HTTP hour acceptance run."""
import concurrent.futures
import csv
import ctypes
import gc
import hashlib
import json
import threading
import time
import tracemalloc
from collections import Counter
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path

import torch
from searchpilot.search.service import build_search_service


def emit(event, **data):
    print(json.dumps({"at": datetime.now(UTC).isoformat(), "event": event, **data}), flush=True)


def memory():
    result = {}
    for source in ("status", "smaps_rollup"):
        data = {}
        for line in Path(f"/proc/self/{source}").read_text().splitlines():
            key, sep, value = line.partition(":")
            parts = value.split()
            if sep and parts and parts[0].isdigit():
                data[key] = int(parts[0]) * (1024 if len(parts) > 1 and parts[1] == "kB" else 1)
        result[source] = data
    if tracemalloc.is_tracing():
        result["tracemalloc_current_peak_bytes"] = tracemalloc.get_traced_memory()
    return result


started = time.perf_counter()
emit("start", scope="direct search service only, no HTTP/DB, c4, invasive tracing; not throughput evidence")
service = build_search_service(Path("/app/artifacts"), warmup_vector=True)
with Path("/app/data/queries/queries.csv").open() as stream:
    queries = [row["query_text"] for row in csv.DictReader(stream)]
modes = ("bm25", "vector", "hybrid", "ltr")
fingerprints = {}
lock = threading.Lock()
grad_counts = Counter()


def forward_hook(module, args):
    with lock:
        grad_counts[(torch.is_grad_enabled(), torch.is_inference_mode_enabled())] += 1


hook = service._encode_query._model.register_forward_pre_hook(forward_hook)


def one(index):
    mode = modes[index % 4]
    query = queries[(index // 4) % len(queries)]
    result = service.search(query, 10, mode)
    digest = hashlib.sha256(json.dumps(asdict(result), sort_keys=True).encode()).hexdigest()
    with lock:
        old = fingerprints.setdefault((query, mode), digest)
        if old != digest:
            raise AssertionError("ranking or scores changed")


with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    # All 400 query/mode combinations are warmed before Python tracing starts.
    for result in pool.map(one, range(4 * len(queries))):
        pass
    emit("warmup_complete", calls=4 * len(queries), elapsed=time.perf_counter()-started, memory=memory())
    tracemalloc.start(2)
    baseline = tracemalloc.take_snapshot()
    for stage in range(3):
        begin = time.perf_counter()
        deadline = begin + 60
        counts = [0] * 4

        def worker(worker_id):
            while time.perf_counter() < deadline:
                one(counts[worker_id] * 4 + worker_id)
                counts[worker_id] += 1

        for future in [pool.submit(worker, n) for n in range(4)]:
            future.result(timeout=100)
        snap = tracemalloc.take_snapshot()
        differences = [{"traceback": str(row.traceback), "size_diff": row.size_diff,
                        "count_diff": row.count_diff} for row in snap.compare_to(baseline, "lineno")[:15]]
        del snap
        emit("stage", stage=stage+1, seconds=time.perf_counter()-begin, calls=sum(counts),
             per_mode=dict(zip(modes, counts)), memory=memory(), top_python_diffs=differences)
        del differences
    emit("before_gc", memory=memory())
    collected = gc.collect()
    emit("after_gc", collected=collected, memory=memory())
    libc = ctypes.CDLL(None)
    libc.malloc_trim.argtypes = [ctypes.c_size_t]
    libc.malloc_trim.restype = ctypes.c_int
    trimmed = libc.malloc_trim(0)
    emit("after_trim", result=trimmed, memory=memory())
emit("pool_closed", memory=memory())
hook.remove()
emit("complete", fingerprints=len(fingerprints), grad_counts={str(k):v for k,v in grad_counts.items()},
     elapsed=time.perf_counter()-started)
