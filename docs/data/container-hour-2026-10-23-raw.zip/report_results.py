"""Derive publication tables from completed evidence; no service writes."""
import json
import statistics
from collections import Counter
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parent
run = root / "run-001"
bench = json.loads((run/"soak.json").read_text())
harness = json.loads((run/"summary.json").read_text())
audit = json.loads((root/"analysis.json").read_text())
samples = [json.loads(line) for line in (run/"samples.jsonl").read_text().splitlines()]
measured = bench["runs"][0]
start = datetime.fromisoformat(measured["started_at"])
rows = []
for sample in samples:
    elapsed = (datetime.fromisoformat(sample["at"])-start).total_seconds()
    sources = sample.get("server",{}).get("sources",{})
    smaps = sources.get("smaps_rollup",{}).get("data",{})
    cgroup = sources.get("cgroup_memory_stat",{}).get("data",{}).get("bytes",{})
    client = sample.get("client",{}).get("sources",{}).get("memory",{}).get("data",{})
    rows.append({"seconds":elapsed,"phase":sample["phase"],"rss":smaps.get("Rss_bytes"),
                 "anon":smaps.get("Anonymous_bytes"),"cgroup_anon":cgroup.get("anon"),
                 "cgroup_file":cgroup.get("file"),"client_rss":client.get("rss_bytes")})

windows=[]
for index in range(12):
    group = [r for r in rows if index*300 <= r["seconds"] < (index+1)*300]
    values = {k:[r[k] for r in group if r[k] is not None]
              for k in ("rss","anon","cgroup_anon","cgroup_file","client_rss")}
    windows.append({"index":index,"sample_count":len(group),
                    "available_count":{k:len(v) for k,v in values.items()},
                    "missing_count":{k:len(group)-len(v) for k,v in values.items()},
                    "median_bytes":{k:statistics.median(v) if v else None for k,v in values.items()},
                    "mean_bytes":{k:statistics.mean(v) if v else None for k,v in values.items()}})

active=set()
peak=0
outcomes=Counter()
with (run/"soak.requests.jsonl").open() as stream:
    for line in stream:
        event=json.loads(line)
        if event["event"]=="pending":
            active.add(event["request_id"])
            peak=max(peak,len(active))
        else:
            active.discard(event["request_id"])
            outcomes[event["phase"]+":"+event["outcome"]]+=1

doc={"schema_version":1,"harness_status":harness["status"],"ledger_status":audit["status"],
     "ledger_issues":audit["issues"],"ledger_phases":audit["phases"],
     "started_at":measured["started_at"],"finished_at":measured["finished_at"],
     "summary":measured["summary"],"by_mode":measured["by_mode"],
     "peak_in_flight_reconstructed":peak,"pending_at_end":sorted(active),
     "outcomes":dict(outcomes),"startup_seconds":harness["startup_seconds"],
     "business_checks":dict(Counter(row["status"] for row in harness["requests"])),
     "business_status_codes":dict(Counter(row.get("http_status") for row in harness["requests"])),
     "database_initial":harness["initial_counts"],"database_final":harness.get("final_counts"),
     "image":harness["image"],"packages":harness["container_packages"],
     "engine":{"cpus":harness["engine"]["NCPU"],"memory_bytes":harness["engine"]["MemTotal"]},
     "windows":windows,"resources":audit["resources"],
     "fingerprint_groups":audit["fingerprints"]["group_count"],
     "limitations":["single worker, c4 closed loop, fixed 100 query fixture, no capacity/SLA claim",
                    "sampled memory is not continuous peak or proof of absence of leaks",
                    "native allocator diagnosis is separate and does not attribute all hour growth",
                    "no tracing, gc or trim during HTTP hour; host background load uncontrolled"],
     "external_llm_calls":0}
(root/"summary.json").write_text(json.dumps(doc,indent=2)+"\n")
print(json.dumps({k:v for k,v in doc.items() if k not in ("resources","windows","by_mode")},indent=2))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axes=plt.subplots(2,1,figsize=(10,7),sharex=True,layout="constrained")
selected=[r for r in rows if r["phase"] in ("baseline", "load", "recovery")]
recovery_start=(datetime.fromisoformat(harness["soak_finished_at"])-start).total_seconds()/60
for key,label in (("rss","API PID 1 RSS"),("anon","API anonymous"),("cgroup_anon","cgroup anonymous")):
    axes[0].plot([r["seconds"]/60 for r in selected],
                 [r[key]/1048576 if r[key] is not None else float("nan") for r in selected],label=label,linewidth=1)
for key,label in (("cgroup_file","cgroup file pages"),("client_rss","Windows load generator RSS")):
    axes[1].plot([r["seconds"]/60 for r in selected],
                 [r[key]/1048576 if r[key] is not None else float("nan") for r in selected],label=label,linewidth=1)
for axis in axes:
    axis.axvline(0,color="#888888",linestyle="--",linewidth=.8)
    axis.axvline(60,color="#888888",linestyle="--",linewidth=.8)
    axis.axvspan(recovery_start, max(r["seconds"] for r in selected)/60,
                 color="#c5e1a5",alpha=.25,label="Post-load recovery")
    axis.set_ylabel("MiB (sampled)")
    axis.grid(alpha=.2)
    axis.legend(loc="best")
axes[1].set_xlabel("Minutes since measured dispatch began; dispatch stops at 60")
axes[0].set_title("SearchPilot: one-hour c4 mixed search, separate memory scopes")
fig.savefig(root/"memory.png",dpi=160)
plt.close(fig)
