"""Record exact local check commands and exit codes after the HTTP observation ends."""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
harness = json.loads((root / "run-001/summary.json").read_text())
if harness["status"] != "COMPLETED":
    raise SystemExit("Do not add test load before formal harness completion")
env = dict(os.environ)
env.update(TMP=str(repo / ".tmp"), TEMP=str(repo / ".tmp"))
env["SEARCHPILOT_DATABASE_URL"] = (
    "postgresql://searchpilot:searchpilot@127.0.0.1:15433/searchpilot_hour_test"
)
checks = [
    ("quality-final.txt", ["-m", "ruff", "check", "."]),
    ("quality-final.txt", ["-m", "ruff", "format", "--check", "."]),
    ("quality-final.txt", ["-m", "mypy", "src"]),
    ("unit-final.txt", ["-m", "pytest"]),
    ("integration-final.txt", ["-m", "pytest", "-m", "integration", "--no-header", "-rs"]),
]
report = []
for filename, args in checks:
    command = [sys.executable, *args]
    with (root / filename).open("a", encoding="utf-8") as output:
        output.write("COMMAND: " + json.dumps(command) + "\n")
        output.flush()
        started = datetime.now(timezone.utc).isoformat()
        result = subprocess.run(command, cwd=repo, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=300)
    report.append({"command": command, "started_at": started,
                   "finished_at": datetime.now(timezone.utc).isoformat(),
                   "exit_code": result.returncode, "log": filename})
    (root / "final-checks.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report[-1]), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
