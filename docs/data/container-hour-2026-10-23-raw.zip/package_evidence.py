"""Package an explicit evidence allowlist after completion; scan private values silently."""
import hashlib
import json
import re
import zipfile
from pathlib import Path

from dotenv import dotenv_values

root = Path(__file__).resolve().parent
repo = root.parents[1]
destination = repo / "docs/data/container-hour-2026-10-23-raw.zip"
names = [
    "analysis.json", "inputs-sha256.json", "final-integrity.json", "final-checks.json",
    "build.txt", "Dockerfile.validation", "diagnose_retention.py", "diagnostic.jsonl",
    "diagnostic-stderr.txt", "diagnostic-fixed.jsonl", "diagnostic-fixed-stderr.txt",
    "diagnostic-manifest.json", "stem-before.txt", "stem-after.txt", "sampler-smoke.json",
    "bench_concurrent.executed.py", "soak_memory.executed.py",
    "validate_container_soak.executed.py", "summarize_soak.executed.py", "report_results.py",
    "verify_integrity.py", "run_final_checks.py", "cleanup_resources.py", "package_evidence.py",
    "unit-final.txt", "integration-final.txt", "quality-final.txt", "cleanup.json",
    "harness-console.txt", "midpoint-fingerprints.json",
    "run-001/summary.json", "run-001/soak.json", "run-001/soak.requests.jsonl",
    "run-001/samples.jsonl", "run-001/soak-console.txt", "run-001/compose.override.yml",
    "run-001/sp-hour-20261023-api-1.log", "run-001/sp-hour-20261023-db-1.log",
]
missing = [name for name in names if not (root / name).is_file()]
if missing:
    raise SystemExit("Missing required evidence files: " + ", ".join(missing))
secrets = [value.encode() for key, value in dotenv_values(repo / ".env").items()
           if value and len(value) >= 12 and re.search(r"KEY|TOKEN|SECRET|PASSWORD", key, re.I)]
manifest = {}
leaks = []
for name in names:
    data = (root / name).read_bytes()
    if any(value in data for value in secrets):
        leaks.append(name)
    manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
if leaks:
    raise SystemExit("Private value found in evidence files: " + ", ".join(leaks))
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name in names:
        archive.write(root / name, name)
    archive.writestr("SHA256SUMS.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name in names:
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == manifest[name]["sha256"]
        assert not any(value in data for value in secrets)
report = {"file": destination.name, "bytes": destination.stat().st_size,
          "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
          "members": len(names) + 1, "private_values_checked": len(secrets),
          "private_values_found": 0, "all_member_hashes_verified": True}
(root / "archive-verification.json").write_text(json.dumps(report, indent=2) + "\n")
summary = json.loads((root / "summary.json").read_text())
summary["archive"] = report
(repo / "docs/data/container-hour-2026-10-23-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(report))
