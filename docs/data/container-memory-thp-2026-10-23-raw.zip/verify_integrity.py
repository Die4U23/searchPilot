"""Check frozen validation inputs and record allowed analyzer-only evolution."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = json.loads((root / "inputs-sha256.json").read_text())
report = {"inputs": {name: digest(repo / name) == expected for name, expected in inputs.items()}}
names = ("validate_container_soak", "soak_memory", "bench_concurrent")
report["measurement_scripts"] = {
    name: digest(repo / f"scripts/{name}.py") == digest(root / f"{name}.executed.py")
    for name in names
}
report["analyzer_snapshot_matches_final"] = (
    digest(repo / "scripts/summarize_soak.py") == digest(root / "summarize_soak.executed.py")
)
run = json.loads((root / "hour-001/summary.json").read_text())
changes = [name for name, expected in run["local_source_sha256"].items()
           if digest(repo / name) != expected]
report["source_changes_since_run_start"] = changes
report["source_change_scope"] = "production and measurement sources frozen throughout formal hour"
report["container_source_files_matched_before_start"] = len(run["container_source_sha256"])
report["installed_source_files_matched_before_start"] = len(run["imported_source"]["sha256"])
report["passed"] = (all(report["inputs"].values()) and all(report["measurement_scripts"].values())
                    and report["analyzer_snapshot_matches_final"]
                    and not changes)
(root / "final-integrity.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["passed"] else 1)
