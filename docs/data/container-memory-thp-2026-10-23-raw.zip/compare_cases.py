"""Offline allocator evidence comparison; reads only explicit case evidence files."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path


def seconds(start, end):
    return (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()


def digest(value):
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()


def source(process, name):
    return process.get("sources", {}).get(name, {}).get("data", {})


def snapshot(row, started_at):
    raw = row["data"]
    value = raw.get("snapshot", raw)
    process = value.get("process", {}).get("data", value)
    smaps = source(process, "smaps_rollup")
    status = source(process, "status")
    allocator = value.get("allocator", {})
    return {
        "label": row["label"],
        "at": row["at"],
        "seconds_since_driver_start": seconds(started_at, row["at"]),
        "rss_bytes": smaps.get("Rss_bytes"),
        "anonymous_bytes": smaps.get("Anonymous_bytes"),
        "anon_huge_pages_bytes": smaps.get("AnonHugePages_bytes"),
        "private_dirty_bytes": smaps.get("Private_Dirty_bytes"),
        "private_clean_bytes": smaps.get("Private_Clean_bytes"),
        "shared_clean_bytes": smaps.get("Shared_Clean_bytes"),
        "swap_bytes": smaps.get("Swap_bytes"),
        "threads": status.get("Threads"),
        "thp_enabled": status.get("THP_enabled"),
        "pid": process.get("pid"),
        "start_time_ticks": source(process, "stat").get("start_time_ticks"),
        "identity_consistent": process.get("identity_consistent"),
        "process_errors": process.get("errors"),
        "glibc": allocator.get("mallinfo2"),
        "glibc_heap_count": allocator.get("malloc_info", {}).get("data", {}).get("heap_count"),
        "pymalloc": value.get("pymalloc"),
        "tracemalloc": value.get("tracemalloc"),
        "action_result": raw.get("result"),
    }


def ledger(path):
    groups = defaultdict(set)
    sizes = Counter()
    phases = Counter()
    modes = Counter()
    pending = Counter()
    completed = Counter()
    outcomes = Counter()
    indices = Counter()
    issued = []
    inflight = set()
    max_inflight = 0
    unmatched_results = 0
    missing_fingerprints = 0
    partial_lines = []
    first = last = None
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                partial_lines.append(line_number)
                continue
            phases[row.get("phase"), row.get("event")] += 1
            if row.get("phase") != "measured":
                continue
            key = row["request_id"]
            if row["event"] == "pending":
                pending[key] += 1
                inflight.add(key)
                max_inflight = max(max_inflight, len(inflight))
                issued.append((row["index"], row["mode"], row["query"]))
                if first is None:
                    first = row["at"]
            elif row["event"] == "result":
                completed[key] += 1
                if key not in inflight:
                    unmatched_results += 1
                inflight.discard(key)
                last = row["at"]
                pair = (row["mode"], row["query"])
                fingerprint = (row.get("result_sha256"), row.get("ranking_sha256"))
                missing_fingerprints += any(part is None for part in fingerprint)
                groups[pair].add(fingerprint)
                sizes[pair] += 1
                modes[row["mode"]] += 1
                outcomes[row.get("outcome")] += 1
                indices[row["index"]] += 1
    canonical = [[*pair, sorted(values, key=repr)] for pair, values in sorted(groups.items())]
    return {
        "phase_event_counts": {"/".join(key): value for key, value in phases.items()},
        "pending_count": sum(pending.values()),
        "result_count": sum(completed.values()),
        "pending_result_ids_match": pending == completed,
        "duplicate_pending_ids": sum(count - 1 for count in pending.values()),
        "duplicate_result_ids": sum(count - 1 for count in completed.values()),
        "unmatched_results": unmatched_results,
        "outstanding_ids": len(inflight),
        "max_inflight": max_inflight,
        "outcomes": dict(outcomes),
        "mode_counts": dict(modes),
        "unique_groups": len(groups),
        "group_repeat_histogram": dict(Counter(sizes.values())),
        "fingerprint_variant_histogram": dict(Counter(map(len, groups.values()))),
        "missing_fingerprints": missing_fingerprints,
        "group_fingerprints_sha256": digest(canonical),
        "issued_sequence_sha256": digest(issued),
        "indices_exactly_once_from_zero": indices == Counter(range(sum(completed.values()))),
        "first_pending_at": first,
        "last_result_at": last,
        "ledger_wall_seconds_including_checkpoints": seconds(first, last) if first and last else None,
        "malformed_or_partial_lines": partial_lines,
    }


def compare_case(path):
    report = json.loads((path / "summary.json").read_text(encoding="utf-8"))
    samples = [snapshot(row, report["started_at"]) for row in report["snapshots"]]
    by_label = {row["label"]: row for row in samples}
    last_load = next((row["label"] for row in reversed(samples) if row["label"].startswith("after_")), None)
    changes = {}
    for first, last in [("warmup", last_load), (last_load, "idle"), ("warmup", "idle"), ("idle", "gc"), ("gc", "trim")]:
        if first not in by_label or last not in by_label:
            continue
        left, right = by_label[first], by_label[last]
        changes[f"{first}_to_{last}"] = {
            "wall_seconds": seconds(left["at"], right["at"]),
            **{field: right[field] - left[field] if right[field] is not None and left[field] is not None else None
               for field in ("rss_bytes", "anonymous_bytes", "anon_huge_pages_bytes")},
        }
    return {
        "case": path.name,
        "status": report["status"],
        "config": report["config"],
        "started_at": report["started_at"],
        "finished_at": report.get("finished_at"),
        "image": report.get("container", {}).get("Image"),
        "queries_sha256": report.get("queries_sha256"),
        "executed_file_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.glob("*.executed.py"))},
        "summary": report.get("summary"),
        "ledger": ledger(path / "requests.jsonl"),
        "snapshots": samples,
        "changes": changes,
        "saved_smaps_checkpoints": [p.stem for p in sorted(path.glob("smaps-*.txt"))],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    cases = []
    errors = []
    for summary in sorted(args.root.glob("*/summary.json")):
        path = summary.parent
        if not (path / "requests.jsonl").exists():
            continue
        try:
            cases.append(compare_case(path))
        except (OSError, ValueError, KeyError, TypeError) as exc:
            errors.append({"case": path.name, "error_type": type(exc).__name__, "message": str(exc)})
    result = {
        "method": "Offline snapshot of evolving evidence. Null means unavailable. All memory quantities use bytes. "
        "RSS, glibc, pymalloc and THP overlap and are not additive. summary.elapsed_seconds sums request blocks; "
        "ledger wall includes intervening checkpoints; snapshot ages start at driver start, before container recreation. "
        "Fingerprint digest excludes repetition counts. RUNNING cases are incomplete.",
        "cases": cases,
        "errors": errors,
    }
    raw = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(raw, encoding="utf-8")
    else:
        print(raw, end="")


if __name__ == "__main__":
    main()
