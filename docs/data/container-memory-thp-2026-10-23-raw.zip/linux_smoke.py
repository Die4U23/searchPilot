import ast
import json
import os
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
docker = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
api = "sp-allocator-20261023-api-1"
def run(args):
    return subprocess.run([docker, *args], cwd=repo, capture_output=True,
                          text=True, encoding="utf-8", check=True, timeout=30).stdout
run(["cp", str(repo / "scripts/docker_entrypoint.py"), api + ":/tmp/thp-entrypoint.py"])
tree = ast.parse((repo / "tests/test_docker_entrypoint.py").read_text())
test = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
            and node.name == "test_linux_policy_survives_exec_in_isolated_child")
child = ast.literal_eval(next(node.value for node in test.body if isinstance(node, ast.Assign)
                             and node.targets[0].id == "child"))
report = {}
for setting in ("true", "false"):
    output = json.loads(run(["exec", "-e", "SEARCHPILOT_DISABLE_THP="+setting,
                             api, "python", "-c", child, "/tmp/thp-entrypoint.py"]))
    assert output == {"observed": int(setting == "true")}
    report[setting] = output
code = """
import json
from scripts.diagnose_allocator import NativeAllocator
a=NativeAllocator(); m=a.mallinfo(); i=a.malloc_info(); p=a.pymalloc()
assert m['arena']>0 and m['uordblks']>0 and i['heap_count']>0
assert p['fields']['arenas_current']>0 and p['fields']['allocated_blocks_bytes']>0
print(json.dumps({'mallinfo':m,'heap_count':i['heap_count'],'pymalloc_fields':p['fields']}))
"""
report["native_statistics"] = json.loads(run(["exec", api, "python", "-c", code]))
report["scope"] = "fresh diagnostic exec processes; does not alter API process policy"
(root / "linux-smoke.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report))
