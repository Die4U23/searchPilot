"""Summarize only the five completed allocator controls; never read hour evidence."""

from __future__ import annotations

import json
from pathlib import Path

from compare_cases import compare_case

ROOT = Path(__file__).resolve().parent
CASES = (
    "diag-default-01",
    "plain-default-01",
    "diag-default-02",
    "diag-no-thp-01",
    "diag-default-03",
)


def mib(value):
    return None if value is None else round(value / 1048576, 6)


def common(cases, accessor):
    values = {accessor(case) for case in cases}
    if len(values) != 1:
        raise ValueError(f"Expected common evidence, found {values!r}")
    return values.pop()


def compact(case):
    ledger = case["ledger"]
    if case["status"] != "COMPLETED":
        raise ValueError(f"Incomplete control: {case['case']}")
    if not (
        ledger["pending_count"] == ledger["result_count"] == 4000
        and ledger["outcomes"] == {"success": 4000}
        and ledger["unique_groups"] == 400
        and ledger["group_repeat_histogram"] == {10: 400}
        and ledger["fingerprint_variant_histogram"] == {1: 400}
        and ledger["pending_result_ids_match"]
        and ledger["indices_exactly_once_from_zero"]
        and ledger["max_inflight"] == 4
        and not any(ledger[key] for key in (
            "duplicate_pending_ids", "duplicate_result_ids", "unmatched_results",
            "outstanding_ids", "missing_fingerprints", "malformed_or_partial_lines",
        ))
    ):
        raise ValueError(f"Unexpected denominator or ledger integrity: {case['case']}")
    snapshots = case["snapshots"]
    checkpoints = []
    for row in snapshots:
        if row["label"] not in ("ready", "warmup", "after_400", "after_4000", "idle", "gc", "trim"):
            continue
        glibc = (row.get("glibc") or {}).get("data", {})
        pymalloc = (row.get("pymalloc") or {}).get("data", {}).get("fields", {})
        checkpoints.append({
            "label": row["label"],
            "rss_mib": mib(row["rss_bytes"]),
            "anonymous_mib": mib(row["anonymous_bytes"]),
            "anon_huge_pages_mib": mib(row["anon_huge_pages_bytes"]),
            "glibc_arena_mib": mib(glibc.get("arena")),
            "glibc_allocated_mib": mib(glibc.get("uordblks")),
            "glibc_free_mib": mib(glibc.get("fordblks")),
            "glibc_mmap_mib": mib(glibc.get("hblkhd")),
            "pymalloc_arenas": pymalloc.get("arenas_current"),
            "pymalloc_allocated_mib": mib(pymalloc.get("allocated_blocks_bytes")),
        })
    return {
        "case": case["case"],
        "status": case["status"],
        "started_at": case["started_at"],
        "finished_at": case["finished_at"],
        "entrypoint": "original production entrypoint" if case["config"]["plain"] else "same-PID diagnostic wrapper",
        "config": case["config"],
        "executed_source_sha256": case["executed_file_sha256"],
        "ledger": {
            key: ledger[key] for key in (
                "phase_event_counts", "pending_count", "result_count", "mode_counts",
                "unique_groups", "group_repeat_histogram", "fingerprint_variant_histogram",
                "max_inflight", "pending_result_ids_match", "indices_exactly_once_from_zero",
                "outstanding_ids", "duplicate_pending_ids", "duplicate_result_ids",
                "unmatched_results", "missing_fingerprints", "malformed_or_partial_lines",
            )
        },
        "timing": {
            "request_blocks_seconds": case["summary"]["elapsed_seconds"],
            "ledger_wall_seconds_including_checkpoints": ledger["ledger_wall_seconds_including_checkpoints"],
            "warmup_to_idle_wall_seconds": case["changes"]["warmup_to_idle"]["wall_seconds"],
            "last_load_to_idle_wall_seconds": case["changes"]["after_4000_to_idle"]["wall_seconds"],
            "requests_per_block_second": case["summary"]["completed_requests_per_second"],
            "p95_ms": case["summary"]["success_latency"]["p95_ms"],
            "p99_ms": case["summary"]["success_latency"]["p99_ms"],
        },
        "observed_thp_enabled_values": sorted({row["thp_enabled"] for row in snapshots}, key=repr),
        "observed_pid_start_time_ticks": sorted({row["start_time_ticks"] for row in snapshots}, key=repr),
        "checkpoint_count": len(snapshots),
        "checkpoints": checkpoints,
        "changes_mib": {
            label: {key.removesuffix("_bytes") + "_mib": mib(value)
                    for key, value in delta.items() if key.endswith("_bytes")}
            for label, delta in case["changes"].items()
        },
    }


def main():
    raw_cases = [compare_case(ROOT / name) for name in CASES]
    cases = [compact(case) for case in raw_cases]
    result = {
        "schema_version": 1,
        "scope": "Exactly five completed 4000-request allocator controls. The formal hour is excluded and is not asserted complete.",
        "units": "MiB = 1048576 bytes; null means unavailable. glibc, pymalloc, THP and RSS scopes overlap and cannot be added.",
        "common_evidence": {
            "image_sha256": common(raw_cases, lambda c: c["image"]),
            "queries_file_sha256": common(raw_cases, lambda c: c["queries_sha256"]),
            "issued_sequence_sha256": common(raw_cases, lambda c: c["ledger"]["issued_sequence_sha256"]),
            "group_fingerprints_sha256": common(raw_cases, lambda c: c["ledger"]["group_fingerprints_sha256"]),
            "protocol": "100 queries x 4 modes x 10 repeats = 4000 measured successes per case; 16 separate sequential warmups; max in-flight 4; limit 10; no retries.",
            "source_limits": "Same image and query file verified. Probe and driver versions are retained per case; diag-default-01 predates pymalloc stats; plain has no in-process diagnostic wrapper. Source hashes do not replace runtime import-path verification.",
        },
        "timing_definitions": {
            "request_blocks_seconds": "Sum of measured request-block durations; excludes startup, checkpoint collection and idle.",
            "ledger_wall_seconds_including_checkpoints": "First measured pending to final measured result; includes intervening checkpoints, excludes final checkpoint and idle.",
            "idle": "Configured 120 seconds plus sampling/control latency; actual last-load-snapshot to idle-snapshot interval is reported per case.",
            "comparison_limit": "Equal work, not identical elapsed time. default03 took longer; exact RSS differences and latency differences are not isolated treatment-effect estimates.",
        },
        "cases": cases,
        "causal_assessment": {
            "sequence": ["diag-default-02", "diag-no-thp-01", "diag-default-03"],
            "supported": [
                "Verified per-process THP disable removed observed huge pages and the 120-second idle RSS rise in this full-API workload; restoring default THP reproduced the rise.",
                "Request order, mode/query coverage and response fingerprints match across the sequence; diagnostic wrapper and sampler versions match.",
                "THP is an important causal contributor to continuing RSS growth in these controls. glibc reclaimable retention also exists; pymalloc arena count stays constant within each run.",
            ],
            "not_established": [
                "The experiments do not attribute all 157.6 MiB of the earlier hour growth or prove absence of leaks.",
                "The owner of the growing THP-eligible anonymous VMA is not identified by smaps alone.",
                "Differences in process age, baseline allocation layout and checkpoint versions limit precise effect sizes; one no-THP run does not establish performance on other workloads.",
                "The production-entrypoint fix still requires its own formal hour acceptance; this summary does not report that run's outcome.",
            ],
            "mapping_evidence": "default02 smaps-mid to smaps-late: same 1 GiB VMA 2a030c00000-2a070c00000 retained size, RSS grew 17320 KiB and AnonHugePages 69632 KiB; approximately 97.3% of whole-process RSS growth in that interval. These extra map captures are not exact checkpoint pairs.",
        },
        "unrun_controls": [
            {"name": "vector candidate-selection ablation", "status": "NOT_RUN", "claim": "Implementation/oracle preparation is not a memory-performance result."},
            {"name": "MALLOC_ARENA_MAX=2", "status": "NOT_RUN", "claim": "No arena-limit mitigation or causal effect is claimed."},
        ],
    }
    target = ROOT / "compact-comparison.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(target), "completed_cases": len(cases), "measured_successes": 5 * 4000}))


if __name__ == "__main__":
    main()
