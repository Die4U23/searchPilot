"""Read-only incremental progress from client files; never call the API."""
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parent
run = root / "hour-001"
cache = root / "monitor.json"
state = json.loads(cache.read_text()) if cache.exists() else {"offset":0,"counts":{},"active":[]}
counts = Counter(state["counts"])
active = set(state["active"])
ledger = run / "soak.requests.jsonl"
if ledger.exists():
    with ledger.open("rb") as stream:
        stream.seek(state["offset"])
        while True:
            offset = stream.tell()
            line = stream.readline()
            if not line.endswith(b"\n"):
                state["offset"] = offset
                break
            event = json.loads(line)
            if event["event"] == "pending":
                active.add(event["request_id"])
            else:
                active.discard(event["request_id"])
                counts[event["phase"]+":"+event["outcome"]] += 1
    state.update(counts=dict(counts),active=sorted(active))
    cache.write_text(json.dumps(state))
samples = []
for line in (run / "samples.jsonl").read_text().splitlines():
    try:
        samples.append(json.loads(line))
    except json.JSONDecodeError:
        pass
last = samples[-1]
source = last["server"].get("sources", {})
memory = source.get("smaps_rollup",{}).get("data",{})
loads = [r for r in samples if r["phase"] == "load"]
elapsed = ((datetime.fromisoformat(last["at"])-datetime.fromisoformat(loads[0]["at"])).total_seconds()
           if loads else None)
print(json.dumps({"at":last["at"],"phase":last["phase"],"load_sample_minutes":round(elapsed/60,2) if elapsed is not None else None,
    "counts":dict(counts),"active":len(active),"rss_mib":round(memory.get("Rss_bytes",0)/1048576,3),
    "anon_mib":round(memory.get("Anonymous_bytes",0)/1048576,3),"thp_bytes":memory.get("AnonHugePages_bytes"),
    "THP_enabled":source.get("status",{}).get("data",{}).get("THP_enabled"),
    "live":last["live"].get("status"),"ready":last["ready"].get("status"),
    "load_health":{kind:dict(Counter(str(row[kind].get("status")) for row in loads)) for kind in ("live","ready")}}))
