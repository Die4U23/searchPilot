"""Equal-work allocator controls. Invasive interventions are diagnostic-only and post-load."""
import argparse
import asyncio
import csv
import hashlib
import json
import shutil
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

import httpx
from scripts.bench_concurrent import Config, MODES, request_once, summarize
from scripts.validate_container_soak import clean_environment

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
API = "sp-allocator-20261023-api-1"
BASE = [DOCKER, "compose", "--env-file", str(REPO / ".env.example"), "-p",
        "sp-allocator-20261023", "-f", str(REPO / "docker-compose.yml"), "-f",
        str(ROOT / "setup/compose.override.yml")]

def now():
    return datetime.now(UTC).isoformat()

def command(args):
    return subprocess.run(args, cwd=REPO, env=clean_environment(), capture_output=True,
                          text=True, encoding="utf-8", timeout=120, check=True)

def control(path="/snapshot", payload=None):
    code = ("import urllib.request; r=urllib.request.Request('http://127.0.0.1:8779' + "
            + repr(path) + ", data=" + repr(json.dumps(payload).encode() if payload is not None else None)
            + ", headers={'Content-Type':'application/json'}); "
            "print(urllib.request.urlopen(r, timeout=60).read().decode())")
    return json.loads(command([DOCKER, "exec", API, "python", "-c", code]).stdout)

async def main(args):
    out = ROOT / args.case
    out.mkdir(exist_ok=False)
    copied = [Path(__file__), REPO / "scripts/soak_memory.py"]
    if not args.plain:
        copied.append(REPO / "scripts/diagnose_allocator.py")
    if args.ablation:
        copied.append(ROOT / "vector_candidate_ablation.py")
    for source in copied:
        shutil.copyfile(source, out / (source.stem + ".executed.py"))
    override = {"services":{"api":{"environment":{"MALLOC_ARENA_MAX":str(args.arenas),
                   "GLIBC_TUNABLES":"", "LD_PRELOAD":"", "PYTHONTRACEMALLOC":""}}}}
    if not args.plain:
        override["services"]["api"].update(command=["python","-m","scripts.diagnose_allocator"],
            volumes=[{"type":"bind","source":str(REPO / "scripts" / name),
                      "target":"/app/scripts/"+name,"read_only":True}
                     for name in ("diagnose_allocator.py", "soak_memory.py")])
        if args.ablation:
            override["services"]["api"]["volumes"].append({"type":"bind",
                "source":str(ROOT / "vector_candidate_ablation.py"),
                "target":"/app/scripts/vector_candidate_ablation.py","read_only":True})
            override["services"]["api"]["command"] = ["python","-c",
                "from scripts.vector_candidate_ablation import install; install(); "
                "from scripts.diagnose_allocator import main; main()"]
    (out / "override.yml").write_text(json.dumps(override, indent=2))
    compose = BASE + ["-f", str(out / "override.yml")]
    report = {"status":"RUNNING", "started_at":now(), "config":vars(args), "blocks":[],
              "method":"fixed index mode/query round robin, c4, 16 sequential warmups; "
                       "drain at checkpoints; no per-thread mode binding; no retries",
              "control_scope":"plain original entrypoint" if args.plain else "same-PID diagnostic wrapper",
              "executed_sha256":{source.name:hashlib.sha256(source.read_bytes()).hexdigest() for source in copied},
              "snapshots":[], "commands":[]}
    def save():
        (out / "summary.json").write_text(json.dumps(report, indent=2)+"\n")
    def snap(label, path="/snapshot", payload=None):
        if args.plain:
            value = json.loads(command([DOCKER,"exec",API,"python","/tmp/soak_memory.py","--pid","1"]).stdout)
        else:
            value = control(path, payload)
        report["snapshots"].append({"label":label,"at":now(),"data":value})
        save()
    save()
    try:
        start = time.perf_counter()
        result = command(compose + ["up","-d","--no-deps","--no-build","--force-recreate","api"])
        report["commands"].append({"command":compose,"output":result.stdout+result.stderr})
        report["container"] = json.loads(command([DOCKER,"inspect",API]).stdout)[0]
        assert report["container"]["Config"]["Labels"]["com.docker.compose.project"] == "sp-allocator-20261023"
        async with httpx.AsyncClient(base_url="http://127.0.0.1:18083", trust_env=False,
              limits=httpx.Limits(max_connections=4, max_keepalive_connections=4), timeout=10) as client:
            async with asyncio.timeout(240):
                while True:
                    try:
                        ready=await client.get("/health/ready")
                        if ready.status_code == 200 and all(ready.json()["checks"].values()):
                            break
                    except httpx.HTTPError:
                        pass
                    await asyncio.sleep(.5)
            report["startup_seconds"]=time.perf_counter()-start
            snap("ready")
            queries_file=REPO/"data/queries/queries.csv"
            with queries_file.open(encoding="utf-8") as f:
                queries=[r["query_text"] for r in csv.DictReader(f)]
            report["queries_sha256"]=hashlib.sha256(queries_file.read_bytes()).hexdigest()
            config=Config(base_url="http://127.0.0.1:18083", concurrency=4, timeout=10, limit=10)
            results=[]
            with (out/"requests.jsonl").open("x",encoding="utf-8") as ledger:
                def sink(event):
                    ledger.write(json.dumps({"at":now(),**event})+"\n")
                    ledger.flush()
                warm=[]
                for mode in MODES:
                    for i in range(4):
                        warm.append(await request_once(client,config,index=i,mode=mode,query=queries[i],
                                                       phase="warmup",event_sink=sink))
                report["warmup"]=summarize(warm,0)
                assert all(r["outcome"]=="success" for r in warm)
                snap("warmup")
                if args.trace:
                    snap("trace_start","/trace/start",{"frames":1})
                issued=0
                while issued<args.requests:
                    end=min(args.requests,400 if issued==0 else issued+800)
                    indices=iter(range(issued,end))
                    block=[]
                    started=time.perf_counter()
                    async def worker():
                        for i in indices:
                            row=await request_once(client,config,index=i,mode=MODES[i%4],
                                query=queries[(i//4)%len(queries)],phase="measured",event_sink=sink)
                            block.append(row)
                    await asyncio.gather(*(worker() for _ in range(4)))
                    elapsed=time.perf_counter()-started
                    results.extend(block)
                    report["blocks"].append({"start":issued,"end":end,"summary":summarize(block,elapsed)})
                    issued=end
                    snap("after_"+str(issued))
                    print(json.dumps({"case":args.case,"completed":issued,"failures":report["blocks"][-1]["summary"]["failures"]}),flush=True)
                    if any(r["outcome"]!="success" for r in block):
                        raise RuntimeError("request failure; preserve partial evidence")
            report["summary"]=summarize(results,sum(b["summary"]["elapsed_seconds"] for b in report["blocks"]))
            await asyncio.sleep(args.idle)
            snap("idle")
            if not args.plain:
                snap("gc","/gc",{})
                snap("trim","/trim",{})
            report["ready_after"]=(await client.get("/health/ready")).json()
            report["status"]="COMPLETED"
    except BaseException as exc:
        report.update(status="FAILED",error_type=type(exc).__name__)
        raise
    finally:
        report["finished_at"]=now()
        save()
        result=command([DOCKER,"logs",API])
        (out/"api.log").write_text(result.stdout+result.stderr,encoding="utf-8")
    print(json.dumps({"case":args.case,"status":report["status"],"summary":report["summary"]}),flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--case",required=True)
    parser.add_argument("--arenas",type=int,default=0)
    parser.add_argument("--requests",type=int,default=7200)
    parser.add_argument("--idle",type=int,default=120)
    parser.add_argument("--trace",action="store_true")
    parser.add_argument("--plain",action="store_true")
    parser.add_argument("--ablation",action="store_true")
    args=parser.parse_args()
    assert args.requests>0 and args.requests%400==0 and args.arenas>=0 and args.idle>=0
    assert not (args.trace and args.plain)
    assert not (args.ablation and args.plain)
    asyncio.run(main(args))
