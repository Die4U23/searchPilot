# 容器内存增长：THP 对照与一小时复验草稿

> 诊断数据来自 `comparison.json` 及其引用的原始记录。正式一小时复验 `hour-001` 在本草稿取证时仍为 **RUNNING**；下面没有填入其最终请求数、内存增量、健康检查、重启或通过结论。所有 MiB 均为 1,048,576 字节。

## 已得到的结论与尚未证明的部分

当前证据支持：在这台 Linux/Docker 主机、这套冻结模型与固定查询负载下，透明大页（THP）是请求结束后仍出现 RSS 增长的一个可干预原因。新进程启动前禁用 THP 后，该次 120 秒空闲阶段的持续增长消失；恢复默认策略的下一轮重新出现增长。这个 A/B/A 结果比 RSS 与 THP 数值同涨的相关性更有说服力。

它不证明全部 RSS 增量都来自 THP，也不证明所有堆对象没有泄漏。RSS、AnonHugePages、glibc 与 pymalloc 数值各有范围且互相重叠，不能相加；AnonHugePages 增加 68 MiB 也不意味着新增了 68 MiB RSS。大页合并会改变已经驻留页面的组织形式，稀疏区域的驻留放大只是其中一种影响。内核文档明确描述稀疏访问在 THP 下可能消耗更多内存，以及后台合并行为。[Linux THP 文档](https://docs.kernel.org/admin-guide/mm/transhuge.html)

## A/B/A 的可比较范围

实际顺序为 A：`diag-default-02`（09:38:19 UTC 开始）、B：`diag-no-thp-01`（09:45:58 UTC）、A：`diag-default-03`（09:54:07 UTC）。三轮均已完成；同一完整 API 镜像 `sha256:5dace93aa828fdece3cc5f689edf8c08db98f0d2a6900236cccbdafedbefed6d`，单进程、并发 4、4 种搜索模式、100 条固定查询，每轮正式 4,000/4,000 成功，另有 16 次预热。各模式正式 1,000 次；400 个查询/模式组合各重复 10 次，组合指纹仅一个版本，无丢失指纹。发出索引完整、无重复、无未配对请求。

三轮组合指纹摘要均为 `a9377fb06cab826cf8b5def316843eda59262b8dd6c1b750b03f714b2b1a8e96`，发出序列摘要均为 `33ca3e604bbc75e318335e473edca00587312a690ae369dce423ff3015038aae`。诊断 wrapper 的执行快照哈希三轮相同，为 `b064f68186ea0c4cdbda46105f108a8a8dc99056ad0b8dd9e48daa0b71d8ca3d`。实验驱动在第一轮后增加了 THP 开关，因此第一轮驱动文件哈希不同；B 与恢复 A 的驱动哈希完全相同。各轮 `*.executed.py` 必须随原始证据保留，不能用最终重构后的脚本替代历史执行文件。

| 轮次 | 策略 | 预热后至 4,000 次结束 RSS 增量 | 随后约 120 秒空闲 RSS 增量 | 预热后至空闲结束 RSS 增量 | 同区间 AnonHugePages 增量 |
|---|---|---:|---:|---:|---:|
| A：default-02 | 系统默认 | +62.24219 MiB | +13.95703 MiB | +76.19922 MiB | +128 MiB |
| B：no-thp-01 | 进程禁用 THP | +37.49219 MiB | −0.61328 MiB | +36.87891 MiB | 0 MiB |
| A：default-03 | 恢复默认 | +72.37891 MiB | +15.14453 MiB | +87.52344 MiB | +126 MiB |

B 轮所采快照的 `THP_enabled` 为 0、`AnonHugePages` 为 0；A 轮为 1。这里 `THP_enabled` 是 `/proc` 状态字段，不能与 `PR_GET_THP_DISABLE` 返回值混为一谈：GET 返回 1 才表示禁用。独立 Linux exec smoke 已分别验证开关 true 后 GET=1、false 后 GET=0。

吞吐与延迟只作本轮观察：A/B/A 请求区段汇总 QPS 分别为 13.7288、13.9451、12.2698，成功请求 p95 分别为 490.173、484.602、581.556 ms。其分母是各请求区段耗时之和，不包含区段间采样暂停；并非全实验墙钟吞吐。只有一次 B 轮、共享主机、非随机执行顺序，不能据此宣称稳定吞吐提升或已完成性能非劣验证。默认条件下另有 `diag-default-01` 与无控制线程的 `plain-default-01` 复现空闲增长，后者约 120 秒空闲 RSS 增加 17.06250 MiB，说明现象并非只出现在诊断 HTTP 控制线程存在时。

## 为什么没有直接把它叫作 Python 泄漏

`diag-default-02` 的第 400 次、4,000 次和空闲结束检查点，pymalloc 当前 arena 均为 642（673,185,792 字节）。已分配块依次为 641,792,384、641,850,464、641,803,888 字节；从 400 到 4,000 次只增加 58,080 字节。相同区段 glibc `uordblks` 从 238,258,288 降为 238,098,960，空闲后进一步降为 236,784,864；glibc heap 数为 70，`hblkhd` 为 100,610,048 字节。它们不能解释为与 RSS 同量的活对象持续累积，也不能排除未覆盖分配域的保留。

CPython 的 pymalloc 本身管理小对象 arena，不能代表所有扩展库和原生缓冲区。本轮只把其内部统计作为可选诊断来源，限定已核对的 CPython 3.12 ABI，通过保留 GIL 的 `ctypes.pythonapi` 把输出定向到临时 FILE；不重定向进程 stderr。缺符号或缺字段记为不可用，不填零。[CPython 内存管理文档](https://docs.python.org/3.12/c-api/memory.html#the-pymalloc-allocator)、[3.12 内部声明](https://github.com/python/cpython/blob/3.12/Include/internal/pycore_obmalloc.h)

另一个独立短进程探针确认，64 MiB Torch 张量分配体现在 glibc mmap 统计，释放后相应值回落；1,024 个 32 KiB 张量也反映在 glibc 分配统计中。它仅说明这些探针分配可被观察，不证明整站所有 Tensor/缓存都由同一统计完整覆盖。已加载 `libtorch_cpu.so` 未导出 `mkl_mem_stat`，记录为 unavailable；没有另载 MKL 实例，也没有把“符号不可用”写成“MKL 缓存为零”。A/B/A 均未开启 tracemalloc，不能据此提供 Python 分配栈归因。

## 映射证据与归因边界

`diag-default-02/maps-mid-late.json` 比较两份保存的 smaps：一个地址区间固定的 1 GiB 无名匿名映射 `2a030c00000-2a070c00000`，Size 不变，RSS/Anonymous 增加 17,735,680 字节（16.9140625 MiB），AnonHugePages 增加 71,303,168 字节（68 MiB）。整个进程在该组两次采样间 RSS 增加 18,223,104 字节。这把增长定位到了具体映射，而非仅看到 Docker 四舍五入后的容器总量。

该映射的创建者仍未知。空路径不能证明它属于 Python、glibc arena、Torch、MKL 或某一模型；确定所有权需要额外的分配调用跟踪。地址匹配也不能排除采样间发生地址复用。当前修复针对经干预验证的 THP 行为，不虚构具体库归属。

## 生产修复和诊断干预的区别

生产仅在 `scripts/docker_entrypoint.py` 的迁移、seed 与模型导入前设置本进程策略：默认 `SEARCHPILOT_DISABLE_THP=true`，调用 `prctl(PR_SET_THP_DISABLE,1,0,0,0)` 后用 GET 严格核验。标志跨 fork/exec 保留，不写宿主 sysfs，不增加容器权限。false 会执行 SET0 清除继承禁用标志，恢复系统策略；这不保证系统一定分配大页。其他平台明确 `applied=false`；非法布尔值、Linux syscall 不可用/失败、GET 不符都显式失败并阻止进入 API。日志只保留 requested/applied/policy，错误不回显环境变量内容。[内核进程级 THP 控制](https://docs.kernel.org/admin-guide/mm/transhuge.html#process-thp-controls)

GC 与 trim 仅在已结束负载的诊断进程中显式调用。A/B/A 的 GC 检查点 RSS 变化分别为 0、0、4 KiB；随后 trim 下降约 33.52、31.81、33.47 MiB。能回收一部分内存说明存在可回收保留，但不等于定期 trim 能解决 THP 增长。本次没有增加生产定时 GC/trim，没有更换分配器，也没有实施或验证 `MALLOC_ARENA_MAX=2`、关闭原生缓存等候选方案；不得宣称这些未执行方案有收益。

## 原始证据、失败记录和待完成验证

交付证据应逐文件复制并记录哈希，包括：各轮 summary、请求 JSONL、完整诊断快照（原始 malloc_info XML/pymalloc 文本）、smaps 与离线差分、镜像和包版本、驱动与 wrapper 执行快照、独立 native probe、内核配置、Linux smoke、测试输出及清理记录。不得覆盖先前失败、把后来的绿色输出改名冒充第一次通过，或混入私有 `.env`。

保留的失败包括 `unit-final.txt`：1 failed、620 passed、68 subtests passed，失败来自 Windows loopback 测试 80ms 总超时预算下，两次连接未及时收到响应头。测试预算改为 500ms，5ms 滴流与 2s 无响应分支保持不变，并保留全部请求超时、响应头状态和总耗时断言；`unit-repaired.txt` 为 621 passed、3 skipped、14 deselected、68 subtests passed。`targeted-tests-final.txt` 另保留诊断控制请求测试一次失败（1 failed、24 passed、3 skipped），其修复后的 `targeted-tests-repaired.txt` 为 25 passed、3 skipped。失败及其修复不应删除；Windows 跳过的 Linux 项由独立 Linux smoke 补充实际证据，不能把 skip 计作通过。

`pre-hour-integrity.json` 已核对冻结的 migrations、queries/labels.csv、搜索/LTR/向量与 CTR 模型产物哈希，全部未变。它是正式一小时开始前的检查，结束后还需再次核对，不能提前当作最终完整性结论。annotator 与原始实验来源不改写。私有 `.env` 不进入 Git 或证据归档；本轮没有外部 LLM 请求。

正式复验由 `sp-thp-hour-20261023` 项目和镜像 `searchpilot-validation:2026-10-23-thp` 执行，独立端口 18084/15435，60 秒基线、3600 秒正式窗口、并发 4、120 秒恢复。驱动于 2026-10-23 10:10:15 UTC 启动，负载子进程于 10:12:03 UTC 启动；精确正式窗口以 benchmark 自身时间戳为准。取证时状态仍为 RUNNING。请求分母、12 个五分钟窗口、进程/容器/客户端内存、恢复期、17 项业务及重启反馈、源文件一致性、最终 CI/合并状态，均留待结束后据实填写。
