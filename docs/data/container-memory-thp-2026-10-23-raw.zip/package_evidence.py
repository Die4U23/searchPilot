"""Archive the owned evidence tree only after completion, with per-file integrity checks."""
import hashlib
import json
import re
import zipfile
from pathlib import Path

from dotenv import dotenv_values

root = Path(__file__).resolve().parent
repo = root.parents[1]
destination = repo / "docs/data/container-memory-thp-2026-10-23-raw.zip"
assert json.loads((root / "hour-001/summary.json").read_text())["status"] == "COMPLETED"
assert json.loads((root / "analysis.json").read_text())["status"] == "PASSED"
assert json.loads((root / "final-integrity.json").read_text())["passed"]
allowed_dirs = {"setup", "diag-default-01", "plain-default-01", "diag-default-02",
                "diag-no-thp-01", "diag-default-03", "hour-001", "image-context", "thp_candidate"}
allowed_suffixes = {".json", ".jsonl", ".txt", ".py", ".md", ".yml", ".diff", ".png", ".log", ".pid", ".start"}
names = []
for path in sorted(root.rglob("*")):
    if not path.is_file() or "__pycache__" in path.parts:
        continue
    relative = path.relative_to(root)
    if len(relative.parts) > 1 and relative.parts[0] not in allowed_dirs:
        raise ValueError("Unrecognized evidence directory: " + str(relative))
    if path.suffix not in allowed_suffixes and path.name != "Dockerfile":
        raise ValueError("Unrecognized evidence type: " + str(relative))
    if path.name in {"archive-verification.json", "monitor.json"}:
        continue
    names.append(relative.as_posix())
required = {"summary.json", "analysis.json", "compact-comparison.json", "final-integrity.json",
            "integration-final.txt", "unit-repaired.txt", "linux-smoke.json", "cleanup-hour.json"}
assert required <= set(names), required-set(names)
# Inspect private values only in memory; never print their values or serialize .env.
secrets = [value.encode() for key,value in dotenv_values(repo / ".env").items()
           if value and len(value) >= 8 and value != "searchpilot"
           and re.search(r"KEY|TOKEN|SECRET|PASSWORD", key, re.I)]
manifest = {}
for name in names:
    data = (root / name).read_bytes()
    if any(value in data for value in secrets):
        raise ValueError("Private credential value found in evidence: " + name)
    manifest[name] = {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(destination,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name in names:
        archive.write(root / name,name)
    archive.writestr("SHA256SUMS.json",json.dumps(manifest,indent=2)+"\n")
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name in names:
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == manifest[name]["sha256"]
        assert not any(value in data for value in secrets)
record = {"path":destination.relative_to(repo).as_posix(),"files":len(names),
          "bytes":destination.stat().st_size,"sha256":hashlib.sha256(destination.read_bytes()).hexdigest(),
          "every_member_hash_verified":True,"private_credential_matches":0}
(root/"archive-verification.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
