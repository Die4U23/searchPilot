import asyncio
import json
from argparse import Namespace
from pathlib import Path

import httpx
from scripts.validate_container_soak import Harness

root = Path(__file__).resolve().parent
h = Harness(Namespace(out=root / "setup", project="sp-allocator-20261023",
                      image="searchpilot-validation:2026-10-23-memory", api_port=18083,
                      db_port=15434, data_version="d3a904f41240", duration_seconds=3600,
                      concurrency=4, baseline_seconds=60, recovery_seconds=120))
h.prepare()
h.command(h.compose + ["up", "-d", "--no-build"], timeout=120)
async def check():
    async with httpx.AsyncClient(base_url=h.base) as client:
        h.report["ready"] = await h.readiness(client)
asyncio.run(check())
h.report["counts"] = h.counts()
h.provenance()
h.report["state"] = h.state()
h.report["status"] = "READY_FOR_DIAGNOSTIC_RESTART"
h.save()
print(json.dumps({"status":h.report["status"],"counts":h.report["counts"]}), flush=True)
