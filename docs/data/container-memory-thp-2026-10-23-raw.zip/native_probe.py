"""Standalone Linux native-allocator probe; run between API experiments, not alongside load.

Uses only standard library and the already-installed torch. Never loads another MKL
instance, redirects stderr, invokes GC/trim, or reads a private .env. Measurements
are sequential and include small Python/reporting allocations. All byte sizes are
binary MiB. No assertion equates glibc/MKL/Python allocator scopes with process RSS.
"""

from __future__ import annotations

import ctypes
import json
import os
import sys
import tempfile
from datetime import UTC, datetime
from pathlib import Path


class Mallinfo2(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_size_t)
        for name in (
            "arena",
            "ordblks",
            "smblks",
            "hblks",
            "hblkhd",
            "usmblks",
            "fsmblks",
            "uordblks",
            "fordblks",
            "keepcost",
        )
    ]


def observe(function):
    try:
        return {"available": True, "data": function()}
    except Exception as exc:
        return {"available": False, "error_type": type(exc).__name__, "message": str(exc)}


def function(library, name, args, result):
    fn = getattr(library, name)
    fn.argtypes, fn.restype = args, result
    return fn


def mkl_reader():
    """Resolve only an existing mapping. RTLD_NOLOAD forbids loading a fresh library."""
    paths = set()
    for line in Path("/proc/self/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].endswith("/libtorch_cpu.so"):
            paths.add(fields[5])
    if len(paths) != 1:
        raise RuntimeError(f"expected one mapped libtorch_cpu.so, found {len(paths)}")
    if not hasattr(os, "RTLD_NOLOAD"):
        raise RuntimeError("RTLD_NOLOAD unavailable; refusing to load a library")
    path = paths.pop()
    library = ctypes.CDLL(path, mode=os.RTLD_NOLOAD | os.RTLD_NOW)
    read = function(library, "mkl_mem_stat", [ctypes.POINTER(ctypes.c_int)], ctypes.c_int64)

    def snapshot():
        buffers = ctypes.c_int()
        count = read(ctypes.byref(buffers))
        # Keep library and symbol alive for the complete independent probe.
        return {
            "bytes": count,
            "buffers": buffers.value,
            "library": library._name,
            "resolution": "existing mapping via RTLD_NOLOAD",
        }

    return snapshot


def pymalloc_stats(libc):
    # CPython 3.12 internal/pycore_obmalloc.h declares int ...(FILE *out).
    # pythonapi is PyDLL: keep the GIL while invoking CPython allocator internals.
    read = function(ctypes.pythonapi, "_PyObject_DebugMallocStats", [ctypes.c_void_p], ctypes.c_int)
    fdopen = function(libc, "fdopen", [ctypes.c_int, ctypes.c_char_p], ctypes.c_void_p)
    fclose = function(libc, "fclose", [ctypes.c_void_p], ctypes.c_int)
    with tempfile.TemporaryFile(mode="w+b") as output:
        duplicate = os.dup(output.fileno())
        stream = fdopen(duplicate, b"w")
        if not stream:
            os.close(duplicate)
            raise OSError(ctypes.get_errno(), "fdopen failed")
        try:
            result = read(stream)
        finally:
            closed = fclose(stream)
        if closed:
            raise OSError(ctypes.get_errno(), "fclose failed")
        output.seek(0)
        raw = output.read(1024 * 1024 + 1)
    if len(raw) > 1024 * 1024:
        raise ValueError("pymalloc stats exceed 1 MiB")
    return {
        "return_code": result,
        "text": raw.decode("utf-8", errors="replace"),
        "destination": "explicit temporary FILE*, no global stderr redirection",
    }


def main():
    if sys.platform != "linux":
        raise RuntimeError("this independent probe requires Linux")
    import torch

    libc = ctypes.CDLL(None, use_errno=True)
    mallinfo = function(libc, "mallinfo2", [], Mallinfo2)
    try:
        read_mkl = mkl_reader()
        mkl_resolution = {"available": True}
    except Exception as exc:
        read_mkl = None
        mkl_resolution = {"available": False, "error_type": type(exc).__name__, "message": str(exc)}

    rows = []

    def sample(stage, live_tensor_bytes):
        fields = mallinfo()
        rows.append(
            {
                "stage": stage,
                "at": datetime.now(UTC).isoformat(),
                "live_probe_tensor_bytes": live_tensor_bytes,
                "mallinfo2": {name: getattr(fields, name) for name, _ in Mallinfo2._fields_},
                "mkl_mem_stat": observe(read_mkl) if read_mkl else mkl_resolution,
                "smaps_rollup": observe(lambda: Path("/proc/self/smaps_rollup").read_text()),
            }
        )

    warmup = torch.empty(1024, dtype=torch.uint8)
    warmup.fill_(1)
    del warmup
    initial_python = observe(lambda: pymalloc_stats(libc))
    sample("baseline_after_tiny_fill", 0)
    large = torch.empty(64 * 1024 * 1024, dtype=torch.uint8)
    sample("large_empty", 64 * 1024 * 1024)
    large.fill_(1)
    sample("large_filled", 64 * 1024 * 1024)
    del large
    sample("large_deleted", 0)
    small = [torch.empty(32 * 1024, dtype=torch.uint8) for _ in range(1024)]
    sample("small_1024_allocated", 32 * 1024 * 1024)
    for index in range(len(small)):
        small[index].fill_(1)
    sample("small_1024_filled", 32 * 1024 * 1024)
    del small
    sample("small_1024_deleted", 0)
    final_python = observe(lambda: pymalloc_stats(libc))
    report = {
        "schema_version": 1,
        "pid": os.getpid(),
        "python": sys.version,
        "torch": torch.__version__,
        "torch_num_threads": torch.get_num_threads(),
        "torch_num_interop_threads": torch.get_num_interop_threads(),
        "method": __doc__,
        "mkl_resolution": mkl_resolution,
        "samples": rows,
        "pymalloc_before": initial_python,
        "pymalloc_after": final_python,
        "environment": {
            key: os.environ.get(key)
            for key in ("MALLOC_ARENA_MAX", "MALLOC_TRIM_THRESHOLD_", "PYTHONMALLOC")
        },
    }
    print(json.dumps(report, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
