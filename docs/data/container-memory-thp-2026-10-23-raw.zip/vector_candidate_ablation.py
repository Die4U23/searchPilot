"""Experimental candidate-selection ablation; not a production change.

Import this file and call install() BEFORE constructing any VectorIndex in a fresh
diagnostic API process. No encoder, model, normalization, or scoring is replaced.
The per-index lexical rank is built before the measurement baseline and costs
O(N) persistent NumPy storage. Each search still uses O(N) native temporary
storage, but creates Python result objects for only the selected k rows.

Run with --self-check for a lightweight, model-free original-implementation
oracle comparison. This establishes behavior on those inputs, not memory gains.
"""

from __future__ import annotations

import argparse
import json
import warnings
from typing import Any

import numpy as np

from searchpilot.search.vector_index import (
    VectorIndex,
    l2_normalize_vector,
    make_vector_meta,
)

ORIGINAL_INIT = VectorIndex.__init__
ORIGINAL_SEARCH = VectorIndex.search


def _init(self: VectorIndex, *args: Any, **kwargs: Any) -> None:
    ORIGINAL_INIT(self, *args, **kwargs)
    # Python's stable string sort matches the oracle's item_id comparison;
    # equal IDs retain ascending original row order, as heapq.nsmallest does.
    lexical_rows = sorted(range(len(self.item_ids)), key=self.item_ids.__getitem__)
    rank = np.empty(len(lexical_rows), dtype=np.intp)
    rank[np.asarray(lexical_rows, dtype=np.intp)] = np.arange(len(rank), dtype=np.intp)
    rank.flags.writeable = False
    self._ablation_id_rank = rank


def _search(
    self: VectorIndex, query: np.ndarray, limit: int, *, category: str | None = None
) -> list[tuple[str, float]]:
    if limit < 1:
        raise ValueError("limit must be >= 1")
    if self.matrix.shape[0] == 0:
        return []
    vector = l2_normalize_vector(query)
    if vector.shape[0] != self.matrix.shape[1]:
        raise ValueError(
            f"query dim {vector.shape[0]} does not match index dim {self.matrix.shape[1]}"
        )
    if float(np.linalg.norm(vector)) == 0.0:
        return []
    scores = self.matrix @ vector
    eligible = np.ones(scores.shape[0], dtype=bool)
    if category is not None:
        wanted = category.casefold()
        eligible = np.fromiter(
            (value.casefold() == wanted for value in self.categories),
            dtype=bool,
            count=len(self.categories),
        )
    scores = np.where(eligible, scores, -np.inf)
    finite_rows = np.flatnonzero(np.isfinite(scores))
    finite_count = len(finite_rows)
    if finite_count == 0:
        return []
    k = min(limit, finite_count)
    try:
        rank = self._ablation_id_rank
    except AttributeError as exc:
        raise RuntimeError("Call install() before constructing VectorIndex instances") from exc

    if k == finite_count:
        chosen = finite_rows
    else:
        values = scores[finite_rows]
        cutoff = np.partition(values, finite_count - k)[finite_count - k]
        above = finite_rows[values > cutoff]
        tied = finite_rows[values == cutoff]
        needed = k - len(above)
        # Selecting arbitrary score-tied rows and sorting them afterwards is
        # incorrect: the globally smallest item IDs at the cutoff must survive.
        if len(tied) > needed:
            positions = np.argpartition(rank[tied], needed - 1)[:needed]
            tied = tied[positions]
        chosen = np.concatenate((above, tied))
    chosen = chosen[np.lexsort((rank[chosen], -scores[chosen]))]
    return [(self.item_ids[row], float(scores[row])) for row in chosen]


def install() -> None:
    """Install once before index construction; leave existing unrelated patches alone."""
    if VectorIndex.__init__ is _init and VectorIndex.search is _search:
        return
    if VectorIndex.__init__ is not ORIGINAL_INIT or VectorIndex.search is not ORIGINAL_SEARCH:
        raise RuntimeError("VectorIndex has another patch; refusing to combine ablations")
    VectorIndex.__init__ = _init
    VectorIndex.search = _search


def self_check() -> dict[str, Any]:
    """Compare IDs, exact float hex strings, and exceptions; restore class afterwards."""
    comparisons = 0
    rng = np.random.default_rng(20261023)

    def compare(index: VectorIndex, query: np.ndarray, limit: int, category=None) -> None:
        nonlocal comparisons

        def outcome(search):
            try:
                result = search(index, query, limit, category=category)
                return ("result", [(item_id, score.hex()) for item_id, score in result])
            except Exception as exc:
                return ("error", type(exc).__name__, str(exc))

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            expected = outcome(ORIGINAL_SEARCH)
            actual = outcome(VectorIndex.search)
        if actual != expected:
            raise AssertionError(
                f"Mismatch #{comparisons}: limit={limit}, category={category!r}, "
                f"expected={expected!r}, actual={actual!r}"
            )
        comparisons += 1

    def make(matrix: np.ndarray, ids: tuple[str, ...] | None = None) -> VectorIndex:
        n = len(matrix)
        if ids is None:
            ids = tuple(f"item-{n - row:06}" for row in range(n))
        categories = tuple("NeWs" if row % 2 else "Straße" for row in range(n))
        meta = make_vector_meta(
            matrix=matrix,
            model_name="ablation-fixture",
            data_version="fixture",
            input_sha256={},
            query_prefix="",
        )
        return VectorIndex(ids, categories, matrix, meta)

    install()
    try:
        install()  # Idempotence matters when a diagnostic bootstrap imports twice.
        for n in (0, 1, 2, 17, 257):
            for dim in (1, 7):
                matrix = rng.normal(size=(n, dim)).astype(np.float32)
                if n > 3:
                    matrix[1::3] = matrix[0]  # Exact ties at multiple cutoffs.
                ids = tuple(("α", "A", "a", "é", "😀", "A")[row % 6] for row in range(n))
                index = make(matrix, ids)
                if index._ablation_id_rank.flags.writeable:
                    raise AssertionError("lexical ranks must be read-only")
                queries = [np.zeros(dim, dtype=np.float32)]
                queries += [rng.normal(size=dim).astype(np.float32) for _ in range(4)]
                queries += [np.full(dim, np.nan), np.full(dim, np.inf)]
                for query in queries:
                    for limit in sorted({1, 2, 10, max(n - 1, 1), max(n, 1), n + 5}):
                        for category in (None, "NEWS", "STRASSE", "missing"):
                            compare(index, query, limit, category)
                compare(index, np.ones(dim + 1), 1)
                compare(index, np.ones(dim), 0)
                compare(index, np.ones(dim), -1)

        # All ties with a corpus-sized candidate set, shuffled IDs and duplicate IDs.
        n = 65_238
        ids = tuple(f"id-{row // 2:06}" for row in rng.permutation(n))
        index = make(np.ones((n, 1), dtype=np.float32), ids)
        for limit in (1, 10, 100, n - 1, n, n + 1):
            compare(index, np.ones(1), limit)

        # Nonfinite rows are excluded, negative scores remain eligible, signed
        # zero is retained exactly in results, and category filtering stays first.
        index = make(np.array([[np.nan], [np.inf], [-np.inf], [0.0], [-0.0], [-1.0]]))
        for limit in (1, 2, 6, 10):
            for category in (None, "NEWS", "STRASSE", "missing"):
                compare(index, np.ones(1), limit, category)
        return {
            "status": "PASSED",
            "comparisons": comparisons,
            "seed": 20261023,
            "scope": "model-free behavior oracle; no memory-performance claim",
        }
    finally:
        VectorIndex.__init__ = ORIGINAL_INIT
        VectorIndex.search = ORIGINAL_SEARCH


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-check", action="store_true", required=True)
    parser.parse_args()
    print(json.dumps(self_check(), ensure_ascii=False))
