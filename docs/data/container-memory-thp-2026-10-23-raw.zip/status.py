import json
from pathlib import Path

root=Path(__file__).resolve().parent
for path in sorted(root.glob("*/summary.json")):
    if path.parent.name=="setup":
        continue
    d=json.loads(path.read_text())
    print(path.parent.name,d["status"],"blocks",len(d.get("blocks",[])))
    for row in d.get("snapshots",[]):
        s=row["data"].get("snapshot",row["data"])
        process=s.get("process",{}).get("data",s)
        smaps=process.get("sources",{}).get("smaps_rollup",{}).get("data",{})
        mall=s.get("allocator",{}).get("mallinfo2",{}).get("data",{})
        def mib(value):
            return round(value/1048576,3) if value is not None else None
        print(json.dumps({"label":row["label"],"rss":mib(smaps.get("Rss_bytes")),
              "anon":mib(smaps.get("Anonymous_bytes")),
              "heap_count":s.get("allocator",{}).get("malloc_info",{}).get("data",{}).get("heap_count"),
              **{k:mib(mall.get(k)) for k in ("arena","uordblks","fordblks","hblkhd")},
              "tracemalloc":s.get("tracemalloc"),
              "pymalloc":s.get("pymalloc",{}).get("data",{}).get("fields")}))
