"""Remove only the completed validation's explicitly identified Compose resources."""
import json
import subprocess
from pathlib import Path

from scripts.validate_container_soak import clean_environment

root = Path(__file__).resolve().parent
repo = root.parents[1]
docker = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
project = "sp-thp-hour-20261023"
volume = project + "_pgdata"
def command(args):
    return subprocess.run([docker, *args], cwd=repo, env=clean_environment(),
                          capture_output=True, text=True, encoding="utf-8", timeout=90, check=True)

assert json.loads((root / "hour-001/summary.json").read_text())["status"] == "COMPLETED"
own_volume = json.loads(command(["volume", "inspect", volume]).stdout)[0]
assert own_volume["Name"] == volume
assert own_volume["Labels"]["com.docker.compose.project"] == project
before = json.loads(command(["volume", "inspect", "searchpilot_pgdata"]).stdout)[0]
for name in (project + "-api-1", project + "-db-1"):
    container = json.loads(command(["inspect", name]).stdout)[0]
    assert container["Config"]["Labels"]["com.docker.compose.project"] == project
result = command(["compose", "--env-file", str(repo / ".env.example"), "-p", project,
                  "-f", str(repo / "docker-compose.yml"),
                  "-f", str(root / "hour-001/compose.override.yml"), "down", "--volumes"])
after = json.loads(command(["volume", "inspect", "searchpilot_pgdata"]).stdout)[0]
assert before == after
remaining = command(["volume", "ls", "--format", "{{.Name}}"]).stdout.splitlines()
assert volume not in remaining
assert not command(["ps", "-aq", "--filter", "label=com.docker.compose.project=" + project]).stdout.strip()
report = {"removed_project": project, "removed_volume": volume, "verified_volume": own_volume,
          "original_volume_metadata_unchanged": before == after, "remaining_volumes": remaining,
          "output": result.stdout + result.stderr, "exit_code": result.returncode}
(root / "cleanup-hour.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: value for key, value in report.items() if key != "verified_volume"}))
