"""Compare saved /proc/PID/smaps files offline; never inspect live processes.

Example: python maps.py --before before.smaps --after after.smaps --out maps-diff.json
Anonymous mappings cannot be attributed to Python, glibc arenas, or tensors from
smaps alone. Exact range matching does not rule out unobserved address reuse.
Resized/split/merged ranges appear as removed/added; category totals retain net change.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

HEADER = re.compile(
    r"^([0-9a-fA-F]+)-([0-9a-fA-F]+)\s+([r-][w-][x-][ps])\s+"
    r"([0-9a-fA-F]+)\s+(\S+)\s+(\d+)(?:\s+(.*))?$"
)
METRICS = (
    "Size",
    "Rss",
    "Pss",
    "Anonymous",
    "Private_Clean",
    "Private_Dirty",
    "Shared_Clean",
    "Shared_Dirty",
    "Swap",
    "AnonHugePages",
    "LazyFree",
)


def classify(path):
    if path == "[heap]":
        return "brk_heap"
    if path.startswith("[stack"):
        return "stack"
    if path in ("[vdso]", "[vvar]", "[vvar_vclock]", "[vsyscall]"):
        return "kernel_special"
    if not path:
        return "anonymous_unattributed"
    if path.startswith("[anon:") or path.startswith("[anon_shmem:"):
        return "named_anonymous_unattributed"
    if path.startswith("/dev/shm/") or path.startswith("/SYSV"):
        return "shared_memory"
    if path.startswith("["):
        return "other_special"
    clean = path.removesuffix(" (deleted)").lower()
    if re.search(r"\.so(?:\.|$)", clean):
        return "shared_library_file"
    if clean.endswith((".pt", ".pth", ".bin", ".npy", ".npz", ".safetensors", ".parquet")):
        return "model_or_data_file_candidate"
    return "other_file"


def parse_smaps(text):
    rows, current = [], None
    for line_number, line in enumerate(text.splitlines(), 1):
        match = HEADER.match(line)
        if match:
            start, end, permissions, offset, device, inode, path = match.groups()
            current = {
                "range": f"{start}-{end}",
                "start": int(start, 16),
                "end": int(end, 16),
                "permissions": permissions,
                "offset": int(offset, 16),
                "device": device,
                "inode": int(inode),
                "path": path or "",
                "bytes": {},
            }
            if current["end"] <= current["start"]:
                raise ValueError(f"invalid mapping range at line {line_number}")
            current["category"] = classify(current["path"])
            rows.append(current)
            continue
        if not line.strip():
            continue
        if current is None:
            raise ValueError(f"smaps content before first mapping at line {line_number}")
        if ":" not in line:
            raise ValueError(f"unrecognized smaps line {line_number}")
        key, value = line.split(":", 1)
        if key in METRICS:
            fields = value.split()
            if len(fields) != 2 or fields[1] != "kB" or not fields[0].isdigit():
                raise ValueError(f"invalid {key} field at line {line_number}")
            if key in current["bytes"]:
                raise ValueError(f"duplicate {key} field at line {line_number}")
            current["bytes"][key] = int(fields[0]) * 1024
        elif key == "VmFlags":
            current["vm_flags"] = value.split()
    if not rows:
        raise ValueError("empty smaps input")
    identities = [identity(row) for row in rows]
    if len(identities) != len(set(identities)):
        raise ValueError("duplicate mapping identity")
    return rows


def identity(row):
    return tuple(
        row[k] for k in ("start", "end", "permissions", "offset", "device", "inode", "path")
    )


def aggregate(rows):
    return {
        "mapping_count": len(rows),
        "address_span_bytes": sum(r["end"] - r["start"] for r in rows),
        "bytes": {
            name: {
                "known_total": sum(r["bytes"].get(name, 0) for r in rows),
                "available_mappings": sum(name in r["bytes"] for r in rows),
                "missing_mappings": sum(name not in r["bytes"] for r in rows),
            }
            for name in METRICS
        },
    }


def group(rows, key):
    groups = defaultdict(list)
    for row in rows:
        groups[row[key]].append(row)
    return {name: aggregate(values) for name, values in sorted(groups.items())}


def aggregate_delta(before, after):
    return {
        name: (
            after["bytes"][name]["known_total"] - before["bytes"][name]["known_total"]
            if not before["bytes"][name]["missing_mappings"]
            and not after["bytes"][name]["missing_mappings"]
            else None
        )
        for name in METRICS
    }


def compare(before, after):
    left, right = {identity(r): r for r in before}, {identity(r): r for r in after}
    changes = []
    for key in left.keys() | right.keys():
        old, new = left.get(key), right.get(key)
        mapping = new or old
        change = "matched" if old and new else "added" if new else "removed"
        deltas = {}
        for metric in METRICS:
            old_value = old["bytes"].get(metric) if old else 0
            new_value = new["bytes"].get(metric) if new else 0
            deltas[metric] = (
                new_value - old_value if old_value is not None and new_value is not None else None
            )
        changes.append(
            {
                "change": change,
                "range": mapping["range"],
                "path": mapping["path"],
                "category": mapping["category"],
                "permissions": mapping["permissions"],
                "before_bytes": old["bytes"] if old else None,
                "after_bytes": new["bytes"] if new else None,
                "delta_bytes": deltas,
            }
        )
    changes.sort(key=lambda row: (-(row["delta_bytes"]["Rss"] or 0), row["range"], row["change"]))
    old_categories, new_categories = group(before, "category"), group(after, "category")
    categories = []
    for category in sorted(old_categories.keys() | new_categories.keys()):
        old = old_categories.get(category, aggregate([]))
        new = new_categories.get(category, aggregate([]))
        categories.append(
            {
                "category": category,
                "before": old,
                "after": new,
                "delta_bytes": aggregate_delta(old, new),
            }
        )
    categories.sort(key=lambda row: -(row["delta_bytes"]["Rss"] or 0))
    old_total, new_total = aggregate(before), aggregate(after)
    return {
        "schema_version": 1,
        "method": __doc__,
        "before": old_total,
        "after": new_total,
        "delta_bytes": aggregate_delta(old_total, new_total),
        "categories": categories,
        "mappings_by_rss_increase": changes,
        "interpretation": "Added/removed mapping contributions use zero only for an absent range; "
        "missing observed metric is null. Known totals exclude missing fields. "
        "Path categories describe mappings, not allocator ownership. "
        "File-backed mappings may have private COW anonymous pages.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--after", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    for source in (args.before, args.after):
        if args.out.resolve() == source.resolve() or (
            args.out.exists() and args.out.samefile(source)
        ):
            parser.error("output must not alias an input")
    if args.out.exists():
        parser.error("output already exists; choose a fresh path")
    before, after = args.before.read_bytes(), args.after.read_bytes()
    report = compare(parse_smaps(before.decode("utf-8")), parse_smaps(after.decode("utf-8")))
    report["inputs"] = {
        name: {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}
        for name, path, raw in (("before", args.before, before), ("after", args.after, after))
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
    print(json.dumps({"out": str(args.out), "delta_bytes": report["delta_bytes"]}))


if __name__ == "__main__":
    main()
