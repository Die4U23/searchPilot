"""One bounded diagnostic against frozen baseline, real saved index, and full-sort oracle."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import platform
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import numpy as np

from searchpilot.search.vector_index import l2_normalize_vector, load_vector_index

root = Path(__file__).resolve().parents[3]
baseline_source = root / ".tmp/perf-2026-10-14/baseline/src/searchpilot/search/vector_index.py"
candidate_source = root / "src/searchpilot/search/vector_index.py"
spec = importlib.util.spec_from_file_location("frozen_vector_baseline", baseline_source)
baseline = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = baseline
spec.loader.exec_module(baseline)
index = load_vector_index(root / "artifacts/search/vector")
old = baseline.VectorIndex(index.item_ids, index.categories, index.matrix, index.meta)
query = index.matrix[0].copy()
tick = time.perf_counter()
before = old.search(query, 100)
before_ms = (time.perf_counter() - tick) * 1000
tick = time.perf_counter()
after = index.search(query, 100)
after_ms = (time.perf_counter() - tick) * 1000
scores = index.matrix @ l2_normalize_vector(query)
reference = sorted(
    [(item_id, float(score)) for item_id, score in zip(index.item_ids, scores) if np.isfinite(score)],
    key=lambda row: (-row[1], row[0]),
)[:100]
tick = time.perf_counter()
old_candidates = [i for i in range(scores.shape[0]) if np.isfinite(scores[i])]
old_scan_ms = (time.perf_counter() - tick) * 1000
tick = time.perf_counter()
new_candidates = np.flatnonzero(np.isfinite(scores)).tolist()
new_scan_ms = (time.perf_counter() - tick) * 1000
report = {
    "at": datetime.now(UTC).isoformat(),
    "scope": "One real saved-index diagnostic; document embedding query, no encoder or HTTP",
    "limits": "Fixed baseline-then-candidate order; not ABBA or service performance acceptance",
    "command": [sys.executable, str(Path(__file__).resolve())],
    "python": platform.python_version(),
    "platform": platform.platform(),
    "numpy": np.__version__,
    "baseline_sha256": hashlib.sha256(baseline_source.read_bytes()).hexdigest(),
    "candidate_sha256": hashlib.sha256(candidate_source.read_bytes()).hexdigest(),
    "diagnostic_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "model_version": index.model_version,
    "data_version": index.meta.data_version,
    "embeddings_sha256": index.meta.embeddings_sha256,
    "shape": list(index.matrix.shape),
    "query_source": {"stored_row": 0, "item_id": index.item_ids[0]},
    "limit": 100,
    "baseline_search_ms": before_ms,
    "candidate_search_ms": after_ms,
    "baseline_scan_ms": old_scan_ms,
    "candidate_scan_ms": new_scan_ms,
    "candidate_indices_equal": old_candidates == new_candidates,
    "candidate_count": len(new_candidates),
    "baseline_candidate_full_sort_equal": before == after == reference,
    "results": after,
}
with Path(__file__).with_suffix(".json").open("x", encoding="utf-8") as file:
    json.dump(report, file, indent=2)
print(json.dumps({key: value for key, value in report.items() if key != "results"}, indent=2))
assert report["candidate_indices_equal"]
assert report["baseline_candidate_full_sort_equal"]
