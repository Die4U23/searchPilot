"""Local Windows experiment coordinator; preserved with the experiment evidence."""
import argparse
import asyncio
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.bench_concurrent import Config, request_once
import httpx

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--source', type=Path, required=True)
args = parser.parse_args()
source = args.source.resolve()
out = ROOT / 'artifacts/performance-2026-10-14' / args.label
out.mkdir(parents=True, exist_ok=False)
report = {'label': args.label, 'source': str(source), 'status': 'RUNNING', 'started_epoch': time.time()}
report['source_files'] = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*.py'))}
report['benchmark_sha256'] = hashlib.sha256((ROOT / 'scripts/bench_concurrent.py').read_bytes()).hexdigest()
env = os.environ.copy()
env.update(PYTHONPATH=str(source), SEARCHPILOT_DATABASE_URL='', SEARCHPILOT_API_TOKEN='',
           SEARCHPILOT_DATA_DIR=str(ROOT/'data'), SEARCHPILOT_ARTIFACT_DIR=str(ROOT/'artifacts'),
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false')
env['PERF_STOP_FILE']=str(out/'stop')
report['thread_env'] = {k: env.get(k) for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','TOKENIZERS_PARALLELISM')}
server_code = '''
import json, sys, threading, uvicorn, searchpilot, os, time, pathlib
print(json.dumps({'import_origin':searchpilot.__file__, 'pid':os.getpid()}), flush=True)
from searchpilot.bootstrap import create_app
from searchpilot.search.service import build_search_service
app=create_app(search=build_search_service(pathlib.Path(os.environ['SEARCHPILOT_ARTIFACT_DIR'])))
server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=18080,access_log=False))
def stop():
    marker=pathlib.Path(os.environ['PERF_STOP_FILE'])
    while not marker.exists(): time.sleep(0.2)
    server.should_exit=True
threading.Thread(target=stop,daemon=True).start()
server.run()
'''
server_log=(out/'server.log').open('x',encoding='utf-8')
proc=subprocess.Popen([sys.executable,'-u','-c',server_code],cwd=ROOT,env=env,stdin=subprocess.PIPE,stdout=server_log,stderr=subprocess.STDOUT,text=True)
report['launcher_pid']=proc.pid
for _ in range(100):
    lines=(out/'server.log').read_text(encoding='utf-8').splitlines()
    if lines:
        report['server_identity']=json.loads(lines[0]); break
    time.sleep(0.1)
report['pid']=report['server_identity']['pid']

class Memory(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(k,ctypes.c_size_t) for k in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
k32=ctypes.WinDLL('kernel32',use_last_error=True)
psapi=ctypes.WinDLL('psapi',use_last_error=True)
k32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
k32.OpenProcess.restype=wintypes.HANDLE
k32.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
k32.CloseHandle.argtypes=[wintypes.HANDLE]
psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD]
handle=k32.OpenProcess(0x0400|0x0010,False,report['pid'])
if not handle: raise ctypes.WinError(ctypes.get_last_error())
stop_sample=threading.Event()
samples=[]
def sample():
    while not stop_sample.is_set():
        times=[wintypes.FILETIME() for _ in range(4)]
        memory=Memory(); memory.cb=ctypes.sizeof(memory)
        ok=k32.GetProcessTimes(handle,*(ctypes.byref(t) for t in times)) and psapi.GetProcessMemoryInfo(handle,ctypes.byref(memory),memory.cb)
        if ok:
            cpu=sum((t.dwHighDateTime<<32)+t.dwLowDateTime for t in times[2:])/1e7
            samples.append({'at':time.time(),'cpu_seconds':cpu,'working_set_bytes':memory.WorkingSetSize,'lifetime_peak_working_set_bytes':memory.PeakWorkingSetSize})
        stop_sample.wait(0.5)
thread=threading.Thread(target=sample,daemon=True); thread.start()
base='http://127.0.0.1:18080'
try:
    with httpx.Client(trust_env=False,timeout=2) as client:
        deadline=time.monotonic()+90
        while True:
            if proc.poll() is not None: raise RuntimeError('server exited before readiness')
            try:
                response=client.get(base+'/health/ready')
                if response.status_code in (200,503) and all(response.json().get('checks',{}).get(k) for k in ('search','vector_index','ltr')):
                    report['initial_readiness']=response.json(); break
            except httpx.HTTPError: pass
            if time.monotonic()>deadline: raise RuntimeError('readiness deadline')
            time.sleep(0.5)
    report['ready_epoch']=time.time()
    async def cold():
        with (out/'cold.requests.jsonl').open('x',encoding='utf-8') as ledger:
            def event(row):
                ledger.write(json.dumps(row)+'\n'); ledger.flush()
            async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=30) as client:
                return await request_once(client,Config(base,requests=1,concurrency=1,timeout=30),index=0,mode='vector',query='microsoft',phase='first_vector',event_sink=event)
    report['first_vector']=asyncio.run(cold())
    report['measured_start_epoch']=time.time()
    command=[sys.executable,str(ROOT/'scripts/bench_concurrent.py'),'--base-url',base,'--requests','120','--concurrency','4','--timeout','10','--warmup','4','--limit','10','--modes','bm25','vector','hybrid','ltr','--data-version','d3a904f41240','--server-description',f'{args.label}; parent PID {proc.pid}; frozen source {source}; search-only production route; single worker no database offline encoder','--out',str(out/'results.json')]
    report['command']=command
    report['benchmark_exit']=subprocess.run(command,cwd=ROOT,env=env,check=False).returncode
    report['measured_end_epoch']=time.time()
    with httpx.Client(trust_env=False,timeout=5) as client:
        report['recovery']={path:{'status_code':r.status_code,'body':r.json()} for path in ('/health/live','/health/ready') for r in [client.get(base+path)]}
    report['status']='COMPLETED'
except BaseException as exc:
    report['status']='FAILED'; report['error_type']=type(exc).__name__; raise
finally:
    if proc.poll() is None:
        try:
            (out/'stop').touch(exist_ok=False); proc.wait(timeout=30)
            report['shutdown']='graceful'
        except (OSError,subprocess.TimeoutExpired):
            proc.kill(); proc.wait(timeout=10); report['shutdown']='forced'
    report['server_exit']=proc.returncode
    stop_sample.set(); thread.join(timeout=2); k32.CloseHandle(handle); server_log.close()
    report['finished_epoch']=time.time(); report['resource_samples']=samples
    with (out/'coordinator.json').open('x',encoding='utf-8') as file: json.dump(report,file,indent=2)
    print(json.dumps({'label':args.label,'status':report['status'],'shutdown':report.get('shutdown'),'first_vector':report.get('first_vector')}),flush=True)
