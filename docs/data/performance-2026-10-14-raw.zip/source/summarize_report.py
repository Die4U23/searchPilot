"""Read completed ABBA ledgers; recompute statistics and write only the two report files."""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "artifacts/performance-2026-10-14"
LABELS = ["A-search-1", "B-search-1", "B-search-2", "A-search-2"]
MODES = ["bm25", "vector", "hybrid", "ltr"]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def latency(rows):
    ordered = sorted(row["elapsed_ms"] for row in rows)
    return {
        "count": len(ordered),
        **{f"p{p}_ms": ordered[math.ceil(p / 100 * len(ordered)) - 1] if ordered else None
           for p in (50, 95, 99)},
        "max_ms": ordered[-1] if ordered else None,
    }


def summary(rows, elapsed):
    success = [row for row in rows if row["outcome"] == "success"]
    outcomes = dict(sorted(Counter(row["outcome"] for row in rows).items()))
    return {
        "total": len(rows), "successes": len(success), "failures": len(rows) - len(success),
        "success_rate": len(success) / len(rows), "outcomes": outcomes,
        "timeout_rate": outcomes.get("timeout", 0) / len(rows),
        "elapsed_seconds": elapsed,
        "successful_requests_per_second": len(success) / elapsed,
        "completed_requests_per_second": len(rows) / elapsed,
        "all_latency": latency(rows), "success_latency": latency(success),
        "model_versions": sorted({row["model_version"] for row in success}),
    }


def ledger_stats(path):
    events = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    pending = [row["request_id"] for row in events if row["event"] == "pending"]
    results = [row["request_id"] for row in events if row["event"] == "result"]
    return {
        "pending": len(pending), "results": len(results),
        "pending_unique": len(set(pending)), "result_unique": len(set(results)),
        "unmatched_pending": sorted(set(pending) - set(results)),
        "result_without_pending": sorted(set(results) - set(pending)),
    }


coordinators = {label: read(RAW / label / "coordinator.json") for label in LABELS}
results = {label: read(RAW / label / "results.json") for label in LABELS}
for label in LABELS:
    assert coordinators[label]["status"] == results[label]["status"] == "COMPLETED", label
    assert [run["mode"] for run in results[label]["runs"]] == MODES, label
    assert all(len(run["requests"]) == 120 and len(run["warmup"]) == 4
               for run in results[label]["runs"]), label

rounds = []
for label in LABELS:
    c, r = coordinators[label], results[label]
    sample = [row for row in c["resource_samples"]
              if c["measured_start_epoch"] <= row["at"] <= c["measured_end_epoch"]]
    assert len(sample) >= 2 and c["server_identity"]["pid"] == c["pid"], label
    cpu_delta = sample[-1]["cpu_seconds"] - sample[0]["cpu_seconds"]
    sampled_elapsed = sample[-1]["at"] - sample[0]["at"]
    warmup = [row for run in r["runs"] for row in run["warmup"]]
    rounds.append({
        "label": label, "variant": label[0], "status": "COMPLETED",
        "server_pid": c["pid"], "launcher_pid_not_sampled": c["launcher_pid"],
        "vector_source_sha256": c["source_files"]["searchpilot\\search\\vector_index.py"],
        "benchmark_sha256": c["benchmark_sha256"], "thread_env": c["thread_env"],
        "started_utc": datetime.fromtimestamp(c["started_epoch"], UTC).isoformat(),
        "finished_utc": datetime.fromtimestamp(c["finished_epoch"], UTC).isoformat(),
        "command_argv": c["command"],
        "first_vector_deadline_seconds": 30, "first_vector": c["first_vector"],
        "warmup": {"total": len(warmup), "outcomes": dict(Counter(x["outcome"] for x in warmup)),
                   "records": [{k: row[k] for k in ("mode", "index", "request_id", "outcome", "elapsed_ms")}
                               for row in warmup]},
        "modes": {run["mode"]: summary(run["requests"], run["summary"]["elapsed_seconds"])
                  for run in r["runs"]},
        "initial_readiness": c["initial_readiness"], "recovery": c["recovery"],
        "shutdown": c["shutdown"], "server_exit": c["server_exit"],
        "resource_window": {
            "measured_start_epoch": c["measured_start_epoch"], "measured_end_epoch": c["measured_end_epoch"],
            "nominal_sample_interval_seconds": 0.5, "sample_count": len(sample),
            "first_sample_epoch": sample[0]["at"], "last_sample_epoch": sample[-1]["at"],
            "sampled_elapsed_seconds": sampled_elapsed, "cpu_seconds_delta": cpu_delta,
            "cpu_core_equivalents": cpu_delta / sampled_elapsed,
            "cpu_percent_of_12_logical_processors": cpu_delta / sampled_elapsed / 12 * 100,
            "sampled_working_set_max_bytes": max(x["working_set_bytes"] for x in sample),
            "scope": "Only samples inside measured_start..end; includes 16 warmups and client setup. Sample max is not absolute peak.",
        },
        "ledger": {name: ledger_stats(RAW / label / name)
                   for name in ("cold.requests.jsonl", "results.requests.jsonl")},
        "raw_sha256": {name: digest(RAW / label / name)
                       for name in ("results.json", "coordinator.json", "cold.requests.jsonl", "results.requests.jsonl", "server.log")},
    })

aggregate = {}
for variant in ("A", "B"):
    aggregate[variant] = {}
    for mode in MODES:
        runs = [run for label in LABELS if label.startswith(variant)
                for run in results[label]["runs"] if run["mode"] == mode]
        aggregate[variant][mode] = summary([row for run in runs for row in run["requests"]],
                                           sum(run["summary"]["elapsed_seconds"] for run in runs))

reference = {(run["mode"], row["index"]): row
             for run in results[LABELS[0]]["runs"] for row in run["requests"]}
comparisons = []
for label in LABELS[1:]:
    mismatches = []
    for run in results[label]["runs"]:
        for row in run["requests"]:
            expected = reference[(run["mode"], row["index"])]
            differing = [key for key in ("query", "outcome", "result_sha256", "ranking_sha256", "model_version")
                         if row.get(key) != expected.get(key) or (key == "outcome" and row[key] != "success")]
            if differing:
                mismatches.append({"mode": run["mode"], "index": row["index"], "fields": differing})
    comparisons.append({"reference": LABELS[0], "candidate": label, "compared": 480,
                        "equal": 480 - len(mismatches), "mismatches": mismatches})

source_differences = [name for name in sorted(coordinators[LABELS[0]]["source_files"])
                      if coordinators[LABELS[0]]["source_files"][name] != coordinators[LABELS[1]]["source_files"].get(name)]
assert source_differences == ["searchpilot\\search\\vector_index.py"]
assert coordinators[LABELS[0]]["source_files"] == coordinators[LABELS[3]]["source_files"]
assert coordinators[LABELS[1]]["source_files"] == coordinators[LABELS[2]]["source_files"]
assert len({c["benchmark_sha256"] for c in coordinators.values()}) == 1
assert len({r["queries"]["sha256"] for r in results.values()}) == 1

changes = {}
for mode in MODES:
    a, b = aggregate["A"][mode], aggregate["B"][mode]
    changes[mode] = {f"p{p}_reduction_percent": (1 - b["all_latency"][f"p{p}_ms"] / a["all_latency"][f"p{p}_ms"]) * 100 for p in (50, 95, 99)}
    changes[mode]["throughput_increase_percent"] = (b["successful_requests_per_second"] / a["successful_requests_per_second"] - 1) * 100

evidence = {
    "schema_version": 1, "status": "COMPLETED", "source": "searchpilot",
    "protocol": "ABBA, 4 independent search-only HTTP servers; 120 requests/mode/round, concurrency4, deadline10s; independent first vector deadline30s",
    "summary_generated_utc": datetime.now(UTC).isoformat(),
    "summarizer_sha256": digest(Path(__file__)),
    "client_machine": results[LABELS[0]]["client_machine"], "queries": results[LABELS[0]]["queries"],
    "data_version": results[LABELS[0]]["data_version_declared"],
    "config": results[LABELS[0]]["config"],
    "source_differences": source_differences, "rounds": rounds,
    "aggregate_by_variant_and_mode": aggregate, "changes_B_relative_to_A": changes,
    "equivalence_comparisons": comparisons,
    "equivalence_scope": "Canonical JSON of results item_id/score/rank/channel plus model_version; not byte-identical full HTTP response. Request IDs differ.",
    "startup_failures": [
        {"label": "A1", "status": "FAILED", "search_requests_sent": 0,
         "cause": "Default application did not reach readiness in90s; forced shutdown; launcher-PID resource samples INVALID", "raw": "A1/coordinator.json"},
        {"label": "A1-retry", "status": "FAILED", "search_requests_sent": 0,
         "cause": "Default application traceback located recommend.ItemCF.fit; owned process terminated; no search benchmark", "raw": "A1-retry/server.log"},
    ],
    "raw_archive": {"status": "AVAILABLE", "local_root": "artifacts/performance-2026-10-14",
                    "repository_path": "docs/data/performance-2026-10-14-raw.zip",
                    "hash_note": "Archive digest is added after packaging; not embedded in its own member files."},
}
(ROOT / "docs/data/performance-2026-10-14-evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"aggregate": aggregate, "changes": changes, "comparisons": comparisons,
                  "resources": {r["label"]: r["resource_window"] for r in rounds},
                  "cold": {r["label"]: r["first_vector"]["elapsed_ms"] for r in rounds}}, ensure_ascii=False, indent=2))
