"""Isolated live Agent endpoint; uses application registry, no search models or database."""
from pathlib import Path
from searchpilot.bootstrap import create_app
from searchpilot.experiments.store import InMemoryExperimentStore

app = create_app(experiments=InMemoryExperimentStore.load(Path('/validation/registry.json')))
