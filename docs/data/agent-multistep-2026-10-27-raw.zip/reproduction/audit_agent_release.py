import hashlib,json,zipfile
from datetime import datetime,UTC
from pathlib import Path
from searchpilot.agent.multistep_eval import score_case,build_cases,SCORER_VERSION

repo=Path('E:/searchPilot')
base=repo/'artifacts'
release=base/'agent-multistep-2026-10-27-release'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def round_audit(paths):
    attempted={}; all_requests=set(); total=known=0
    for folder in paths:
        events=[json.loads(l) for l in (folder/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        manifest=events[0]
        assert manifest['inputs_sha256']==events[0]['inputs_sha256']
        pending=[e for e in events if e['event']=='request']
        results=[e for e in events if e['event']=='request_result']
        pids=[e['request_id'] for e in pending]; rids=[e['request_id'] for e in results]
        assert len(set(pids))==len(pids)==len(rids)==len(set(rids)) and set(pids)==set(rids)
        assert not (all_requests&set(pids));all_requests.update(pids)
        assert all(e['sent'] is True and e['usage_known'] is True for e in results)
        total+=sum(e['usage']['total_tokens'] for e in results);known+=len(results)
        for row in read(folder/'results.json'):
            if not row['attempted']:continue
            assert row['task_id'] not in attempted
            task_events=[e for e in results if e['task_id']==row['task_id']]
            assert len(task_events)==row['provider']['requests_sent']
            attempted[row['task_id']]=row
        summary=read(folder/'summary.json')
        assert summary['requests_sent']==len(pids)
    assert len(attempted)==8
    return {'requests':len(all_requests),'known_usage_requests':known,'total_tokens':total,
            'original_structured_pass':sum(r['scores']['structured_pass'] for r in attempted.values()),
            'completed':sum(r['status']=='completed' for r in attempted.values()),'tasks':8},attempted

v1, _=round_audit([base/'agent-multistep-2026-10-27'/p for p in ('smoke-001','remaining-007')])
v2, _=round_audit([base/'agent-multistep-2026-10-27-v2/final-008'])
final, rows=round_audit([base/'agent-multistep-2026-10-27-final/final-008'])
folder=base/'agent-multistep-2026-10-27-final/final-008'
cases=read(folder/'inputs.json')
assert cases==build_cases()
rescored=[]
for case in cases:
    row=rows[case['task_id']]
    rescored.append({'task_id':case['task_id'],'original':row['scores'],
                     'recomputed':score_case(case,row['result'])})
retro={'status':'RETROSPECTIVE_RESCORE','new_model_calls':0,'scorer_version':SCORER_VERSION,
       'scope':'Correct discovery-before-reads bug; preserves original preregistered 6/8 FAIL',
       'original_structured_pass':final['original_structured_pass'],
       'recomputed_structured_pass':sum(r['recomputed']['structured_pass'] for r in rescored),
       'tasks':rescored,'original_files_sha256':{n:sha(folder/n) for n in
           ('inputs.json','results.json','summary.json','events.jsonl')},
       'current_scorer_sha256':sha(repo/'src/searchpilot/agent/multistep_eval.py')}
with (release/'retrospective-rescore.json').open('x',encoding='utf-8') as f:
    json.dump(retro,f,ensure_ascii=False,indent=2)
api=read(base/'agent-multistep-2026-10-27-final/online-api.json')
assert api['accepted'] and api['response']['usage']['requests_sent']==4
diagnostic=read(base/'agent-multistep-2026-10-27/protocol-diagnostic.json')
summary={'checked_at':datetime.now(UTC).isoformat(),'scope':'Finite Agent implementation and synthetic evidence',
         'rounds':{'initial':v1,'protocol_repair':v2,'final_runtime_original_score':final},
         'retrospective_final_score':{'passed':retro['recomputed_structured_pass'],'tasks':8,
                                     'new_calls':0,'pre_registered':False},
         'api':{'accepted':True,'requests':4,'tokens':api['response']['usage']['total_tokens'],
                'scope':api['scope']},'diagnostic_requests':diagnostic['requests_sent'],
         'all_external_requests':sum(r['requests'] for r in (v1,v2,final))+4+diagnostic['requests_sent'],
         'all_known_tokens':sum(r['total_tokens'] for r in (v1,v2,final))+
             api['response']['usage']['total_tokens']+diagnostic['usage']['total_tokens'],
         'free_text_semantics':'UNSCORED','memory_stability':'PENDING_SEPARATE_VALIDATION'}
with (release/'evidence-summary.json').open('x',encoding='utf-8') as f:
    json.dump(summary,f,ensure_ascii=False,indent=2)
print(json.dumps(summary,ensure_ascii=False))
