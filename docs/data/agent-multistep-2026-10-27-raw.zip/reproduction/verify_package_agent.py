import hashlib,json,zipfile
from datetime import datetime,UTC
from pathlib import Path
from searchpilot.agent.multistep_eval import digest
repo=Path('E:/searchPilot'); base=repo/'artifacts'
names=['agent-multistep-2026-10-27','agent-multistep-2026-10-27-v2',
       'agent-multistep-2026-10-27-final','agent-multistep-2026-10-27-release']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
mapping={'provider':'src/searchpilot/agent/provider.py','runtime':'src/searchpilot/agent/runtime.py',
         'errors':'src/searchpilot/agent/errors.py','tools':'src/searchpilot/agent/tools.py',
         'experiment_store':'src/searchpilot/experiments/store.py',
         'evaluator':'src/searchpilot/agent/multistep_eval.py','cli':'scripts/evaluate_agent_multistep.py'}
verified=0
for name in names[:3]:
    root=base/name
    for snapshot_path,expected in read(root/'source-snapshot.json').items():
        assert sha(root/'source'/snapshot_path)==expected
    for folder in root.iterdir():
        if not (folder/'events.jsonl').is_file():continue
        events=[json.loads(l) for l in (folder/'events.jsonl').read_text(encoding='utf-8').splitlines()]
        manifest=events[0]
        assert manifest['inputs_sha256']==digest(read(folder/'inputs.json'))
        for key,path in mapping.items():assert manifest['source_sha256'][key]==sha(root/'source'/path)
        tasks=[{k:v for k,v in e.items() if k!='recorded_at'} for e in events if e['event']=='task_result']
        assert tasks==read(folder/'results.json')
        summary={k:v for k,v in events[-1].items() if k!='recorded_at'}
        assert summary==read(folder/'summary.json')
        verified+=1
release=base/names[-1]
manifest=read(release/'source-snapshot.json')
assert all(sha(repo/p)==v and sha(release/'source'/p)==v for p,v in manifest.items())
public=repo/'docs/data/agent-multistep-2026-10-27-raw.zip'
files={f'{name}/{p.relative_to(base/name).as_posix()}':p for name in names
       for p in (base/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for helper in ('audit_agent_release.py','verify_package_agent.py'):
    files['reproduction/'+helper]=repo/'.tmp'/helper
hashes={n:sha(p) for n,p in files.items()}
with zipfile.ZipFile(public,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in files.items():z.write(path,name)
    z.writestr('SHA256SUMS.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(public) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(hashes)+1
    for name,expected in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==expected==sha(files[name])
result={'status':'VERIFIED','archive':public.name,'sha256':sha(public),'bytes':public.stat().st_size,
        'evidence_members':len(hashes),'execution_shards':verified,
        'crc_and_all_member_hashes':True,'source_snapshots_and_manifest_hashes':True,
        'task_results_and_summary_match_durable_ledger':True,'checked_at':datetime.now(UTC).isoformat()}
with (release/'archive-verification.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
