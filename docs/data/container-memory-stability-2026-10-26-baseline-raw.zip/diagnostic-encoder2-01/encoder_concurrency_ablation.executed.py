"""Explicit diagnostic-only class patch; never imported by the normal application."""

from __future__ import annotations

import functools
import hashlib
import inspect
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

_installed = None


class EncoderLimiter:
    """Constant-size counters; no request text, result, exception, or thread retention."""

    def __init__(self, limit):
        if type(limit) is not int or limit not in (2, 32):
            raise ValueError("Diagnostic encoder limit must be 2 or 32")
        self.limit = limit
        self._semaphore = threading.BoundedSemaphore(limit)
        self._lock = threading.Lock()
        self._stats = dict(
            calls_started=0,
            calls_entered=0,
            calls_completed=0,
            errors=0,
            active=0,
            peak_active=0,
            waiting=0,
            peak_waiting=0,
            wait_seconds_total=0.0,
            wait_seconds_max=0.0,
            execution_seconds_total=0.0,
            execution_seconds_max=0.0,
        )

    def snapshot(self):
        with self._lock:
            return {"limit": self.limit, **self._stats}

    def call(self, original, instance, text):
        wait_start = time.perf_counter()
        with self._lock:
            self._stats["calls_started"] += 1
            self._stats["waiting"] += 1
            self._stats["peak_waiting"] = max(self._stats["peak_waiting"], self._stats["waiting"])
        acquired, entered, failed = False, False, False
        execution_start = None
        try:
            acquired = self._semaphore.acquire()
            waited = time.perf_counter() - wait_start
            with self._lock:
                self._stats["waiting"] -= 1
                self._stats["calls_entered"] += 1
                self._stats["active"] += 1
                self._stats["peak_active"] = max(self._stats["peak_active"], self._stats["active"])
                self._stats["wait_seconds_total"] += waited
                self._stats["wait_seconds_max"] = max(self._stats["wait_seconds_max"], waited)
                entered = True
            execution_start = time.perf_counter()
            return original(instance, text)
        except BaseException:
            failed = True
            raise
        finally:
            elapsed = time.perf_counter() - execution_start if execution_start is not None else 0.0
            try:
                with self._lock:
                    self._stats["calls_completed"] += 1
                    self._stats["errors"] += failed
                    if entered:
                        self._stats["active"] -= 1
                    else:
                        self._stats["waiting"] -= 1
                    self._stats["execution_seconds_total"] += elapsed
                    self._stats["execution_seconds_max"] = max(
                        self._stats["execution_seconds_max"], elapsed
                    )
            finally:
                if acquired:
                    self._semaphore.release()


def install(limit, *, encoder_class=None, diagnostic_class=None):
    """Install before app construction; injectable classes support model-free toy checks."""
    global _installed
    if _installed is not None:
        raise RuntimeError("Encoder diagnostic patch is already installed")
    limiter = EncoderLimiter(limit)
    if encoder_class is None:
        from searchpilot.search.vector_index import SentenceTransformerQueryEncoder

        encoder_class = SentenceTransformerQueryEncoder
    if diagnostic_class is None:
        from scripts.diagnose_allocator import Diagnostic

        diagnostic_class = Diagnostic
    original = encoder_class.__call__
    base_snapshot = diagnostic_class.snapshot
    source_path = inspect.getsourcefile(original)
    evidence = {
        "schema_version": 1,
        "installed_at": datetime.now(UTC).isoformat(),
        "patch_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "original_module": original.__module__,
        "original_qualname": original.__qualname__,
        "original_source_path": source_path,
        "original_source_sha256": hashlib.sha256(Path(source_path).read_bytes()).hexdigest()
        if source_path and Path(source_path).is_file()
        else None,
        "scope": "Class __call__, global process semaphore, same original implementation. "
        "Waiting includes acquisition overhead. Counters are bounded aggregates; "
        "native and encoder observations are sequential/non-atomic.",
    }

    @functools.wraps(original)
    def wrapped(instance, text):
        return limiter.call(original, instance, text)

    @functools.wraps(base_snapshot)
    def observed(instance):
        result = base_snapshot(instance)
        result["encoder_concurrency"] = {**evidence, **limiter.snapshot()}
        return result

    encoder_class.__call__ = wrapped
    diagnostic_class.snapshot = observed
    _installed = limiter
    return {**evidence, **limiter.snapshot()}
