"""Read only cached-file path/stat metadata; never read weight bytes or issue HTTP."""
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from scripts.validate_container_soak import clean_environment

root = Path(__file__).resolve().parent
code = '''import json
from pathlib import Path
blob=Path('/home/searchpilot/.cache/huggingface/hub/blobs/f3/f34dad568ecbc8f2452ae7ea84e72884e1bab4f299cec39fd8f978b5fba8d3c9')
model=Path('/home/searchpilot/.cache/huggingface/hub/models--BAAI--bge-small-en-v1.5')
info=blob.stat()
matches=[]
for path in model.rglob('*'):
    if path.is_file() and path.samefile(blob):
        matches.append({'path':str(path),'resolved':str(path.resolve()),'is_symlink':path.is_symlink()})
print(json.dumps({'blob':str(blob),'inode':info.st_ino,'device':info.st_dev,'size_bytes':info.st_size,
                  'model_cache_exists':model.exists(),'matches':matches,'weight_bytes_read':False}))
'''
command = [r'C:\Program Files\Docker\Docker\resources\bin\docker.exe', 'exec', '-i',
           'sp-memory-diagnostic-20261026-api-1', 'python', '-']
result = subprocess.run(command, input=code, capture_output=True, text=True, encoding='utf-8',
                        check=True, env=clean_environment(), timeout=30)
record = {'at':datetime.now(UTC).isoformat(),'command':command,'code':code,'data':json.loads(result.stdout),
          'scope':'File metadata only; no weight contents, model initialization or API requests.'}
with (root/'model-file-mapping.json').open('x',encoding='utf-8') as file:
    json.dump(record,file,indent=2)
print(json.dumps(record['data']))
