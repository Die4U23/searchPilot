"""MiB and actual elapsed seconds; descriptive evidence only, never acceptance.

Reads completed final-two-hour evidence, including a FAILED stability verdict.
Missing observations remain gaps. PID, cgroup and Windows client scopes are separate.
"""

from __future__ import annotations

import hashlib
import io
import json
import math
import statistics
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASE = ROOT / "final-two-hour"
MIB = 1024**2
METRICS = {
    "pid_rss_mib": ("smaps_rollup", "Rss_bytes"),
    "pid_anonymous_mib": ("smaps_rollup", "Anonymous_bytes"),
    "pid_pss_mib": ("smaps_rollup", "Pss_bytes"),
    "pid_rssfile_mib": ("status", "RssFile_bytes"),
    "pid_vmdata_mib": ("status", "VmData_bytes"),
    "cgroup_current_mib": ("cgroup_memory_current", "bytes"),
}
ALL_METRICS = (*METRICS, "client_rss_mib", "client_private_mib")


def number(value):
    return value if type(value) in (int, float) and math.isfinite(value) and value >= 0 else None


def timestamp(value):
    try:
        stamp = datetime.fromisoformat(value)
        return stamp.timestamp() if stamp.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError):
        return None


def source(owner, name):
    envelope = owner.get("sources", {}).get(name, {})
    return envelope.get("data", {}) if envelope.get("available") is True else {}


def identity(server):
    before, after = source(server, "stat"), source(server, "stat_after")
    pid, ticks = before.get("pid"), before.get("start_time_ticks")
    if (
        server.get("available") is not True
        or server.get("identity_consistent") is not True
        or type(pid) is not int
        or pid <= 0
        or type(ticks) is not int
        or ticks < 0
        or type(after.get("pid")) is not int
        or type(server.get("pid")) is not int
        or server["pid"] != pid
        or after["pid"] != pid
        or type(after.get("start_time_ticks")) is not int
        or after["start_time_ticks"] != ticks
    ):
        return None
    return [pid, ticks]


def flatten(rows, anchor):
    result = []
    for line, row in enumerate(rows, 1):
        at = timestamp(row.get("at"))
        server, client = row.get("server", {}), row.get("client", {})
        pid = identity(server)
        values = {}
        for name, (section, key) in METRICS.items():
            value = number(source(server, section).get(key))
            valid = server.get("available") is True and (not name.startswith("pid_") or pid)
            values[name] = value / MIB if valid and value is not None else None
        client_pid = client.get("pid")
        client_valid = (
            client.get("available") is True and type(client_pid) is int and client_pid > 0
        )
        for key in ("rss", "private"):
            value = number(source(client, "memory").get(key + "_bytes"))
            values["client_" + key + "_mib"] = (
                value / MIB if client_valid and value is not None else None
            )
        server_at, client_at = timestamp(server.get("at")), timestamp(client.get("at"))
        result.append(
            {
                "line": line,
                "at": row.get("at"),
                "phase": row.get("phase"),
                "seconds": at - anchor if at is not None else None,
                "server_seconds": server_at - anchor if server_at is not None else None,
                "client_seconds": client_at - anchor if client_at is not None else None,
                "server_offset_seconds": server_at - at
                if server_at is not None and at is not None
                else None,
                "client_offset_seconds": client_at - at
                if client_at is not None and at is not None
                else None,
                "identity": pid,
                "client_pid": client_pid if client_valid else None,
                "source_availability": {
                    key: value.get("available") is True
                    for key, value in server.get("sources", {}).items()
                },
                "metrics": values,
            }
        )
    return result


def describe(points, same_identity=True):
    valid = [(t, value) for t, value in points if t is not None and value is not None]
    result = {
        "observations": len(points),
        "valid": len(valid),
        "missing": len(points) - len(valid),
        "endpoint_growth": None,
        "ols_per_minute": None,
    }
    if not valid:
        return result
    times, values = zip(*valid, strict=True)
    increasing = all(b > a for a, b in zip(times, times[1:], strict=False))
    result.update(
        first=values[0],
        last=values[-1],
        minimum=min(values),
        maximum=max(values),
        median=statistics.median(values),
        mean=statistics.mean(values),
        first_seconds=times[0],
        last_seconds=times[-1],
        time_increasing=increasing,
        max_gap_seconds=max((b - a for a, b in zip(times, times[1:], strict=False)), default=None),
    )
    if len(valid) == len(points) and len(valid) >= 2 and same_identity and increasing:
        mean_x, mean_y = statistics.mean(times), statistics.mean(values)
        denominator = sum((t - mean_x) ** 2 for t in times)
        result["endpoint_growth"] = values[-1] - values[0]
        result["ols_per_minute"] = (
            sum((t - mean_x) * (v - mean_y) for t, v in valid) / denominator * 60
        )
    else:
        result["trend_unavailable_reason"] = (
            "missing/short/unordered data or multiple/no process identities"
        )
    return result


def group(rows):
    ids = {tuple(r["identity"]) for r in rows if r["identity"] is not None}
    clients = {r["client_pid"] for r in rows if r["client_pid"] is not None}
    return {
        "sample_count": len(rows),
        "phase_counts": dict(Counter(r["phase"] for r in rows)),
        "identities": sorted(ids),
        "client_pids": sorted(clients),
        "first_seconds": rows[0]["seconds"] if rows else None,
        "last_seconds": rows[-1]["seconds"] if rows else None,
        "metrics": {
            name: describe(
                [(r["seconds"], r["metrics"][name]) for r in rows],
                len(clients) == 1 if name.startswith("client_") else len(ids) == 1,
            )
            for name in ALL_METRICS
        },
    }


def window(rows, left, right):
    selected = [
        r
        for r in rows
        if r["phase"] == "load" and r["seconds"] is not None and left <= r["seconds"] < right
    ]
    return {"start_seconds": left, "end_seconds": right, **group(selected)}


def background_summary(raw_rows, anchor, harness, left=None, right=None):
    own = harness.get("initial_state", [])
    names = {str(row.get("Name", "")).lstrip("/") for row in own}
    ids = {str(row.get("Id", "")) for row in own if row.get("Id")}
    records, unresolved, catalog = [], [], {}
    for line, row in enumerate(raw_rows, 1):
        stamp = timestamp(row.get("at"))
        seconds = stamp - anchor if stamp is not None else None
        if left is not None and (seconds is None or not left <= seconds < right):
            continue
        poll = row.get("containers", {})
        others, unknown = [], []
        data = poll.get("data")
        available = poll.get("available") is True and isinstance(data, list)
        for item in data if available else []:
            name, cid = item.get("Name"), item.get("ID")
            if not name or name == "--" or not cid or cid == "--" or not names or not ids:
                unknown.append(item)
                unresolved.append({"line": line, "at": row.get("at"), "raw": item})
                continue
            if name.lstrip("/") not in names and not any(oid.startswith(cid) for oid in ids):
                key = cid + ":" + name
                others.append(key)
                catalog[key] = {"name": name, "id": cid}
        host = row.get("windows_host", {})
        host_available = host.get("available") is True
        records.append(
            {
                "line": line,
                "seconds": seconds,
                "docker_available": available,
                "other_container_ids": others,
                "unresolved_count": len(unknown),
                "linux_loadavg": row.get("linux_loadavg"),
                "windows_available": host_available,
                "windows_cpu_percent": number(host.get("interval_cpu_busy_percent"))
                if host_available
                else None,
                "windows_memory_load_percent": number(host.get("memory_load_percent"))
                if host_available
                else None,
                "windows_available_physical_mib": number(host.get("available_physical_bytes")) / MIB
                if host_available and number(host.get("available_physical_bytes")) is not None
                else None,
                "windows_total_physical_mib": number(host.get("total_physical_bytes")) / MIB
                if host_available and number(host.get("total_physical_bytes")) is not None
                else None,
            }
        )
    return {
        "polls": len(records),
        "unavailable_docker_polls": sum(not r["docker_available"] for r in records),
        "unavailable_windows_polls": sum(not r["windows_available"] for r in records),
        "polls_with_other_containers": sum(bool(r["other_container_ids"]) for r in records),
        "unique_other_container_ids": len(catalog),
        "max_simultaneous_other_containers": max(
            (len(r["other_container_ids"]) for r in records), default=None
        ),
        "unresolved_record_count": len(unresolved),
        "unresolved_records": unresolved,
        "other_container_catalog": catalog,
        "windows_host": {
            name: describe([(r["seconds"], r[name]) for r in records])
            for name in (
                "windows_cpu_percent",
                "windows_memory_load_percent",
                "windows_available_physical_mib",
                "windows_total_physical_mib",
            )
        },
        "records": records,
    }


def assemble(harness, bench, stability, raw_samples, background):
    if harness.get("status") != "COMPLETED" or bench.get("status") != "COMPLETED":
        raise ValueError("Harness and benchmark must be COMPLETED; stability may fail")
    if len(bench.get("runs", [])) != 1:
        raise ValueError("Expected one measured run")
    run = bench["runs"][0]
    duration = number(run.get("dispatch_window_seconds"))
    if duration is None or duration != bench.get("config", {}).get("duration_seconds"):
        raise ValueError("Missing/inconsistent dispatch duration")
    anchor = timestamp(run.get("started_at"))
    if anchor is None:
        raise ValueError("Missing timezone-aware benchmark start")
    samples = flatten(raw_samples, anchor)
    formal = window(samples, 0, duration)
    report = {
        "schema_version": 1,
        "descriptive_only": True,
        "units": "MiB; actual elapsed seconds",
        "window_clock": "harness sample at; strict windows phase=load, [start,end)",
        "plot_clock": "server/client observed_at; missing timestamps are gaps; no substitution",
        "benchmark_started_at": run["started_at"],
        "duration_seconds": duration,
        "stable_after_seconds": 3600,
        "stability_declared_stable_after_seconds": stability.get("stable_after_seconds"),
        "stability_status": stability.get("status", "MISSING"),
        "stability_errors": stability.get("errors", []),
        "stability_gates": stability.get("gates"),
        "all_phases": group(samples),
        "strict_formal": formal,
        "phases": {
            phase: group([r for r in samples if r["phase"] == phase])
            for phase in dict.fromkeys(r["phase"] for r in samples)
        },
        "five_minutes": [
            window(samples, left, min(left + 300, duration))
            for left in range(0, math.ceil(duration), 300)
        ],
        "twenty_minutes": [
            window(samples, left, min(left + 1200, duration))
            for left in range(0, math.ceil(duration), 1200)
        ],
        "hours": [
            window(samples, left, min(left + 3600, duration))
            for left in range(0, math.ceil(duration), 3600)
        ],
        "last_ten_minutes": window(samples, max(0, duration - 600), duration),
        "last_twenty_minutes": window(samples, max(0, duration - 1200), duration),
        "timestamp_offsets": {
            name: describe([(r["seconds"], r[name]) for r in samples])
            for name in ("server_offset_seconds", "client_offset_seconds")
        },
        "missing_outer_timestamps": sum(r["seconds"] is None for r in samples),
        "background_available": background is not None,
        "background_all": background_summary(background or [], anchor, harness),
        "background_formal": background_summary(background or [], anchor, harness, 0, duration),
        "samples": samples,
        "limitations": [
            "Descriptive output never changes acceptance or its thresholds.",
            "MiB scales differ by panel; PID/cgroup/client scopes are not summed.",
            "Recovery includes recorded recovery probes, not necessarily fully idle.",
            "Missing, invalid identity, nonincreasing timestamps, and >15s gaps break curves.",
            "Observed maxima are sampled maxima, not continuous peaks.",
        ],
    }
    return report


def plot_line(ax, samples, metric, label, *, shift=0, select=lambda r: True):
    owner = "client" if metric.startswith("client_") else "server"
    identity_key = "client_pid" if owner == "client" else "identity"
    x, y, previous = [], [], None
    for row in samples:
        seconds, value = row[owner + "_seconds"], row["metrics"][metric]
        if seconds is None or not select(row):
            x.append(float("nan"))
            y.append(float("nan"))
            previous = None
            continue
        if previous is not None and (
            not 0 < seconds - previous[owner + "_seconds"] <= 15
            or row[identity_key] != previous[identity_key]
        ):
            x.append(seconds / 60)
            y.append(float("nan"))
        x.append(seconds / 60)
        y.append(value - shift if value is not None else float("nan"))
        previous = row
    ax.plot(x, y, label=label, linewidth=1, marker=".", markersize=1.6)


def render_png(report):
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt
    from matplotlib.ticker import ScalarFormatter

    rows = report["samples"]
    fig, axes = plt.subplots(4, 1, figsize=(14, 15), sharex=True)
    fig.subplots_adjust(left=0.1, right=0.9, bottom=0.095, top=0.9, hspace=0.28)
    duration, stable = report["duration_seconds"], report["stable_after_seconds"]
    for name, label in (
        ("pid_rss_mib", "PID RSS"),
        ("pid_anonymous_mib", "Anonymous"),
        ("pid_pss_mib", "PSS"),
        ("pid_rssfile_mib", "RssFile (status)"),
    ):
        plot_line(axes[0], rows, name, label)
    axes[0].set_ylabel("Resident / file memory (MiB)")
    for name, label in (("pid_rss_mib", "RSS"), ("pid_anonymous_mib", "Anonymous")):
        selected = [
            r
            for r in rows
            if r["phase"] == "load"
            and r["seconds"] is not None
            and stable <= r["seconds"] < duration
            and r["metrics"][name] is not None
        ]
        if selected:
            first = selected[0]
            plot_line(
                axes[1],
                rows,
                name,
                f"{label} relative to t={first['seconds']:.3f}s",
                shift=first["metrics"][name],
                select=lambda r: (
                    r["phase"] == "load"
                    and r["seconds"] is not None
                    and stable <= r["seconds"] < duration
                ),
            )
    axes[1].set_ylabel("Stable interval delta (MiB)")
    axes[1].axhline(0, color="gray", linewidth=0.6)
    plot_line(axes[2], rows, "pid_vmdata_mib", "PID VmData (virtual; left axis)")
    right = axes[2].twinx()
    plot_line(right, rows, "cgroup_current_mib", "API cgroup current (right axis)")
    right.lines[-1].set_color("tab:orange")
    axes[2].set_ylabel("VmData virtual (MiB)")
    right.set_ylabel("cgroup current (MiB)", color="tab:orange")
    right.tick_params(axis="y", colors="tab:orange")
    right.legend(loc="upper right", fontsize=8)
    plot_line(axes[3], rows, "client_rss_mib", "Windows benchmark client RSS")
    plot_line(axes[3], rows, "client_private_mib", "Windows benchmark client private")
    axes[3].set_ylabel("Client process memory (MiB)")
    all_times = [
        r[key] / 60
        for r in rows
        for key in ("seconds", "server_seconds", "client_seconds")
        if r[key] is not None
    ]
    for ax in axes:
        ax.axvspan(stable / 60, duration / 60, color="gold", alpha=0.13)
        ax.axvline(0, color="gray", linestyle=":", linewidth=0.8)
        ax.axvline(stable / 60, color="darkgoldenrod", linestyle="--", linewidth=0.8)
        ax.axvline(duration / 60, color="gray", linestyle=":", linewidth=0.8)
        ax.set_xlim(min(all_times), max(all_times))
        ax.yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
        ax.grid(alpha=0.2)
        if ax.get_legend_handles_labels()[0]:
            ax.legend(loc="upper left", fontsize=8)
    axes[3].set_xlabel(
        "Actual elapsed minutes from formal start; includes baseline/recovery/restart"
    )
    fig.suptitle(
        f"Normal container memory evidence: {duration / 3600:g} hours formal load\n"
        f"Descriptive only | stability verdict: {report['stability_status']} | units: MiB",
        fontsize=14,
    )
    fig.text(
        0.1,
        0.025,
        "Full time range retained; yellow = predeclared stable interval. "
        "Curves use actual owner timestamps.\n"
        "Missing / invalid identity / >15s gaps break lines. "
        "Panel 2 supplements the full curve in panel 1.\n"
        "VmData is virtual; cgroup/client are separate scopes. "
        "PID changes remain separate segments.",
        fontsize=9,
    )
    buffer = io.BytesIO()
    try:
        fig.savefig(buffer, format="png", dpi=160)
        return buffer.getvalue()
    finally:
        plt.close(fig)


def main():
    json_path = ROOT / "final-two-hour-resource-summary.json"
    png_path = ROOT / "final-two-hour-memory.png"
    if json_path.exists() or png_path.exists():
        raise FileExistsError("Refuse to overwrite a resource summary or plot")
    raw = {
        name: (CASE / name).read_bytes()
        for name in ("summary.json", "soak.json", "samples.jsonl", "stability.json")
    }
    if (CASE / "background.jsonl").is_file():
        raw["background.jsonl"] = (CASE / "background.jsonl").read_bytes()
    report = assemble(
        json.loads(raw["summary.json"]),
        json.loads(raw["soak.json"]),
        json.loads(raw["stability.json"]),
        [json.loads(line) for line in raw["samples.jsonl"].splitlines()],
        [json.loads(line) for line in raw["background.jsonl"].splitlines()]
        if "background.jsonl" in raw
        else None,
    )
    if report["duration_seconds"] != 7200:
        raise ValueError("Final output requires an actual 7200-second declared dispatch window")
    report["input_sha256"] = {
        name: hashlib.sha256(content).hexdigest() for name, content in raw.items()
    }
    report["helper_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    image = render_png(report)
    encoded = (json.dumps(report, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with png_path.open("xb") as sink:
        sink.write(image)
    with json_path.open("xb") as sink:
        sink.write(encoded)
    print(
        json.dumps(
            {
                "descriptive_only": True,
                "stability_status": report["stability_status"],
                "summary": str(json_path),
                "png": str(png_path),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
