"""Read current ledgers and samples; never issue service requests or mutate evidence."""
import json
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIB = 1048576


def read_last(path):
    if not path.is_file():
        return None
    with path.open('rb') as handle:
        size = handle.seek(0, 2)
        handle.seek(max(0, size - 200000))
        lines = handle.read().splitlines()
    for line in reversed(lines):
        try:
            return json.loads(line)
        except (ValueError, UnicodeDecodeError):
            continue
    return None


def recent_results(path):
    if not path.is_file():
        return None
    with path.open('rb') as handle:
        size = handle.seek(0, 2)
        offset = max(0, size - 4 * 1024 * 1024)
        handle.seek(offset)
        lines = handle.read().splitlines()
    records = []
    for line in lines[1:] if offset else lines:
        try:
            row = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            continue
        if row.get('event') == 'result' and row.get('phase') == 'measured':
            records.append(row)
    if not records:
        return None
    latency = sorted(row['elapsed_ms'] for row in records)
    return {'scope': 'bounded ledger tail, not whole-run acceptance',
            'count': len(records), 'first_at': records[0]['at'], 'last_at': records[-1]['at'],
            'outcomes': dict(Counter(row['outcome'] for row in records)),
            'p95_ms': latency[int((len(latency)-1)*.95)], 'max_ms': latency[-1]}


def main():
    rows = []
    for case in ('diagnostic-expanded-01', 'diagnostic-original-01', 'diagnostic-encoder32-01', 'diagnostic-encoder2-01', 'diagnostic-omp-default-01', 'diagnostic-omp1-01', 'final-two-hour'):
        folder = ROOT / case
        if not folder.exists():
            continue
        record = {'case': case}
        try:
            summary = json.loads((folder/'summary.json').read_text(encoding='utf-8'))
            record['status'] = summary.get('status')
            record['snapshots'] = [row['label'] for row in summary.get('snapshots', [])]
            start = summary.get('load_started_at') or summary.get('soak_started_at')
            if start and record['status'] == 'RUNNING':
                record['wall_seconds_since_start'] = round((datetime.now(UTC)-datetime.fromisoformat(start)).total_seconds(), 1)
        except (OSError, ValueError):
            record['status'] = 'SUMMARY_WRITING_OR_MISSING'
        sample = read_last(folder/'samples.jsonl')
        if sample:
            sources = sample.get('server', {}).get('sources', {})
            memory = sources.get('smaps_rollup', {}).get('data', {})
            status = sources.get('status', {}).get('data', {})
            record.update(phase=sample.get('phase'), sample_at=sample.get('at'),
                sample_completed=sample.get('completed'), inflight=sample.get('inflight'),
                live=sample.get('live', {}).get('status'), ready=sample.get('ready', {}).get('status'),
                rss_mib=memory.get('Rss_bytes',0)/MIB if 'Rss_bytes' in memory else None,
                anon_mib=memory.get('Anonymous_bytes',0)/MIB if 'Anonymous_bytes' in memory else None,
                threads=status.get('Threads'))
        ledger_path = folder/('soak.requests.jsonl' if case=='final-two-hour' else 'requests.jsonl')
        ledger = read_last(ledger_path)
        if ledger:
            record['last_event'] = {key:ledger.get(key) for key in ('event','phase','index','outcome','at')}
        if record['status'] == 'RUNNING':
            record['recent_results'] = recent_results(ledger_path)
        rows.append(record)
    print(json.dumps({'at':datetime.now(UTC).isoformat(), 'cases':rows}))


if __name__ == '__main__':
    main()
