"""Adapt previously reviewed evidence helpers into new, never-overwritten files."""
from pathlib import Path

root = Path(__file__).resolve().parent
old = root.parent / 'expanded-soak-2026-10-25'


def replace_once(text, old_value, new_value):
    assert text.count(old_value) == 1, old_value
    return text.replace(old_value, new_value, 1)


build = (old / 'build_candidate.py').read_text(encoding='utf-8')
build = replace_once(build, "base = 'searchpilot-validation:2026-10-25-arena2'", "base = 'searchpilot-validation:2026-10-25-expanded'")
build = replace_once(build, 'sha256:a97dc62115f0b617d962423739a45f71dfc7a93ec05c4e055575fe7d65a710d1', 'sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1')
build = replace_once(build, "tag = 'searchpilot-validation:2026-10-25-expanded'", "tag = 'searchpilot-validation:2026-10-26-stability'")
start = build.index('old_inputs = ')
end = build.index("context = root/'image-context'", start)
build = build[:start] + '''inputs = json.loads((root/'inputs-sha256.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest() == value
           for name, value in inputs.items())
''' + build[end:]
with (root / 'build_candidate.py').open('x', encoding='utf-8') as out:
    out.write(build)

audit = (old / 'audit_case.py').read_text(encoding='utf-8')
audit = replace_once(audit, 'import statistics\n', 'import statistics\nimport subprocess\nimport sys\n')
start = audit.index('CASES = ')
end = audit.index('NATIVE_KEYS = ', start)
audit = audit[:start] + "CASES = {'final-two-hour': (32, 7200, 12, 60, 600)}\n" + audit[end:]
start = audit.index("    memory_gate = {'status': 'NOT_APPLICABLE_SHORT_SCREEN'}")
end = audit.index('    groups = ', start)
audit = audit[:start] + '''    stability_path = folder/'stability.json'
    result = subprocess.run([sys.executable, '-m', 'scripts.audit_memory_stability',
        '--bench', str(folder/'soak.json'), '--samples', str(folder/'samples.jsonl'),
        '--duration-seconds', '7200', '--stable-after-seconds', '3600',
        '--out', str(stability_path)], cwd=REPO, capture_output=True, text=True,
        encoding='utf-8', timeout=120)
    memory_gate = read(stability_path) if stability_path.exists() else {
        'status': 'FAILED', 'reason': 'stability auditor did not create output',
        'stdout': result.stdout, 'stderr': result.stderr}
    checks['two_hour_memory_stability'] = result.returncode == 0 and memory_gate.get('status') == 'PASSED'
''' + audit[end:]
with (root / 'audit_case.py').open('x', encoding='utf-8') as out:
    out.write(audit)
print('Prepared final image builder and resource audit helpers; no containers started.')
