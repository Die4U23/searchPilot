"""Read-only raw-ledger replay and hash binding for final normal acceptance.

This is an offline auditor helper, not part of the frozen running measurement image.
"""

from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
from scripts.summarize_soak import summarize  # noqa: E402

CASE_FILES = (
    "summary.json",
    "soak.json",
    "soak.requests.jsonl",
    "samples.jsonl",
    "queries.csv",
    "soak.queries.csv",
    "analysis.json",
)
ROOT_FILES = (
    "build-summary.json",
    "inputs-sha256.json",
    "sources-sha256.json",
    "acceptance-plan.md",
    "audit_case.py",
    "normal_raw_evidence.py",
    "fixture/queries.csv",
)
REPO_FILES = ("scripts/summarize_soak.py", "scripts/audit_memory_stability.py")
MODES = ["bm25", "vector", "hybrid", "ltr"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pairs_unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def parse(text):
    return json.loads(text, object_pairs_hook=pairs_unique, parse_constant=invalid_constant)


def read(path):
    return parse(path.read_text(encoding="utf-8-sig"))


def read_jsonl(path):
    rows = []
    with path.open(encoding="utf-8") as stream:
        for index, line in enumerate(stream, 1):
            value = parse(line)
            require(isinstance(value, dict), f"Invalid JSONL object at {path.name}:{index}")
            rows.append(value)
    require(rows, "Empty evidence: " + path.name)
    return rows


def evidence_hashes(folder):
    root = folder.parent
    names = [*(folder.name + "/" + name for name in CASE_FILES), *ROOT_FILES]
    return {
        "root": {name: digest(root / name) for name in names},
        "repository": {name: digest(REPO / name) for name in REPO_FILES},
    }


def normalized_analysis(analysis, folder):
    """Only path spellings are normalized; every derived value must match replay."""
    value = copy.deepcopy(analysis)
    inputs = value.pop("inputs")
    allowed_queries = {
        p.resolve()
        for p in (
            folder / "queries.csv",
            folder / "soak.queries.csv",
            folder.parent / "fixture/queries.csv",
        )
    }
    require(set(inputs) == {"bench", "ledger", "samples", "queries"}, "Analysis inputs incomplete")
    for key, name in (
        ("bench", "soak.json"),
        ("ledger", "soak.requests.jsonl"),
        ("samples", "samples.jsonl"),
    ):
        require(
            Path(inputs[key]).resolve() == (folder / name).resolve(),
            "Analysis input path is stale: " + key,
        )
    require(Path(inputs["queries"]).resolve() in allowed_queries, "Unbound analysis query path")
    require(
        Path(value["coverage"].pop("path")).resolve() == Path(inputs["queries"]).resolve(),
        "Analysis query paths disagree",
    )
    return value


def replay_analysis(folder):
    bench = read(folder / "soak.json")
    events = read_jsonl(folder / "soak.requests.jsonl")
    samples = read_jsonl(folder / "samples.jsonl")
    current = summarize(
        bench,
        events,
        duration_seconds=7200,
        window_seconds=300,
        samples=samples,
        queries=folder / "soak.queries.csv",
        min_repeats=12,
    )
    require(
        current["status"] == "PASSED" and not current["issues"],
        "Current raw ledger failed: " + str([x.get("kind") for x in current["issues"][:12]]),
    )
    expected = copy.deepcopy(current)
    expected["coverage"].pop("path")
    require(
        normalized_analysis(read(folder / "analysis.json"), folder) == expected,
        "Saved analysis does not equal current raw-ledger replay",
    )
    return current


def require_final_protocol(analysis, bench, summary, build):
    require(bench["status"] == summary["status"] == "COMPLETED", "Normal run incomplete")
    for config in (bench["config"], summary["config"]):
        require(
            config.get("duration_seconds") == 7200 and config.get("concurrency") == 32,
            "Unexpected final duration/concurrency",
        )
    require(
        bench["config"].get("warmup") == 4
        and bench["config"].get("limit") == bench["config"].get("timeout") == 10
        and bench["requested_modes"] == MODES,
        "Unexpected request protocol",
    )
    require(
        summary["config"].get("baseline_seconds") == 60
        and summary["config"].get("recovery_seconds") == 600,
        "Unexpected baseline/recovery",
    )
    require(
        analysis["duration_seconds"] == 7200
        and analysis["window_seconds"] == 300
        and len(analysis["windows"]) == 24
        and all(w["issued"] > 0 for w in analysis["windows"]),
        "Incomplete dispatch windows",
    )
    coverage = analysis["coverage"]
    require(
        coverage["verified"] is True
        and coverage["min_repeats"] == 12
        and coverage["query_count"] == 1300
        and coverage["expected_group_count"] == 5200
        and len(coverage["groups"]) == 5200
        and all(type(g["successful"]) is int and g["successful"] >= 12 for g in coverage["groups"]),
        "Incomplete 5200-group minimum-repeat coverage",
    )
    require(coverage["sha256"] == build["query_sha256"], "Query differs from build")
    require(
        analysis["inflight"]["configured_concurrency"] == analysis["inflight"]["peak"] == 32
        and analysis["inflight"]["pending_events_at_end"] == 0,
        "Concurrency/drain differs",
    )
    require(
        analysis["phases"]["warmup"]["issued"] == analysis["phases"]["warmup"]["success"] == 16,
        "Incomplete sixteen-request warmup",
    )


def verify_normal_raw(folder, acceptance=None):
    """Recompute from current files, reject stale values and bind exact input bytes."""
    before = evidence_hashes(folder)
    if acceptance is not None:
        require(
            acceptance.get("input_sha256") == before, "Acceptance input hashes are stale/incomplete"
        )
    frozen = read(folder.parent / "sources-sha256.json")
    require(
        all(frozen[name] == before["repository"][name] for name in REPO_FILES),
        "Frozen replay/auditor source changed",
    )
    build = read(folder.parent / "build-summary.json")
    for path in (
        folder / "queries.csv",
        folder / "soak.queries.csv",
        folder.parent / "fixture/queries.csv",
    ):
        require(digest(path) == build["query_sha256"], "Query snapshot changed: " + path.name)
    current = replay_analysis(folder)
    require_final_protocol(
        current, read(folder / "soak.json"), read(folder / "summary.json"), build
    )
    require(evidence_hashes(folder) == before, "Evidence changed during offline audit")
    return current, before
