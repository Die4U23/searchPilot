# 追加编码并发单因子对照（运行前声明）

2026-10-26，A扩展查询组运行中已观察到10400→15600请求RSS/Anonymous增加约4.89MiB，
glibc arena增加4.98MiB、free增加6.63MiB、used下降，pymalloc arenas仍641。不能据此
把增长直接归于编码器，故追加匹配干预；本文件先于这两组任何请求保存。

## 匹配协议

先完成原A expanded1300和B original100，保留其所有结果及原版驱动。随后顺序运行：

| case | 编码器执行上限 | HTTP客户端并发 | 正式请求 |
|---|---:|---:|---:|
| diagnostic-encoder32-01 | 32（对HTTP c32不额外限制的sham） | 32 | 20800 |
| diagnostic-encoder2-01 | 2 | 32 | 20800 |

两组均使用完全相同的1300查询字节、原镜像、THP-off/arena2、现有独立诊断PG项目，
API每组强制重建。limit10、timeout10、16预热、400/5200/10400/15600/20800检查点、
120秒idle然后GC/trim；不可增加timeout或重试来隐藏排队超时。完整原始账本和全部
健康/来源/identity/无OOM、冻结原模型/标签/依赖检查继续适用。

同一个只读挂载诊断patch包装SentenceTransformerQueryEncoder.__call__，仅信号量
limit32/2不同；模型初始化/编码/归一化及结果不变。聚合计数为有界标量（无每次调用
对象列表），包括started/completed/error、active/peak、waiting/peak、等待与执行耗时。
通过诊断snapshot报告；在正常最终服务中不保留patch或这些诊断计数。

派生runner保留原runner，记录base/derived/patch/override执行副本及SHA。实际容器
command/mount和生效计数均核验；不能以原镜像相同冒充原版无patch执行。只修改Compose
最后一层诊断command和只读patch挂载，不修改或重建原模型/依赖/源文件。

## 观察与接受候选的条件

- 每组20800/20800成功，所有5200组合各4次，16/16预热；完整唯一配对，HTTP峰值32。
- 组内及两组全部查询×模式结果/排名/模型指纹一致。
- warmup→after20800的编码started/completed差均15600（三个编码模式）；异常0，
  执行峰值<=对应limit，cap2必须实际达到2；sham真实峰值披露，不强填32。
- 最终/idle/GC/trim waiting与active为0，PID和wrapper配置稳定。
- 描述各检查点、最终排空/idle/GC/trim的RSS/anonymous、文件resident、glibc
  used/free、pymalloc和线程ID更替。它们是不同且可能重叠的口径，不相加。
- 干预若没有降低后段匿名/原生保留或引入超时/错误，否定或削弱该候选；保留全部结果。
  若显著降低保留且语义/功能通过，才考虑生产实现，并以正常入口完整7200秒复验。

任何效应只能归为“编码器级并发限制这一整体干预”，它同时改变推理、排队及下游
重叠，不能证明所有增长来自某个库或线程缓存。顺序对照和背景差异不构成吞吐的
统计因果证明；协议PASSED也不自动意味着修复有效。原两小时内存门槛不因候选调整。
