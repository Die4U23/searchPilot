"""Display already-written native checkpoints without probing the process."""
import argparse
import json
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('case', choices=('diagnostic-expanded-01', 'diagnostic-original-01', 'diagnostic-encoder32-01', 'diagnostic-encoder2-01', 'diagnostic-omp-default-01', 'diagnostic-omp1-01'))
args = parser.parse_args()
report = json.loads((root / args.case / 'summary.json').read_text(encoding='utf-8'))
rows = []
for row in report['snapshots']:
    data = row['data'].get('snapshot', row['data'])
    native = data['allocator']['mallinfo2']['data']
    rollup = data['process']['data']['sources']['smaps_rollup']['data']
    python = data['pymalloc']['data']['fields']
    rows.append({
        'label': row['label'], 'completed': row['counts_after']['completed'],
        'rss_mib': rollup['Rss_bytes'] / 1048576,
        'anon_mib': rollup['Anonymous_bytes'] / 1048576,
        'arena_mib': native['arena'] / 1048576,
        'used_mib': native['uordblks'] / 1048576,
        'free_mib': native['fordblks'] / 1048576,
        'python_allocated_mib': python['allocated_blocks_bytes'] / 1048576,
        'python_arenas': python['arenas_current'],
        'action_result': row['data'].get('result'),
        'encoder': {key: data.get('encoder_concurrency', {}).get(key)
                    for key in ('limit', 'calls_started', 'calls_completed', 'errors', 'active', 'peak_active', 'waiting', 'peak_waiting')}
        if 'encoder_concurrency' in data else None,
    })
print(json.dumps({'case': args.case, 'status': report['status'], 'snapshots': rows}))
