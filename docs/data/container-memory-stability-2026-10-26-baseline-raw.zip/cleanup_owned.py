"""Remove only completed, audited, exact-label experiment resources; preserve originals."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
from scripts.validate_container_soak import clean_environment  # noqa: E402

DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
PROJECTS = {
    "diagnostic": "sp-memory-diagnostic-20261026",
    "normal": "sp-memory-stability-20261026",
}
FLAGS = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def now():
    return datetime.now(UTC).isoformat()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def completed_evidence(target, project):
    if target == "diagnostic":
        # Share the publication gates; these functions read saved files only.
        from package_evidence import (
            DIAGNOSTICS,
            ENCODER_CONTROLS,
            NATIVE_CONTROLS,
            validate_diagnostics,
            validate_encoder_controls,
            validate_native_controls,
        )

        validate_diagnostics()
        validate_encoder_controls()
        validate_native_controls()
        setup = read(ROOT / "setup/summary.json")
        require(
            setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART"
            and setup["config"]["project"] == project,
            "Diagnostic setup/project mismatch",
        )
        names = [*DIAGNOSTICS, *ENCODER_CONTROLS, *NATIVE_CONTROLS]
        cases = [read(ROOT / name / "summary.json") for name in names]
        for name, case in zip(names, cases, strict=True):
            require(
                case["case"] == name and case["requests"] == 20800 and case["concurrency"] == 32,
                "Diagnostic workload identity differs",
            )
            require(case["container"]["project"] == project, "Diagnostic ownership mismatch")
            if "final_container" in case:
                require(
                    case["final_container"]["project"] == project,
                    "Final diagnostic ownership mismatch",
                )
        require(
            cases[-1]["case"] == "diagnostic-omp1-01"
            and cases[-1]["collection_status"] == "COMPLETED"
            and cases[-1]["status"] in ("COMPLETED", "COMPLETED_WITH_WORKLOAD_FAILURES")
            and cases[-1]["workload_status"] in ("PASSED", "FAILED"),
            "Final rejected OMP1 collection is incomplete",
        )
        expected = {row["Name"].lstrip("/"): row["Id"] for row in setup["state"]}
        expected[project + "-api-1"] = cases[-1]["final_container"]["Id"]
        evidence = [
            "setup/summary.json",
            *[name + "/summary.json" for name in names],
            "comparison-failed.json",
            "encoder-comparison-failed.json",
            "native-thread-comparison-rejected.json",
            "diagnostic-failure-followup-plan.md",
            "encoder-control-plan.md",
            "native-thread-control-plan.md",
            "native-thread-preflight.json",
        ]
    else:
        summary = read(ROOT / "final-two-hour/summary.json")
        require(summary["status"] == "COMPLETED", "Incomplete normal validation must be preserved")
        require(summary["config"]["project"] == project, "Normal project identity mismatch")
        require(
            summary["config"]["duration_seconds"] == 7200
            and summary["config"]["concurrency"] == 32,
            "Normal workload differs from plan",
        )
        require(
            read(ROOT / "final-two-hour-launcher.json")["status"] == "COMPLETED",
            "Launcher did not complete",
        )
        require(
            read(ROOT / "final-two-hour/stability.json")["status"] == "PASSED",
            "Failed stability evidence must be preserved",
        )
        require(
            read(ROOT / "final-two-hour/acceptance.json")["status"] == "PASSED",
            "Full acceptance must pass before cleanup",
        )
        expected = {row["Name"].lstrip("/"): row["Id"] for row in summary["final_state"]}
        evidence = [
            "final-two-hour/summary.json",
            "final-two-hour-launcher.json",
            "final-two-hour/stability.json",
            "final-two-hour/acceptance.json",
        ]
    require(
        set(expected) == {project + "-api-1", project + "-db-1"},
        "Unexpected completion container set",
    )
    return expected, evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", choices=PROJECTS)
    parser.add_argument("--attempt", default="01", help="new evidence suffix for an explicit retry")
    args = parser.parse_args()
    require(bool(re.fullmatch(r"[a-z0-9-]{1,40}", args.attempt)), "Invalid evidence suffix")
    project = PROJECTS[args.target]
    volume, network = project + "_pgdata", project + "_default"
    require(volume != "searchpilot_pgdata", "Original volume can never be a cleanup target")
    record_path = ROOT / f"cleanup-{args.target}-{args.attempt}.json"
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "target": args.target,
        "project": project,
        "commands": [],
        "deleted_containers": [],
        "deleted_volumes": [],
        "deleted_networks": [],
        "private_env_read": False,
    }
    with record_path.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)

    def save():
        record_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    def command(args, timeout=60):
        row = {"argv": [DOCKER, *args], "started_at": now()}
        record["commands"].append(row)
        save()
        try:
            result = subprocess.run(
                row["argv"],
                cwd=REPO,
                env=clean_environment(),
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=timeout,
                check=True,
                creationflags=FLAGS,
            )
            row["exit_code"] = result.returncode
            return result.stdout
        except BaseException as exc:
            row["error_type"] = type(exc).__name__
            raise
        finally:
            row["finished_at"] = now()
            save()

    def inspect(kind, name):
        rows = json.loads(command([kind, "inspect", name]))
        require(len(rows) == 1, "Inspection did not resolve exactly one resource")
        return rows[0]

    try:
        expected, record["completion_evidence"] = completed_evidence(args.target, project)
        preflight = read(ROOT / "preflight.json")
        require(preflight["status"] == "PASSED", "Preflight did not pass")
        original = inspect("volume", "searchpilot_pgdata")
        require(
            original == preflight["original_volume"],
            "Original volume metadata differs from preflight",
        )
        record["original_volume_before"] = original
        names = set(
            command(
                [
                    "ps",
                    "-a",
                    "--filter",
                    "label=com.docker.compose.project=" + project,
                    "--format",
                    "{{.Names}}",
                ]
            ).splitlines()
        )
        require(names == set(expected), "Project container set differs from exact declared names")
        containers = {}
        for role in ("api", "db"):
            name = project + "-" + role + "-1"
            c = inspect("container", name)
            labels = c["Config"]["Labels"]
            require(
                c["Name"] == "/" + name and c["Id"] == expected[name],
                "Container was replaced since completion",
            )
            require(
                labels.get("com.docker.compose.project") == project
                and labels.get("com.docker.compose.service") == role,
                "Container labels mismatch",
            )
            require(
                labels.get("com.docker.compose.container-number") == "1",
                "Unexpected container number",
            )
            if role == "db":
                require(
                    any(
                        mount.get("Type") == "volume" and mount.get("Name") == volume
                        for mount in c["Mounts"]
                    ),
                    "Database is not bound to the declared owned volume",
                )
            containers[name] = c["Id"]
        owned = inspect("volume", volume)
        require(
            owned["Name"] == volume
            and owned["Labels"].get("com.docker.compose.project") == project
            and owned["Labels"].get("com.docker.compose.volume") == "pgdata",
            "Volume labels mismatch",
        )
        require(
            set(
                command(
                    [
                        "volume",
                        "ls",
                        "--filter",
                        "label=com.docker.compose.project=" + project,
                        "--format",
                        "{{.Name}}",
                    ]
                ).splitlines()
            )
            == {volume},
            "Unexpected project volume set",
        )
        net = inspect("network", network)
        require(
            net["Name"] == network
            and net["Labels"].get("com.docker.compose.project") == project
            and net["Labels"].get("com.docker.compose.network") == "default",
            "Network labels mismatch",
        )
        require(
            set(
                command(
                    [
                        "network",
                        "ls",
                        "--filter",
                        "label=com.docker.compose.project=" + project,
                        "--format",
                        "{{.Name}}",
                    ]
                ).splitlines()
            )
            == {network},
            "Unexpected project network set",
        )
        require(
            set(net.get("Containers", {})) <= set(containers.values()),
            "Network has other containers",
        )
        record.update(
            verified_containers=containers,
            verified_volume=owned,
            verified_network={"Name": network, "Id": net["Id"], "Labels": net["Labels"]},
        )
        save()
        # All identities were validated before the first destructive command. Never use prune.
        for name, container_id in containers.items():
            current = inspect("container", container_id)
            require(
                current["Name"] == "/" + name
                and current["Config"]["Labels"].get("com.docker.compose.project") == project,
                "Container changed during cleanup",
            )
            command(["stop", "--time", "30", container_id], timeout=60)
            command(["rm", container_id])
            record["deleted_containers"].append(container_id)
            save()
        require(inspect("volume", volume) == owned, "Owned volume changed during cleanup")
        require(
            inspect("volume", "searchpilot_pgdata") == original,
            "Original volume changed during cleanup",
        )
        command(["volume", "rm", volume])
        record["deleted_volumes"].append(volume)
        save()
        current_network = inspect("network", network)
        require(
            current_network["Id"] == net["Id"] and not current_network.get("Containers"),
            "Network changed or still attached",
        )
        command(["network", "rm", net["Id"]])
        record["deleted_networks"].append(network)
        require(
            inspect("volume", "searchpilot_pgdata") == preflight["original_volume"],
            "Original volume metadata changed",
        )
        require(
            not command(
                ["ps", "-aq", "--filter", "label=com.docker.compose.project=" + project]
            ).strip(),
            "Owned containers remain",
        )
        require(
            volume not in command(["volume", "ls", "--format", "{{.Name}}"]).splitlines(),
            "Owned volume remains",
        )
        record.update(status="COMPLETED", original_volume_metadata_unchanged=True)
    except BaseException as exc:
        record.update(
            status="INTERRUPTED" if isinstance(exc, KeyboardInterrupt) else "FAILED",
            error_type=type(exc).__name__,
        )
        raise
    finally:
        record["finished_at"] = now()
        save()
        print(json.dumps(record))


if __name__ == "__main__":
    main()
