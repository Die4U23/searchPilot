"""Offline rejected native-thread result reconciliation; never protocol acceptance."""

from __future__ import annotations

import argparse
import copy
import json
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import compare_native_thread_controls as native

ROOT = Path(__file__).resolve().parent
base, observed, encoder = native.base, native.observed, native.encoder
require, digest, CASES = native.require, native.digest, native.CASES
FIELDS = ("result_sha256", "ranking_sha256", "model_version", "result_count")


def semantic_differences(left, right):
    require(
        len(left) == len(right) == 5200 and left.keys() == right.keys(),
        "Incomplete semantic groups",
    )
    rows = []
    fields, modes = Counter(), Counter()
    for query, mode in sorted(left):
        a, b = left[(query, mode)], right[(query, mode)]
        require(len(a) == len(b) == len(FIELDS), "Unexpected semantic tuple")
        changes = {
            field: {"baseline": av, "treatment": bv}
            for field, av, bv in zip(FIELDS, a, b, strict=True)
            if av != bv
        }
        if changes:
            rows.append({"query": query, "mode": mode, "fields": changes})
            fields.update(changes.keys())
            modes[mode] += 1
    if rows:
        try:
            encoder.semantic_equality(left, right)
        except ValueError as exc:
            require(
                str(exc) == "Cross-case semantic fingerprints differ", "Unexpected strict rejection"
            )
        else:
            raise ValueError("Strict comparator unexpectedly accepted differences")
    return {
        "total_groups": 5200,
        "different_groups": len(rows),
        "equal_groups": 5200 - len(rows),
        "by_field": dict(sorted(fields.items())),
        "by_mode": dict(sorted(modes.items())),
        "groups": rows,
        "limitations": [
            "Only saved fingerprints, model version and result count are compared.",
            "Raw scores are not retained; magnitude and quality effect are unknown.",
        ],
    }


def matched_factors(a, b, aq, bq):
    require(aq == bq, "Matched controls changed queries")
    require(
        base.timestamp(a["finished_at"]) <= base.timestamp(b["started_at"])
        and a["container"]["Id"] != b["container"]["Id"],
        "Control order/recreation differs",
    )
    require(
        a["final_container"]["Id"] == b["previous_container"]["Id"],
        "Broken control container chain",
    )
    for key in (
        "input_sha256",
        "source_sha256",
        "executed_script_sha256",
        "helper_sha256",
        "public_config_sha256",
        "query_sha256",
        "process_native_environment",
        "requests",
        "concurrency",
        "limit",
        "timeout",
        "checkpoints",
        "idle_seconds",
        "health_period_seconds",
    ):
        require(a[key] == b[key], "Unexpected matched factor: " + key)
    for key in native.THREAD_KEYS:
        if key != "OMP_NUM_THREADS":
            require(
                a["process_thread_environment"][key] == b["process_thread_environment"][key],
                "Unexpected thread environment factor: " + key,
            )


def compare():
    preflight = base.read(ROOT / "native-thread-preflight.json")
    require(
        preflight.get("status") == "FROZEN_BEFORE_NATIVE_THREAD_RUNS"
        and preflight.get("case_order") == list(CASES)
        and preflight.get("models_labels_sources_unchanged") is True,
        "Native preflight did not freeze the declared experiment",
    )
    expected_frozen = {
        "native-thread-control-plan.md",
        "native_thread_ablation.py",
        "diagnostic_native_thread_case.py",
        "inputs-sha256.json",
        "sources-sha256.json",
    }
    require(
        set(preflight.get("sha256", {})) == expected_frozen
        and all(
            digest(observed.failed.safe_path(ROOT, name)) == expected
            for name, expected in preflight["sha256"].items()
        ),
        "Native preflight hash mismatch",
    )
    records = []
    raws = []
    querysets = []
    semantics = []
    manifests = []
    for name, setting in CASES.items():
        audited, raw, queries, semantic = observed.observed_case(name)
        require(
            base.timestamp(preflight["at"]) <= base.timestamp(raw["started_at"]),
            "Native run started before declared freeze",
        )
        manifest = native.execution(ROOT / name, raw, setting)
        audited["native_threads"] = native.collection(raw, audited, setting, manifest)
        audited["execution_manifest"] = manifest
        records.append(audited)
        raws.append(raw)
        querysets.append(queries)
        semantics.append(semantic)
        manifests.append(manifest)
    matched_factors(raws[0], raws[1], querysets[0], querysets[1])
    differences = semantic_differences(semantics[0], semantics[1])
    require(differences["different_groups"] > 0, "No result differences: use strict comparator")
    for key in (
        "base_driver_sha256",
        "derived_driver_sha256",
        "patch_sha256",
        "derived_diff_sha256",
        "parent_encoder_driver_sha256",
        "parent_encoder_patch_sha256",
        "parent_driver_diff_sha256",
        "parent_patch_diff_sha256",
        "base_override_sha256",
    ):
        require(manifests[0][key] == manifests[1][key], "Matched native code differs: " + key)
    require(
        records[0]["native_threads"]["interop"] == records[1]["native_threads"]["interop"],
        "Interop changed across arms",
    )
    resource_deltas = []
    for record in records:
        warm = record["snapshots"]["warmup"]
        for label, end in record["snapshots"].items():
            if label in ("ready", "warmup"):
                continue
            resource_deltas.append(
                {
                    "case": record["case"],
                    "from": "warmup",
                    "to": label,
                    "process_rollup_delta_bytes": base.delta(
                        warm["process_rollup_bytes"], end["process_rollup_bytes"]
                    ),
                    "mallinfo2_delta": base.delta(warm["mallinfo2"], end["mallinfo2"]),
                    "pymalloc_delta": base.delta(warm["pymalloc"], end["pymalloc"]),
                    "task_ids_added": sorted(set(end["task_ids"]) - set(warm["task_ids"])),
                    "task_ids_removed": sorted(set(warm["task_ids"]) - set(end["task_ids"])),
                }
            )
    baseline, treatment = (raw["workload_status"] for raw in raws)
    return {
        "status": "REJECTED_RESULT_DIFFERENCE",
        "evidence_status": "RECONCILED",
        "baseline_workload_status": baseline,
        "treatment_workload_status": treatment,
        "candidate_protocol_eligible": False,
        "efficacy_verdict": "REJECTED_NO_PRODUCTION_PROMOTION",
        "case_order": list(CASES),
        "cases": records,
        "common_successful_groups": 5200,
        "common_successful_fingerprints_equal": False,
        "semantic_differences": differences,
        "strict_comparator_rejected": True,
        "strict_rejection_reason": "Cross-case semantic fingerprints differ",
        "strict_rejection_scope": "Original semantic_equality invoked on complete 5200-group maps; "
        "the strict comparator CLI was not rerun",
        "warmup_relative_resources": resource_deltas,
        "root_input_sha256": {
            name: digest(ROOT / name)
            for name in (
                "reconcile_native_difference.py",
                "native-thread-control-plan.md",
                "native-thread-preflight.json",
                "compare_native_thread_controls.py",
                "reconcile_encoder_failure.py",
                "compare_encoder_controls.py",
                "audit_failed_diagnostic.py",
                "compare_diagnostics.py",
                "setup/summary.json",
            )
        },
        "limitations": [
            "Worker getters are configuration observations, "
            "not busy-thread counts or all native libraries.",
            "Both arms use the same new native patch; "
            "the old encoder patch is an unexecuted derivation reference.",
            "Baseline failures remain failures; the complete 5200 successful-group sets "
            "are both complete; all cross-arm differences are retained.",
            "HTTP success does not imply experiment success. Sequential/background "
            "confounding and 7200-second normal validation remain separate.",
            "Drain proves encoder calls completed, not every background task in the server.",
        ],
    }


def validate_saved_differences(result):
    """Recompute all differences from hash-bound raw ledgers for publication/cleanup."""
    semantics = []
    for name in CASES:
        folder = ROOT / name
        raw = base.read(folder / "summary.json")
        queries, _ = base.read_queries(folder / "queries.csv")
        if raw["workload_status"] == "PASSED":
            _, semantic = base.ledger(folder, raw, queries)
        else:
            with (folder / "requests.jsonl").open(encoding="utf-8") as stream:
                _, semantic = observed.failed.reconcile_ledger(
                    (json.loads(line) for line in stream), raw, queries
                )
        semantics.append(semantic)
    differences = semantic_differences(*semantics)
    require(
        differences["different_groups"] > 0
        and differences == result.get("semantic_differences")
        and result.get("strict_comparator_rejected") is True
        and result.get("strict_rejection_reason") == "Cross-case semantic fingerprints differ",
        "Saved result differences do not match complete raw ledgers",
    )


def self_test():
    left = {
        (f"q{i}", mode): ("a" * 64, "b" * 64, "model", 10)
        for i in range(1300)
        for mode in ("bm25", "vector", "hybrid", "ltr")
    }
    right = copy.deepcopy(left)
    right[("q0", "vector")] = ("c" * 64, "b" * 64, "model", 10)
    right[("q1", "ltr")] = ("d" * 64, "e" * 64, "other", 9)
    changes = semantic_differences(left, right)
    require(
        changes["different_groups"] == 2
        and changes["by_field"]
        == {"result_sha256": 2, "ranking_sha256": 1, "model_version": 1, "result_count": 1},
        "Field differences lost",
    )
    require(semantic_differences(left, left)["different_groups"] == 0, "Equal groups changed")
    missing = dict(right)
    missing.pop(("q0", "vector"))
    swapped = dict(right)
    swapped[("new", "vector")] = swapped.pop(("q0", "vector"))
    for bad in (missing, swapped):
        try:
            semantic_differences(left, bad)
        except ValueError:
            pass
        else:
            raise ValueError("Incomplete/key-shifted groups accepted")
    print(
        json.dumps(
            {
                "status": "TOY_CHECKS_PASSED",
                "groups": 5200,
                "exact_all_field_differences": True,
                "missing_and_shifted_keys_rejected": True,
                "strict_semantic_comparator_rejects": True,
                "real_requests": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    output = ROOT / "native-thread-comparison-rejected.json"
    with output.open("x", encoding="utf-8") as sink:
        json.dump({"evidence_status": "RUNNING", "candidate_protocol_eligible": False}, sink)
    try:
        result = compare()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result = {
            "status": "UNRECONCILED",
            "evidence_status": "UNRECONCILED",
            "candidate_protocol_eligible": False,
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    result["audited_at"] = datetime.now(UTC).isoformat()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {k: result[k] for k in ("status", "evidence_status", "candidate_protocol_eligible")}
        )
    )
    return int(result["evidence_status"] != "RECONCILED")


if __name__ == "__main__":
    raise SystemExit(main())
