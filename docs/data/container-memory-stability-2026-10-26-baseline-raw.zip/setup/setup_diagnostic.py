"""Prepare only the fresh owned diagnostic project; preserve existing failure evidence."""

from __future__ import annotations

import asyncio
import hashlib
import json
from argparse import Namespace
from pathlib import Path

import httpx
from scripts.bench_concurrent import read_queries
from scripts.validate_container_soak import Harness

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = "sp-memory-diagnostic-20261026"
IMAGE = "searchpilot-validation:2026-10-25-expanded"
SCRIPTS = (
    "bench_concurrent.py",
    "validate_container_soak.py",
    "diagnose_allocator.py",
    "soak_memory.py",
    "summarize_soak.py",
)
HELPERS = ("setup_diagnostic.py", "diagnostic_case.py")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_new(path, data):
    with path.open("xb") as sink:
        sink.write(data)


async def main():
    frozen, preflight = read(ROOT / "inputs-sha256.json"), read(ROOT / "preflight.json")
    require(preflight.get("status") == "PASSED", "Root preflight must pass")
    require(len(frozen) == 29, "Expected the 29 frozen inputs")
    require(
        all(digest(REPO / name) == value for name, value in frozen.items()),
        "Frozen input differs before setup",
    )
    expanded, expanded_raw = read_queries(ROOT / "fixture/queries.csv")
    original, original_raw = read_queries(REPO / "data/queries/queries.csv")
    require(
        len(expanded) == 1300 and len(original) == 100 and expanded[:100] == original,
        "Expanded fixture must retain the original 100 query texts in order",
    )
    require(
        hashlib.sha256(expanded_raw).hexdigest() == preflight["query_sha256"],
        "Fixture differs from root preflight",
    )
    harness = Harness(
        Namespace(
            out=ROOT / "setup",
            project=PROJECT,
            image=IMAGE,
            api_port=18232,
            db_port=15632,
            data_version="d3a904f41240",
            duration_seconds=3600,
            concurrency=32,
            baseline_seconds=60,
            recovery_seconds=120,
            queries=ROOT / "fixture/queries.csv",
        )
    )
    try:
        harness.prepare()  # Exclusive output and fresh project/volume/network checks precede up.
        runtime_scripts = {
            "scripts/" + name
            for name in (
                *SCRIPTS,
                "docker_entrypoint.py",
                "docker_seed.py",
                "seed_items.py",
                "seed_catalog.py",
            )
        }
        harness.report["local_source_sha256"] = {
            name: value
            for name, value in harness.report["local_source_sha256"].items()
            if name.startswith("src/") or name in runtime_scripts
        }
        require(harness.report["image"] == preflight["image"], "Image tag changed")
        for label, data in (("expanded1300", expanded_raw), ("original100", original_raw)):
            write_new(harness.out / (label + ".queries.csv"), data)
        for name in SCRIPTS:
            write_new(
                harness.out / (Path(name).stem + ".executed.py"),
                (REPO / "scripts" / name).read_bytes(),
            )
        for name in HELPERS:
            write_new(harness.out / name, (ROOT / name).read_bytes())
        for name, target in (
            (".env.example", "public-env.txt"),
            ("docker-compose.yml", "compose-base.yml"),
            ("Dockerfile", "Dockerfile"),
        ):
            write_new(harness.out / target, (REPO / name).read_bytes())
        harness.report["frozen_inputs"] = frozen
        harness.report["public_config_sha256"] = {
            name: digest(REPO / name)
            for name in (".env.example", "docker-compose.yml", "Dockerfile")
        }
        harness.report["helper_sha256"] = {name: digest(ROOT / name) for name in HELPERS}
        harness.report["executed_script_sha256"] = {
            name: digest(REPO / "scripts" / name) for name in SCRIPTS
        }
        harness.report["query_sets"] = {
            label: {
                "count": count,
                "sha256": hashlib.sha256(data).hexdigest(),
                "snapshot": label + ".queries.csv",
            }
            for label, count, data in (
                ("expanded1300", 1300, expanded_raw),
                ("original100", 100, original_raw),
            )
        }
        # Base Compose stays at repository root to preserve its relative bind mount paths.
        harness.compose[harness.compose.index("--env-file") + 1] = str(
            harness.out / "public-env.txt"
        )
        harness.report["compose_command"] = harness.compose
        harness.save()
        await asyncio.to_thread(
            harness.command, harness.compose + ["up", "-d", "--no-build", "api"], 180
        )
        async with httpx.AsyncClient(base_url=harness.base, trust_env=False, timeout=10) as client:
            harness.report["ready"] = await harness.readiness(client)
        harness.report["counts"] = harness.counts()
        for name, count in (
            ("items", 65238),
            ("queries", 100),
            ("relevance_labels", 1012),
            ("feedback_events", 0),
        ):
            require(
                harness.report["counts"][name] == count,
                "Unexpected initial database count: " + name,
            )
        harness.provenance()
        harness.report["state"] = (
            harness.state()
        )  # Native environment allowlist, never full Config.Env.
        require(
            all(digest(REPO / name) == value for name, value in frozen.items()),
            "Frozen input changed during setup",
        )
        harness.report["status"] = "READY_FOR_DIAGNOSTIC_RESTART"
    except BaseException as exc:
        harness.report.update(status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        if harness.owns_output:
            harness.save()
    print(
        json.dumps(
            {
                "status": harness.report["status"],
                "project": PROJECT,
                "image": harness.report["image"],
                "counts": harness.report["counts"],
            }
        )
    )


if __name__ == "__main__":
    asyncio.run(main())
