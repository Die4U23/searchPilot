"""Offline native-thread control audit; configuration strings alone never prove effect."""

from __future__ import annotations

import argparse
import copy
import json
import math
import re
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(ROOT))
import compare_diagnostics as base  # noqa: E402
import compare_encoder_controls as encoder  # noqa: E402
import reconcile_encoder_failure as observed  # noqa: E402

require, digest = base.require, observed.digest
CASES = {"diagnostic-omp-default-01": "unset", "diagnostic-omp1-01": "1"}
THREAD_KEYS = (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "OMP_THREAD_LIMIT",
    "OMP_DYNAMIC",
    "MKL_DYNAMIC",
    "NUMEXPR_NUM_THREADS",
    "NUMEXPR_MAX_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "OMP_MAX_ACTIVE_LEVELS",
    "OMP_NESTED",
    "OMP_PROC_BIND",
    "OMP_PLACES",
    "KMP_AFFINITY",
    "KMP_BLOCKTIME",
    "KMP_SETTINGS",
    "TOKENIZERS_PARALLELISM",
    "RAYON_NUM_THREADS",
)
TARGET = "/app/diagnostic/native_thread_ablation.py"
COUNTS = ("calls", "available", "unavailable", "errors", "histogram_overflow")


def observation_shape(row):
    for key in COUNTS:
        require(type(row.get(key)) is int and row[key] >= 0, "Invalid getter count: " + key)
    require(
        row["calls"] == sum(row[key] for key in ("available", "unavailable", "errors")),
        "Getter accounting mismatch",
    )
    require(row["histogram_overflow"] == 0, "Getter histogram overflow")
    histograms = {}
    for name in ("intra", "interop"):
        hist = row[name + "_histogram"]
        require(isinstance(hist, dict) and len(hist) <= 16, "Unbounded getter histogram")
        require(
            all(
                isinstance(key, str)
                and re.fullmatch(r"[1-9][0-9]*", key)
                and type(count) is int
                and count > 0
                for key, count in hist.items()
            ),
            "Malformed getter histogram",
        )
        require(sum(hist.values()) == row["available"], "Getter histogram denominator differs")
        for suffix, expected in (
            ("_eq1", hist.get("1", 0)),
            ("_gt1", sum(v for k, v in hist.items() if k != "1")),
        ):
            require(
                type(row.get(name + suffix)) is int and row[name + suffix] == expected,
                "Getter category differs",
            )
        values = [int(value) for value in hist]
        for suffix, expected in (
            ("_min", min(values) if values else None),
            ("_max", max(values) if values else None),
        ):
            require(
                row.get(name + suffix) == expected
                and (expected is None or type(row[name + suffix]) is int),
                "Getter range differs",
            )
        histograms[name] = hist
    return histograms


def thread_delta(warm, drained, setting):
    require(warm["limit"] == drained["limit"] == 32, "Encoder concurrency changed")
    for stats in (warm, drained):
        for key in encoder.INTEGER_COUNTERS:
            require(type(stats.get(key)) is int and stats[key] >= 0, "Invalid encoder counter")
        require(
            stats["active"] == stats["waiting"] == 0 and stats["errors"] == 0,
            "Encoder not cleanly drained",
        )
        require(0 < stats["peak_active"] <= 32, "Invalid observed encoder execution peak")
    require(
        all(
            drained[key] - warm[key] == 15600
            for key in ("calls_started", "calls_entered", "calls_completed")
        ),
        "Formal encoder denominator is not 15600 from warmup to encoder drain",
    )
    stages = {}
    for stage in ("before", "after"):
        left, right = (stats["torch_thread_observations"][stage] for stats in (warm, drained))
        lh, rh = observation_shape(left), observation_shape(right)
        changes = {key: right[key] - left[key] for key in COUNTS}
        require(
            changes
            == {
                "calls": 15600,
                "available": 15600,
                "unavailable": 0,
                "errors": 0,
                "histogram_overflow": 0,
            },
            "Formal actual-worker getter coverage is incomplete",
        )
        deltas = {}
        for metric in ("intra", "interop"):
            difference = {
                key: rh[metric].get(key, 0) - lh[metric].get(key, 0)
                for key in rh[metric].keys() | lh[metric].keys()
            }
            require(all(value >= 0 for value in difference.values()), "Getter histogram reset")
            deltas[metric] = {key: value for key, value in difference.items() if value}
        require(
            sum(deltas["intra"].values()) == 15600 and sum(deltas["interop"].values()) == 15600,
            "Wrong measured histogram",
        )
        require(
            deltas["intra"] == {"1": 15600}
            if setting == "1"
            else all(int(key) > 1 for key in deltas["intra"]),
            "OMP intervention is not observed in actual call threads",
        )
        require(len(deltas["interop"]) == 1, "Interop varied in formal calls")
        stages[stage] = {
            "counts": changes,
            "intra_histogram": deltas["intra"],
            "interop_histogram": deltas["interop"],
        }
    require(
        stages["before"]["interop_histogram"] == stages["after"]["interop_histogram"],
        "Interop changed around encoder",
    )
    return {
        "stages": stages,
        "encoder_calls": 15600,
        "peak_encoder_active": drained["peak_active"],
        "startup_warmup_getters": warm["torch_thread_observations"],
        "interop": next(iter(stages["after"]["interop_histogram"])),
    }


def execution(case, raw, setting, *, initial_only=False):
    manifest = base.read(case / "execution-manifest.json")
    expected_env = {key: None for key in THREAD_KEYS}
    expected_env["OMP_NUM_THREADS"] = None if setting == "unset" else "1"
    require(
        manifest == raw["execution_manifest"]
        and raw["omp_threads"] == manifest["omp_threads"] == setting
        and raw["encoder_limit"] == manifest["encoder_limit"] == 32,
        "Native control manifest mismatch",
    )
    require(
        manifest["variant"] == "diagnostic_native_thread_environment"
        and manifest["actual_entry"] == "diagnostic_native_thread_case.executed.py"
        and manifest["parent_copy_role"]
        == (
            "The encoder parent driver and patch base copies "
            "are unexecuted derivation references; only native patch is installed"
        ),
        "Actual native entry/patch is ambiguous",
    )
    paths = {
        "diagnostic_case.executed.py": "base_driver_sha256",
        "diagnostic_native_thread_case.executed.py": "derived_driver_sha256",
        "native_thread_ablation.executed.py": "patch_sha256",
        "diagnostic_encoder_case.base.py": "parent_encoder_driver_sha256",
        "encoder_concurrency_ablation.base.py": "parent_encoder_patch_sha256",
        "derived-driver.diff": "derived_diff_sha256",
        "parent-driver.diff": "parent_driver_diff_sha256",
        "parent-patch.diff": "parent_patch_diff_sha256",
        "override.yml": "base_override_sha256",
        "native-thread.override.yml": "native_override_sha256",
    }
    require(
        all(
            digest(observed.failed.safe_path(case, name)) == manifest[key]
            for name, key in paths.items()
        ),
        "Native executed snapshot changed",
    )
    for name, key in (
        ("diagnostic_native_thread_case.py", "derived_driver_sha256"),
        ("native_thread_ablation.py", "patch_sha256"),
        ("diagnostic_encoder_case.py", "parent_encoder_driver_sha256"),
        ("encoder_concurrency_ablation.py", "parent_encoder_patch_sha256"),
    ):
        require(digest(ROOT / name) == manifest[key], "Native/parent frozen helper changed")
    require(
        manifest["patch_sha256"] != manifest["parent_encoder_patch_sha256"]
        and manifest["derived_driver_sha256"] != manifest["parent_encoder_driver_sha256"],
        "Parent copy masquerades as actual code",
    )
    command = encoder.command(32)
    command[2] = command[2].replace(
        "from encoder_concurrency_ablation", "from native_thread_ablation"
    )
    require(
        manifest["expected_command"] == command
        and manifest["expected_thread_environment"] == expected_env
        and raw["process_thread_environment"] == expected_env,
        "Actual command or PID1 thread environment differs",
    )
    patch_copy = case / "native_thread_ablation.executed.py"
    require(
        manifest["patch_target"] == TARGET
        and encoder.host_path(manifest["patch_host_path"]) == encoder.host_path(str(patch_copy)),
        "Wrong native patch target",
    )
    require(
        base.read(case / "native-thread.override.yml")
        == {
            "services": {
                "api": {
                    "command": command,
                    "environment": expected_env,
                    "volumes": [
                        {
                            "type": "bind",
                            "source": str(patch_copy),
                            "target": TARGET,
                            "read_only": True,
                        }
                    ],
                }
            }
        },
        "Unexpected native override factor",
    )
    expected_mounts = {
        "/app/scripts/" + name: encoder.host_path(
            str(ROOT / "setup" / (Path(name).stem + ".executed.py"))
        )
        for name in ("diagnose_allocator.py", "soak_memory.py")
    }
    expected_mounts[TARGET] = encoder.host_path(str(patch_copy))
    for field in ("container",) if initial_only else ("container", "final_container"):
        container = raw[field]
        require(
            container["command"] == command
            and container["entrypoint"] is None
            and container["thread_environment"] == expected_env
            and encoder.mount_map(container["diagnostic_mounts"]) == expected_mounts,
            "Actual native runtime differs",
        )
    runtime = manifest["runtime"]
    require(
        runtime == {key: raw["container"][key] for key in runtime}
        and {"Id", "Image", "command", "entrypoint", "diagnostic_mounts"} <= runtime.keys(),
        "Native runtime manifest differs",
    )
    return manifest


def collection(raw, audited, setting, manifest):
    require(raw.get("collection_status") == "COMPLETED", "Native collection did not complete")
    expected = (
        "COMPLETED" if raw["workload_status"] == "PASSED" else "COMPLETED_WITH_WORKLOAD_FAILURES"
    )
    require(
        raw["status"] == expected and raw["workload_status"] in ("PASSED", "FAILED"),
        "Workload/collection statuses disagree",
    )
    snapshots = {row["label"]: row for row in raw["snapshots"]}
    require(
        list(snapshots) == list(base.LABELS) and len(raw["snapshots"]) == len(base.LABELS),
        "Required observations missing/reordered",
    )
    require(
        not audited.get("unavailable_snapshots") and len(audited["snapshots"]) == len(base.LABELS),
        "Native observation unavailable",
    )
    identities = {row["pid_start_ticks"] for row in audited["snapshots"].values()}
    require(
        len(identities) == 1 and audited["observations"].get("pid_start_ticks") in identities,
        "Native snapshots and sampled process identities differ",
    )
    require(
        base.timestamp(snapshots["idle"]["started_at"]) - base.timestamp(raw["idle_started_at"])
        >= timedelta(seconds=120),
        "Idle shorter than120s",
    )
    for label in ("gc", "trim"):
        require(
            snapshots[label]["data"].get("action") == "/" + label, "Wrong diagnostic intervention"
        )
    require(
        raw["final_container"]["Id"] == raw["container"]["Id"]
        and raw["final_container"]["RestartCount"] == 0
        and raw["final_container"]["State"]["OOMKilled"] is False,
        "Final process identity/restart/OOM failure",
    )
    stats = {
        label: row["data"].get("snapshot", row["data"])["encoder_concurrency"]
        for label, row in snapshots.items()
    }
    identities = []
    for label, value in stats.items():
        require(
            value["variant"] == "native_thread_observation"
            and value["limit"] == 32
            and value["patch_sha256"] == manifest["patch_sha256"]
            and value["original_source_sha256"] == raw["source_sha256"][encoder.SOURCE_KEY]
            and value["original_qualname"] == "SentenceTransformerQueryEncoder.__call__",
            "Wrong actual probe/encoder source",
        )
        require(
            base.timestamp(value["installed_at"]) <= base.timestamp(snapshots[label]["started_at"]),
            "Probe installed late",
        )
        identities.append(value["installed_at"])
        for stage in ("before", "after"):
            observation_shape(value["torch_thread_observations"][stage])
    require(len(set(identities)) == 1, "Probe reinstalled during control")
    load_end = base.timestamp(raw["load_finished_at"])
    drain_start = base.timestamp(raw["encoder_drain_started_at"])
    drain_end = base.timestamp(raw["encoder_drained_at"])
    require(
        load_end
        <= drain_start
        <= drain_end
        <= base.timestamp(snapshots["after_20800"]["started_at"]),
        "Client drain was confused with encoder drain",
    )
    require(
        type(raw["encoder_drain_seconds"]) in (int, float)
        and math.isfinite(raw["encoder_drain_seconds"])
        and 0 <= raw["encoder_drain_seconds"] <= 60
        and abs((drain_end - drain_start).total_seconds() - raw["encoder_drain_seconds"]) <= 1,
        "Invalid bounded encoder-drain duration",
    )
    polls = raw["drain_observations"]
    require(1 <= len(polls) <= 121, "Missing/unbounded encoder drain evidence")
    times = [base.timestamp(row["at"]) for row in polls]
    require(
        drain_start <= times[0] <= times[-1] <= drain_end
        and all(b >= a for a, b in zip(times, times[1:], strict=False)),
        "Drain polling time invalid",
    )
    measured = thread_delta(stats["warmup"], stats["after_20800"], setting)
    require(
        thread_delta(stats["warmup"], polls[-1]["encoder_concurrency"], setting) == measured,
        "Final poll and after20800 disagree",
    )
    for label in ("idle", "gc", "trim"):
        require(
            thread_delta(stats["warmup"], stats[label], setting) == measured,
            "Post-drain counters changed",
        )
    return {
        **measured,
        "encoder_drain_seconds": raw["encoder_drain_seconds"],
        "encoder_drain_scope": raw["encoder_drain_scope"],
        "drain_poll_count": len(polls),
        "all_snapshots": stats,
        "drain_observations": polls,
    }


def compare():
    preflight = base.read(ROOT / "native-thread-preflight.json")
    require(
        preflight.get("status") == "FROZEN_BEFORE_NATIVE_THREAD_RUNS"
        and preflight.get("case_order") == list(CASES)
        and preflight.get("models_labels_sources_unchanged") is True,
        "Native preflight did not freeze the declared experiment",
    )
    expected_frozen = {
        "native-thread-control-plan.md",
        "native_thread_ablation.py",
        "diagnostic_native_thread_case.py",
        "inputs-sha256.json",
        "sources-sha256.json",
    }
    require(
        set(preflight.get("sha256", {})) == expected_frozen
        and all(
            digest(observed.failed.safe_path(ROOT, name)) == expected
            for name, expected in preflight["sha256"].items()
        ),
        "Native preflight hash mismatch",
    )
    records = []
    raws = []
    querysets = []
    semantics = []
    manifests = []
    for name, setting in CASES.items():
        audited, raw, queries, semantic = observed.observed_case(name)
        require(
            base.timestamp(preflight["at"]) <= base.timestamp(raw["started_at"]),
            "Native run started before declared freeze",
        )
        manifest = execution(ROOT / name, raw, setting)
        audited["native_threads"] = collection(raw, audited, setting, manifest)
        audited["execution_manifest"] = manifest
        records.append(audited)
        raws.append(raw)
        querysets.append(queries)
        semantics.append(semantic)
        manifests.append(manifest)
    observed.matched(raws[0], raws[1], querysets[0], querysets[1], semantics[0], semantics[1])
    for key in (
        "base_driver_sha256",
        "derived_driver_sha256",
        "patch_sha256",
        "derived_diff_sha256",
        "parent_encoder_driver_sha256",
        "parent_encoder_patch_sha256",
        "parent_driver_diff_sha256",
        "parent_patch_diff_sha256",
        "base_override_sha256",
    ):
        require(manifests[0][key] == manifests[1][key], "Matched native code differs: " + key)
    require(
        records[0]["native_threads"]["interop"] == records[1]["native_threads"]["interop"],
        "Interop changed across arms",
    )
    resource_deltas = []
    for record in records:
        warm = record["snapshots"]["warmup"]
        for label, end in record["snapshots"].items():
            if label in ("ready", "warmup"):
                continue
            resource_deltas.append(
                {
                    "case": record["case"],
                    "from": "warmup",
                    "to": label,
                    "process_rollup_delta_bytes": base.delta(
                        warm["process_rollup_bytes"], end["process_rollup_bytes"]
                    ),
                    "mallinfo2_delta": base.delta(warm["mallinfo2"], end["mallinfo2"]),
                    "pymalloc_delta": base.delta(warm["pymalloc"], end["pymalloc"]),
                    "task_ids_added": sorted(set(end["task_ids"]) - set(warm["task_ids"])),
                    "task_ids_removed": sorted(set(warm["task_ids"]) - set(end["task_ids"])),
                }
            )
    baseline, treatment = (raw["workload_status"] for raw in raws)
    return {
        "status": "PROTOCOL_PASSED"
        if baseline == treatment == "PASSED"
        else "BASELINE_FAILED_TREATMENT_PASSED"
        if treatment == "PASSED"
        else "TREATMENT_FAILED",
        "evidence_status": "RECONCILED",
        "baseline_workload_status": baseline,
        "treatment_workload_status": treatment,
        "candidate_protocol_eligible": treatment == "PASSED",
        "efficacy_verdict": "REQUIRES_RESOURCE_EFFECT_REVIEW",
        "case_order": list(CASES),
        "cases": records,
        "common_successful_groups": 5200,
        "common_successful_fingerprints_equal": True,
        "warmup_relative_resources": resource_deltas,
        "root_input_sha256": {
            name: digest(ROOT / name)
            for name in (
                "native-thread-control-plan.md",
                "native-thread-preflight.json",
                "compare_native_thread_controls.py",
                "reconcile_encoder_failure.py",
                "compare_encoder_controls.py",
                "audit_failed_diagnostic.py",
                "compare_diagnostics.py",
                "setup/summary.json",
            )
        },
        "limitations": [
            "Worker getters are configuration observations, "
            "not busy-thread counts or all native libraries.",
            "Both arms use the same new native patch; "
            "the old encoder patch is an unexecuted derivation reference.",
            "Baseline failures remain failures; the complete 5200 successful-group sets "
            "must match, not only their intersection.",
            "Only protocol eligibility is computed. Memory effect, sequential/background "
            "confounding and 7200-second normal validation remain separate.",
            "Drain proves encoder calls completed, not every background task in the server.",
        ],
    }


def self_test():
    def stats(count, intra, missing=0):
        row = {
            "calls": count,
            "available": count - missing,
            "unavailable": missing,
            "errors": 0,
            "histogram_overflow": 0,
        }
        for name, value in (("intra", intra), ("interop", 8)):
            row.update(
                {
                    name + "_min": value,
                    name + "_max": value,
                    name + "_eq1": count - missing if value == 1 else 0,
                    name + "_gt1": count - missing if value > 1 else 0,
                    name + "_histogram": {str(value): count - missing},
                }
            )
        return row

    def encoder_stats(count, intra):
        return {
            "limit": 32,
            "calls_started": count,
            "calls_entered": count,
            "calls_completed": count,
            "errors": 0,
            "active": 0,
            "waiting": 0,
            "peak_active": 1,
            "peak_waiting": 1,
            "torch_thread_observations": {
                "before": stats(count, intra, 1),
                "after": stats(count, intra),
            },
        }

    warm, end = encoder_stats(13, 1), encoder_stats(15613, 1)
    require(thread_delta(warm, end, "1")["encoder_calls"] == 15600, "Toy denominator wrong")
    thread_delta(encoder_stats(13, 8), encoder_stats(15613, 8), "unset")
    rejected = []
    for fault in (
        "cumulative15613",
        "client_only_drain",
        "getter_missing",
        "getter_error",
        "wrong_intra",
        "overflow",
        "interop_change",
        "negative_histogram",
    ):
        bad = copy.deepcopy(end)
        if fault == "cumulative15613":
            bad["calls_completed"] += 13
        elif fault == "client_only_drain":
            bad["active"] = 1
        elif fault == "getter_missing":
            bad["torch_thread_observations"]["before"]["available"] -= 1
        elif fault == "getter_error":
            bad["torch_thread_observations"]["after"]["errors"] = 1
        elif fault == "wrong_intra":
            bad = encoder_stats(15613, 8)
        elif fault == "overflow":
            bad["torch_thread_observations"]["before"]["histogram_overflow"] = 1
        elif fault == "interop_change":
            bad["torch_thread_observations"]["after"].update(
                interop_histogram={"8": 13, "4": 15600}, interop_min=4, interop_max=8
            )
        else:
            bad["torch_thread_observations"]["before"]["intra_histogram"] = {"1": -1}
        try:
            thread_delta(warm, bad, "1")
        except ValueError:
            rejected.append(fault)
        else:
            raise AssertionError("Invalid thread proof passed: " + fault)
    print(
        json.dumps(
            {
                "status": "TOY_CHECKS_PASSED",
                "formal_count": 15600,
                "rejected": rejected,
                "real_requests": 0,
                "files_written": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument(
        "--check-initial",
        choices=CASES,
        help="Read-only actual initial manifest check; never claims collection completion",
    )
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.check_initial:
        case = ROOT / args.check_initial
        raw = base.read(case / "summary.json")
        manifest = execution(case, raw, CASES[args.check_initial], initial_only=True)
        preflight = base.read(ROOT / "native-thread-preflight.json")
        require(
            base.timestamp(preflight["at"]) <= base.timestamp(raw["started_at"])
            and all(
                digest(observed.failed.safe_path(ROOT, name)) == expected
                for name, expected in preflight["sha256"].items()
            ),
            "Initial execution preflight hash/time mismatch",
        )
        print(
            json.dumps(
                {
                    "scope": "INITIAL_EXECUTION_ONLY",
                    "identity_consistent": True,
                    "recorded_status": raw["status"],
                    "actual_entry": manifest["actual_entry"],
                    "final_container_checked": False,
                    "collection_or_workload_pass_inferred": False,
                    "files_written": 0,
                }
            )
        )
        return 0
    output = ROOT / "native-thread-comparison.json"
    with output.open("x", encoding="utf-8") as sink:
        json.dump({"evidence_status": "RUNNING", "candidate_protocol_eligible": False}, sink)
    try:
        result = compare()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result = {
            "status": "UNRECONCILED",
            "evidence_status": "UNRECONCILED",
            "candidate_protocol_eligible": False,
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    result["audited_at"] = datetime.now(UTC).isoformat()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                key: result[key]
                for key in ("status", "evidence_status", "candidate_protocol_eligible")
            }
        )
    )
    return int(result["evidence_status"] != "RECONCILED")


if __name__ == "__main__":
    raise SystemExit(main())
