# 原生线程配置对照（任何新组启动之前声明）

2026-10-26T07:48 UTC。encoder2 组仍运行，已出现一次 HTTP timeout，且在实际编码
调用的累计计数中观察到最大信号量等待 10.583 秒；因此该候选目前不能推广。
原始失败和原 encoder32/2 协议全部保留，不修改原脚本或通过门槛。

## 新假设和匹配方法

检查每次 CPU 编码的内部并行，是否在 HTTP c32 下增加线程/分配器高水位。
两组继续使用同一冻结镜像、模型、查询、数据库、THP-off/arena2，API 每组重建：

| case | OMP_NUM_THREADS | HTTP 并发 | encoder 信号量 | 正式请求 |
|---|---|---:|---:|---:|
| diagnostic-omp-default-01 | 显式移除 | 32 | 32 | 20800 |
| diagnostic-omp1-01 | 1 | 32 | 32 | 20800 |

顺序 default→1。每组 expanded1300、四模式、16 预热、limit10、总 timeout10 秒、
无重试、原五检查点与两分钟 idle 后 GC/trim 协议不变。先自然完成当前 encoder2。
两组使用同一个新诊断包装器；保留全部执行源码、原版/派生差异、只读挂载和实际命令。
运行前从 Compose 子进程环境清除线程控制变量，防止 null 分支意外继承宿主设置。
MKL_NUM_THREADS、OPENBLAS_NUM_THREADS、OMP_THREAD_LIMIT、OMP_DYNAMIC、
MKL_DYNAMIC、NUMEXPR_NUM_THREADS、VECLIB_MAXIMUM_THREADS 等白名单在两组保持
一致并保存；不设置 torch.set_num_threads，不改变 interop 或模型逻辑。

## 干预生效与验收

- 在实际调用编码器的工作线程中、原调用前后读取已经导入的 torch.get_num_threads
  与 get_num_interop_threads。探针不能提前导入模型栈；只有固定大小的计数/min/max，
  不保留每次查询对象。启动首次 import 前不可用可单列，正式 15600 次编码前后均须
  可用、无观测错误；完整记录 min/max/等于1/大于1计数。
- default 组正式调用观察值须大于1；OMP=1 组须始终等于1，interop保持一致。
  否则干预未生效，不以配置字符串当作成功证据。
- HTTP 实测峰值32；编码峰值如实报告（<=32），不强制两组具有相同执行重叠。
  配置改变可能改变实际重叠；不能据此伪造峰值。
- 完整请求配对、5200查询×模式覆盖、组内成功指纹稳定、两组成功指纹完全一致。
  所有失败保留在分母和结果中。若基线失败，它仍是失败基线，不能改称通过；处理组
  成为候选必须20800/20800成功、16/16预热成功、编码异常0且最终排空。
- 报告自身 warmup→各检查点/idle 的 RSS、Anonymous、glibc used/free、pymalloc、
  实际task ID变化及背景观测；未执行阶段保持缺失。不同统计口径不相加。
- 若实际线程值下降但保留/后段增长未改善、响应指纹变化或处理组引入超时，则不推广。
  若支持候选，才实现可逆生产配置，并使用正常入口完整7200秒及600秒恢复验证。
  原 acceptance-plan.md 的所有最终账本、业务、健康、覆盖与内存门槛完全不变。

get_num_threads 是调用线程看到的配置，不是同时忙碌线程数，也不涵盖所有原生库。
顺序和共享宿主的限制继续存在；即使改善，也只能支持 OMP 环境干预效果，不能将全部
历史增长归为特定库的线程缓存。不修改冻结模型、标签或依赖，不使用私有 .env。

## 运行前审查补充（两组均尚未启动）

正式编码和getter计数使用 warmup 快照到最终服务端排空快照的差值，排除 startup 与
warmup 的13次编码。客户端全部结果结束后，至多60秒只读控制轮询并保存每次观察；
只有started=entered=completed增量均15600且active=waiting=0，才能称编码器排空。
轮询不发搜索请求，期满仍未满足则收集失败并保留所有记录，不填补缺失。

新driver对任一组的HTTP业务失败仍继续进行计划的排空/idle/GC/trim采集（前提是控制
接口和进程本身可用）。收集完成但有业务失败时，必须写
COMPLETED_WITH_WORKLOAD_FAILURES/collection_status=COMPLETED/workload_status=FAILED；
不得标成实验通过。其他采集异常仍为FAILED。原有四组失败处理和状态不追溯修改。

跨组成功语义比较要求两组完整5200个组都有成功指纹，不能仅比较成功交集。基线若某
组四次全失败，该组语义是未验证；处理组即使成功，也不能自动取得完整对照资格。
