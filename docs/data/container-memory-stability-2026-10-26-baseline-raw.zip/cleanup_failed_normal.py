"""Clean only exact failed-normal resources after verified rejected-baseline archival."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

import cleanup_owned as original
import package_failed_baseline as packaging
from reconcile_failed_normal import PROJECT, validate_saved

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECTS = {"normal": PROJECT}
DOCKER, FLAGS, clean_environment = original.DOCKER, original.FLAGS, original.clean_environment
now, read, require = original.now, original.read, original.require


def verified_archive():
    record, hashes = read(packaging.RECORD), read(packaging.SHA_RECORD)
    require(
        record["status"] == "VERIFIED"
        and record.get("production_acceptance") is False
        and record.get("baseline_status") == "FAILED_STABILITY_RECONCILED"
        and record["crc_verified"] is True
        and record["every_member_hash_verified"] is True,
        "Rejected baseline archive not verified",
    )
    archive_path = packaging.safe_path(REPO, packaging.DESTINATION.relative_to(REPO).as_posix())
    require(archive_path.stat().st_size <= packaging.LIMIT, "Archive exceeds fixed 90 MiB limit")
    require(
        record["path"] == archive_path.relative_to(REPO).as_posix()
        and hashes["archive"] == {k: record[k] for k in ("path", "bytes", "sha256")}
        and archive_path.stat().st_size == record["bytes"]
        and packaging.file_hash(archive_path) == record["sha256"],
        "Archive identity changed",
    )
    with zipfile.ZipFile(archive_path) as archive:
        manifest = json.loads(archive.read("SHA256SUMS.json"))
        require(manifest == hashes["members"], "Archive manifest differs")
        require(
            len(archive.namelist()) == len(manifest) + 1
            and set(archive.namelist()) == set(manifest) | {"SHA256SUMS.json"}
            and archive.testzip() is None,
            "Archive membership/CRC differs",
        )
        for name, expected in manifest.items():
            packaging.original.permitted_name(name, archive=True)
            count, hasher = 0, hashlib.sha256()
            with archive.open(name) as stream:
                for chunk in iter(lambda: stream.read(packaging.CHUNK), b""):
                    count += len(chunk)
                    hasher.update(chunk)
            require(
                expected == {"bytes": count, "sha256": hasher.hexdigest()},
                "Archive member changed: " + name,
            )
            if name != "EVIDENCE-SCOPE.json":
                require(
                    packaging.file_hash(packaging.safe_path(ROOT, name)) == expected["sha256"],
                    "Archived source changed: " + name,
                )
        scope = json.loads(archive.read("EVIDENCE-SCOPE.json"))
        require(
            scope.get("production_acceptance") is False
            and scope.get("baseline_status") == "FAILED_STABILITY_RECONCILED",
            "Archive scope is not rejected baseline",
        )
    return record


def completed_evidence(target, project):
    require(
        target == "normal" and project == PROJECT, "Only exact failed normal project is allowed"
    )
    validate_saved()
    verified_archive()
    summary = read(ROOT / "final-two-hour/summary.json")
    expected = {row["Name"].lstrip("/"): row["Id"] for row in summary["final_state"]}
    require(
        set(expected) == {PROJECT + "-api-1", PROJECT + "-db-1"},
        "Unexpected failed-normal resources",
    )
    return expected, [
        "final-two-hour/failed-stability-reconciliation.json",
        packaging.RECORD.name,
        packaging.SHA_RECORD.name,
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", choices=PROJECTS)
    parser.add_argument("--attempt", default="01", help="new evidence suffix for an explicit retry")
    args = parser.parse_args()
    require(bool(re.fullmatch(r"[a-z0-9-]{1,40}", args.attempt)), "Invalid evidence suffix")
    project = PROJECTS[args.target]
    volume, network = project + "_pgdata", project + "_default"
    require(volume != "searchpilot_pgdata", "Original volume can never be a cleanup target")
    record_path = ROOT / f"cleanup-failed-{args.target}-{args.attempt}.json"
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "target": args.target,
        "project": project,
        "commands": [],
        "deleted_containers": [],
        "deleted_volumes": [],
        "deleted_networks": [],
        "private_env_read": False,
    }
    with record_path.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)

    def save():
        record_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    def command(args, timeout=60):
        row = {"argv": [DOCKER, *args], "started_at": now()}
        record["commands"].append(row)
        save()
        try:
            result = subprocess.run(
                row["argv"],
                cwd=REPO,
                env=clean_environment(),
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=timeout,
                check=True,
                creationflags=FLAGS,
            )
            row["exit_code"] = result.returncode
            return result.stdout
        except BaseException as exc:
            row["error_type"] = type(exc).__name__
            raise
        finally:
            row["finished_at"] = now()
            save()

    def inspect(kind, name):
        rows = json.loads(command([kind, "inspect", name]))
        require(len(rows) == 1, "Inspection did not resolve exactly one resource")
        return rows[0]

    try:
        expected, record["completion_evidence"] = completed_evidence(args.target, project)
        preflight = read(ROOT / "preflight.json")
        require(preflight["status"] == "PASSED", "Preflight did not pass")
        original = inspect("volume", "searchpilot_pgdata")
        require(
            original == preflight["original_volume"],
            "Original volume metadata differs from preflight",
        )
        record["original_volume_before"] = original
        names = set(
            command(
                [
                    "ps",
                    "-a",
                    "--filter",
                    "label=com.docker.compose.project=" + project,
                    "--format",
                    "{{.Names}}",
                ]
            ).splitlines()
        )
        require(names == set(expected), "Project container set differs from exact declared names")
        containers = {}
        for role in ("api", "db"):
            name = project + "-" + role + "-1"
            c = inspect("container", name)
            labels = c["Config"]["Labels"]
            require(
                c["Name"] == "/" + name and c["Id"] == expected[name],
                "Container was replaced since completion",
            )
            require(
                labels.get("com.docker.compose.project") == project
                and labels.get("com.docker.compose.service") == role,
                "Container labels mismatch",
            )
            require(
                labels.get("com.docker.compose.container-number") == "1",
                "Unexpected container number",
            )
            if role == "db":
                require(
                    any(
                        mount.get("Type") == "volume" and mount.get("Name") == volume
                        for mount in c["Mounts"]
                    ),
                    "Database is not bound to the declared owned volume",
                )
            containers[name] = c["Id"]
        owned = inspect("volume", volume)
        require(
            owned["Name"] == volume
            and owned["Labels"].get("com.docker.compose.project") == project
            and owned["Labels"].get("com.docker.compose.volume") == "pgdata",
            "Volume labels mismatch",
        )
        require(
            set(
                command(
                    [
                        "volume",
                        "ls",
                        "--filter",
                        "label=com.docker.compose.project=" + project,
                        "--format",
                        "{{.Name}}",
                    ]
                ).splitlines()
            )
            == {volume},
            "Unexpected project volume set",
        )
        net = inspect("network", network)
        require(
            net["Name"] == network
            and net["Labels"].get("com.docker.compose.project") == project
            and net["Labels"].get("com.docker.compose.network") == "default",
            "Network labels mismatch",
        )
        require(
            set(
                command(
                    [
                        "network",
                        "ls",
                        "--filter",
                        "label=com.docker.compose.project=" + project,
                        "--format",
                        "{{.Name}}",
                    ]
                ).splitlines()
            )
            == {network},
            "Unexpected project network set",
        )
        require(
            set(net.get("Containers", {})) <= set(containers.values()),
            "Network has other containers",
        )
        record.update(
            verified_containers=containers,
            verified_volume=owned,
            verified_network={"Name": network, "Id": net["Id"], "Labels": net["Labels"]},
        )
        save()
        # All identities were validated before the first destructive command. Never use prune.
        for name, container_id in containers.items():
            current = inspect("container", container_id)
            require(
                current["Name"] == "/" + name
                and current["Config"]["Labels"].get("com.docker.compose.project") == project,
                "Container changed during cleanup",
            )
            command(["stop", "--time", "30", container_id], timeout=60)
            command(["rm", container_id])
            record["deleted_containers"].append(container_id)
            save()
        require(inspect("volume", volume) == owned, "Owned volume changed during cleanup")
        require(
            inspect("volume", "searchpilot_pgdata") == original,
            "Original volume changed during cleanup",
        )
        command(["volume", "rm", volume])
        record["deleted_volumes"].append(volume)
        save()
        current_network = inspect("network", network)
        require(
            current_network["Id"] == net["Id"] and not current_network.get("Containers"),
            "Network changed or still attached",
        )
        command(["network", "rm", net["Id"]])
        record["deleted_networks"].append(network)
        require(
            inspect("volume", "searchpilot_pgdata") == preflight["original_volume"],
            "Original volume metadata changed",
        )
        require(
            not command(
                ["ps", "-aq", "--filter", "label=com.docker.compose.project=" + project]
            ).strip(),
            "Owned containers remain",
        )
        require(
            volume not in command(["volume", "ls", "--format", "{{.Name}}"]).splitlines(),
            "Owned volume remains",
        )
        record.update(status="COMPLETED", original_volume_metadata_unchanged=True)
    except BaseException as exc:
        record.update(
            status="INTERRUPTED" if isinstance(exc, KeyboardInterrupt) else "FAILED",
            error_type=type(exc).__name__,
        )
        raise
    finally:
        record["finished_at"] = now()
        save()
        print(json.dumps(record))


if __name__ == "__main__":
    main()
