"""Offline tests of failed-baseline delivery; no Docker, HTTP or real archive output."""

import ast
import copy
import hashlib
import inspect
import json
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cleanup_failed_normal as cleanup  # noqa: E402
import package_failed_baseline as packaging  # noqa: E402
import reconcile_failed_normal as failed  # noqa: E402


def reports():
    memory = {
        "status": "FAILED",
        "errors": [],
        "gates": {
            "rss": {
                "passed": False,
                "checks": {"stable_growth": True, "five_minute_median_range": False},
            },
            "anonymous": {
                "passed": False,
                "checks": {"stable_growth": True, "five_minute_median_range": False},
            },
        },
    }
    acceptance = {
        "status": "FAILED",
        "checks": {"business": True, "ready_all_success": True, "two_hour_memory_stability": False},
        "memory_gate": memory,
    }
    return acceptance, memory


def test_original_business_checks_are_exactly_preserved():
    source = (failed.ROOT / "audit_case.py").read_text(encoding="utf-8")
    assert failed.digest(failed.ROOT / "audit_case.py") == failed.ORIGINAL_AUDITOR_SHA256
    body = source[
        source.index("    ledger, input_sha256 = verify_normal_raw(folder)") : source.index(
            '    with output.open("x", encoding="utf-8") as sink:'
        )
    ]
    body = body.replace("args.case", '"final-two-hour"')
    left = body.index('    stability_path = folder / "stability.json"')
    right = body.index("    groups = [", left)
    body = (
        body[:left]
        + '    checks["two_hour_memory_stability"] = memory_gate.get("status") == "PASSED"\n'
        + body[right:]
    )
    expected = ast.parse(
        "def recompute_acceptance(folder, memory_gate):\n" + body + "    return record\n"
    )
    actual = ast.parse(inspect.getsource(failed.recompute_acceptance))
    assert ast.dump(expected, include_attributes=False) == ast.dump(
        actual, include_attributes=False
    )


def test_failed_gates_all_listed_and_never_pass():
    acceptance, memory = reports()
    checks, gates = failed.compare_failed_reports(acceptance, memory, acceptance, memory)
    assert checks == ["two_hour_memory_stability"]
    assert gates == ["rss.five_minute_median_range", "anonymous.five_minute_median_range"]
    acceptance["checks"]["business"] = False
    checks, _ = failed.compare_failed_reports(acceptance, memory, acceptance, memory)
    assert checks == ["business", "two_hour_memory_stability"]


@pytest.mark.parametrize(
    "mutation", ["stale_acceptance", "stale_memory", "no_failure", "missing_samples"]
)
def test_incomplete_or_stale_failure_not_reconciled(mutation):
    acceptance, memory = reports()
    a, m = copy.deepcopy(acceptance), copy.deepcopy(memory)
    if mutation == "stale_acceptance":
        a["checks"]["business"] = False
    elif mutation == "stale_memory":
        m["gates"]["rss"]["checks"]["stable_growth"] = False
    elif mutation == "no_failure":
        for row in memory["gates"].values():
            row["checks"]["five_minute_median_range"] = True
        m = copy.deepcopy(memory)
    else:
        memory["errors"] = ["missing sample"]
        m = copy.deepcopy(memory)
    with pytest.raises(ValueError):
        failed.compare_failed_reports(a, m, acceptance, memory)


def test_passing_run_cannot_enter_failed_delivery():
    acceptance, memory = reports()
    acceptance["status"] = memory["status"] = "PASSED"
    with pytest.raises(ValueError, match="did not fail"):
        failed.compare_failed_reports(acceptance, memory, acceptance, memory)


@pytest.fixture
def toy_archive(tmp_path, monkeypatch):
    root = tmp_path / "evidence"
    root.mkdir()
    destination = tmp_path / "docs/baseline.zip"
    destination.parent.mkdir()
    record_path = root / "baseline-archive-verification.json"
    sha_path = root / "baseline-archive-sha256.json"
    data = b'{"status":"FAILED"}\n'
    (root / "toy.json").write_bytes(data)
    scope = json.dumps(
        {"production_acceptance": False, "baseline_status": "FAILED_STABILITY_RECONCILED"}
    ).encode()
    members = {"toy.json": data, "EVIDENCE-SCOPE.json": scope}
    manifest = {
        name: {"bytes": len(value), "sha256": hashlib.sha256(value).hexdigest()}
        for name, value in members.items()
    }
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, value in members.items():
            archive.writestr(name, value)
        archive.writestr("SHA256SUMS.json", json.dumps(manifest))
    record = {
        "status": "VERIFIED",
        "production_acceptance": False,
        "baseline_status": "FAILED_STABILITY_RECONCILED",
        "crc_verified": True,
        "every_member_hash_verified": True,
        "path": "docs/baseline.zip",
        "bytes": destination.stat().st_size,
        "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
    }
    record_path.write_text(json.dumps(record), encoding="utf-8")
    sha_path.write_text(
        json.dumps(
            {"archive": {k: record[k] for k in ("path", "bytes", "sha256")}, "members": manifest}
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(cleanup, "ROOT", root)
    monkeypatch.setattr(cleanup, "REPO", tmp_path)
    monkeypatch.setattr(packaging, "DESTINATION", destination)
    monkeypatch.setattr(packaging, "RECORD", record_path)
    monkeypatch.setattr(packaging, "SHA_RECORD", sha_path)
    return root, destination, record_path


def test_cleanup_archive_rechecks_crc_members_and_current_source(toy_archive):
    root, _, _ = toy_archive
    assert cleanup.verified_archive()["status"] == "VERIFIED"
    (root / "toy.json").write_text('{"status":"PASSED"}', encoding="utf-8")
    with pytest.raises(ValueError, match="source changed"):
        cleanup.verified_archive()


def test_cleanup_rejects_tampered_zip(toy_archive):
    _, path, _ = toy_archive
    with path.open("ab") as stream:
        stream.write(b"changed")
    with pytest.raises(ValueError, match="Archive identity changed"):
        cleanup.verified_archive()


def test_cleanup_rejects_incomplete_archive_record(toy_archive):
    _, _, path = toy_archive
    data = json.loads(path.read_text())
    data["every_member_hash_verified"] = False
    path.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ValueError, match="not verified"):
        cleanup.verified_archive()


def test_cleanup_requires_failed_reconciliation_before_archive(monkeypatch):
    monkeypatch.setattr(
        cleanup, "validate_saved", lambda: (_ for _ in ()).throw(ValueError("unreconciled"))
    )
    monkeypatch.setattr(
        cleanup, "verified_archive", lambda: pytest.fail("must not inspect archive yet")
    )
    with pytest.raises(ValueError, match="unreconciled"):
        cleanup.completed_evidence("normal", failed.PROJECT)
    with pytest.raises(ValueError, match="Only exact"):
        cleanup.completed_evidence("diagnostic", failed.PROJECT)


def test_archive_retains_partial_and_excludes_own_outputs(monkeypatch):
    names = [
        "old-partial.json",
        "old-observed-summary.json",
        packaging.RECORD.name,
        packaging.SHA_RECORD.name,
    ]
    monkeypatch.setattr(packaging.original, "collect", lambda: (names, []))
    included, excluded = packaging.collect()
    assert included == names[:2]
    assert {row["path"] for row in excluded} == set(names[2:])
