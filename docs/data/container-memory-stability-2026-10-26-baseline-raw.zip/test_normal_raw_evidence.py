"""Tiny offline counterexamples only; no real services or full two-hour fixture."""

import copy
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import normal_raw_evidence as raw  # noqa: E402


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


@pytest.fixture
def evidence(tmp_path):
    folder = tmp_path / "final-two-hour"
    folder.mkdir()
    query_bytes = b"query_text\nquery\n"
    for name in ("queries.csv", "soak.queries.csv"):
        (folder / name).write_bytes(query_bytes)
    (tmp_path / "fixture").mkdir()
    (tmp_path / "fixture/queries.csv").write_bytes(query_bytes)
    events = []
    for phase, count in (("warmup", 4), ("measured", 24)):
        for index in range(count):
            event = {
                "request_id": phase + str(index),
                "phase": phase,
                "index": index,
                "query": "query",
                "mode": "bm25",
            }
            if phase == "measured":
                event["dispatched_ms"] = index * 300000 + 299999
            events.append({**event, "event": "pending", "outcome": "pending"})
            events.append(
                {
                    **event,
                    "event": "result",
                    "outcome": "success",
                    "status_code": 200,
                    "elapsed_ms": 1,
                    "result_count": 1,
                    "model_version": "toy",
                    "result_sha256": "a" * 64,
                    "ranking_sha256": "b" * 64,
                }
            )
    ledger = folder / "soak.requests.jsonl"
    ledger.write_text("".join(json.dumps(row) + "\n" for row in events), encoding="utf-8")
    bench = {
        "status": "COMPLETED",
        "config": {
            "duration_seconds": 7200,
            "warmup": 4,
            "concurrency": 32,
            "limit": 10,
            "timeout": 10,
        },
        "requested_modes": ["bm25"],
        "queries": {"count": 1, "sha256": raw.digest(folder / "queries.csv")},
        "runs": [
            {
                "mode": "mixed",
                "dispatch_window_seconds": 7200,
                "started_at": "2026-10-26T00:00:00+00:00",
                "finished_at": "2026-10-26T02:00:01+00:00",
                "last_dispatch_seconds": 7199.999,
                "summary": {"total": 24, "successes": 24, "failures": 0, "elapsed_seconds": 7201},
            }
        ],
    }
    samples = [{"phase": "load", "at": "2026-10-26T00:00:00+00:00"}]
    (folder / "samples.jsonl").write_text(json.dumps(samples[0]) + "\n", encoding="utf-8")
    write(folder / "soak.json", bench)
    analysis = raw.summarize(
        bench,
        events,
        duration_seconds=7200,
        window_seconds=300,
        queries=folder / "soak.queries.csv",
        min_repeats=12,
        samples=samples,
    )
    assert analysis["status"] == "PASSED", analysis["issues"]
    analysis["inputs"] = {
        key: str(folder / name)
        for key, name in (
            ("bench", "soak.json"),
            ("ledger", "soak.requests.jsonl"),
            ("samples", "samples.jsonl"),
            ("queries", "soak.queries.csv"),
        )
    }
    write(folder / "analysis.json", analysis)
    write(
        folder / "summary.json",
        {
            "status": "COMPLETED",
            "config": {
                "duration_seconds": 7200,
                "concurrency": 32,
                "baseline_seconds": 60,
                "recovery_seconds": 600,
            },
        },
    )
    for name in raw.ROOT_FILES:
        if not (tmp_path / name).exists():
            write(tmp_path / name, {})
    write(tmp_path / "build-summary.json", {"query_sha256": raw.digest(folder / "queries.csv")})
    write(
        tmp_path / "sources-sha256.json",
        {name: raw.digest(raw.REPO / name) for name in raw.REPO_FILES},
    )
    return folder


def test_replay_uses_real_summarizer_but_toy_is_not_final_acceptance(evidence):
    report = raw.replay_analysis(evidence)
    assert report["phases"]["measured"]["success"] == 24
    assert report["coverage"]["min_repeats"] == 12
    with pytest.raises(ValueError, match="request protocol"):
        raw.verify_normal_raw(evidence)


def test_missing_ledger_rejected_before_saved_pass(evidence):
    (evidence / "soak.requests.jsonl").unlink()
    with pytest.raises(FileNotFoundError):
        raw.verify_normal_raw(evidence)


def test_replaced_or_missing_result_rejected(evidence):
    path = evidence / "soak.requests.jsonl"
    original = path.read_text(encoding="utf-8")
    events = raw.read_jsonl(path)
    events[-1]["outcome"] = "timeout"
    path.write_text("".join(json.dumps(x) + "\n" for x in events), encoding="utf-8")
    with pytest.raises(ValueError, match="Current raw ledger failed"):
        raw.replay_analysis(evidence)
    path.write_text("\n".join(original.splitlines()[:-1]) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="Current raw ledger failed"):
        raw.replay_analysis(evidence)


def test_stale_pass_with_same_paths_rejected(evidence):
    path = evidence / "analysis.json"
    value = raw.read(path)
    value["phases"]["measured"]["latency_success"]["p99_ms"] = 1234
    write(path, value)
    with pytest.raises(ValueError, match="does not equal current"):
        raw.replay_analysis(evidence)


def test_stale_analysis_path_rejected(evidence):
    path = evidence / "analysis.json"
    value = raw.read(path)
    value["inputs"]["ledger"] = str(evidence / "old.requests.jsonl")
    write(path, value)
    with pytest.raises(ValueError, match="path is stale"):
        raw.replay_analysis(evidence)


def test_wrong_or_incomplete_acceptance_hash_rejected(evidence):
    hashes = raw.evidence_hashes(evidence)
    bad = copy.deepcopy(hashes)
    bad["root"]["final-two-hour/soak.requests.jsonl"] = "0" * 64
    with pytest.raises(ValueError, match="hashes are stale/incomplete"):
        raw.verify_normal_raw(evidence, {"input_sha256": bad})
    del hashes["root"]["final-two-hour/soak.requests.jsonl"]
    with pytest.raises(ValueError, match="hashes are stale/incomplete"):
        raw.verify_normal_raw(evidence, {"input_sha256": hashes})


def test_hashes_bind_all_current_artifacts_and_changed_ledger(evidence):
    before = raw.evidence_hashes(evidence)
    assert {evidence.name + "/" + name for name in raw.CASE_FILES} <= before["root"].keys()
    assert {"audit_case.py", "normal_raw_evidence.py", "build-summary.json"} <= before[
        "root"
    ].keys()
    with (evidence / "soak.requests.jsonl").open("a", encoding="utf-8") as stream:
        stream.write("{}\n")
    with pytest.raises(ValueError, match="hashes are stale/incomplete"):
        raw.verify_normal_raw(evidence, {"input_sha256": before})


def test_malformed_lines_not_dropped(evidence):
    with (evidence / "soak.requests.jsonl").open("a", encoding="utf-8") as stream:
        stream.write("{bad json}\n")
    with pytest.raises(ValueError):
        raw.replay_analysis(evidence)


def test_duplicate_keys_and_nonfinite_rejected():
    for text in ('{"event":"pending","event":"result"}', '{"latency":NaN}'):
        with pytest.raises(ValueError):
            raw.parse(text)


def test_package_cannot_bypass_raw_verifier(monkeypatch):
    import package_evidence as package

    monkeypatch.setattr(package, "read", lambda name: {})
    called = []

    def reject(folder, acceptance):
        called.append((folder, acceptance))
        raise ValueError("raw verifier rejected stale acceptance")

    monkeypatch.setattr(raw, "verify_normal_raw", reject)
    with pytest.raises(ValueError, match="raw verifier rejected"):
        package.validate_normal()
    assert called == [(package.ROOT / "final-two-hour", {})]


def test_auditor_calls_raw_verifier_before_trusting_analysis(monkeypatch, tmp_path):
    import audit_case

    monkeypatch.setattr(audit_case, "ROOT", tmp_path)
    monkeypatch.setattr(sys, "argv", ["audit_case.py", "final-two-hour"])
    called = []

    def reject(folder):
        called.append(folder)
        raise ValueError("raw verifier rejected stale analysis")

    monkeypatch.setattr(audit_case, "verify_normal_raw", reject)
    with pytest.raises(ValueError, match="raw verifier rejected"):
        audit_case.main()
    assert called == [tmp_path / "final-two-hour"]
    assert not (tmp_path / "final-two-hour/acceptance.json").exists()
