"""Run the declared two-hour normal-entrypoint case once; never overwrite evidence."""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
from scripts.validate_container_soak import (  # noqa: E402 - direct artifact execution
    bind_windows_worker,
    clean_environment,
    stop_owned_process,
)

DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
PROJECT = "sp-memory-stability-20261026"
OUT = ROOT / "final-two-hour"
DURATION, BASELINE, RECOVERY = 7200, 60, 600
# Includes warmups, import/model readiness, 17 business checks, restart and cleanup margin.
OUTER_TIMEOUT = DURATION + BASELINE + RECOVERY + 1800
FLAGS = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def now():
    return datetime.now(UTC).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def windows_resources():
    if os.name != "nt":
        return {"available": False, "reason": "not Windows"}
    from ctypes import wintypes

    class Memory(ctypes.Structure):
        _fields_ = [("length", wintypes.DWORD), ("load_percent", wintypes.DWORD)] + [
            (name, ctypes.c_ulonglong)
            for name in (
                "total_physical",
                "available_physical",
                "total_pagefile",
                "available_pagefile",
                "total_virtual",
                "available_virtual",
                "available_extended_virtual",
            )
        ]

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Memory)]
    kernel.GetSystemTimes.argtypes = [ctypes.POINTER(wintypes.FILETIME)] * 3
    memory = Memory()
    memory.length = ctypes.sizeof(memory)
    times = [wintypes.FILETIME() for _ in range(3)]
    if not kernel.GlobalMemoryStatusEx(ctypes.byref(memory)) or not kernel.GetSystemTimes(
        *(ctypes.byref(value) for value in times)
    ):
        raise ctypes.WinError(ctypes.get_last_error())
    idle, kernel_ticks, user = [
        (value.dwHighDateTime << 32) + value.dwLowDateTime for value in times
    ]
    return {
        "available": True,
        "at": now(),
        "memory_load_percent": memory.load_percent,
        "available_physical_bytes": memory.available_physical,
        "total_physical_bytes": memory.total_physical,
        "system_total_cpu_seconds": (kernel_ticks + user) / 1e7,
        "system_idle_cpu_seconds": idle / 1e7,
        "logical_processors": os.cpu_count(),
    }


def observation(command, env, *, json_lines=False):
    started = time.monotonic()
    try:
        completed = subprocess.run(
            command,
            cwd=REPO,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=8,
            check=True,
            creationflags=FLAGS,
        )
        data = (
            [json.loads(line) for line in completed.stdout.splitlines()]
            if json_lines
            else completed.stdout.strip()
        )
        return {"available": True, "data": data, "seconds": time.monotonic() - started}
    except Exception as exc:
        return {
            "available": False,
            "error_type": type(exc).__name__,
            "seconds": time.monotonic() - started,
        }


def observe(stop, env, errors):
    try:
        while not OUT.exists() and not stop.wait(0.2):
            pass
        if not OUT.exists():
            return
        previous = None
        with (
            (OUT / "background.jsonl").open("x", encoding="utf-8") as sink,
            ThreadPoolExecutor(2) as pool,
        ):
            while not stop.is_set():
                began = time.monotonic()
                row = {"at": now()}
                jobs = {
                    "containers": pool.submit(
                        observation,
                        [DOCKER, "stats", "--no-stream", "--format", "{{json .}}"],
                        env,
                        json_lines=True,
                    ),
                    "linux_loadavg": pool.submit(
                        observation,
                        [DOCKER, "exec", PROJECT + "-api-1", "cat", "/proc/loadavg"],
                        env,
                    ),
                }
                try:
                    host = windows_resources()
                    if host.get("available") and previous is not None:
                        total = (
                            host["system_total_cpu_seconds"] - previous["system_total_cpu_seconds"]
                        )
                        idle = host["system_idle_cpu_seconds"] - previous["system_idle_cpu_seconds"]
                        host["interval_cpu_busy_percent"] = (
                            100 * (total - idle) / total if total > 0 else None
                        )
                    if host.get("available"):
                        previous = host.copy()
                    row["windows_host"] = host
                except Exception as exc:
                    row["windows_host"] = {"available": False, "error_type": type(exc).__name__}
                row.update({name: future.result(timeout=10) for name, future in jobs.items()})
                row["observation_seconds"] = time.monotonic() - began
                sink.write(json.dumps(row) + "\n")
                sink.flush()
                stop.wait(max(0.01, 10 - row["observation_seconds"]))
    except BaseException as exc:
        errors.append({"at": now(), "error_type": type(exc).__name__})


def main():
    record_path = ROOT / "final-two-hour-launcher.json"
    log_path = ROOT / "final-two-hour-console.txt"
    pid_path = ROOT / "final-two-hour-harness.pid"
    stop_path = ROOT / "final-two-hour-harness.stop"
    if any(path.exists() for path in (OUT, record_path, log_path, pid_path, stop_path)):
        raise FileExistsError("Refuse to overwrite final two-hour evidence")
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "project": PROJECT,
        "out": str(OUT),
        "outer_timeout_seconds": OUTER_TIMEOUT,
        "observation": (
            "Docker stats + /proc/loadavg and Windows system CPU/memory every ~10s; no extra HTTP"
        ),
        "external_llm_calls": 0,
        "private_env_read": False,
    }
    with record_path.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    process = observer = None
    stop = threading.Event()
    errors = []
    try:
        preflight = json.loads((ROOT / "preflight.json").read_text(encoding="utf-8"))
        build = json.loads((ROOT / "build-summary.json").read_text(encoding="utf-8"))
        image = build["image"]
        if preflight["status"] != "PASSED" or not re.fullmatch(r"sha256:[0-9a-f]{64}", image):
            raise ValueError("Passed preflight and immutable image ID required")
        if build.get("cmd") != ["python", "scripts/docker_entrypoint.py"]:
            raise ValueError("Normal docker_entrypoint required")
        if (
            build.get("native_env", {}).get("MALLOC_ARENA_MAX") != "2"
            or build.get("native_env", {}).get("SEARCHPILOT_DISABLE_THP") != "true"
        ):
            raise ValueError("Declared arena2 and THP-off image required")
        query = ROOT / "fixture/queries.csv"
        if sha(query) != preflight["query_sha256"] or sha(query) != build["query_sha256"]:
            raise ValueError("Frozen query input changed")
        if sha(ROOT / "acceptance-plan.md") != preflight["plan_sha256"]:
            raise ValueError("Acceptance plan changed after preflight")
        env = clean_environment()
        env["PYTHONPATH"] = str(REPO)
        command = [
            sys.executable,
            "-m",
            "scripts.validate_container_soak",
            "--out",
            str(OUT),
            "--project",
            PROJECT,
            "--image",
            image,
            "--api-port",
            "18233",
            "--db-port",
            "15633",
            "--duration-seconds",
            str(DURATION),
            "--concurrency",
            "32",
            "--baseline-seconds",
            str(BASELINE),
            "--recovery-seconds",
            str(RECOVERY),
            "--queries",
            str(query),
        ]
        record.update(
            command=command,
            image=image,
            image_tag=build.get("tag"),
            build_summary_sha256=sha(ROOT / "build-summary.json"),
            query_sha256=sha(query),
            script_sha256=sha(Path(__file__)),
            source_sha256={
                name: sha(REPO / "scripts" / name)
                for name in (
                    "bench_concurrent.py",
                    "validate_container_soak.py",
                    "summarize_soak.py",
                )
            },
        )
        record_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        wrapper = (
            "import os,sys,runpy,threading,time,_thread;from pathlib import Path;"
            f"p=Path({str(pid_path)!r});s=Path({str(stop_path)!r});"
            "p.open('x',encoding='ascii').write(str(os.getpid()));"
            "\ndef watch():\n while not s.exists(): time.sleep(0.2)\n _thread.interrupt_main()\n"
            "threading.Thread(target=watch,daemon=True).start();"
            "sys.argv=['scripts.validate_container_soak',*sys.argv[1:]];"
            "runpy.run_module('scripts.validate_container_soak',run_name='__main__')"
        )
        with log_path.open("x", encoding="utf-8") as log:
            process = subprocess.Popen(
                [sys.executable, "-u", "-c", wrapper, *command[3:]],
                cwd=REPO,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                creationflags=FLAGS,
            )
            registration = time.monotonic() + 15
            while not pid_path.exists() or not pid_path.read_text(encoding="ascii"):
                if process.poll() is not None or time.monotonic() >= registration:
                    raise RuntimeError("Owned harness worker failed to register")
                time.sleep(0.1)
            pid = int(pid_path.read_text(encoding="ascii"))
            bind_windows_worker(process, pid)
            record.update(launcher_pid=process.pid, harness_pid=pid)
            record_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
            observer = threading.Thread(target=observe, args=(stop, env, errors), daemon=True)
            observer.start()
            deadline = time.monotonic() + OUTER_TIMEOUT
            while process.poll() is None:
                if errors:
                    raise RuntimeError("Background observer failed; see launcher record")
                if time.monotonic() >= deadline:
                    raise TimeoutError("Outer harness deadline exceeded")
                time.sleep(1)
            record["exit_code"] = process.returncode
            summary = json.loads((OUT / "summary.json").read_text(encoding="utf-8"))
            if process.returncode != 0 or summary.get("status") != "COMPLETED":
                raise RuntimeError("Harness did not complete successfully")
            record["status"] = "COMPLETED"
    except BaseException as exc:
        record.update(
            status="INTERRUPTED" if isinstance(exc, KeyboardInterrupt) else "FAILED",
            error_type=type(exc).__name__,
        )
        if process is not None and process.poll() is None:
            # Ask the owned harness to unwind its asyncio finally blocks and reap its load worker.
            stop_path.touch(exist_ok=False)
            try:
                process.wait(timeout=180)
                record["exception_shutdown"] = "cooperative"
            except subprocess.TimeoutExpired:
                record["exception_shutdown"] = (
                    "forced; inspect retained containers and child evidence"
                )
        raise
    finally:
        if process is not None:
            try:
                stop_owned_process(process)
            except BaseException as exc:
                record.update(status="FAILED", cleanup_error=type(exc).__name__)
        stop.set()
        if observer is not None:
            observer.join(timeout=20)
        record["observer_stopped"] = observer is None or not observer.is_alive()
        record["observer_errors"] = errors
        if errors or not record["observer_stopped"]:
            record["status"] = "FAILED"
        record["finished_at"] = now()
        record_path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(record))
    return int(record["status"] != "COMPLETED")


if __name__ == "__main__":
    raise SystemExit(main())
