"""Reconcile a completed failed workload without relaxing the successful audit.

Exit zero means evidence reconciliation, never experiment success. No service calls.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(ROOT))
import compare_diagnostics as base  # noqa: E402

A, B = "diagnostic-expanded-01", "diagnostic-original-01"
PLAN = "diagnostic-failure-followup-plan.md"
OUTCOMES = {
    "success",
    "timeout",
    "http_error",
    "response_too_large",
    "malformed_response",
    "invalid_response",
    "incomplete_response",
    "transport_error",
    "client_error",
}
require = base.require


def safe_path(root, name):
    relative = Path(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe evidence name")
    path = root / relative
    require(path.resolve().is_relative_to(root.resolve()), "Evidence path escaped root")
    for part in (path, *path.parents):
        require(not part.is_symlink() and not part.is_junction(), "Linked raw evidence")
        if part == root:
            break
    require(not any(part.lower().startswith(".env") for part in relative.parts), "Private env path")
    return path


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def raw_hashes(folder):
    result = {}
    for path in sorted(folder.rglob("*")):
        name = path.relative_to(folder).as_posix()
        safe_path(folder, name)
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            result[name] = digest(path)
    return result


def reconcile_ledger(events, report, queries):
    active, pending_ids, result_ids = {}, set(), set()
    measured, warmup, failures = [], [], []
    semantics, attempts, successes = defaultdict(set), Counter(), Counter()
    peak, next_index, previous, count = 0, 0, None, 0
    for event in events:
        count += 1
        at = base.timestamp(event["at"])
        require(previous is None or at >= previous, "Ledger timestamps moved backward")
        previous = at
        rid, kind = event["request_id"], event["event"]
        require(isinstance(rid, str) and rid, "Invalid request ID")
        if kind == "pending":
            require(rid not in pending_ids and rid not in result_ids, "Duplicate pending")
            pending_ids.add(rid)
            active[rid] = event
            peak = max(peak, len(active))
            require(peak <= report["concurrency"], "Client concurrency exceeded")
            index = event["index"]
            require(type(index) is int and index >= 0, "Invalid index")
            if event["phase"] == "measured":
                require(index == next_index, "Fixed measured sequence incomplete/reordered")
                require(
                    event["mode"] == base.MODES[index % 4]
                    and event["query"] == queries[(index // 4) % len(queries)],
                    "Measured query/mode sequence differs",
                )
                offset = event.get("dispatched_ms")
                require(
                    type(offset) in (int, float)
                    and math.isfinite(offset)
                    and 0 <= offset <= report["load_seconds"] * 1000,
                    "Invalid dispatch time",
                )
                next_index += 1
            else:
                require(
                    event["phase"] == "warmup"
                    and index < 16
                    and event["mode"] == base.MODES[index // 4]
                    and event["query"] == queries[index % 4],
                    "Warmup sequence differs",
                )
        elif kind == "result":
            require(rid in active and rid not in result_ids, "Orphan/duplicate result")
            pending = active.pop(rid)
            result_ids.add(rid)
            require(
                all(
                    event.get(key) == pending.get(key)
                    for key in ("phase", "index", "mode", "query", "dispatched_ms")
                ),
                "Pair mismatch",
            )
            latency = event.get("elapsed_ms")
            require(
                type(latency) in (int, float) and math.isfinite(latency) and latency >= 0,
                "Invalid result latency",
            )
            require(event.get("outcome") in OUTCOMES, "Unknown result outcome")
            key = event["query"], event["mode"]
            if event["phase"] == "measured":
                measured.append(event)
                attempts[key] += 1
            else:
                warmup.append(event)
            if event["outcome"] == "success":
                require(
                    event.get("status_code") == 200
                    and type(event.get("result_count")) is int
                    and 0 < event["result_count"] <= 10,
                    "Invalid/empty claimed success",
                )
                require(
                    all(
                        isinstance(event.get(field), str)
                        and re.fullmatch(r"[0-9a-f]{64}", event[field])
                        for field in ("result_sha256", "ranking_sha256")
                    )
                    and isinstance(event.get("model_version"), str)
                    and event["model_version"],
                    "Incomplete successful fingerprint",
                )
                semantics[key].add(
                    tuple(
                        event[field]
                        for field in (
                            "result_sha256",
                            "ranking_sha256",
                            "model_version",
                            "result_count",
                        )
                    )
                )
                if event["phase"] == "measured":
                    successes[key] += 1
            else:
                failures.append(dict(event))
        else:
            raise ValueError("Unknown ledger event")
    expected = {(query, mode) for query in queries for mode in base.MODES}
    require(
        not active
        and pending_ids == result_ids
        and len(measured) == report["requests"] == next_index
        and len(warmup) == 16,
        "Incomplete unique paired denominator",
    )
    require(
        {row["index"] for row in warmup} == set(range(16))
        and all(row["outcome"] == "success" for row in warmup),
        "Warmup incomplete/failed",
    )
    require(
        failures and all(row["phase"] == "measured" for row in failures), "Expected failed workload"
    )
    require(
        set(attempts) == expected
        and all(value == report["requests"] // len(expected) for value in attempts.values()),
        "Fixed group attempts differ",
    )
    require(
        set(successes) == set(semantics) == expected
        and all(len(value) == 1 for value in semantics.values()),
        "Missing/inconsistent successful semantic groups",
    )
    require(
        peak == report["peak_inflight"] == report["concurrency"], "Observed concurrency differs"
    )
    summary = base.summarize(measured, report["load_seconds"])
    require(summary == report["summary"], "Summary differs from full raw denominator")
    return {
        "events": count,
        "pending": len(pending_ids),
        "results": len(result_ids),
        "measured": summary,
        "warmup": base.summarize(warmup, 0),
        "failures": failures,
        "failure_outcomes": dict(Counter(row["outcome"] for row in failures)),
        "success_group_count": len(successes),
        "group_attempts": dict(Counter(attempts.values())),
        "group_successes": dict(Counter(successes.values())),
        "peak_inflight": peak,
        "pending_at_end": 0,
        "last_event_at": previous.isoformat(),
    }, {key: next(iter(value)) for key, value in semantics.items()}


def compare():
    setup = base.read(ROOT / "setup/summary.json")
    a, a_raw, a_queries, a_sem = base.audit_case(A, "expanded1300")
    folder = ROOT / B
    b = base.read(folder / "summary.json")
    require(
        b.get("status") == "FAILED" and b.get("case") == B and b.get("error_type"),
        "B must actually be FAILED, not RUNNING or rewritten COMPLETED",
    )
    require(
        base.timestamp(b["finished_at"])
        >= base.timestamp(b["load_finished_at"])
        > base.timestamp(b["load_started_at"]),
        "Failure has not ended",
    )
    require(
        (folder / "api.log").is_file() or b.get("log_error"), "Final log capture is not reconciled"
    )
    require(
        b["requests"] == 20800
        and b["concurrency"] == 32
        and b["query_set"] == "original100"
        and b["timeout"] == b["limit"] == 10
        and b["idle_seconds"] == 120
        and b["checkpoints"] == [400, 5200, 10400, 15600, 20800],
        "Failed workload protocol differs",
    )
    require(
        type(b["load_seconds"]) in (int, float)
        and math.isfinite(b["load_seconds"])
        and b["load_seconds"] > 0,
        "Invalid failed-load duration",
    )
    queries, raw = base.read_queries(folder / "queries.csv")
    require(
        len(queries) == 100 and a_queries[:100] == queries and base.sha(raw) == b["query_sha256"],
        "Original query bytes/order differ",
    )
    for report in (a_raw, b):
        for field, setup_field in (
            ("input_sha256", "frozen_inputs"),
            ("source_sha256", "local_source_sha256"),
            ("helper_sha256", "helper_sha256"),
            ("executed_script_sha256", "executed_script_sha256"),
            ("public_config_sha256", "public_config_sha256"),
        ):
            require(report[field] == setup[setup_field], "Setup identity mismatch: " + field)
        require(report["container"]["Image"] == setup["image"], "Diagnostic image mismatch")
        require(
            report["query_sha256"] == setup["query_sets"][report["query_set"]]["sha256"],
            "Setup query provenance differs",
        )
    require(
        b["process_native_environment"] == a_raw["process_native_environment"]
        and b["health_period_seconds"] == a_raw["health_period_seconds"],
        "Failed workload runtime policy differs",
    )
    require(
        all(
            b["container"][key] == a_raw["container"][key]
            for key in ("Image", "command", "entrypoint", "project", "native_env")
        ),
        "Failed workload runtime identity differs",
    )
    require(
        base.timestamp(a_raw["finished_at"]) <= base.timestamp(b["started_at"])
        and a_raw["final_container"]["Id"] == b["previous_container"]["Id"]
        and b["container"]["Id"] != b["previous_container"]["Id"],
        "A/B order or recreation differs",
    )
    with (folder / "requests.jsonl").open(encoding="utf-8") as source:
        accounting, semantic = reconcile_ledger((json.loads(line) for line in source), b, queries)
    require(
        base.timestamp(accounting["last_event_at"]) <= base.timestamp(b["finished_at"]),
        "Ledger continued after declared failure end",
    )
    require(
        len(semantic) == 400 and all(value == a_sem[key] for key, value in semantic.items()),
        "Successful common 400 groups differ from A",
    )
    observed = {}
    labels = [row["label"] for row in b["snapshots"]]
    require(
        len(labels) == len(set(labels))
        and labels == [label for label in base.LABELS if label in labels],
        "Existing snapshot labels duplicate/reorder",
    )
    for row in b["snapshots"]:
        label = row["label"]
        try:
            native = base.native_snapshot(row)
            native["raw_smaps"] = base.map_totals(
                base.parse_smaps((folder / ("smaps-" + label + ".txt")).read_text())
            )
            observed[label] = {"available": True, "data": native}
        except (OSError, ValueError, KeyError, TypeError) as exc:
            observed[label] = {
                "available": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
    try:
        resources = {"available": True, "data": base.sampled_observations(folder, b)}
    except (ValueError, KeyError, TypeError) as exc:
        resources = {"available": False, "error_type": type(exc).__name__, "error": str(exc)}
    for name, expected in b["executed_script_sha256"].items():
        require(
            digest(folder / (Path(name).stem + ".executed.py")) == expected,
            "Executed source changed",
        )
    require(
        digest(folder / "diagnostic_case.executed.py") == b["helper_sha256"]["diagnostic_case.py"],
        "Executed driver changed",
    )
    missing = {
        "snapshots": [label for label in base.LABELS if label not in labels],
        "fields": [
            key for key in ("idle_started_at", "ready_after", "final_container") if key not in b
        ],
        "api_log": not (folder / "api.log").is_file(),
        "log_error": b.get("log_error"),
    }
    failed = {
        "case": B,
        "status": "FAILED",
        "workload_status": "FAILED",
        "evidence_status": "RECONCILED",
        "ledger": accounting,
        "observed_snapshots": observed,
        "resources": resources,
        "missing_observations": missing,
        "input_sha256": raw_hashes(folder),
    }
    a["input_sha256"] = raw_hashes(ROOT / A)
    root_hashes = {
        name: digest(safe_path(ROOT, name))
        for name in (
            PLAN,
            "audit_failed_diagnostic.py",
            "compare_diagnostics.py",
            "setup/summary.json",
        )
    }
    for name in (A + "-console.txt", B + "-console.txt"):
        if (ROOT / name).is_file():
            root_hashes[name] = digest(ROOT / name)
    return {
        "schema_version": 1,
        "status": "FAILED_WORKLOAD_RECONCILED",
        "workload_status": "FAILED",
        "evidence_status": "RECONCILED",
        "case_order": [A, B],
        "cases": [a, failed],
        "common_successful_groups": 400,
        "common_successful_fingerprints_equal": True,
        "root_input_sha256": root_hashes,
        "limitations": [
            "Reconciliation is not successful acceptance or a repair claim.",
            "Failures remain in the denominator. "
            "Missing observations are not zero or borrowed from A.",
            "Resource observations may be unavailable; "
            "their status does not mask the failed workload.",
            "Background activity and latency association do not establish the timeout cause.",
        ],
    }


def validate_saved(root=ROOT):
    """Shared publication/cleanup gate, reading only saved failed-run evidence."""
    result = base.read(safe_path(root, "comparison-failed.json"))
    require(
        result.get("status") == "FAILED_WORKLOAD_RECONCILED"
        and result.get("workload_status") == "FAILED"
        and result.get("evidence_status") == "RECONCILED"
        and result.get("case_order") == [A, B],
        "Failure reconciliation is absent/incomplete; it must never claim PASSED",
    )
    require(
        result.get("common_successful_groups") == 400
        and result.get("common_successful_fingerprints_equal") is True,
        "Failed comparison lacks common successful semantics",
    )
    require([row.get("case") for row in result["cases"]] == [A, B], "Wrong failed-comparison cases")
    for row, expected in zip(result["cases"], ("COMPLETED", "FAILED"), strict=True):
        folder = safe_path(root, row["case"])
        require(base.read(folder / "summary.json")["status"] == expected, "Original status changed")
        require(
            row.get("input_sha256") == raw_hashes(folder),
            "Raw failure evidence changed or incomplete",
        )
    require(
        result["cases"][0].get("status") == "PASSED"
        and result["cases"][1].get("status") == "FAILED"
        and result["cases"][1].get("evidence_status") == "RECONCILED",
        "Case status is misleading",
    )
    ledger = result["cases"][1]["ledger"]
    require(
        ledger["measured"]["total"] == 20800
        and ledger["measured"]["failures"] > 0
        and len(ledger["failures"]) == ledger["measured"]["failures"]
        and ledger["pending_at_end"] == 0,
        "Failure denominator was not preserved",
    )
    hashes = result.get("root_input_sha256", {})
    require(
        {PLAN, "audit_failed_diagnostic.py", "compare_diagnostics.py", "setup/summary.json"}
        <= hashes.keys(),
        "Failure plan/auditor provenance missing",
    )
    require(
        all(digest(safe_path(root, name)) == expected for name, expected in hashes.items()),
        "Failure reconciliation provenance changed",
    )
    return {
        A: "COMPLETED",
        B: "FAILED",
        "comparison-failed": "RECONCILED",
        "workload_status": "FAILED",
    }


def self_test():
    queries = ["q" + str(index) for index in range(100)]
    events = []

    def pair(index, phase, fail=False):
        mode = base.MODES[index % 4] if phase == "measured" else base.MODES[index // 4]
        query = queries[(index // 4) % 100] if phase == "measured" else queries[index % 4]
        row = {
            "at": "2026-10-26T00:00:00+00:00",
            "request_id": phase + str(index),
            "index": index,
            "phase": phase,
            "mode": mode,
            "query": query,
            "dispatched_ms": index if phase == "measured" else None,
        }
        pending = {**row, "event": "pending", "outcome": "pending"}
        result = {
            **row,
            "event": "result",
            "outcome": "timeout" if fail else "success",
            "status_code": None if fail else 200,
            "elapsed_ms": 10000 if fail else 1,
            "result_count": None if fail else 1,
            "model_version": "m",
            "result_sha256": "a" * 64,
            "ranking_sha256": "b" * 64,
        }
        return pending, result

    for index in range(16):
        events.extend(pair(index, "warmup"))
    measured = []
    for start in range(0, 800, 32):
        batch = [
            pair(index, "measured", index in (5, 21))
            for index in range(start, min(start + 32, 800))
        ]
        events.extend(pending for pending, _ in batch)
        events.extend(result for _, result in batch)
        measured.extend(result for _, result in batch)
    report = {
        "requests": 800,
        "concurrency": 32,
        "peak_inflight": 32,
        "load_seconds": 100,
        "summary": base.summarize(measured, 100),
    }
    reconciled, _ = reconcile_ledger(events, report, queries)
    require(
        len(reconciled["failures"]) == 2 and reconciled["success_group_count"] == 400,
        "Toy failure count got hidden",
    )
    rejected = []
    for fault in ("orphan", "duplicate", "order", "summary", "fingerprint"):
        rows, config = copy.deepcopy(events), copy.deepcopy(report)
        if fault == "orphan":
            rows.pop()
        elif fault == "duplicate":
            rows.append(rows[-1])
        elif fault == "order":
            rows[32]["query"] = "wrong"
        elif fault == "summary":
            config["summary"]["failures"] = 0
        else:
            rows[-1]["model_version"] = "changed"
        try:
            reconcile_ledger(rows, config, queries)
        except ValueError:
            rejected.append(fault)
        else:
            raise AssertionError("Invalid toy passed: " + fault)
    print(
        json.dumps(
            {
                "evidence_status": "RECONCILED",
                "toy_failures_retained": 2,
                "rejected": rejected,
                "real_requests": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    if parser.parse_args().self_test:
        self_test()
        return 0
    output = ROOT / "comparison-failed.json"
    with output.open("x", encoding="utf-8") as sink:
        json.dump({"workload_status": "FAILED", "evidence_status": "RUNNING"}, sink)
    try:
        result = compare()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result = {
            "status": "UNRECONCILED",
            "workload_status": "FAILED",
            "evidence_status": "UNRECONCILED",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    result["audited_at"] = datetime.now(UTC).isoformat()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(
        json.dumps({key: result[key] for key in ("status", "workload_status", "evidence_status")})
    )
    return int(result["evidence_status"] != "RECONCILED")


if __name__ == "__main__":
    raise SystemExit(main())
