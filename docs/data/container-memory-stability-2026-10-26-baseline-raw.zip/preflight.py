"""Freeze input and baseline identities without reading private environment values."""
import hashlib
import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from scripts.validate_container_soak import clean_environment

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DOCKER = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(argv):
    return subprocess.run(argv, cwd=REPO, env=clean_environment(), check=True,
                          capture_output=True, text=True, encoding='utf-8', timeout=30).stdout


def main():
    old = REPO / 'artifacts/expanded-soak-2026-10-25'
    inputs = json.loads((old / 'inputs-sha256.json').read_text(encoding='utf-8'))
    mismatches = [name for name, value in inputs.items() if digest(REPO / name) != value]
    assert not mismatches, mismatches
    fixture = ROOT / 'fixture'
    fixture.mkdir(exist_ok=False)
    for name in ('queries.csv', 'manifest.json'):
        shutil.copyfile(old / 'fixture' / name, fixture / name)
    assert digest(fixture / 'queries.csv') == '7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6'
    with (ROOT / 'inputs-sha256.json').open('x', encoding='utf-8') as out:
        json.dump(inputs, out, indent=2)
    image = json.loads(command([DOCKER, 'image', 'inspect', 'searchpilot-validation:2026-10-25-expanded']))[0]
    assert image['Id'] == 'sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1'
    free = shutil.disk_usage(REPO).free
    assert free > 10 * 1024**3
    record = {
        'at': datetime.now(UTC).isoformat(), 'status': 'PASSED',
        'head': command(['git', 'rev-parse', 'HEAD']).strip(),
        'branch': command(['git', 'branch', '--show-current']).strip(),
        'dirty_files': command(['git', 'status', '--short']).splitlines(),
        'frozen_input_count': len(inputs), 'image': image['Id'], 'disk_free_bytes': free,
        'query_sha256': digest(fixture / 'queries.csv'),
        'plan_sha256': digest(ROOT / 'acceptance-plan.md'),
        'original_volume': json.loads(command([DOCKER, 'volume', 'inspect', 'searchpilot_pgdata']))[0],
        'running_containers': command([DOCKER, 'ps', '--format', '{{.ID}} {{.Names}}']).splitlines(),
        'private_env_read': False, 'external_llm_calls': 0,
    }
    with (ROOT / 'preflight.json').open('x', encoding='utf-8') as out:
        json.dump(record, out, indent=2)
    print(json.dumps({key: record[key] for key in ('status', 'head', 'frozen_input_count', 'disk_free_bytes')}))


if __name__ == '__main__':
    main()
