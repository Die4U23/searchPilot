# 剩余内存增长：运行前固定方案

日期：2026-10-26；接手基线 fae045d3539d40e702724949d47e44e551843e77。
本方案在本轮任何 HTTP 负载之前保存。后续偏差、失败与修订另存，不覆盖本方案。

## 问题和证据边界

上一轮 c32 一小时 RSS 增加55.984375 MiB，其中文件resident增加36.0625 MiB，
Anonymous增加19.921875 MiB。首轮5200组约373秒完成后仍有约912/1813/2783秒的
匿名台阶，不能以首次查询解释。旧末20分钟通过不等同长时平台。新实验区分文件
触页、glibc used/free、pymalloc allocated/free、线程映射及剩余匿名驻留。

## 匹配诊断对照

- 顺序 A expanded1300、B original100；各20800请求、c32、四模式混合、limit10、
  total timeout10秒、16次预热、无重试。仅查询集改变：同时改变长度/字符及唯一性，
  不声称分离这些因素的单独因果效果。两个case均覆盖所有本组query×mode。
- 同一冻结镜像searchpilot-validation:2026-10-25-expanded、THP-off、arena2；同一
  全新独立PG项目sp-memory-diagnostic-20261026，API每case强制重建。API18232/PG15632。
  不读取私有.env，诊断control只监听容器loopback且不发布端口。
- 保留正常预热及Docker healthcheck；使用已有诊断wrapper，明确不是正常入口验收。
  在ready/warmup/完成400,5200,10400,15600,20800请求时采集mallinfo2、malloc_info、
  pymalloc统计、完整smaps、task IDs；连续worker不中途排空，快照非原子且记录前后计数。
- 负载/健康/PID/Docker背景每10秒采样；不tracemalloc、不在负载/idle执行GC/trim。
  完全排空后idle120秒，然后显式GC和malloc_trim各一次，仅作可回收性诊断。
- 全部请求账本唯一配对、0失败/未知/遗留/空成功、组内结果/排名/模型指纹稳定；
  两组共同100查询×4模式指纹一致。校验image/source/input身份；保留混杂及未解释部分。
- 根据证据追加的定位实验须在启动前另存计划，保留所有先前结果；不把GC/trim加入服务。

## 最终正常入口持续验证

- 完整7200秒正式窗口，c32，同一1300条fixture字节（SHA256
  7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6），
  四模式轮转、16预热、limit10、timeout10、闭环无重试，基线60秒、恢复600秒。
- 全新项目sp-memory-stability-20261026/API18233/PG15633/独立新卷。
  最终image ID及执行源码在运行前冻结；正常docker_entrypoint、THP-off、arena2，
  无诊断wrapper/tracing/主动GC/trim。不在最终运行期间变更生产/测量源码。
- strict ledger全部配对成功；5200组均至少成功12次、指纹稳定；peak client inflight32。
  实际服务端执行并发不据此推定。所有load live/ready成功且7组件为真；全11来源可用，
  同PID1身份、THP/swap/OOM为0、无意外restart；17业务及计划restart同反馈持久性通过。
- 总formal时长/每窗实际覆盖/末端排空分开；所需采样每10秒，边界误差不超过10秒、
  最大gap15秒、每窗最少floor(window/10)-2点。缺失不填0，身份变化/时间无效不能通过。
- 全7200秒、每5分钟、每固定20分钟、两个小时、末10/20分钟、恢复期完整报告。
  RSS/Anonymous/PSS/VmData/cgroup/客户端资源分开，缺失明确；外层/实际采样时间差保留。

### 预声明稳定性门槛

只取phase=load且严格[0,7200)数据；前3600秒按计划视作观察到平台之前的阶段，
仍完整报告，不以最终结果选择开始时刻。RSS及Anonymous分别需要全部满足：

1. 整个[3600,7200)端点增长<=2MiB，按实际时间OLS<=0.03MiB/分钟。
2. [3600,4200)与[6600,7200)中位数差<=2MiB。
3. 稳定期12个固定五分钟窗口的中位数最大-最小<=2MiB。
4. 稳定期起点3600,3900,...,6000的全部滑动20分钟窗口：端点增长<=2MiB，
   OLS<=0.1MiB/分钟，每窗采样完整。不仅检查最后一个窗口。

PSS可能受其他共享映射者退出影响，仅描述不冒充独占内存；VmData/cgroup不套同一门槛。
以上只是固定负载、有限两小时内的工程平台判据，不证明零泄漏或任意部署稳定。
任何门槛失败不得改阈值或挑窗：保留失败、定位；有服务修复则完整重跑受影响对照和
7200秒最终验证，并明确基线/修复版的实验是否匹配。

## 运行和交付约束

原searchpilot_pgdata、其他项目容器/卷保留；清理仅本轮显式项目和已核对label的资源。
外部LLM调用0；模型/labels/依赖/原始输入冻结，.env不发布。记录Docker背景和Linux
loadavg，不能因此声称完整Windows资源监测。原始失败及非原子采样限制必须归档。
本地回归和独立证据审查通过后，以用户身份commit/push/PR；精确head CI通过自主merge，
核对署名并等待main CI，不加共同作者或AI贡献者。
