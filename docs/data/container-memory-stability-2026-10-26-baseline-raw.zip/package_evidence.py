"""Package completed evidence only; --check is read-only and never reads private .env.

No services, HTTP, Docker, dependency installation or exact-secret-value scan.
Failed/partial material remains provenance, never a substitute for final acceptance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import zipfile
import zlib
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DESTINATION = REPO / "docs/data/container-memory-stability-2026-10-26-raw.zip"
STAGING = DESTINATION.with_suffix(".zip.partial")
RECORD = ROOT / "archive-verification.json"
SHA_RECORD = ROOT / "archive-sha256.json"
LIMIT = 90 * 1024 * 1024
CHUNK = 1024 * 1024
EXCLUDED_OUTPUTS = {RECORD.name, SHA_RECORD.name}
GENERATED = {"SHA256SUMS.json", "EVIDENCE-SCOPE.json"}
SUFFIXES = {
    ".py",
    ".json",
    ".jsonl",
    ".txt",
    ".log",
    ".md",
    ".csv",
    ".toml",
    ".sql",
    ".yml",
    ".yaml",
    ".png",
    ".svg",
    ".html",
    ".pid",
    ".start",
    ".stop",
    ".diff",
}
PRIVATE_NAME = re.compile(
    r"(?:^|[._-])(?:keys?|tokens?|credentials?|secrets?|passwords?|id_rsa|id_ed25519)(?:[._-]|$)",
    re.I,
)
MODEL_NAME = re.compile(r"(?:^|[._-])(?:weights?|checkpoints?|embeddings)(?:[._-]|$)", re.I)
DIAGNOSTICS = {
    "diagnostic-expanded-01": "expanded1300",
    "diagnostic-original-01": "original100",
}
ENCODER_CONTROLS = {"diagnostic-encoder32-01": 32, "diagnostic-encoder2-01": 2}
NATIVE_CONTROLS = {"diagnostic-omp-default-01": "unset", "diagnostic-omp1-01": "1"}
REQUIRED = (
    {
        "acceptance-plan.md",
        "preflight.json",
        "inputs-sha256.json",
        "sources-sha256.json",
        "build-summary.json",
        "build.txt",
        "comparison-failed.json",
        "diagnostic-failure-followup-plan.md",
        "audit_failed_diagnostic.py",
        "encoder-comparison-failed.json",
        "reconcile_encoder_failure.py",
        "native-thread-comparison-rejected.json",
        "native-thread-preflight.json",
        "native-thread-control-plan.md",
        "compare_native_thread_controls.py",
        "reconcile_native_difference.py",
        "native_thread_ablation.py",
        "diagnostic_native_thread_case.py",
        "encoder-control-plan.md",
        "compare_encoder_controls.py",
        "diagnostic_encoder_case.py",
        "encoder_concurrency_ablation.py",
        "setup/summary.json",
        "fixture/queries.csv",
        "fixture/manifest.json",
        "image-context/Dockerfile",
        "source-config/Dockerfile",
        "source-config/docker-compose.yml",
        "source-config/pyproject.toml",
        "source-config/public-env.txt",
        "run_stability.py",
        "cleanup_owned.py",
        "audit_case.py",
        "normal_raw_evidence.py",
        "compare_diagnostics.py",
        "diagnostic_case.py",
        "setup_diagnostic.py",
        "package_evidence.py",
        "final-two-hour-launcher.json",
        "final-two-hour-console.txt",
    }
    | {
        f"{case}/{name}"
        for case in (*DIAGNOSTICS, *ENCODER_CONTROLS, *NATIVE_CONTROLS)
        for name in (
            "summary.json",
            "requests.jsonl",
            "samples.jsonl",
            "queries.csv",
            "override.yml",
        )
    }
    | {
        f"{case}/{name}"
        for case in ENCODER_CONTROLS
        for name in (
            "execution-manifest.json",
            "diagnostic_case.executed.py",
            "diagnostic_encoder_case.executed.py",
            "encoder_concurrency_ablation.executed.py",
            "derived-driver.diff",
            "encoder.override.yml",
        )
    }
    | {
        f"{case}/{name}"
        for case in NATIVE_CONTROLS
        for name in (
            "execution-manifest.json",
            "diagnostic_case.executed.py",
            "diagnostic_native_thread_case.executed.py",
            "native_thread_ablation.executed.py",
            "diagnostic_encoder_case.base.py",
            "encoder_concurrency_ablation.base.py",
            "parent-driver.diff",
            "parent-patch.diff",
            "derived-driver.diff",
            "native-thread.override.yml",
        )
    }
    | {
        f"final-two-hour/{name}"
        for name in (
            "summary.json",
            "soak.json",
            "soak.requests.jsonl",
            "samples.jsonl",
            "background.jsonl",
            "analysis.json",
            "acceptance.json",
            "stability.json",
            "queries.csv",
            "soak.queries.csv",
            "compose.override.yml",
            "soak-console.txt",
        )
    }
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(UTC).isoformat()


def safe_path(base, name):
    require(isinstance(name, str) and "\\" not in name and ":" not in name, "Unsafe path spelling")
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe relative path")
    require(relative.as_posix() == name and name not in {"", "."}, "Noncanonical member path")
    path = base.joinpath(*relative.parts)
    require(path.resolve().is_relative_to(base.resolve()), "Path escapes declared root: " + name)
    for part in (path, *path.parents):
        require(not part.is_symlink() and not part.is_junction(), "Linked path rejected: " + name)
        if part == base:
            break
    return path


def permitted_name(name, *, archive):
    for part in PurePosixPath(name).parts:
        lower = part.lower()
        require(not lower.startswith(".env"), "Environment filename rejected: " + name)
        require(not PRIVATE_NAME.search(part), "Private credential filename rejected: " + name)
        if archive:
            require(not MODEL_NAME.search(part), "Model/embedding filename rejected: " + name)
    if archive:
        path = PurePosixPath(name)
        require(
            path.suffix.lower() in SUFFIXES or path.name == "Dockerfile",
            "Unknown or binary payload type requires explicit review: " + name,
        )


def reject_duplicate(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def read(name):
    permitted_name(name, archive=True)
    return json.loads(
        safe_path(ROOT, name).read_text(encoding="utf-8-sig"),
        object_pairs_hook=reject_duplicate,
        parse_constant=reject_constant,
    )


def file_hash(path):
    result = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(CHUNK), b""):
            result.update(block)
    return result.hexdigest()


def collect():
    names, excluded = [], []
    # os.walk never follows links. Reject every link before deciding to prune a directory.
    for current, directories, filenames in os.walk(ROOT, followlinks=False):
        for entry in list(directories) + filenames:
            path = Path(current) / entry
            name = path.relative_to(ROOT).as_posix()
            safe_path(ROOT, name)
            if entry in directories:
                permitted_name(name, archive=False)
                if entry in {"__pycache__", ".pytest_cache", ".ruff_cache"}:
                    excluded.append({"path": name + "/", "reason": "runtime cache directory"})
                    directories.remove(entry)
                continue
            if entry in EXCLUDED_OUTPUTS and path.parent == ROOT:
                excluded.append({"path": name, "reason": "archive output; avoids self-reference"})
                continue
            permitted_name(name, archive=False)
            if path.suffix.lower() in {".pyc", ".pyo", ".tmp"} or re.fullmatch(
                r"(?:progress|.*-progress)(?:[._-].*)?\.json", entry, re.I
            ):
                excluded.append({"path": name, "reason": "temporary progress/runtime cache"})
                continue
            permitted_name(name, archive=True)
            require(path.is_file(), "Non-regular evidence file: " + name)
            if path.suffix.lower() == ".diff":
                text = path.read_bytes().decode("utf-8")
                require("\x00" not in text, "Binary content masquerades as text diff: " + name)
            require(name not in GENERATED, "Reserved generated archive member: " + name)
            names.append(name)
    folded = [name.casefold() for name in names]
    require(len(folded) == len(set(folded)), "Duplicate or case-colliding member paths")
    return sorted(names), sorted(excluded, key=lambda row: row["path"])


def validate_frozen():
    build, preflight = read("build-summary.json"), read("preflight.json")
    require(preflight.get("status") == "PASSED", "Preflight has not passed")
    require(re.fullmatch(r"sha256:[0-9a-f]{64}", build.get("image", "")), "Missing image ID")
    require(build.get("cmd") == ["python", "scripts/docker_entrypoint.py"], "Not normal entrypoint")
    require(
        build.get("native_env") == {"MALLOC_ARENA_MAX": "2", "SEARCHPILOT_DISABLE_THP": "true"},
        "Image native environment differs from plan",
    )
    inputs, sources = read("inputs-sha256.json"), read("sources-sha256.json")
    require(len(inputs) == build.get("frozen_input_count") == 29, "Expected 29 frozen inputs")
    require(len(sources) == build.get("source_count") and sources, "Frozen source count mismatch")
    for label, manifest in (("input", inputs), ("source", sources)):
        for name, expected in manifest.items():
            permitted_name(name, archive=False)  # Weights may be hashed, never archived.
            require(
                isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected),
                "Invalid frozen digest: " + name,
            )
            require(file_hash(safe_path(REPO, name)) == expected, f"Frozen {label} changed: {name}")
            if label == "source":
                require(
                    re.fullmatch(r"(?:src|scripts|tests)/[A-Za-z0-9_/]+\.py", name),
                    "Unexpected frozen source path: " + name,
                )
                if name.startswith("scripts/"):
                    require(
                        file_hash(safe_path(ROOT, "image-context/" + name)) == expected,
                        "Executed script snapshot mismatch: " + name,
                    )
    require(
        file_hash(safe_path(ROOT, "fixture/queries.csv"))
        == build["query_sha256"]
        == preflight["query_sha256"],
        "Fixture does not match frozen build/preflight",
    )
    require(
        file_hash(safe_path(ROOT, "acceptance-plan.md")) == preflight["plan_sha256"],
        "Predeclared acceptance plan changed",
    )
    for name in ("Dockerfile", "docker-compose.yml", "pyproject.toml"):
        require(
            file_hash(safe_path(ROOT, "source-config/" + name)) == file_hash(safe_path(REPO, name)),
            "Public configuration changed: " + name,
        )
    # public-env.txt is the saved public snapshot; do not open even .env.example here.
    return {
        "image": build["image"],
        "inputs": len(inputs),
        "sources": len(sources),
        "query_sha256": build["query_sha256"],
    }


def validate_diagnostics():
    from audit_failed_diagnostic import validate_saved

    require(
        read("diagnostic-original-01/summary.json").get("status") == "FAILED",
        "Original failed workload must remain FAILED",
    )
    return validate_saved(ROOT)


def bound_comparison(filename, case_names, required_root):
    """Bind saved decisions to complete raw files and the auditors that made them."""
    result = read(filename)
    require(
        result.get("case_order") == list(case_names)
        and [row.get("case") for row in result.get("cases", [])] == list(case_names),
        "Comparison case identities differ: " + filename,
    )
    root_hashes = result.get("root_input_sha256", {})
    require(set(required_root) <= root_hashes.keys(), "Comparison root provenance incomplete")
    for name, expected in root_hashes.items():
        permitted_name(name, archive=True)
        require(file_hash(safe_path(ROOT, name)) == expected, "Comparison source changed: " + name)
    for row in result["cases"]:
        folder = safe_path(ROOT, row["case"])
        actual = {}
        for path in sorted(folder.rglob("*")):
            name = path.relative_to(folder).as_posix()
            safe_path(folder, name)
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                permitted_name(name, archive=True)
                actual[name] = file_hash(path)
        require(
            {"summary.json", "requests.jsonl", "samples.jsonl", "queries.csv"} <= actual.keys()
            and actual == row.get("input_sha256"),
            "Comparison raw files changed: " + row["case"],
        )
        summary = read(row["case"] + "/summary.json")
        require(
            row.get("recorded_status") == summary["status"]
            and row["ledger"]["measured"] == summary["summary"],
            "Saved workload summary differs",
        )
    return result


def execution_evidence(row, summary, files, actual_entry):
    name = row["case"]
    manifest = read(name + "/execution-manifest.json")
    require(
        manifest == row.get("execution_manifest") == summary.get("execution_manifest")
        and manifest.get("actual_entry") == actual_entry
        and manifest.get("base_driver_sha256") != manifest.get("derived_driver_sha256"),
        "Actual execution manifest differs or base copy masquerades as entry",
    )
    require(set(files) <= row["input_sha256"].keys(), "Execution snapshot provenance incomplete")
    for filename, key in files.items():
        require(
            row["input_sha256"][filename] == manifest.get(key),
            "Executed snapshot differs: " + filename,
        )
    runtime = manifest["runtime"]
    require(
        {"Id", "Image", "command", "entrypoint", "diagnostic_mounts"} <= runtime.keys()
        and runtime == {key: summary["container"][key] for key in runtime},
        "Saved runtime differs",
    )
    return manifest


def validate_encoder_controls():
    result = bound_comparison(
        "encoder-comparison-failed.json",
        ENCODER_CONTROLS,
        {
            "encoder-control-plan.md",
            "native-thread-control-plan.md",
            "reconcile_encoder_failure.py",
            "audit_failed_diagnostic.py",
            "compare_encoder_controls.py",
            "compare_diagnostics.py",
            "setup/summary.json",
        },
    )
    require(
        result.get("status") == "FAILED_WORKLOAD_RECONCILED"
        and result.get("workload_status") == "FAILED"
        and result.get("evidence_status") == "RECONCILED"
        and result.get("candidate_status") == "REJECTED_TIMEOUT_OR_FAILURE"
        and result.get("common_successful_groups") == 5200
        and result.get("common_successful_fingerprints_equal") is True,
        "Rejected encoder candidate must remain a reconciled failure",
    )
    files = {
        "diagnostic_case.executed.py": "base_driver_sha256",
        "diagnostic_encoder_case.executed.py": "derived_driver_sha256",
        "encoder_concurrency_ablation.executed.py": "patch_sha256",
        "derived-driver.diff": "derived_diff_sha256",
        "override.yml": "base_override_sha256",
        "encoder.override.yml": "encoder_override_sha256",
    }
    for row, (name, limit), status in zip(
        result["cases"], ENCODER_CONTROLS.items(), ("COMPLETED", "FAILED"), strict=True
    ):
        summary = read(name + "/summary.json")
        require(
            summary["status"] == status
            and summary["case"] == name
            and summary["encoder_limit"] == limit
            and summary["requests"] == 20800
            and summary["concurrency"] == 32
            and summary["query_set"] == "expanded1300",
            "Encoder control identity/status changed",
        )
        manifest = execution_evidence(row, summary, files, "diagnostic_encoder_case.executed.py")
        require(manifest["encoder_limit"] == limit, "Encoder manifest limit differs")
        measured = row["ledger"]["measured"]
        require(measured["total"] == 20800, "Incomplete encoder workload")
        if limit == 32:
            require(
                row.get("status") == "PASSED"
                and row.get("workload_status") == "PASSED"
                and measured["failures"] == 0,
                "Sham did not pass",
            )
        else:
            require(
                row.get("status") == row.get("workload_status") == "FAILED"
                and row.get("evidence_status") == "RECONCILED"
                and measured["failures"] > 0
                and len(row["ledger"]["failures"]) == measured["failures"]
                and row["ledger"]["pending_at_end"] == 0,
                "Cap2 failure denominator was hidden",
            )
    return {
        "diagnostic-encoder32-01": "COMPLETED",
        "diagnostic-encoder2-01": "FAILED",
        "encoder-comparison-failed": "RECONCILED",
        "candidate_status": "REJECTED_TIMEOUT_OR_FAILURE",
    }


def validate_native_controls():
    result = bound_comparison(
        "native-thread-comparison-rejected.json",
        NATIVE_CONTROLS,
        {
            "native-thread-control-plan.md",
            "native-thread-preflight.json",
            "compare_native_thread_controls.py",
            "reconcile_native_difference.py",
            "reconcile_encoder_failure.py",
            "compare_encoder_controls.py",
            "audit_failed_diagnostic.py",
            "compare_diagnostics.py",
            "setup/summary.json",
        },
    )
    baseline = result.get("baseline_workload_status")
    treatment = result.get("treatment_workload_status")
    require(
        baseline in ("PASSED", "FAILED")
        and treatment in ("PASSED", "FAILED")
        and result.get("evidence_status") == "RECONCILED"
        and result.get("candidate_protocol_eligible") is False
        and result.get("status") == "REJECTED_RESULT_DIFFERENCE"
        and result.get("common_successful_groups") == 5200
        and result.get("common_successful_fingerprints_equal") is False,
        "Native rejection evidence incomplete or mislabeled",
    )
    from reconcile_native_difference import validate_saved_differences

    validate_saved_differences(result)
    preflight = read("native-thread-preflight.json")
    frozen = {
        "native-thread-control-plan.md",
        "native_thread_ablation.py",
        "diagnostic_native_thread_case.py",
        "inputs-sha256.json",
        "sources-sha256.json",
    }
    require(
        preflight.get("status") == "FROZEN_BEFORE_NATIVE_THREAD_RUNS"
        and preflight.get("case_order") == list(NATIVE_CONTROLS)
        and set(preflight.get("sha256", {})) == frozen,
        "Native preflight identity differs",
    )
    require(
        all(
            file_hash(safe_path(ROOT, name)) == expected
            for name, expected in preflight["sha256"].items()
        ),
        "Native preflight sources changed",
    )
    files = {
        "diagnostic_case.executed.py": "base_driver_sha256",
        "diagnostic_native_thread_case.executed.py": "derived_driver_sha256",
        "native_thread_ablation.executed.py": "patch_sha256",
        "diagnostic_encoder_case.base.py": "parent_encoder_driver_sha256",
        "encoder_concurrency_ablation.base.py": "parent_encoder_patch_sha256",
        "parent-driver.diff": "parent_driver_diff_sha256",
        "parent-patch.diff": "parent_patch_diff_sha256",
        "derived-driver.diff": "derived_diff_sha256",
        "override.yml": "base_override_sha256",
        "native-thread.override.yml": "native_override_sha256",
    }
    statuses = {}
    for row, (name, setting), workload in zip(
        result["cases"], NATIVE_CONTROLS.items(), (baseline, treatment), strict=True
    ):
        summary = read(name + "/summary.json")
        expected_status = (
            "COMPLETED" if workload == "PASSED" else "COMPLETED_WITH_WORKLOAD_FAILURES"
        )
        require(
            summary["case"] == name
            and summary["status"] == expected_status
            and summary.get("collection_status") == "COMPLETED"
            and summary.get("workload_status") == workload
            and row.get("workload_status") == workload
            and row.get("evidence_status") == "RECONCILED"
            and summary["requests"] == 20800
            and summary["concurrency"] == 32
            and summary["query_set"] == "expanded1300"
            and summary["encoder_limit"] == 32
            and summary["omp_threads"] == setting,
            "Native case status/configuration differs",
        )
        require(
            datetime.fromisoformat(preflight["at"])
            <= datetime.fromisoformat(summary["started_at"]),
            "Native case predates preflight",
        )
        manifest = execution_evidence(
            row, summary, files, "diagnostic_native_thread_case.executed.py"
        )
        require(
            manifest["patch_sha256"] == preflight["sha256"]["native_thread_ablation.py"]
            and manifest["derived_driver_sha256"]
            == preflight["sha256"]["diagnostic_native_thread_case.py"]
            and manifest["encoder_limit"] == 32
            and manifest["omp_threads"] == setting,
            "Native runtime is not the frozen actual entry/patch",
        )
        measured = row["ledger"]["measured"]
        require(
            measured["total"] == 20800 and measured["successes"] + measured["failures"] == 20800,
            "Native denominator incomplete",
        )
        if workload == "PASSED":
            require(
                measured["successes"] == 20800
                and measured["failures"] == 0
                and row["status"] == "PASSED",
                "Collection completion masks failed workload",
            )
        else:
            require(
                row["status"] == "FAILED"
                and measured["failures"] > 0
                and len(row["ledger"]["failures"]) == measured["failures"],
                "Native workload failures hidden",
            )
        proof = row["native_threads"]
        require(proof["encoder_calls"] == 15600, "Native formal encoder coverage incomplete")
        for stage in ("before", "after"):
            data = proof["stages"][stage]
            require(
                data["counts"]
                == {
                    "calls": 15600,
                    "available": 15600,
                    "unavailable": 0,
                    "errors": 0,
                    "histogram_overflow": 0,
                },
                "Actual-thread getter evidence incomplete",
            )
            require(
                data["intra_histogram"] == {"1": 15600}
                if setting == "1"
                else sum(data["intra_histogram"].values()) == 15600
                and all(int(k) > 1 for k in data["intra_histogram"]),
                "Native setting was not observed in worker threads",
            )
        statuses[name] = expected_status
    require(
        result["cases"][0]["native_threads"]["interop"]
        == result["cases"][1]["native_threads"]["interop"],
        "Interop changed between native controls",
    )
    return {
        **statuses,
        "native-thread-comparison": result["status"],
        "candidate_protocol_eligible": False,
        "efficacy_verdict": "REJECTED_NO_PRODUCTION_PROMOTION",
    }


def validate_normal():
    from normal_raw_evidence import verify_normal_raw

    build = read("build-summary.json")
    prefix = "final-two-hour/"
    summary, bench, analysis, acceptance, stability = [
        read(prefix + name)
        for name in (
            "summary.json",
            "soak.json",
            "analysis.json",
            "acceptance.json",
            "stability.json",
        )
    ]
    # Recheck all input bytes and reconstruct the complete protocol from the raw ledger.
    # A saved PASS or analysis.inputs path alone cannot establish current acceptance.
    verify_normal_raw(ROOT / "final-two-hour", acceptance)
    launcher = read("final-two-hour-launcher.json")
    require(summary.get("status") == bench.get("status") == "COMPLETED", "Normal run incomplete")
    require(
        launcher.get("status") == "COMPLETED"
        and launcher.get("exit_code") == 0
        and launcher.get("observer_stopped") is True,
        "Normal launcher incomplete",
    )
    require(
        summary.get("image") == build["image"] == launcher.get("image"), "Normal image mismatch"
    )
    for result in (analysis, acceptance, stability):
        require(result.get("status") == "PASSED", "Normal acceptance/ledger/stability not PASSED")
    require(
        acceptance.get("checks") and all(value is True for value in acceptance["checks"].values()),
        "Acceptance contains incomplete/failed checks",
    )
    require(acceptance.get("memory_gate") == stability, "Embedded stability result differs")
    require(
        stability.get("duration_seconds") == 7200 and stability.get("stable_after_seconds") == 3600,
        "Unexpected stability window",
    )
    require(
        stability.get("inputs")
        == {
            "bench_sha256": file_hash(safe_path(ROOT, prefix + "soak.json")),
            "samples_sha256": file_hash(safe_path(ROOT, prefix + "samples.jsonl")),
        },
        "Stability result is stale",
    )
    for value in (summary, bench):
        config = value.get("config", {})
        require(
            config.get("duration_seconds") == 7200 and config.get("concurrency") == 32,
            "Normal duration/concurrency mismatch",
        )
    require(
        summary["config"].get("baseline_seconds") == 60
        and summary["config"].get("recovery_seconds") == 600,
        "Baseline/recovery mismatch",
    )
    for filename in ("queries.csv", "soak.queries.csv"):
        require(
            file_hash(safe_path(ROOT, prefix + filename)) == build["query_sha256"],
            "Normal query snapshot changed: " + filename,
        )
    require(analysis.get("issues") == [], "Ledger has unresolved issues")
    require(
        analysis["coverage"].get("verified") is True
        and analysis["coverage"].get("min_repeats") == 12
        and len(analysis["coverage"].get("groups", [])) == 5200
        and all(
            type(group.get("successful")) is int and group["successful"] >= 12
            for group in analysis["coverage"]["groups"]
        ),
        "Missing final query coverage",
    )
    return {"summary": "COMPLETED", "acceptance": "PASSED", "stability": "PASSED"}


def provenance(names):
    partial = []
    for name in names:
        if name.endswith("-preliminary.json"):
            value = read(name)
            observed = name.removesuffix("-preliminary.json") + "-summary-observed.json"
            require(observed in names, "PARTIAL provenance lacks observed summary: " + name)
            require(value.get("status") == "PARTIAL", "Unexpected preliminary status: " + name)
            partial.append(
                {
                    "file": name,
                    "status": "PARTIAL",
                    "observed_summary": observed,
                    "observed_status": read(observed).get("status"),
                    "role": "historical observation only; not final acceptance",
                }
            )
    return partial


def describe(path):
    hasher, compressor = hashlib.sha256(), zlib.compressobj(9, zlib.DEFLATED, -15)
    count = compressed = 0
    with path.open("rb") as source:
        for block in iter(lambda: source.read(CHUNK), b""):
            count += len(block)
            hasher.update(block)
            compressed += len(compressor.compress(block))
    return {
        "bytes": count,
        "sha256": hasher.hexdigest(),
        "estimated_deflate_bytes": compressed + len(compressor.flush()),
    }


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check", action="store_true", help="List scope, size and gates; write nothing"
    )
    args = parser.parse_args()
    names, excluded = collect()
    failures, gates = [], {}
    missing = sorted(REQUIRED - set(names))
    if missing:
        failures.append({"gate": "required_evidence", "missing": missing})
    for label, function in (
        ("frozen", validate_frozen),
        ("diagnostic", validate_diagnostics),
        ("encoder_controls", validate_encoder_controls),
        ("native_controls", validate_native_controls),
        ("normal", validate_normal),
    ):
        try:
            gates[label] = function()
        except (OSError, ValueError, KeyError, TypeError) as exc:
            failures.append({"gate": label, "error": str(exc), "type": type(exc).__name__})
    partial = provenance(names)
    details = {name: describe(safe_path(ROOT, name)) for name in names}
    manifest = {
        name: {key: data[key] for key in ("bytes", "sha256")} for name, data in details.items()
    }
    scope = encode(
        {
            "schema_version": 1,
            "gates": gates,
            "partial_provenance": partial,
            "scope": "Finite matched diagnostics and final normal-entrypoint acceptance",
            "excluded": excluded,
            "private_env_read": False,
            "private_secret_value_scan": "NOT_PERFORMED; publisher must scan separately",
            "limitations": "No zero-leak, capacity-SLA or independent causal proof.",
        }
    )
    manifest["EVIDENCE-SCOPE.json"] = {
        "bytes": len(scope),
        "sha256": hashlib.sha256(scope).hexdigest(),
    }
    manifest_bytes = encode(manifest)
    generated = {"EVIDENCE-SCOPE.json": scope, "SHA256SUMS.json": manifest_bytes}
    # Conservative ZIP overhead plus raw-deflate sizes; no evidence is silently dropped.
    estimate = sum(row["estimated_deflate_bytes"] for row in details.values())
    estimate += sum(len(zlib.compress(data, 9)) for data in generated.values())
    estimate += sum(256 + 2 * len(name.encode("utf-8")) for name in [*names, *generated]) + 1024
    if estimate > LIMIT:
        failures.append(
            {
                "gate": "archive_size",
                "estimated_bytes": estimate,
                "limit_bytes": LIMIT,
                "action": (
                    "Stop; obtain explicit packaging decision, never omit evidence automatically."
                ),
            }
        )
    for path in (DESTINATION, STAGING, RECORD, SHA_RECORD):
        safe_path(REPO, path.relative_to(REPO).as_posix())
        if path.exists():
            failures.append({"gate": "exclusive_output", "path": path.relative_to(REPO).as_posix()})
    check = {
        "status": "PREFLIGHT_PASSED" if not failures else "PREFLIGHT_FAILED",
        "gates": gates,
        "failures": failures,
        "files": len(names),
        "members": details,
        "generated_members": list(generated),
        "duplicate_paths": [],
        "excluded": excluded,
        "source_bytes": sum(item["bytes"] for item in details.values()),
        "estimated_zip_bytes": estimate,
        "limit_bytes": LIMIT,
        "partial_provenance": partial,
    }
    if args.check or failures:
        print(json.dumps(check, ensure_ascii=False))
        return int(bool(failures))
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "path": DESTINATION.relative_to(REPO).as_posix(),
        "staging_path": STAGING.relative_to(REPO).as_posix(),
        "private_env_read": False,
    }
    with RECORD.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    try:
        with zipfile.ZipFile(
            STAGING, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for name in names:
                with safe_path(ROOT, name).open("rb") as source, archive.open(name, "w") as target:
                    hasher, count = hashlib.sha256(), 0
                    for block in iter(lambda: source.read(CHUNK), b""):
                        hasher.update(block)
                        count += len(block)
                        target.write(block)
                require(
                    {"bytes": count, "sha256": hasher.hexdigest()} == manifest[name],
                    "Evidence changed during archive writing: " + name,
                )
            for name, data in generated.items():
                archive.writestr(name, data)
        require(
            STAGING.stat().st_size <= LIMIT, "Actual ZIP exceeds 90 MiB; retain partial and report"
        )
        with zipfile.ZipFile(STAGING) as archive:
            expected_names = set(names) | set(generated)
            require(
                len(archive.namelist()) == len(expected_names)
                and set(archive.namelist()) == expected_names,
                "ZIP membership mismatch",
            )
            require(archive.testzip() is None, "ZIP CRC verification failed")
            for name in names:
                hasher, count = hashlib.sha256(), 0
                with archive.open(name) as source:
                    for block in iter(lambda: source.read(CHUNK), b""):
                        hasher.update(block)
                        count += len(block)
                require(
                    {"bytes": count, "sha256": hasher.hexdigest()} == manifest[name],
                    "ZIP member readback mismatch: " + name,
                )
                require(
                    file_hash(safe_path(ROOT, name)) == manifest[name]["sha256"],
                    "Source changed before verification completed: " + name,
                )
            for name, data in generated.items():
                require(archive.read(name) == data, "Generated member mismatch: " + name)
        require(collect()[0] == names, "Evidence membership changed during packaging")
        require(
            validate_frozen() == gates["frozen"]
            and validate_diagnostics() == gates["diagnostic"]
            and validate_encoder_controls() == gates["encoder_controls"]
            and validate_native_controls() == gates["native_controls"]
            and validate_normal() == gates["normal"],
            "Final gates changed during packaging",
        )
        archive_sha = file_hash(STAGING)
        record.update(
            status="VERIFIED",
            finished_at=now(),
            bytes=STAGING.stat().st_size,
            sha256=archive_sha,
            files=len(names),
            zip_members=len(names) + 2,
            crc_verified=True,
            every_member_hash_verified=True,
            gates=gates,
            excluded=excluded,
            partial_provenance=partial,
            private_secret_value_scan="NOT_PERFORMED; publisher must scan separately",
        )
        # Same-directory hard link is exclusive on Windows and POSIX; never replace a final ZIP.
        os.link(STAGING, DESTINATION)
        with SHA_RECORD.open("x", encoding="utf-8") as sink:
            json.dump(
                {
                    "archive": {key: record[key] for key in ("path", "bytes", "sha256")},
                    "members": manifest,
                },
                sink,
                indent=2,
            )
            sink.write("\n")
        STAGING.unlink()  # Exact owned file, after verified final link exists.
    except BaseException as exc:
        record.update(
            status="FAILED",
            finished_at=now(),
            error_type=type(exc).__name__,
            error=str(exc),
            note="Do not publish. Retain partial archive and verification failure evidence.",
        )
        raise
    finally:
        RECORD.write_bytes(encode(record))
    print(json.dumps(record, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
