"""Archive only a complete reconciled FAILED baseline; never production acceptance."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import zipfile
import zlib
from pathlib import Path

import package_evidence as original
from reconcile_failed_normal import validate_saved as validate_failed_normal

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DESTINATION = REPO / "docs/data/container-memory-stability-2026-10-26-baseline-raw.zip"
STAGING = DESTINATION.with_suffix(".zip.partial")
RECORD = ROOT / "baseline-archive-verification.json"
SHA_RECORD = ROOT / "baseline-archive-sha256.json"
LIMIT, CHUNK = original.LIMIT, original.CHUNK
safe_path, require, file_hash = original.safe_path, original.require, original.file_hash
encode, now, describe, provenance = (
    original.encode,
    original.now,
    original.describe,
    original.provenance,
)
validate_frozen = original.validate_frozen
validate_diagnostics = original.validate_diagnostics
validate_encoder_controls = original.validate_encoder_controls
validate_native_controls = original.validate_native_controls
REQUIRED = original.REQUIRED | {
    "reconcile_failed_normal.py",
    "package_failed_baseline.py",
    "cleanup_failed_normal.py",
    "final-two-hour/failed-stability-reconciliation.json",
}


def collect():
    names, excluded = original.collect()
    outputs = {RECORD.name, SHA_RECORD.name}
    return (
        [name for name in names if name not in outputs],
        excluded
        + [
            {"path": name, "reason": "baseline archive output; avoids self-reference"}
            for name in names
            if name in outputs
        ],
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check", action="store_true", help="List scope, size and gates; write nothing"
    )
    args = parser.parse_args()
    names, excluded = collect()
    failures, gates = [], {}
    missing = sorted(REQUIRED - set(names))
    if missing:
        failures.append({"gate": "required_evidence", "missing": missing})
    for label, function in (
        ("frozen", validate_frozen),
        ("diagnostic", validate_diagnostics),
        ("encoder_controls", validate_encoder_controls),
        ("native_controls", validate_native_controls),
        ("failed_normal", validate_failed_normal),
    ):
        try:
            gates[label] = function()
        except (OSError, ValueError, KeyError, TypeError) as exc:
            failures.append({"gate": label, "error": str(exc), "type": type(exc).__name__})
    partial = provenance(names)
    details = {name: describe(safe_path(ROOT, name)) for name in names}
    manifest = {
        name: {key: data[key] for key in ("bytes", "sha256")} for name, data in details.items()
    }
    scope = encode(
        {
            "schema_version": 1,
            "production_acceptance": False,
            "baseline_status": "FAILED_STABILITY_RECONCILED",
            "gates": gates,
            "partial_provenance": partial,
            "scope": "Rejected baseline and all historical diagnostics; NOT production acceptance",
            "excluded": excluded,
            "private_env_read": False,
            "private_secret_value_scan": "NOT_PERFORMED; publisher must scan separately",
            "limitations": "No zero-leak, capacity-SLA or independent causal proof.",
        }
    )
    manifest["EVIDENCE-SCOPE.json"] = {
        "bytes": len(scope),
        "sha256": hashlib.sha256(scope).hexdigest(),
    }
    manifest_bytes = encode(manifest)
    generated = {"EVIDENCE-SCOPE.json": scope, "SHA256SUMS.json": manifest_bytes}
    # Conservative ZIP overhead plus raw-deflate sizes; no evidence is silently dropped.
    estimate = sum(row["estimated_deflate_bytes"] for row in details.values())
    estimate += sum(len(zlib.compress(data, 9)) for data in generated.values())
    estimate += sum(256 + 2 * len(name.encode("utf-8")) for name in [*names, *generated]) + 1024
    if estimate > LIMIT:
        failures.append(
            {
                "gate": "archive_size",
                "estimated_bytes": estimate,
                "limit_bytes": LIMIT,
                "action": (
                    "Stop; obtain explicit packaging decision, never omit evidence automatically."
                ),
            }
        )
    for path in (DESTINATION, STAGING, RECORD, SHA_RECORD):
        safe_path(REPO, path.relative_to(REPO).as_posix())
        if path.exists():
            failures.append({"gate": "exclusive_output", "path": path.relative_to(REPO).as_posix()})
    check = {
        "status": "PREFLIGHT_PASSED" if not failures else "PREFLIGHT_FAILED",
        "gates": gates,
        "failures": failures,
        "files": len(names),
        "members": details,
        "generated_members": list(generated),
        "duplicate_paths": [],
        "excluded": excluded,
        "source_bytes": sum(item["bytes"] for item in details.values()),
        "estimated_zip_bytes": estimate,
        "limit_bytes": LIMIT,
        "partial_provenance": partial,
    }
    if args.check or failures:
        print(json.dumps(check, ensure_ascii=False))
        return int(bool(failures))
    record = {
        "status": "RUNNING",
        "production_acceptance": False,
        "baseline_status": "FAILED_STABILITY_RECONCILED",
        "started_at": now(),
        "path": DESTINATION.relative_to(REPO).as_posix(),
        "staging_path": STAGING.relative_to(REPO).as_posix(),
        "private_env_read": False,
    }
    with RECORD.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    try:
        with zipfile.ZipFile(
            STAGING, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for name in names:
                with safe_path(ROOT, name).open("rb") as source, archive.open(name, "w") as target:
                    hasher, count = hashlib.sha256(), 0
                    for block in iter(lambda: source.read(CHUNK), b""):
                        hasher.update(block)
                        count += len(block)
                        target.write(block)
                require(
                    {"bytes": count, "sha256": hasher.hexdigest()} == manifest[name],
                    "Evidence changed during archive writing: " + name,
                )
            for name, data in generated.items():
                archive.writestr(name, data)
        require(
            STAGING.stat().st_size <= LIMIT, "Actual ZIP exceeds 90 MiB; retain partial and report"
        )
        with zipfile.ZipFile(STAGING) as archive:
            expected_names = set(names) | set(generated)
            require(
                len(archive.namelist()) == len(expected_names)
                and set(archive.namelist()) == expected_names,
                "ZIP membership mismatch",
            )
            require(archive.testzip() is None, "ZIP CRC verification failed")
            for name in names:
                hasher, count = hashlib.sha256(), 0
                with archive.open(name) as source:
                    for block in iter(lambda: source.read(CHUNK), b""):
                        hasher.update(block)
                        count += len(block)
                require(
                    {"bytes": count, "sha256": hasher.hexdigest()} == manifest[name],
                    "ZIP member readback mismatch: " + name,
                )
                require(
                    file_hash(safe_path(ROOT, name)) == manifest[name]["sha256"],
                    "Source changed before verification completed: " + name,
                )
            for name, data in generated.items():
                require(archive.read(name) == data, "Generated member mismatch: " + name)
        require(collect()[0] == names, "Evidence membership changed during packaging")
        require(
            validate_frozen() == gates["frozen"]
            and validate_diagnostics() == gates["diagnostic"]
            and validate_encoder_controls() == gates["encoder_controls"]
            and validate_native_controls() == gates["native_controls"]
            and validate_failed_normal() == gates["failed_normal"],
            "Final gates changed during packaging",
        )
        archive_sha = file_hash(STAGING)
        record.update(
            status="VERIFIED",
            finished_at=now(),
            bytes=STAGING.stat().st_size,
            sha256=archive_sha,
            files=len(names),
            zip_members=len(names) + 2,
            crc_verified=True,
            every_member_hash_verified=True,
            gates=gates,
            excluded=excluded,
            partial_provenance=partial,
            private_secret_value_scan="NOT_PERFORMED; publisher must scan separately",
        )
        # Same-directory hard link is exclusive on Windows and POSIX; never replace a final ZIP.
        os.link(STAGING, DESTINATION)
        with SHA_RECORD.open("x", encoding="utf-8") as sink:
            json.dump(
                {
                    "archive": {key: record[key] for key in ("path", "bytes", "sha256")},
                    "members": manifest,
                },
                sink,
                indent=2,
            )
            sink.write("\n")
        STAGING.unlink()  # Exact owned file, after verified final link exists.
    except BaseException as exc:
        record.update(
            status="FAILED",
            finished_at=now(),
            error_type=type(exc).__name__,
            error=str(exc),
            note="Do not publish. Retain partial archive and verification failure evidence.",
        )
        raise
    finally:
        RECORD.write_bytes(encode(record))
    print(json.dumps(record, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
