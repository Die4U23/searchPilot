"""Preserve exact source bytes before any evidence-backed production candidate is considered."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
sources = json.loads((root / 'sources-sha256.json').read_text(encoding='utf-8'))
target = root / 'baseline-sources'
target.mkdir(exist_ok=False)
for relative, expected in sources.items():
    source = repo / relative
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, relative
    output = target / relative
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as file:
        file.write(raw)
with (target / 'SHA256SUMS.json').open('x', encoding='utf-8') as file:
    json.dump(sources, file, indent=2)
print(json.dumps({'status': 'PASSED', 'source_count': len(sources), 'models_or_data_copied': False}))
