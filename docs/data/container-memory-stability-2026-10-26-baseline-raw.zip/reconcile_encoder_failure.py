"""Offline accounting of the rejected encoder-cap2 candidate; never a passing comparison."""

from __future__ import annotations

import argparse
import copy
import json
import math
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(ROOT))
import audit_failed_diagnostic as failed  # noqa: E402
import compare_diagnostics as base  # noqa: E402
import compare_encoder_controls as encoder  # noqa: E402

require, digest = base.require, failed.digest
A, B = "diagnostic-encoder32-01", "diagnostic-encoder2-01"


def observed_case(name):
    """Shared reader: preserve FAILED, auditing only observations that actually exist."""
    folder = failed.safe_path(ROOT, name)
    raw = base.read(folder / "summary.json")
    require(
        raw.get("status") in ("COMPLETED", "FAILED", "COMPLETED_WITH_WORKLOAD_FAILURES"),
        "Case has not ended: " + name,
    )
    if raw["status"] == "COMPLETED":
        result, raw, queries, semantic = base.audit_case(name, "expanded1300")
        result.update(
            workload_status="PASSED", evidence_status="RECONCILED", missing_observations=[]
        )
    else:
        require(raw.get("case") == name, "Failure identity missing")
        if raw["status"] == "COMPLETED_WITH_WORKLOAD_FAILURES":
            require(
                raw.get("collection_status") == "COMPLETED"
                and raw.get("workload_status") == "FAILED",
                "Collected failure states disagree",
            )
        else:
            require(raw.get("error_type"), "Failure error missing")
        require(
            base.timestamp(raw["finished_at"])
            >= base.timestamp(raw["load_finished_at"])
            > base.timestamp(raw["load_started_at"]),
            "Failure has not ended",
        )
        require(
            (folder / "api.log").is_file() or raw.get("log_error"), "Final log attempt incomplete"
        )
        require(
            raw["requests"] == 20800
            and raw["concurrency"] == 32
            and raw["query_set"] == "expanded1300"
            and raw["timeout"] == raw["limit"] == 10
            and raw["idle_seconds"] == 120
            and raw["health_period_seconds"] == 10
            and raw["checkpoints"] == [400, 5200, 10400, 15600, 20800],
            "Failed control workload differs",
        )
        require(
            type(raw["load_seconds"]) in (int, float)
            and math.isfinite(raw["load_seconds"])
            and raw["load_seconds"] > 0,
            "Invalid failed-load duration",
        )
        queries, query_bytes = base.read_queries(folder / "queries.csv")
        require(
            len(queries) == 1300 and base.sha(query_bytes) == raw["query_sha256"],
            "Query bytes differ",
        )
        with (folder / "requests.jsonl").open(encoding="utf-8") as source:
            accounting, semantic = failed.reconcile_ledger(
                (json.loads(line) for line in source), raw, queries
            )
        require(
            base.timestamp(accounting["last_event_at"]) <= base.timestamp(raw["finished_at"]),
            "Request events continued after declared end",
        )
        labels = [row["label"] for row in raw["snapshots"]]
        require(
            len(labels) == len(set(labels))
            and labels == [label for label in base.LABELS if label in labels],
            "Existing snapshots reordered or duplicated",
        )
        snapshots, unavailable = {}, {}
        for row in raw["snapshots"]:
            label = row["label"]
            try:
                data = base.native_snapshot(row)
                maps = base.parse_smaps(
                    (folder / ("smaps-" + label + ".txt")).read_text(encoding="utf-8")
                )
                data["raw_smaps"] = base.map_totals(maps)
                snapshots[label] = data
            except (OSError, ValueError, KeyError, TypeError) as exc:
                unavailable[label] = {"error_type": type(exc).__name__, "error": str(exc)}
        try:
            observations = base.sampled_observations(folder, raw)
        except (ValueError, KeyError, TypeError) as exc:
            observations = {"available": False, "error_type": type(exc).__name__, "error": str(exc)}
        result = {
            "case": name,
            "status": "FAILED",
            "workload_status": "FAILED",
            "evidence_status": "RECONCILED",
            "ledger": accounting,
            "snapshots": snapshots,
            "unavailable_snapshots": unavailable,
            "observations": observations,
            "load_seconds": raw["load_seconds"],
            "started_at": raw["started_at"],
            "finished_at": raw["finished_at"],
            "missing_observations": {
                "snapshots": [label for label in base.LABELS if label not in labels],
                "fields": [
                    key
                    for key in ("idle_started_at", "ready_after", "final_container")
                    if key not in raw
                ],
                "api_log": not (folder / "api.log").is_file(),
                "log_error": raw.get("log_error"),
            },
        }
    setup = base.read(ROOT / "setup/summary.json")
    require(setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART", "Setup incomplete")
    for key, source in (
        ("input_sha256", "frozen_inputs"),
        ("source_sha256", "local_source_sha256"),
        ("executed_script_sha256", "executed_script_sha256"),
        ("helper_sha256", "helper_sha256"),
        ("public_config_sha256", "public_config_sha256"),
    ):
        require(raw[key] == setup[source], "Frozen control provenance differs: " + key)
    require(
        raw["query_sha256"] == setup["query_sets"]["expanded1300"]["sha256"], "Setup query differs"
    )
    require(
        raw["container"]["Image"] == setup["image"]
        and raw["container"]["Id"] != raw["previous_container"]["Id"]
        and raw["container"]["native_env"] == raw["process_native_environment"],
        "Initial runtime differs",
    )
    for name, expected in raw["executed_script_sha256"].items():
        require(
            digest(folder / (Path(name).stem + ".executed.py")) == expected,
            "Executed script changed",
        )
    require(
        digest(folder / "diagnostic_case.executed.py")
        == raw["helper_sha256"]["diagnostic_case.py"],
        "Frozen base-driver copy changed",
    )
    result["recorded_status"] = raw["status"]
    result["input_sha256"] = failed.raw_hashes(folder)
    return result, raw, queries, semantic


def matched(a, b, a_queries, b_queries, a_sem, b_sem):
    require(a_queries == b_queries, "Matched controls changed queries")
    encoder.semantic_equality(a_sem, b_sem)
    require(
        base.timestamp(a["finished_at"]) <= base.timestamp(b["started_at"])
        and a["container"]["Id"] != b["container"]["Id"],
        "Control order/recreation differs",
    )
    prior = a.get("final_container", a["container"])
    require(prior["Id"] == b["previous_container"]["Id"], "Broken control container chain")
    for key in (
        "input_sha256",
        "source_sha256",
        "executed_script_sha256",
        "helper_sha256",
        "public_config_sha256",
        "query_sha256",
        "process_native_environment",
        "requests",
        "concurrency",
        "limit",
        "timeout",
        "checkpoints",
        "idle_seconds",
        "health_period_seconds",
    ):
        require(a[key] == b[key], "Unexpected matched factor: " + key)


def failed_execution(case, raw, limit):
    """Check actual recorded initial execution; never invent a missing final_container."""
    manifest = base.read(case / "execution-manifest.json")
    require(
        manifest == raw["execution_manifest"]
        and raw["encoder_limit"] == limit
        and manifest["encoder_limit"] == limit
        and manifest["actual_entry"] == "diagnostic_encoder_case.executed.py"
        and manifest["base_copy_role"]
        == "diagnostic_case.executed.py is an unexecuted base-protocol copy",
        "Wrong actual encoder-control entry",
    )
    require(
        manifest["derived_driver_sha256"] != manifest["base_driver_sha256"],
        "Base is not actual derived entry",
    )
    files = {
        "diagnostic_case.executed.py": "base_driver_sha256",
        "diagnostic_encoder_case.executed.py": "derived_driver_sha256",
        "encoder_concurrency_ablation.executed.py": "patch_sha256",
        "derived-driver.diff": "derived_diff_sha256",
        "override.yml": "base_override_sha256",
        "encoder.override.yml": "encoder_override_sha256",
    }
    require(
        all(digest(failed.safe_path(case, name)) == manifest[key] for name, key in files.items()),
        "Execution file changed",
    )
    for name, key in (
        ("diagnostic_encoder_case.py", "derived_driver_sha256"),
        ("encoder_concurrency_ablation.py", "patch_sha256"),
    ):
        require(digest(ROOT / name) == manifest[key], "Actual frozen helper changed")
    require(
        manifest["expected_command"] == encoder.command(limit)
        and raw["container"]["command"] == manifest["expected_command"],
        "Wrong actual patch command",
    )
    require(
        manifest["runtime"]
        == {
            key: raw["container"][key]
            for key in ("Id", "Image", "command", "entrypoint", "diagnostic_mounts")
        },
        "Runtime manifest mismatch",
    )
    expected_mounts = {
        "/app/scripts/" + name: encoder.host_path(
            str(ROOT / "setup" / (Path(name).stem + ".executed.py"))
        )
        for name in ("diagnose_allocator.py", "soak_memory.py")
    }
    expected_mounts[encoder.TARGET] = encoder.host_path(
        str(case / "encoder_concurrency_ablation.executed.py")
    )
    require(
        encoder.mount_map(raw["container"]["diagnostic_mounts"]) == expected_mounts,
        "Wrong initial readonly mounts",
    )
    counters = {}
    for row in raw["snapshots"]:
        stats = row["data"].get("snapshot", row["data"])["encoder_concurrency"]
        require(
            stats["limit"] == limit
            and stats["patch_sha256"] == manifest["patch_sha256"]
            and stats["original_source_sha256"] == raw["source_sha256"][encoder.SOURCE_KEY],
            "Snapshot patch identity differs",
        )
        counters[row["label"]] = stats
    return {
        "execution_manifest": manifest,
        "observed_encoder_counters": counters,
        "final_container_observed": "final_container" in raw,
        "scope": (
            "Failed-arm observations only; "
            "no successful latency, drain or idle acceptance inferred."
        ),
    }


def compare():
    a, ar, aq, asem = observed_case(A)
    b, br, bq, bsem = observed_case(B)
    require(
        ar["status"] == "COMPLETED" and br["status"] == "FAILED",
        "Expected successful sham and failed cap2",
    )
    matched(ar, br, aq, bq, asem, bsem)
    setup = base.read(ROOT / "setup/summary.json")
    manifest, _, _ = encoder.execution_identity(ROOT / A, ar, setup)
    a["encoder"] = encoder.check_encoder(
        ar, 32, manifest["patch_sha256"], ar["source_sha256"][encoder.SOURCE_KEY]
    )
    a["execution_manifest"] = manifest
    b.update(failed_execution(ROOT / B, br, 2))
    for key in (
        "base_driver_sha256",
        "derived_driver_sha256",
        "patch_sha256",
        "derived_diff_sha256",
        "base_override_sha256",
    ):
        require(
            ar["execution_manifest"][key] == br["execution_manifest"][key],
            "Matched encoder helpers differ",
        )
    return {
        "status": "FAILED_WORKLOAD_RECONCILED",
        "workload_status": "FAILED",
        "evidence_status": "RECONCILED",
        "candidate_status": "REJECTED_TIMEOUT_OR_FAILURE",
        "case_order": [A, B],
        "cases": [a, b],
        "common_successful_groups": 5200,
        "common_successful_fingerprints_equal": True,
        "root_input_sha256": {
            name: digest(ROOT / name)
            for name in (
                "encoder-control-plan.md",
                "native-thread-control-plan.md",
                "reconcile_encoder_failure.py",
                "audit_failed_diagnostic.py",
                "compare_encoder_controls.py",
                "compare_diagnostics.py",
                "setup/summary.json",
            )
        },
        "limitations": [
            "Failed cap2 remains rejected; this is accounting, not a passing matched comparison.",
            "No missing idle/GC/trim or final-container observation is synthesized.",
            "Observed wait and timeout association does not establish a sole cause.",
        ],
    }


def self_test():
    from unittest.mock import patch

    failed.self_test()
    case = ROOT / "toy-unexecuted-case"
    mounts = [
        {
            "Type": "bind",
            "Source": str(ROOT / "setup" / (Path(name).stem + ".executed.py")),
            "Destination": "/app/scripts/" + name,
            "RW": False,
        }
        for name in ("diagnose_allocator.py", "soak_memory.py")
    ]
    mounts.append(
        {
            "Type": "bind",
            "Source": str(case / "encoder_concurrency_ablation.executed.py"),
            "Destination": encoder.TARGET,
            "RW": False,
        }
    )
    container = {
        "Id": "toy",
        "Image": "toy-image",
        "command": encoder.command(2),
        "entrypoint": None,
        "diagnostic_mounts": mounts,
    }
    manifest = {
        "encoder_limit": 2,
        "actual_entry": "diagnostic_encoder_case.executed.py",
        "base_copy_role": "diagnostic_case.executed.py is an unexecuted base-protocol copy",
        "base_driver_sha256": "base",
        "derived_driver_sha256": "h",
        "patch_sha256": "h",
        "derived_diff_sha256": "h",
        "base_override_sha256": "h",
        "encoder_override_sha256": "h",
        "expected_command": encoder.command(2),
        "runtime": copy.deepcopy(container),
    }
    raw = {
        "status": "FAILED",
        "encoder_limit": 2,
        "execution_manifest": manifest,
        "container": container,
        "source_sha256": {encoder.SOURCE_KEY: "h"},
        "snapshots": [
            {
                "label": "after_20800",
                "data": {
                    "encoder_concurrency": {
                        "limit": 2,
                        "patch_sha256": "h",
                        "original_source_sha256": "h",
                    }
                },
            }
        ],
    }
    before = copy.deepcopy(raw)
    rejected = []
    with (
        patch.object(base, "read", side_effect=lambda _: raw["execution_manifest"]),
        patch.dict(
            globals(),
            digest=lambda path: "base" if Path(path).name == "diagnostic_case.executed.py" else "h",
        ),
    ):
        result = failed_execution(case, raw, 2)
        require(
            result["final_container_observed"] is False and raw == before,
            "Invented final container or changed FAILED",
        )
        for field, bad in (
            ("actual_entry", "diagnostic_case.executed.py"),
            ("patch_sha256", "different"),
        ):
            old = manifest[field]
            manifest[field] = bad
            try:
                failed_execution(case, raw, 2)
            except ValueError:
                rejected.append(field)
            else:
                raise AssertionError("Invalid execution provenance passed")
            manifest[field] = old
        raw["container"]["diagnostic_mounts"][-1]["RW"] = True
        try:
            failed_execution(case, raw, 2)
        except ValueError:
            rejected.append("writable_mount")
        else:
            raise AssertionError("Writable mount passed")
    print(
        json.dumps(
            {
                "status": "TOY_CHECKS_PASSED",
                "workload_status_example": "FAILED",
                "execution_counterexamples_rejected": rejected,
                "services_called": 0,
                "files_written": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    if parser.parse_args().self_test:
        self_test()
        return 0
    output = ROOT / "encoder-comparison-failed.json"
    with output.open("x", encoding="utf-8") as sink:
        json.dump({"evidence_status": "RUNNING", "workload_status": "FAILED"}, sink)
    try:
        result = compare()
    except (OSError, ValueError, TypeError, KeyError) as exc:
        result = {
            "status": "UNRECONCILED",
            "workload_status": "FAILED",
            "evidence_status": "UNRECONCILED",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    result["audited_at"] = datetime.now(UTC).isoformat()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(
        json.dumps({key: result[key] for key in ("status", "workload_status", "evidence_status")})
    )
    return int(result["evidence_status"] != "RECONCILED")


if __name__ == "__main__":
    raise SystemExit(main())
