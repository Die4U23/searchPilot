"""Diagnostic encoder32 patch with bounded in-worker torch thread observations."""

from __future__ import annotations

import functools
import hashlib
import inspect
import sys
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

_installed = None


class EncoderLimiter:
    """Constant-size counters; no request text, result, exception, or thread retention."""

    def __init__(self, limit):
        if type(limit) is not int or limit != 32:
            raise ValueError("Native-thread control must preserve encoder limit32")
        self.limit = limit
        self._semaphore = threading.BoundedSemaphore(limit)
        self._lock = threading.Lock()
        self._stats = dict(
            calls_started=0,
            calls_entered=0,
            calls_completed=0,
            errors=0,
            active=0,
            peak_active=0,
            waiting=0,
            peak_waiting=0,
            wait_seconds_total=0.0,
            wait_seconds_max=0.0,
            execution_seconds_total=0.0,
            execution_seconds_max=0.0,
        )

        self._observations = {
            stage: {
                "calls": 0,
                "available": 0,
                "unavailable": 0,
                "errors": 0,
                "intra_min": None,
                "intra_max": None,
                "intra_eq1": 0,
                "intra_gt1": 0,
                "interop_min": None,
                "interop_max": None,
                "interop_eq1": 0,
                "interop_gt1": 0,
                "intra_histogram": {},
                "interop_histogram": {},
                "histogram_overflow": 0,
            }
            for stage in ("before", "after")
        }

    def observe(self, stage):
        # Do not import torch here: preserve the original lazy initialization order.
        torch = sys.modules.get("torch")
        outcome, values = "unavailable", None
        if torch is not None:
            try:
                values = (torch.get_num_threads(), torch.get_num_interop_threads())
                if any(type(value) is not int or value < 1 for value in values):
                    raise ValueError("Invalid thread count")
                outcome = "available"
            except Exception:
                outcome = "errors"
        with self._lock:
            stats = self._observations[stage]
            stats["calls"] += 1
            stats[outcome] += 1
            if outcome != "available":
                return
            for name, value in zip(("intra", "interop"), values, strict=True):
                minimum, maximum = stats[name + "_min"], stats[name + "_max"]
                stats[name + "_min"] = value if minimum is None else min(minimum, value)
                stats[name + "_max"] = value if maximum is None else max(maximum, value)
                stats[name + ("_eq1" if value == 1 else "_gt1")] += 1
                histogram = stats[name + "_histogram"]
                key = str(value)
                if key not in histogram and len(histogram) >= 16:
                    stats["histogram_overflow"] += 1
                else:
                    histogram[key] = histogram.get(key, 0) + 1

    def snapshot(self):
        with self._lock:
            observations = {
                stage: {
                    key: dict(value) if isinstance(value, dict) else value
                    for key, value in stats.items()
                }
                for stage, stats in self._observations.items()
            }
            return {"limit": self.limit, **self._stats, "torch_thread_observations": observations}

    def call(self, original, instance, text):
        wait_start = time.perf_counter()
        with self._lock:
            self._stats["calls_started"] += 1
            self._stats["waiting"] += 1
            self._stats["peak_waiting"] = max(self._stats["peak_waiting"], self._stats["waiting"])
        acquired, entered, failed = False, False, False
        execution_start = None
        try:
            acquired = self._semaphore.acquire()
            waited = time.perf_counter() - wait_start
            with self._lock:
                self._stats["waiting"] -= 1
                self._stats["calls_entered"] += 1
                self._stats["active"] += 1
                self._stats["peak_active"] = max(self._stats["peak_active"], self._stats["active"])
                self._stats["wait_seconds_total"] += waited
                self._stats["wait_seconds_max"] = max(self._stats["wait_seconds_max"], waited)
                entered = True
            execution_start = time.perf_counter()
            self.observe("before")
            try:
                return original(instance, text)
            finally:
                self.observe("after")
        except BaseException:
            failed = True
            raise
        finally:
            elapsed = time.perf_counter() - execution_start if execution_start is not None else 0.0
            try:
                with self._lock:
                    self._stats["calls_completed"] += 1
                    self._stats["errors"] += failed
                    if entered:
                        self._stats["active"] -= 1
                    else:
                        self._stats["waiting"] -= 1
                    self._stats["execution_seconds_total"] += elapsed
                    self._stats["execution_seconds_max"] = max(
                        self._stats["execution_seconds_max"], elapsed
                    )
            finally:
                if acquired:
                    self._semaphore.release()


def install(limit, *, encoder_class=None, diagnostic_class=None):
    """Install before app construction; injectable classes support model-free toy checks."""
    global _installed
    if _installed is not None:
        raise RuntimeError("Encoder diagnostic patch is already installed")
    limiter = EncoderLimiter(limit)
    if encoder_class is None:
        from searchpilot.search.vector_index import SentenceTransformerQueryEncoder

        encoder_class = SentenceTransformerQueryEncoder
    if diagnostic_class is None:
        from scripts.diagnose_allocator import Diagnostic

        diagnostic_class = Diagnostic
    original = encoder_class.__call__
    base_snapshot = diagnostic_class.snapshot
    source_path = inspect.getsourcefile(original)
    evidence = {
        "schema_version": 2,
        "variant": "native_thread_observation",
        "installed_at": datetime.now(UTC).isoformat(),
        "patch_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "original_module": original.__module__,
        "original_qualname": original.__qualname__,
        "original_source_path": source_path,
        "original_source_sha256": hashlib.sha256(Path(source_path).read_bytes()).hexdigest()
        if source_path and Path(source_path).is_file()
        else None,
        "scope": "Class __call__, global process semaphore, same original implementation. "
        "Waiting includes acquisition overhead. Counters are bounded aggregates; "
        "native and encoder observations are sequential/non-atomic. Torch getters execute "
        "in the original caller thread before/after the original call, without eager torch import. "
        "Execution seconds include getter overhead. Histograms retain at most16 distinct values; "
        "overflow is explicit and invalidates complete observation acceptance.",
    }

    @functools.wraps(original)
    def wrapped(instance, text):
        return limiter.call(original, instance, text)

    @functools.wraps(base_snapshot)
    def observed(instance):
        result = base_snapshot(instance)
        result["encoder_concurrency"] = {**evidence, **limiter.snapshot()}
        return result

    encoder_class.__call__ = wrapped
    diagnostic_class.snapshot = observed
    _installed = limiter
    return {**evidence, **limiter.snapshot()}
