"""Derived OMP environment control; all earlier diagnostic helpers remain frozen.

Only OMP_NUM_THREADS changes; identical encoder32 and worker-thread observations.
All slow control/proc/Docker observations run off the client event loop.
"""

from __future__ import annotations

import argparse
import asyncio
import difflib
import hashlib
import json
import re
import subprocess
import time
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path

import httpx
from scripts.bench_concurrent import MODES, Config, read_queries, request_once, summarize
from scripts.validate_container_soak import clean_environment, probe_health

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = "sp-memory-diagnostic-20261026"
API = PROJECT + "-api-1"
BASE_URL = "http://127.0.0.1:18232"
DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
TOTAL, CONCURRENCY = 20800, 32
CHECKPOINTS = (400, 5200, 10400, 15600, 20800)
ENVIRONMENT = {
    "MALLOC_ARENA_MAX": "2",
    "SEARCHPILOT_DISABLE_THP": "true",
    "GLIBC_TUNABLES": None,
    "LD_PRELOAD": None,
    "PYTHONMALLOC": None,
    "PYTHONTRACEMALLOC": None,
}
THREAD_ENV_KEYS = (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "OMP_THREAD_LIMIT",
    "OMP_DYNAMIC",
    "MKL_DYNAMIC",
    "NUMEXPR_NUM_THREADS",
    "NUMEXPR_MAX_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "OMP_MAX_ACTIVE_LEVELS",
    "OMP_NESTED",
    "OMP_PROC_BIND",
    "OMP_PLACES",
    "KMP_AFFINITY",
    "KMP_BLOCKTIME",
    "KMP_SETTINGS",
    "TOKENIZERS_PARALLELISM",
    "RAYON_NUM_THREADS",
)
THREAD_ENV_PREFIXES = (
    "OMP_",
    "MKL_",
    "OPENBLAS_",
    "NUMEXPR_",
    "VECLIB_",
    "KMP_",
    "TOKENIZERS_",
    "RAYON_",
)


def clean_thread_environment():
    return {
        key: value
        for key, value in clean_environment().items()
        if not key.upper().startswith(THREAD_ENV_PREFIXES)
    }


READY_CHECKS = ("search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database")
SAMPLE_CODE = (
    "import json;from pathlib import Path;from scripts.soak_memory import sample_linux_process;"
    "r=sample_linux_process(1);"
    "r['task_ids']=sorted(int(p.name) for p in Path('/proc/1/task').iterdir());"
    "r['host_loadavg']=Path('/proc/loadavg').read_text().strip();print(json.dumps(r))"
)


def now():
    return datetime.now(UTC).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def command(argv, timeout=120):
    return subprocess.run(
        argv,
        cwd=REPO,
        env=clean_thread_environment(),
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    ).stdout


def safe_container(raw):
    config = raw["Config"]
    env = dict(item.split("=", 1) for item in config.get("Env", []) if "=" in item)
    return {
        **{key: raw[key] for key in ("Id", "Name", "Image", "RestartCount", "State")},
        "command": config.get("Cmd"),
        "entrypoint": config.get("Entrypoint"),
        "project": config["Labels"].get("com.docker.compose.project"),
        "native_env": {key: env.get(key) for key in ENVIRONMENT},
        "thread_environment": {key: env.get(key) for key in THREAD_ENV_KEYS},
        "diagnostic_mounts": [
            {key: mount[key] for key in ("Type", "Source", "Destination", "RW")}
            for mount in raw.get("Mounts", [])
            if mount["Destination"]
            in (
                "/app/scripts/diagnose_allocator.py",
                "/app/scripts/soak_memory.py",
                "/app/diagnostic/native_thread_ablation.py",
            )
        ],
    }


def inspect_api():
    return safe_container(json.loads(command([DOCKER, "inspect", API]))[0])


def capture_logs():
    result = subprocess.run(
        [DOCKER, "logs", API],
        cwd=REPO,
        env=clean_thread_environment(),
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return result.stdout + result.stderr


def control(path="/snapshot", payload=None, timeout=60):
    body = json.dumps(payload).encode() if payload is not None else None
    code = (
        "import urllib.request; r=urllib.request.Request('http://127.0.0.1:8779' + "
        + repr(path)
        + ",data="
        + repr(body)
        + ",headers={'Content-Type':'application/json'});"
        "print(urllib.request.urlopen(r,timeout=" + repr(timeout) + ").read().decode())"
    )
    return json.loads(command([DOCKER, "exec", API, "python", "-c", code], timeout + 5))


def ready(probe):
    return (
        probe.get("available") is True
        and probe.get("status") == 200
        and all(probe.get("body", {}).get("checks", {}).get(k) is True for k in READY_CHECKS)
    )


def verify_frozen(setup):
    for mapping in (
        setup["frozen_inputs"],
        setup["local_source_sha256"],
        setup["public_config_sha256"],
    ):
        require(
            all(digest(REPO / name) == value for name, value in mapping.items()),
            "Frozen repository input/source/config changed",
        )
    require(
        all(digest(ROOT / name) == value for name, value in setup["helper_sha256"].items()),
        "Frozen diagnostic helper changed",
    )
    for name, expected in setup["executed_script_sha256"].items():
        require(
            digest(ROOT / "setup" / (Path(name).stem + ".executed.py")) == expected,
            "Executed script snapshot changed: " + name,
        )


async def main(args):
    require(
        args.encoder_limit == 32
        and args.omp_threads in ("unset", "1")
        and args.query_set == "expanded1300",
        "Use the declared expanded-query encoder control protocol",
    )
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]*", args.case), "Use a unique lowercase case name")
    setup = read(ROOT / "setup/summary.json")
    require(setup.get("status") == "READY_FOR_DIAGNOSTIC_RESTART", "Diagnostic setup is not ready")
    for path in ROOT.glob("*/summary.json"):
        previous = read(path)
        require(
            not (previous.get("query_set") and previous.get("status") == "RUNNING"),
            "Another diagnostic case is still RUNNING; preserve/reconcile it first",
        )
    verify_frozen(setup)
    queries, query_raw = read_queries(
        ROOT / "setup" / setup["query_sets"][args.query_set]["snapshot"]
    )
    query_sha = hashlib.sha256(query_raw).hexdigest()
    require(query_sha == setup["query_sets"][args.query_set]["sha256"], "Query snapshot changed")
    out = ROOT / args.case
    out.mkdir(exist_ok=False)
    (out / "queries.csv").write_bytes(query_raw)
    for name in setup["executed_script_sha256"]:
        source = ROOT / "setup" / (Path(name).stem + ".executed.py")
        (out / source.name).write_bytes(source.read_bytes())
    base_bytes = (ROOT / "diagnostic_case.py").read_bytes()
    derived_bytes = Path(__file__).read_bytes()
    patch_bytes = (ROOT / "native_thread_ablation.py").read_bytes()
    parent_driver_bytes = (ROOT / "diagnostic_encoder_case.py").read_bytes()
    parent_patch_bytes = (ROOT / "encoder_concurrency_ablation.py").read_bytes()
    (out / "diagnostic_encoder_case.base.py").write_bytes(parent_driver_bytes)
    (out / "encoder_concurrency_ablation.base.py").write_bytes(parent_patch_bytes)
    # Retain this base copy for base-protocol audit; it is NOT the executed driver.
    (out / "diagnostic_case.executed.py").write_bytes(base_bytes)
    (out / "diagnostic_native_thread_case.executed.py").write_bytes(derived_bytes)
    patch_copy = out / "native_thread_ablation.executed.py"
    patch_copy.write_bytes(patch_bytes)
    diff = "".join(
        difflib.unified_diff(
            base_bytes.decode().splitlines(keepends=True),
            derived_bytes.decode().splitlines(keepends=True),
            fromfile="diagnostic_case.py (frozen base)",
            tofile="diagnostic_native_thread_case.py (actual driver)",
        )
    )
    (out / "derived-driver.diff").write_text(diff, encoding="utf-8")
    for filename, before, after in (
        ("parent-driver.diff", parent_driver_bytes, derived_bytes),
        ("parent-patch.diff", parent_patch_bytes, patch_bytes),
    ):
        (out / filename).write_text(
            "".join(
                difflib.unified_diff(
                    before.decode().splitlines(keepends=True),
                    after.decode().splitlines(keepends=True),
                    fromfile="frozen encoder-control parent",
                    tofile="actual native-thread control",
                )
            ),
            encoding="utf-8",
        )
    thread_environment = {key: None for key in THREAD_ENV_KEYS}
    thread_environment["OMP_NUM_THREADS"] = None if args.omp_threads == "unset" else "1"
    prefix = (
        "import ctypes;c=ctypes.CDLL(None,use_errno=True);"
        "r=c.prctl(41,1,0,0,0);assert r==0,ctypes.get_errno();"
        "assert c.prctl(42,0,0,0,0)==1;from scripts.diagnose_allocator import main;main()"
    )
    override = {
        "services": {
            "api": {
                "environment": ENVIRONMENT,
                "command": ["python", "-c", prefix],
                "volumes": [
                    {
                        "type": "bind",
                        "source": str(ROOT / "setup" / (Path(name).stem + ".executed.py")),
                        "target": "/app/scripts/" + name,
                        "read_only": True,
                    }
                    for name in ("diagnose_allocator.py", "soak_memory.py")
                ],
            }
        }
    }
    (out / "override.yml").write_text(json.dumps(override, indent=2), encoding="utf-8")
    compose = [
        DOCKER,
        "compose",
        "--env-file",
        str(ROOT / "setup/public-env.txt"),
        "-p",
        PROJECT,
        "-f",
        str(REPO / "docker-compose.yml"),
        "-f",
        str(ROOT / "setup/compose.override.yml"),
        "-f",
        str(out / "override.yml"),
    ]
    patch_target = "/app/diagnostic/native_thread_ablation.py"
    patched_prefix = (
        "import ctypes;c=ctypes.CDLL(None,use_errno=True);"
        "r=c.prctl(41,1,0,0,0);assert r==0,ctypes.get_errno();"
        "assert c.prctl(42,0,0,0,0)==1;"
        "import sys;sys.path.insert(0,'/app/diagnostic');"
        "from native_thread_ablation import install;install("
        + str(args.encoder_limit)
        + ");from scripts.diagnose_allocator import main;main()"
    )
    native_override = {
        "services": {
            "api": {
                "command": ["python", "-c", patched_prefix],
                "environment": thread_environment,
                "volumes": [
                    {
                        "type": "bind",
                        "source": str(patch_copy),
                        "target": patch_target,
                        "read_only": True,
                    }
                ],
            }
        }
    }
    native_override_path = out / "native-thread.override.yml"
    native_override_path.write_text(json.dumps(native_override, indent=2), encoding="utf-8")
    compose.extend(["-f", str(native_override_path)])
    manifest = {
        "schema_version": 1,
        "variant": "diagnostic_native_thread_environment",
        "omp_threads": args.omp_threads,
        "expected_thread_environment": thread_environment,
        "parent_encoder_driver_sha256": hashlib.sha256(parent_driver_bytes).hexdigest(),
        "parent_encoder_patch_sha256": hashlib.sha256(parent_patch_bytes).hexdigest(),
        "parent_driver_diff_sha256": digest(out / "parent-driver.diff"),
        "parent_patch_diff_sha256": digest(out / "parent-patch.diff"),
        "parent_copy_role": "The encoder parent driver and patch base copies "
        "are unexecuted derivation references; only native patch is installed",
        "encoder_limit": args.encoder_limit,
        "actual_entry": "diagnostic_native_thread_case.executed.py",
        "base_copy_role": "diagnostic_case.executed.py is an unexecuted base-protocol copy",
        "base_driver_sha256": hashlib.sha256(base_bytes).hexdigest(),
        "derived_driver_sha256": hashlib.sha256(derived_bytes).hexdigest(),
        "patch_sha256": hashlib.sha256(patch_bytes).hexdigest(),
        "derived_diff_sha256": digest(out / "derived-driver.diff"),
        "base_override_sha256": digest(out / "override.yml"),
        "native_override_sha256": digest(native_override_path),
        "expected_command": native_override["services"]["api"]["command"],
        "patch_target": patch_target,
        "patch_host_path": str(patch_copy),
        "protocol_note": "Same frozen base/data/model/image, explicitly patched runtime class. "
        "Both OMP settings use identical encoder32 and bounded worker-thread observers.",
    }
    report = {
        "status": "RUNNING",
        "collection_status": "RUNNING",
        "workload_status": "UNDETERMINED",
        "drain_observations": [],
        "encoder_drain_scope": "Encoder invocation counters only. This does not prove that "
        "a timed-out handler finished subsequent retrieval/serialization.",
        "omp_threads": args.omp_threads,
        "encoder_limit": args.encoder_limit,
        "execution_manifest": manifest,
        "started_at": now(),
        "case": args.case,
        "query_set": args.query_set,
        "query_sha256": query_sha,
        "query_count": len(queries),
        "requests": TOTAL,
        "concurrency": CONCURRENCY,
        "timeout": 10,
        "limit": 10,
        "checkpoints": list(CHECKPOINTS),
        "idle_seconds": 120,
        "health_period_seconds": 10,
        "external_llm_calls": 0,
        "private_env_read": False,
        "input_sha256": setup["frozen_inputs"],
        "source_sha256": setup["local_source_sha256"],
        "executed_script_sha256": setup["executed_script_sha256"],
        "public_config_sha256": setup["public_config_sha256"],
        "helper_sha256": setup["helper_sha256"],
        "checkpoint_triggers": [],
        "snapshots": [],
        "method": "Explicit OMP unset/1 environment ablation; unchanged encoder32 semaphore. "
        "Fixed-count round-robin query x four modes; 32 continuous workers, "
        "no intermediate drain. Snapshots sequential/non-atomic while issuing continues; "
        "explicit idle120, GC, trim only after drain. Same fresh DB, force-recreated API; "
        "same expanded fixture for both OMP settings. All-container Docker stats "
        "and Linux loadavg are not complete Windows-host CPU monitoring.",
    }
    phase, completed, inflight, peak = "startup", 0, 0, 0
    stop = asyncio.Event()
    client_load_finished = asyncio.Event()
    monitor = observer = None

    def save():
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    async def snap(label, path="/snapshot", payload=None, trigger=None):
        before = {"completed": completed, "inflight": inflight}
        started = now()
        value = await asyncio.to_thread(control, path, payload)
        smaps = await asyncio.to_thread(command, [DOCKER, "exec", API, "cat", "/proc/1/smaps"])
        external = json.loads(
            await asyncio.to_thread(command, [DOCKER, "exec", API, "python", "-c", SAMPLE_CODE])
        )
        after = {"completed": completed, "inflight": inflight}
        row = {
            "label": label,
            "started_at": started,
            "at": now(),
            "data": value,
            "counts_before": before,
            "counts_after": after,
            "trigger": trigger,
            "external_process": external,
            "atomic": False,
        }
        await asyncio.to_thread(
            (out / ("smaps-" + label + ".txt")).write_text, smaps, encoding="utf-8"
        )
        report["snapshots"].append(row)
        frozen_report = json.dumps(report, indent=2) + "\n"
        await asyncio.to_thread((out / "summary.json").write_text, frozen_report, encoding="utf-8")
        native = value.get("snapshot", value)
        require(
            native["allocator"]["mallinfo2"]["available"] is True
            and native["allocator"]["malloc_info"]["available"] is True
            and native["pymalloc"]["available"] is True,
            "Native diagnostic unavailable",
        )
        require(native["tracemalloc"]["enabled"] is False, "Unexpected tracing intervention")
        stats = native["encoder_concurrency"]
        require(
            stats["limit"] == args.encoder_limit
            and stats["variant"] == "native_thread_observation"
            and stats["patch_sha256"] == manifest["patch_sha256"]
            and stats["original_source_sha256"]
            == setup["local_source_sha256"]["src/searchpilot/search/vector_index.py"]
            and stats["peak_active"] <= args.encoder_limit,
            "Encoder patch identity/counters invalid",
        )
        if label in ("after_20800", "idle", "gc", "trim"):
            require(
                stats["active"] == stats["waiting"] == 0,
                "Encoder invocations remained active after client drain",
            )
            warm = next(row for row in report["snapshots"] if row["label"] == "warmup")
            initial = warm["data"]["encoder_concurrency"]
            if stats["errors"] - initial["errors"] > 0:
                report["workload_status"] = "FAILED"
            require(
                all(
                    stats[key] - initial[key] == 15600
                    for key in ("calls_started", "calls_entered", "calls_completed")
                ),
                "Measured encoder invocation denominator differs",
            )
            for stage in ("before", "after"):
                observed = stats["torch_thread_observations"][stage]
                start_observed = initial["torch_thread_observations"][stage]
                require(
                    all(
                        observed[key] - start_observed[key] == 15600
                        for key in ("calls", "available")
                    ),
                    "Formal worker-thread observation denominator differs",
                )
                require(
                    all(
                        observed[key] - start_observed[key] == 0
                        for key in ("unavailable", "errors", "histogram_overflow")
                    ),
                    "Incomplete/error worker-thread observation",
                )

    async def await_encoder_drain():
        report["encoder_drain_started_at"] = now()
        clock = time.perf_counter()
        warm = next(row for row in report["snapshots"] if row["label"] == "warmup")
        initial = warm["data"]["encoder_concurrency"]
        async with asyncio.timeout(60):
            while True:
                value = await asyncio.to_thread(control, "/snapshot", None, 3)
                stats = value["encoder_concurrency"]
                report["drain_observations"].append(
                    {
                        "at": now(),
                        "elapsed_seconds": time.perf_counter() - clock,
                        "encoder_concurrency": stats,
                    }
                )
                require(
                    len(report["drain_observations"]) <= 121,
                    "Encoder drain observation budget exceeded",
                )
                counters = ("calls_started", "calls_entered", "calls_completed")
                changes = {key: stats[key] - initial[key] for key in counters}
                require(
                    all(0 <= delta <= 15600 for delta in changes.values()),
                    "Encoder drain count exceeded planned workload",
                )
                if stats["active"] == stats["waiting"] == 0 and all(
                    delta == 15600 for delta in changes.values()
                ):
                    report["encoder_drained_at"] = now()
                    report["encoder_drain_seconds"] = time.perf_counter() - clock
                    return
                await asyncio.sleep(0.5)

    async def observation(argv, lines=False):
        try:
            raw_output = await asyncio.to_thread(command, argv, 8)
            return {
                "available": True,
                "data": [json.loads(line) for line in raw_output.splitlines()]
                if lines
                else json.loads(raw_output),
            }
        except Exception as exc:
            return {"available": False, "error_type": type(exc).__name__}

    async def sample(client):
        with (out / "samples.jsonl").open("x", encoding="utf-8") as sink:
            while not stop.is_set():
                clock = time.perf_counter()
                row = {"at": now(), "phase": phase, "completed": completed, "inflight": inflight}
                server, stats, live, health = await asyncio.gather(
                    observation([DOCKER, "exec", API, "python", "-c", SAMPLE_CODE]),
                    observation([DOCKER, "stats", "--no-stream", "--format", "{{json .}}"], True),
                    probe_health(client, "live"),
                    probe_health(client, "ready"),
                )
                row.update(
                    server=server.get("data", server),
                    stats=stats,
                    live=live,
                    ready=health,
                    sample_seconds=time.perf_counter() - clock,
                )
                sink.write(json.dumps(row) + "\n")
                sink.flush()
                with suppress(TimeoutError):
                    await asyncio.wait_for(stop.wait(), max(0.01, 10 - row["sample_seconds"]))

    save()
    try:
        before = await asyncio.to_thread(inspect_api)
        require(before["project"] == PROJECT, "Existing API does not belong to owned project")
        report["previous_container"] = before
        report["compose_output"] = await asyncio.to_thread(
            command,
            compose + ["up", "-d", "--no-deps", "--no-build", "--force-recreate", "api"],
            180,
        )
        current = await asyncio.to_thread(inspect_api)
        report["container"] = current
        require(current["command"] == manifest["expected_command"], "Patch command mismatch")
        patch_mounts = [
            mount for mount in current["diagnostic_mounts"] if mount["Destination"] == patch_target
        ]
        require(
            len(patch_mounts) == 1
            and patch_mounts[0]["Type"] == "bind"
            and patch_mounts[0]["RW"] is False,
            "Patch mount is not readonly",
        )
        manifest["runtime"] = {
            key: current[key]
            for key in (
                "Id",
                "Image",
                "command",
                "entrypoint",
                "diagnostic_mounts",
                "thread_environment",
            )
        }
        with (out / "execution-manifest.json").open("x", encoding="utf-8") as sink:
            json.dump(manifest, sink, indent=2)
            sink.write("\n")
        require(
            current["Id"] != before["Id"]
            and current["Image"] == setup["image"]
            and current["project"] == PROJECT,
            "API identity/image mismatch",
        )
        require(current["native_env"] == ENVIRONMENT, "Container native environment mismatch")
        require(
            current["thread_environment"] == thread_environment,
            "Container thread environment mismatch",
        )
        env_code = (
            "import json;from pathlib import Path;keys="
            + repr([*ENVIRONMENT, *THREAD_ENV_KEYS])
            + ";"
            "parts=Path('/proc/1/environ').read_bytes().split(b'\\0');"
            "values={k.decode():v.decode() for p in parts if b'=' in p "
            "for k,v in [p.split(b'=',1)] if k.decode() in keys};"
            "print(json.dumps({k:values.get(k) for k in keys}))"
        )
        process_environment = json.loads(
            await asyncio.to_thread(command, [DOCKER, "exec", API, "python", "-c", env_code])
        )
        report["process_native_environment"] = {
            key: process_environment[key] for key in ENVIRONMENT
        }
        report["process_thread_environment"] = {
            key: process_environment[key] for key in THREAD_ENV_KEYS
        }
        require(
            report["process_thread_environment"] == thread_environment,
            "PID1 thread environment mismatch",
        )
        require(
            report["process_native_environment"] == ENVIRONMENT, "PID1 native environment mismatch"
        )
        async with (
            httpx.AsyncClient(
                base_url=BASE_URL,
                trust_env=False,
                timeout=10,
                limits=httpx.Limits(
                    max_connections=CONCURRENCY, max_keepalive_connections=CONCURRENCY
                ),
            ) as client,
            httpx.AsyncClient(base_url=BASE_URL, trust_env=False, timeout=10) as health,
        ):
            async with asyncio.timeout(240):
                while not ready(await probe_health(health, "ready")):
                    await asyncio.sleep(0.5)
            await snap("ready")
            config = Config(
                base_url=BASE_URL,
                requests=TOTAL,
                concurrency=CONCURRENCY,
                timeout=10,
                warmup=4,
                limit=10,
            )
            results, warmup = [], []
            with (out / "requests.jsonl").open("x", encoding="utf-8") as ledger:

                def event_sink(event):
                    ledger.write(json.dumps({"at": now(), **event}) + "\n")
                    ledger.flush()

                for mode_index, mode in enumerate(MODES):
                    for index in range(4):
                        warmup.append(
                            await request_once(
                                client,
                                config,
                                index=mode_index * 4 + index,
                                mode=mode,
                                query=queries[index],
                                phase="warmup",
                                event_sink=event_sink,
                            )
                        )
                report["warmup"] = summarize(warmup, 0)
                require(
                    all(row["outcome"] == "success" and row["result_count"] > 0 for row in warmup),
                    "Warmup failed; evidence preserved",
                )
                await snap("warmup")
                phase = "load"
                report["load_started_at"] = now()
                load_clock = time.perf_counter()
                queue = asyncio.Queue()
                monitor = asyncio.create_task(sample(health))

                async def checkpoints():
                    nonlocal phase
                    for expected in CHECKPOINTS:
                        trigger = await queue.get()
                        require(trigger["completed"] == expected, "Checkpoint sequence mismatch")
                        if expected == TOTAL:
                            await client_load_finished.wait()
                            await await_encoder_drain()
                            phase = "post_load_snapshot"
                        await snap("after_" + str(expected), trigger=trigger)
                        print(
                            json.dumps(
                                {
                                    "case": args.case,
                                    "trigger_completed": expected,
                                    "actual_completed": completed,
                                }
                            ),
                            flush=True,
                        )

                observer = asyncio.create_task(checkpoints())
                indices = iter(range(TOTAL))

                async def worker():
                    nonlocal completed, inflight, peak
                    for index in indices:
                        dispatched_ms = (time.perf_counter() - load_clock) * 1000
                        inflight += 1
                        peak = max(peak, inflight)
                        try:
                            result = await request_once(
                                client,
                                config,
                                index=index,
                                mode=MODES[index % len(MODES)],
                                query=queries[(index // len(MODES)) % len(queries)],
                                phase="measured",
                                dispatched_ms=dispatched_ms,
                                event_sink=event_sink,
                            )
                        finally:
                            inflight -= 1
                        results.append(result)
                        completed += 1
                        if completed in CHECKPOINTS:
                            trigger = {
                                "completed": completed,
                                "at": now(),
                                "elapsed_seconds": time.perf_counter() - load_clock,
                            }
                            report["checkpoint_triggers"].append(trigger)
                            queue.put_nowait(trigger)
                        if monitor.done():
                            monitor.result()
                            raise RuntimeError("Sampler stopped before load completed")
                        if observer.done():
                            observer.result()

                # Await cancelled workers before closing their ledger on any worker/probe failure.
                async with asyncio.timeout(3600):
                    async with asyncio.TaskGroup() as group:
                        for _ in range(CONCURRENCY):
                            group.create_task(worker())
                report["load_seconds"] = time.perf_counter() - load_clock
                report["load_finished_at"] = now()
                report["peak_inflight"] = peak
                report["summary"] = summarize(results, report["load_seconds"])
                require(len(results) == TOTAL, "Incomplete measured request denominator")
                report["workload_status"] = (
                    "PASSED"
                    if all(
                        row["outcome"] == "success" and row["result_count"] > 0 for row in results
                    )
                    else "FAILED"
                )
                phase = "encoder_drain"
                client_load_finished.set()
                await observer
            phase = "idle"
            report["idle_started_at"] = now()
            await asyncio.sleep(120)
            await snap("idle")
            phase = "intervention"
            await snap("gc", "/gc", {})
            await snap("trim", "/trim", {})
            report["ready_after"] = await probe_health(health, "ready")
            require(ready(report["ready_after"]), "Final readiness failed")
            stop.set()
            await monitor
        report["final_container"] = await asyncio.to_thread(inspect_api)
        require(
            report["final_container"]["Id"] == current["Id"]
            and report["final_container"]["RestartCount"] == 0
            and report["final_container"]["State"]["OOMKilled"] is False,
            "API identity/OOM/restart changed",
        )
        verify_frozen(setup)
        require(
            digest(Path(__file__)) == manifest["derived_driver_sha256"]
            and digest(ROOT / "native_thread_ablation.py") == manifest["patch_sha256"]
            and digest(patch_copy) == manifest["patch_sha256"]
            and digest(native_override_path) == manifest["native_override_sha256"]
            and digest(ROOT / "diagnostic_encoder_case.py")
            == manifest["parent_encoder_driver_sha256"]
            and digest(ROOT / "encoder_concurrency_ablation.py")
            == manifest["parent_encoder_patch_sha256"],
            "Ablation driver/patch/override changed during execution",
        )
        require(
            report["final_container"]["command"] == current["command"]
            and report["final_container"]["diagnostic_mounts"] == current["diagnostic_mounts"]
            and report["final_container"]["thread_environment"] == thread_environment,
            "Runtime ablation command/mount changed",
        )
        report["collection_status"] = "COMPLETED"
        report["status"] = (
            "COMPLETED"
            if report["workload_status"] == "PASSED"
            else "COMPLETED_WITH_WORKLOAD_FAILURES"
        )
    except BaseException as exc:
        report.update(status="FAILED", collection_status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        stop.set()
        for task in (monitor, observer):
            if task is not None and not task.done():
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
        report["finished_at"] = now()
        save()
        try:
            output = await asyncio.to_thread(capture_logs)
            (out / "api.log").write_text(output, encoding="utf-8")
        except Exception as exc:
            report["log_error"] = type(exc).__name__
            report["status"] = "FAILED"
            report["collection_status"] = "FAILED"
            save()
    require(report["collection_status"] == "COMPLETED", "Diagnostic collection/log capture failed")
    print(
        json.dumps({"case": args.case, "status": report["status"], "summary": report["summary"]}),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--query-set", default="expanded1300", choices=("expanded1300",))
    parser.add_argument("--encoder-limit", default=32, type=int, choices=(32,))
    parser.add_argument("--omp-threads", required=True, choices=("unset", "1"))
    asyncio.run(main(parser.parse_args()))
