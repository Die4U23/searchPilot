# 两小时正常容器资源稳定性判据

本文件记录运行前确定的判据，不包含尚未发生的运行结果。历史小时档的末二十分钟 RSS 门槛通过，不等于后续台阶消失，也不是本轮验收结果。

## 固定协议

主线程确定：正常容器入口、c32、7200 秒固定闭环调度、冻结的 1300 条查询及四模式顺序，前 3600 秒作为预先确定的暖化区间但全部披露。固定后 3600 秒作为稳定区间；恢复阶段为 600 秒。对照/复现维持同一输入与配置。允许在运行前选择最长 14400 秒，但不允许看到结果后调整门槛或暖化终点。

RSS 与 Anonymous 分别满足以下所有条件：

- 整个稳定区间端点增长不超过 2 MiB，OLS 不超过 0.03 MiB/分钟。
- 稳定区间头十分钟和末十分钟的中位数之差不超过 2 MiB。
- 稳定区间每个固定五分钟中位数的极差不超过 2 MiB。
- 稳定区间每五分钟滑动一次的二十分钟窗口全部满足端点增长不超过 2 MiB、OLS 不超过 0.1 MiB/分钟。7200/3600 配置的起点为 3600、3900、4200、4500、4800、5100、5400、5700、6000 秒。

窗口采用 `[start,end)`；边界外的 load 点不被偷偷补入。报告完整正式窗、全部固定五分钟窗、稳定区间、所有滑动二十分钟窗、稳定区间头十分钟、末十/二十分钟和已有恢复采样。PSS、VmData、cgroup current 单独报告；缺失不是零，不以它们推断 RSS 增长原因。PSS 不参与本轮数值门槛。

数值比较只允许 `1e-9` 绝对浮点舍入容差，避免精确 0.03 的斜率被表示为 0.030000000000000006 而误判；该容差不能用于放宽实际门槛。

## 数据完整性

每个必需窗口首样本不晚于左边界 10 秒，末样本不早于右边界 10 秒；相邻时间严格增加，最大间隔 15 秒，最少点数为 `max(2,floor(window_seconds/10)-2)`。正式窗每行要求 server available、identity_consistent、PID1、stat/stat_after PID 与启动 ticks 一致，整段仅一个启动 ticks；采样外层和 server 时间均严格增加，server 时间在外层采样开始之后 15 秒以内。

RSS/Anonymous 每行要求来源 available、数值有限且非负。可选指标缺失在各窗口给出 missing_count；任何已提供的非法负值或非有限数都使正式证据失败。

基准必须 COMPLETED、一个 mixed run，config 与 run dispatch 时长匹配 CLI；稳定区间至少 3600 秒。finished-start 与 summary elapsed 相差至多 1 秒。逐请求 dispatch/latency 必须有限非负，dispatch 单调不减且严格小于调度截止，首末 dispatch 距两侧边界不超过 10 秒；last_dispatch 与实际最大 dispatch 一致；最后完成时间与 summary elapsed 相差至多 1 秒。总请求数与 timing 记录长度一致。这些只是证明资源时间窗对应持续运行所需的时间一致性，不代替请求账本、成功率、查询覆盖、健康、源码/模型来源和业务验收。

缺失、PID 变化、采样覆盖不足、短档、错报时长或不完整基准一律 FAILED/非零退出，没有 N/A 通过。恢复期为描述性数据，不改变负载门槛。

## 离线命令

```powershell
.venv/Scripts/python.exe -m scripts.audit_memory_stability --bench <case>/soak.json --samples <case>/samples.jsonl --duration-seconds 7200 --stable-after-seconds 3600 --out <case>/memory-stability.json
```

输出独占创建并记录输入 SHA-256。工具只读证据，不运行容器、模型或负载。有限十秒采样的两小时通过不能证明无限运行无泄漏。

## 必须保留的反例

整体持续上涨但末二十分钟平坦；稳定区间内上升后回落的台阶；RSS 平稳但 Anonymous 上升；缺失来源/指标、NaN、负值、PID 变化、身份标志缺失、重复或逆序时间、server 时间不可信；窗口边界不足/间隔过大；7200 秒半开边界；稳定区间不足一小时；把旧小时档 metadata 改成两小时但请求时间不匹配；CLI 畸形 JSON 与拒绝覆盖已有输出。
