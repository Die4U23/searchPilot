"""Reconcile a completed rejected baseline; never declare production acceptance."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime
from pathlib import Path

import audit_case as original
import normal_raw_evidence as raw
import package_evidence as packaging
from scripts.audit_memory_stability import audit as audit_memory

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = "sp-memory-stability-20261026"
OUTPUT = ROOT / "final-two-hour/failed-stability-reconciliation.json"
ORIGINAL_AUDITOR_SHA256 = "125125cada3c908143064626ee87ee711577d37d143b49fb13e14994d0bf6480"
# This pure replay below copies the frozen original auditor's checks without its CLI,
# subprocess or writes. Its source hash is pinned: no thresholds or checks are relaxed.
read, digest, require = raw.read, raw.digest, raw.require
source, window = original.source, original.window
CASES, CHECKS, SOURCES, NATIVE_KEYS = (
    original.CASES,
    original.CHECKS,
    original.SOURCES,
    original.NATIVE_KEYS,
)
verify_normal_raw, evidence_hashes = raw.verify_normal_raw, raw.evidence_hashes


def recompute_acceptance(folder, memory_gate):
    ledger, input_sha256 = verify_normal_raw(folder)
    harness, bench = [read(folder / name) for name in ("summary.json", "soak.json")]
    build = read(ROOT / "build-summary.json")
    if harness["status"] != "COMPLETED" or bench["status"] != "COMPLETED":
        raise ValueError("Complete cases required; preserve failure evidence separately")
    run = bench["runs"][0]
    start = datetime.fromisoformat(run["started_at"])
    concurrency, duration, repeats, baseline, recovery = CASES["final-two-hour"]
    samples = [
        json.loads(line)
        for line in (folder / "samples.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    for row in samples:
        row["elapsed_seconds"] = (datetime.fromisoformat(row["at"]) - start).total_seconds()
    load = [row for row in samples if row["phase"] == "load"]
    checks, details = {}, {}
    checks["planned_case"] = (
        len(bench["runs"]) == 1
        and all(
            c.get("duration_seconds") == duration and c.get("concurrency") == concurrency
            for c in (bench["config"], harness["config"])
        )
        and harness["config"].get("baseline_seconds") == baseline
        and harness["config"].get("recovery_seconds") == recovery
        and bench["config"].get("limit") == 10
        and bench["config"].get("timeout") == 10
        and bench["config"].get("warmup") == 4
        and bench["requested_modes"] == ["bm25", "vector", "hybrid", "ltr"]
        and run.get("dispatch_window_seconds") == duration
        and ledger.get("duration_seconds") == duration
        and ledger["coverage"].get("min_repeats") == repeats
        and ledger["inflight"].get("configured_concurrency") == concurrency
    )
    checks["query_metadata"] = (
        all(
            meta.get("sha256") == build["query_sha256"] and meta.get("count") == 1300
            for meta in (bench["queries"], harness["queries"])
        )
        and ledger["coverage"].get("sha256") == build["query_sha256"]
        and ledger["coverage"].get("query_count") == 1300
    )
    checks["ledger"] = ledger["status"] == "PASSED"
    checks["current_raw_ledger_replayed"] = True
    checks["query_coverage"] = (
        ledger["coverage"]["verified"] is True
        and ledger["coverage"]["expected_group_count"] == 5200
        and len(ledger["coverage"]["groups"]) == 5200
        and all(
            type(g.get("successful")) is int and g["successful"] >= repeats
            for g in ledger["coverage"]["groups"]
        )
    )
    checks["actual_client_concurrency"] = ledger["inflight"]["peak"] == concurrency
    checks["no_pending"] = ledger["inflight"]["pending_events_at_end"] == 0
    checks["warmup"] = (
        ledger["phases"]["warmup"]["success"] == 16 and ledger["phases"]["warmup"]["issued"] == 16
    )
    whole = window(load)
    checks["identity_and_rss"] = (
        whole.get("available") is True and whole.get("single_pid_start") is True
    )
    checks["health_coverage"] = (
        checks["identity_and_rss"]
        and whole["max_gap_seconds"] <= 15
        and whole["first_seconds"] <= 10
        and whole["last_seconds"] >= duration - 10
    )
    unavailable = [
        {"at": row["at"], "source": name}
        for row in load
        for name in SOURCES
        if row.get("server", {}).get("sources", {}).get(name, {}).get("available") is not True
    ]
    checks["sources_available"] = bool(load) and not unavailable
    details["unavailable_sources"] = unavailable
    details["health"] = {}
    for kind in ("live", "ready"):
        bad = []
        for row in load:
            probe = row.get(kind, {})
            good = probe.get("available") is True and probe.get("status") == 200
            if kind == "ready":
                good = good and all(
                    probe.get("body", {}).get("checks", {}).get(k) is True for k in CHECKS
                )
            if not good:
                bad.append(row["at"])
        details["health"][kind] = {
            "total": len(load),
            "success": len(load) - len(bad),
            "bad_at": bad,
        }
        checks[kind + "_all_success"] = bool(load) and not bad
    zero_fields = (
        ("smaps_rollup", "AnonHugePages_bytes"),
        ("smaps_rollup", "Swap_bytes"),
        ("smaps_rollup", "SwapPss_bytes"),
        ("status", "VmSwap_bytes"),
        ("status", "THP_enabled"),
        ("cgroup_memory_events", "oom"),
        ("cgroup_memory_events", "oom_kill"),
        ("cgroup_memory_events", "oom_group_kill"),
    )
    details["zero_fields"] = {}
    for name, key in zero_fields:
        values = [source(row, name).get(key) for row in load]
        details["zero_fields"][key] = dict(Counter(str(value) for value in values))
        checks[key + "_zero_complete"] = bool(values) and all(
            type(v) is int and v == 0 for v in values
        )
    api_states = {
        name: next(row for row in harness[name] if row["Name"].endswith("-api-1"))
        for name in ("initial_state", "post_soak_state", "stopped_state", "final_state")
    }
    checks["no_unplanned_restart_or_oom"] = all(
        row["RestartCount"] == 0 and row["State"]["OOMKilled"] is False
        for row in api_states.values()
    )
    checks["same_container"] = len({row["Id"] for row in api_states.values()}) == 1
    checks["same_load_start"] = (
        api_states["initial_state"]["State"]["StartedAt"]
        == api_states["post_soak_state"]["State"]["StartedAt"]
    )
    checks["planned_restart_observed"] = (
        api_states["final_state"]["State"]["StartedAt"]
        != api_states["post_soak_state"]["State"]["StartedAt"]
    )
    checks["clean_stop"] = api_states["stopped_state"]["State"]["ExitCode"] == 0
    runtime_ok = []
    for row in api_states.values():
        env = row.get("native_env", {})
        runtime_ok.append(
            row["Image"] == build["image"]
            and row.get("command") == ["python", "scripts/docker_entrypoint.py"]
            and "entrypoint" in row
            and row["entrypoint"] is None
            and env.keys() >= NATIVE_KEYS
            and env.get("MALLOC_ARENA_MAX") == "2"
            and env.get("SEARCHPILOT_DISABLE_THP") == "true"
            and all(
                env.get(key) is None
                for key in ("GLIBC_TUNABLES", "LD_PRELOAD", "PYTHONMALLOC", "PYTHONTRACEMALLOC")
            )
        )
    checks["runtime_config"] = all(runtime_ok)
    requests = harness["requests"]
    checks["business"] = len(requests) == 17 and all(
        row["status"] == "completed" and row["http_status"] == row["expected_status"]
        for row in requests
    )
    by_label = {row["label"]: row for row in requests}
    feedback = [
        by_label[label]["response"].get("event_id")
        for label in ("feedback_create", "feedback_replay", "feedback_after_restart")
    ]
    checks["feedback_same_id"] = bool(feedback[0]) and len(set(feedback)) == 1
    checks["feedback_persisted_once"] = (
        harness["initial_counts"]["feedback_events"] == 0
        and harness["final_counts"]["feedback_events"] == 1
    )
    checks["restart_ready"] = all(harness["restart_ready"]["checks"].get(k) is True for k in CHECKS)
    inputs = read(ROOT / "inputs-sha256.json")
    details["input_mismatch"] = [
        name for name, value in inputs.items() if digest(REPO / name) != value
    ]
    details["source_mismatch"] = [
        name
        for name, value in read(ROOT / "sources-sha256.json").items()
        if digest(REPO / name) != value
    ]
    checks["frozen_inputs_sources"] = (
        not details["input_mismatch"] and not details["source_mismatch"]
    )
    frozen_sources = read(ROOT / "sources-sha256.json")
    expected_container = {
        name: sha
        for name, sha in frozen_sources.items()
        if name.startswith("src/")
        or name
        in {
            "scripts/docker_entrypoint.py",
            "scripts/docker_seed.py",
            "scripts/seed_items.py",
            "scripts/seed_catalog.py",
        }
    }
    checks["container_and_installed_sources"] = harness[
        "container_source_sha256"
    ] == expected_container and harness["imported_source"]["sha256"] == {
        name: sha for name, sha in expected_container.items() if name.startswith("src/searchpilot/")
    }
    checks["query_bytes"] = all(
        digest(folder / name) == build["query_sha256"]
        for name in ("queries.csv", "soak.queries.csv")
    )
    strict = [row for row in load if 0 <= row["elapsed_seconds"] < duration]
    tail20 = (
        window([row for row in load if duration - 1200 <= row["elapsed_seconds"] < duration])
        if duration >= 1200
        else {"available": False, "reason": "dispatch_shorter_than_twenty_minutes"}
    )
    checks["two_hour_memory_stability"] = memory_gate.get("status") == "PASSED"
    groups = [
        {
            key: row[key]
            for key in ("query", "mode", "result_sha256", "ranking_sha256", "model_versions")
        }
        for row in ledger["fingerprints"]["groups"]
    ]
    if evidence_hashes(folder) != input_sha256:
        raise ValueError("Evidence changed during acceptance audit")
    record = {
        "schema_version": 2,
        "input_sha256": input_sha256,
        "case": "final-two-hour",
        "status": "PASSED" if all(checks.values()) else "FAILED",
        "checks": checks,
        "details": details,
        "benchmark_summary": run["summary"],
        "concurrency": bench["config"]["concurrency"],
        "duration_seconds": duration,
        "memory_gate": memory_gate,
        "memory": {
            "phase_load": whole,
            "strict_dispatch": window(strict),
            "last_ten": window(
                [row for row in load if duration - 600 <= row["elapsed_seconds"] < duration]
            ),
            "last_twenty": tail20,
            "recovery": window([row for row in samples if row["phase"] == "recovery"]),
        },
        "windows": [
            {
                "start_seconds": left,
                **window([row for row in strict if left <= row["elapsed_seconds"] < left + 300]),
            }
            for left in range(0, int(duration), 300)
        ],
        "fingerprint_groups": len(groups),
        "semantic_sha256": hashlib.sha256(json.dumps(groups, sort_keys=True).encode()).hexdigest(),
        "group_repeat_histogram": dict(
            Counter(str(g["successful"]) for g in ledger["coverage"]["groups"])
        ),
        "inside_load_samples": len(strict),
        "outside_load_samples": len(load) - len(strict),
        "sample_phase_counts": dict(Counter(row["phase"] for row in samples)),
        "limitations": [
            "Fixed query fixture and closed-loop client concurrency; "
            "not server execution concurrency or capacity SLA.",
            "Ten-second sampled memory and finite duration do not prove absence of leaks.",
        ],
    }
    return record


def compare_failed_reports(saved_acceptance, saved_memory, current_acceptance, current_memory):
    require(saved_memory == current_memory, "Saved stability report differs from raw replay")
    require(saved_acceptance == current_acceptance, "Saved acceptance differs from full replay")
    require(
        current_acceptance["status"] == current_memory["status"] == "FAILED",
        "Baseline did not fail original fixed gates",
    )
    require(current_memory.get("errors") == [], "Incomplete/invalid stability evidence")
    gates = current_memory.get("gates", {})
    require(set(gates) == {"rss", "anonymous"}, "Missing original RSS/Anonymous gates")
    failed_memory = [
        metric + "." + name
        for metric, row in gates.items()
        for name, ok in row["checks"].items()
        if ok is False
    ]
    require(failed_memory, "No original fixed memory gate actually failed")
    checks = current_acceptance["checks"]
    require(all(type(ok) is bool for ok in checks.values()), "Invalid acceptance check type")
    failed_checks = [name for name, ok in checks.items() if not ok]
    require("two_hour_memory_stability" in failed_checks, "Memory failure hidden")
    return failed_checks, failed_memory


def reconciliation():
    require(
        digest(ROOT / "audit_case.py") == ORIGINAL_AUDITOR_SHA256,
        "Original auditor changed; copied replay must be reviewed again",
    )
    folder = ROOT / "final-two-hour"
    binding = raw.evidence_hashes(folder)
    bench = read(folder / "soak.json")
    samples = raw.read_jsonl(folder / "samples.jsonl")
    current_memory = audit_memory(bench, samples, duration_seconds=7200, stable_after_seconds=3600)
    current_memory["inputs"] = {
        "bench_sha256": digest(folder / "soak.json"),
        "samples_sha256": digest(folder / "samples.jsonl"),
    }
    current_acceptance = recompute_acceptance(folder, current_memory)
    saved_acceptance, saved_memory = (
        read(folder / "acceptance.json"),
        read(folder / "stability.json"),
    )
    failures, memory_failures = compare_failed_reports(
        saved_acceptance, saved_memory, current_acceptance, current_memory
    )
    require(saved_acceptance["input_sha256"] == binding, "Acceptance raw binding differs")
    summary = read(folder / "summary.json")
    launcher = read(ROOT / "final-two-hour-launcher.json")
    build = read(ROOT / "build-summary.json")
    require(summary["config"]["project"] == PROJECT, "Wrong failed project")
    require(
        summary["image"] == launcher["image"] == build["image"], "Failed baseline image differs"
    )
    require(
        launcher["status"] == "COMPLETED"
        and launcher["exit_code"] == 0
        and launcher["observer_stopped"] is True,
        "Normal collection did not end cleanly",
    )
    expected = {row["Name"].lstrip("/"): row["Id"] for row in summary["final_state"]}
    require(
        set(expected) == {PROJECT + "-api-1", PROJECT + "-db-1"}
        and all(isinstance(value, str) and value for value in expected.values()),
        "Final container identity incomplete",
    )
    diagnostic_gates = {
        "original": packaging.validate_diagnostics(),
        "encoder": packaging.validate_encoder_controls(),
        "native": packaging.validate_native_controls(),
    }
    names = (
        "final-two-hour/acceptance.json",
        "final-two-hour/stability.json",
        "final-two-hour-launcher.json",
        "comparison-failed.json",
        "encoder-comparison-failed.json",
        "native-thread-comparison-rejected.json",
        "reconcile_failed_normal.py",
        "package_failed_baseline.py",
        "cleanup_failed_normal.py",
    )
    hashes = {name: digest(ROOT / name) for name in names}
    require(raw.evidence_hashes(folder) == binding, "Evidence changed during failed audit")
    return {
        "schema_version": 1,
        "status": "FAILED_STABILITY_RECONCILED",
        "evidence_status": "RECONCILED",
        "production_acceptance": False,
        "case": "final-two-hour",
        "project": PROJECT,
        "image": build["image"],
        "failed_checks": failures,
        "failed_memory_checks": memory_failures,
        "acceptance_status": "FAILED",
        "stability_status": "FAILED",
        "workload_status": "PASSED",
        "collection_status": "COMPLETED",
        "expected_containers": expected,
        "diagnostics": diagnostic_gates,
        "input_sha256": binding,
        "root_input_sha256": hashes,
        "recomputed_original_acceptance": current_acceptance,
        "limitations": [
            "Baseline rejected under original fixed gates; not production acceptance.",
            "Historical diagnostic failures and rejected candidates remain failures.",
            "Sampled finite evidence does not prove a memory leak or its cause.",
        ],
    }


def validate_saved():
    saved = read(OUTPUT)
    current = reconciliation()
    require(saved == current, "Saved failed-baseline reconciliation is stale or incomplete")
    return {
        "status": current["status"],
        "production_acceptance": False,
        "failed_checks": current["failed_checks"],
        "failed_memory_checks": current["failed_memory_checks"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check", action="store_true", help="Verify existing reconciliation, write nothing"
    )
    args = parser.parse_args()
    if args.check:
        print(json.dumps(validate_saved()))
        return 0
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump({"status": "RUNNING", "production_acceptance": False}, stream)
    try:
        result = reconciliation()
    except BaseException as exc:
        OUTPUT.write_text(
            json.dumps(
                {
                    "status": "UNRECONCILED",
                    "production_acceptance": False,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        raise
    OUTPUT.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "status",
                    "production_acceptance",
                    "failed_checks",
                    "failed_memory_checks",
                )
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
