"""Independent, synthetic offline counterchecks; never start Docker, HTTP or load."""

from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
from scripts.audit_memory_stability import audit  # noqa: E402

EPOCH = datetime(2026, 10, 26, 1, 2, 3, tzinfo=UTC)
MIB = 1 << 20


def stamp(seconds):
    return (EPOCH + timedelta(seconds=seconds)).isoformat()


def fresh():
    # Independent construction: 2-second requests, samples offset four seconds.
    requests = [
        {"dispatched_ms": second * 1000, "elapsed_ms": 2000}
        for second in range(0, 7200, 2)
    ]
    bench = {
        "status": "COMPLETED",
        "config": {"duration_seconds": 7200},
        "runs": [{
            "mode": "mixed", "dispatch_window_seconds": 7200,
            "started_at": stamp(0), "finished_at": stamp(7200),
            "last_dispatch_seconds": 7198,
            "summary": {"total": len(requests), "elapsed_seconds": 7200},
            "requests": requests,
        }],
    }
    samples = []
    for second in range(4, 7200, 10):
        sources = {
            "stat": {"pid": 1, "start_time_ticks": 778899},
            "stat_after": {"pid": 1, "start_time_ticks": 778899},
            "smaps_rollup": {
                "Rss_bytes": 1536*MIB, "Anonymous_bytes": 1024*MIB,
                "Pss_bytes": 1400*MIB,
            },
            "status": {"VmData_bytes": 4096*MIB},
            "cgroup_memory_current": {"bytes": 1600*MIB},
        }
        samples.append({
            "at": stamp(second), "phase": "load",
            "server": {
                "at": stamp(second+0.25), "pid": 1, "available": True,
                "identity_consistent": True,
                "sources": {key: {"available": True, "data": value}
                            for key, value in sources.items()},
            },
        })
    return bench, samples


def smaps(row):
    return row["server"]["sources"]["smaps_rollup"]["data"]


def change(name, bench, samples):
    run = bench["runs"][0]
    if name == "one_hour_claimed_two":
        run["finished_at"] = stamp(3600)
        run["requests"] = run["requests"][:1800]
        run["summary"]["total"] = 1800
        run["last_dispatch_seconds"] = 3598
        samples[:] = samples[:360]
    elif name == "clock_claim_only":
        run["requests"] = run["requests"][:1800]
        run["summary"]["total"] = 1800
        run["last_dispatch_seconds"] = 3598
    elif name == "continuous_steps_flat_last_twenty":
        for index, row in enumerate(samples):
            smaps(row)["Rss_bytes"] += min(6, max(0, (index-360)//40))*MIB
    elif name == "rss_growth_pss_flat":
        for index, row in enumerate(samples):
            smaps(row)["Rss_bytes"] += max(0, index-360)*MIB/30
    elif name == "anonymous_growth_rss_pss_flat":
        for index, row in enumerate(samples):
            smaps(row)["Anonymous_bytes"] += max(0, index-360)*MIB/30
    elif name == "pss_growth_rss_anonymous_flat":
        for index, row in enumerate(samples):
            smaps(row)["Pss_bytes"] += index*MIB
    elif name == "pss_present_rss_missing":
        smaps(samples[415]).pop("Rss_bytes")
    elif name == "identity_changed_then_restored":
        for source in ("stat", "stat_after"):
            samples[415]["server"]["sources"][source]["data"]["start_time_ticks"] += 1
    elif name == "identity_missing":
        samples[415]["server"].pop("identity_consistent")
    elif name == "out_of_order":
        samples[415], samples[416] = samples[416], samples[415]
    elif name == "invalid_timestamp":
        samples[415]["at"] = "not-a-date"
    elif name == "phase_hidden_bad_metric":
        samples[415]["phase"] = "recovery"
        smaps(samples[415])["Rss_bytes"] = None
    elif name == "deleted_sample_gap":
        del samples[415]
    elif name == "missing_descriptive_is_not_zero":
        for row in samples:
            smaps(row).pop("Pss_bytes")
    elif name == "delayed_server_observation":
        samples[415]["server"]["at"] = stamp(4154+16)
    elif name == "sparse_dispatch_scope_boundary":
        run["requests"] = [run["requests"][0], run["requests"][-1]]
        run["summary"]["total"] = 2


def main():
    output = ROOT / "audit-counterchecks.json"
    if output.exists():
        raise FileExistsError(output)
    cases = []
    passes = {
        "positive_offset_samples", "pss_growth_rss_anonymous_flat",
        "missing_descriptive_is_not_zero", "sparse_dispatch_scope_boundary",
    }
    names = [
        "positive_offset_samples", "one_hour_claimed_two", "clock_claim_only",
        "continuous_steps_flat_last_twenty", "rss_growth_pss_flat",
        "anonymous_growth_rss_pss_flat", "pss_growth_rss_anonymous_flat",
        "pss_present_rss_missing", "identity_changed_then_restored", "identity_missing",
        "out_of_order", "invalid_timestamp", "phase_hidden_bad_metric",
        "deleted_sample_gap", "missing_descriptive_is_not_zero",
        "delayed_server_observation", "sparse_dispatch_scope_boundary",
    ]
    for name in names:
        bench, samples = fresh()
        change(name, bench, samples)
        before = copy.deepcopy(samples)
        start = time.perf_counter()
        result = audit(bench, samples)
        expected = "PASSED" if name in passes else "FAILED"
        row = {
            "name": name, "expected": expected, "actual": result["status"],
            "seconds": time.perf_counter()-start, "errors": result["errors"],
            "gates": result.get("gates"), "input_unchanged": samples == before,
        }
        if "windows" in result:
            row["last_twenty_rss_growth"] = result["windows"]["last_twenty"]["metrics"]["rss"].get("growth_mib")
            row["pss_stable"] = result["windows"]["stable"]["metrics"]["pss"]
        row["check_passed"] = result["status"] == expected and samples == before
        cases.append(row)
    # Exercise the real CLI on fresh files, then an old passing output and a bad JSONL.
    with tempfile.TemporaryDirectory(prefix="audit-countercheck-", dir=REPO/".tmp") as temp:
        folder = Path(temp)
        bench, samples = fresh()
        bench_path, samples_path = folder/"bench.json", folder/"samples.jsonl"
        bench_path.write_text(json.dumps(bench), encoding="utf-8")
        samples_path.write_text("\n".join(json.dumps(row) for row in samples), encoding="utf-8")
        command = [sys.executable, "-m", "scripts.audit_memory_stability",
                   "--bench", str(bench_path), "--samples", str(samples_path),
                   "--out", str(folder/"audit.json")]
        first = subprocess.run(command, cwd=REPO, capture_output=True, timeout=20)
        raw = (folder/"audit.json").read_bytes()
        report = json.loads(raw)
        hashes = {"bench_sha256": hashlib.sha256(bench_path.read_bytes()).hexdigest(),
                  "samples_sha256": hashlib.sha256(samples_path.read_bytes()).hexdigest()}
        second = subprocess.run(command, cwd=REPO, capture_output=True, timeout=20)
        samples_path.write_text(samples_path.read_text(encoding="utf-8")+"\n{}", encoding="utf-8")
        command[-1] = str(folder/"bad.json")
        third = subprocess.run(command, cwd=REPO, capture_output=True, timeout=20)
        cli = {
            "fresh_exit": first.returncode, "fresh_status": report["status"],
            "input_hashes_match": report["inputs"] == hashes,
            "existing_pass_exit": second.returncode,
            "existing_pass_preserved": (folder/"audit.json").read_bytes() == raw,
            "malformed_extra_sample_exit": third.returncode,
            "malformed_extra_sample_status": json.loads((folder/"bad.json").read_text())["status"],
        }
        cli["check_passed"] = (first.returncode == 0 and report["status"] == "PASSED"
            and report["inputs"] == hashes and second.returncode != 0
            and cli["existing_pass_preserved"] and third.returncode == 1
            and cli["malformed_extra_sample_status"] == "FAILED")
    result = {
        "status": "PASSED" if all(row["check_passed"] for row in cases) and cli["check_passed"] else "FAILED",
        "scope": "independent synthetic counterchecks, not real duration/load evidence",
        "generated_at": datetime.now(UTC).isoformat(),
        "source_sha256": {name: hashlib.sha256((REPO/name).read_bytes()).hexdigest()
                          for name in ("scripts/audit_memory_stability.py",
                                       "artifacts/extended-memory-2026-10-26/audit_case.py")},
        "cases": cases, "cli": cli,
        "boundary": "Resource-only audit accepts sparse dispatches; strict ledger and 5200 groups x 12 coverage remain mandatory in overall audit.",
    }
    with output.open("x", encoding="utf-8") as sink:
        json.dump(result, sink, indent=2, allow_nan=False)
    print(json.dumps({"status": result["status"], "cases": len(cases), "cli": cli}))
    return int(result["status"] != "PASSED")


if __name__ == "__main__":
    raise SystemExit(main())
