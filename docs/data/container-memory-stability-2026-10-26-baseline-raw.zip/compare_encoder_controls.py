"""Offline matched encoder controls; protocol PASSED never asserts treatment efficacy.

Reuses the base diagnostic auditor without changing its source. The base-driver copy
is provenance only; actual derived-driver, patch, runtime and counter identities are
checked separately. --self-test uses toy structures and writes nothing.
"""

from __future__ import annotations

import argparse
import copy
import difflib
import hashlib
import json
import math
import re
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(ROOT))
import compare_diagnostics as base  # noqa: E402

CASES = {"diagnostic-encoder32-01": 32, "diagnostic-encoder2-01": 2}
TARGET = "/app/diagnostic/encoder_concurrency_ablation.py"
SOURCE_KEY = "src/searchpilot/search/vector_index.py"
END_LABELS = ("after_20800", "idle", "gc", "trim")
INTEGER_COUNTERS = (
    "calls_started",
    "calls_entered",
    "calls_completed",
    "errors",
    "active",
    "peak_active",
    "waiting",
    "peak_waiting",
)
TIMES = (
    "wait_seconds_total",
    "wait_seconds_max",
    "execution_seconds_total",
    "execution_seconds_max",
)
MONOTONIC = tuple(key for key in INTEGER_COUNTERS if key not in ("active", "waiting")) + TIMES


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def local_path(base_path, relative):
    require(
        isinstance(relative, str)
        and not Path(relative).is_absolute()
        and ".." not in Path(relative).parts,
        "Unsafe evidence filename",
    )
    path = base_path / relative
    require(path.resolve().is_relative_to(base_path.resolve()), "Evidence path escaped root")
    for part in (path, *path.parents):
        require(not part.is_symlink() and not part.is_junction(), "Linked evidence path")
        if part == base_path:
            break
    require(
        not any(part.lower().startswith(".env") for part in Path(relative).parts),
        "Private environment reads are prohibited",
    )
    return path


def command(limit):
    require(type(limit) is int and limit in (2, 32), "Unplanned encoder limit")
    return [
        "python",
        "-c",
        (
            "import ctypes;c=ctypes.CDLL(None,use_errno=True);"
            "r=c.prctl(41,1,0,0,0);assert r==0,ctypes.get_errno();"
            "assert c.prctl(42,0,0,0,0)==1;"
            "import sys;sys.path.insert(0,'/app/diagnostic');"
            "from encoder_concurrency_ablation import install;install("
            + str(limit)
            + ");from scripts.diagnose_allocator import main;main()"
        ),
    ]


def host_path(value):
    require(isinstance(value, str), "Missing host mount path")
    value = value.replace("\\", "/")
    for prefix in ("/run/desktop/mnt/host/", "/host_mnt/"):
        if value.startswith(prefix):
            tail = value[len(prefix) :]
            require(re.match(r"^[A-Za-z]/", tail), "Unexpected Docker Desktop mount path")
            value = tail[0] + ":" + tail[1:]
            break
    require(re.match(r"^[A-Za-z]:/", value), "Expected explicit Windows host mount path")
    require(".." not in value.split("/"), "Parent segment in mount path")
    return value.casefold().rstrip("/")


def mount_map(rows):
    require(isinstance(rows, list), "Missing diagnostic mounts")
    result = {}
    for row in rows:
        require(row.get("Type") == "bind" and row.get("RW") is False, "Writable/nonbind mount")
        destination = row["Destination"]
        require(destination not in result, "Duplicate mount target")
        result[destination] = host_path(row["Source"])
    return result


def check_encoder(report, limit, patch_sha, original_sha):
    require(report.get("encoder_limit") == limit, "Summary encoder limit differs")
    counters, previous, identity = {}, None, None
    require(
        [row["label"] for row in report["snapshots"]] == list(base.LABELS),
        "Incomplete or reordered encoder snapshots",
    )
    for row in report["snapshots"]:
        label = row["label"]
        native = row["data"].get("snapshot", row["data"])
        stats = native["encoder_concurrency"]
        require(
            type(stats.get("limit")) is int and stats["limit"] == limit, "Runtime limit differs"
        )
        for key in INTEGER_COUNTERS:
            require(
                type(stats.get(key)) is int and stats[key] >= 0, "Invalid encoder counter: " + key
            )
        for key in TIMES:
            value = stats.get(key)
            require(
                type(value) in (int, float) and math.isfinite(value) and value >= 0,
                "Invalid encoder timing: " + key,
            )
        require(stats["errors"] == 0, "Encoder exception observed")
        require(
            stats["calls_started"] - stats["calls_entered"] == stats["waiting"]
            and stats["calls_entered"] - stats["calls_completed"] == stats["active"],
            "Encoder call accounting does not reconcile",
        )
        require(
            stats["active"] <= stats["peak_active"] <= limit
            and stats["waiting"] <= stats["peak_waiting"],
            "Encoder peak exceeds limit",
        )
        require(
            stats["wait_seconds_max"] <= stats["wait_seconds_total"] + 1e-9
            and stats["execution_seconds_max"] <= stats["execution_seconds_total"] + 1e-9,
            "Encoder timing aggregate mismatch",
        )
        require(
            stats["patch_sha256"] == patch_sha
            and stats["original_source_sha256"] == original_sha
            and stats["original_module"] == "searchpilot.search.vector_index"
            and stats["original_qualname"] == "SentenceTransformerQueryEncoder.__call__",
            "Wrong patch or original encoder implementation",
        )
        current_identity = {
            key: stats[key]
            for key in (
                "installed_at",
                "patch_sha256",
                "original_source_sha256",
                "original_source_path",
                "original_module",
                "original_qualname",
                "limit",
            )
        }
        require(
            isinstance(stats["original_source_path"], str)
            and stats["original_source_path"].endswith("/searchpilot/search/vector_index.py"),
            "Unexpected original encoder source path",
        )
        require(
            base.timestamp(stats["installed_at"]) <= base.timestamp(row["started_at"]),
            "Patch installed after observation started",
        )
        if identity is None:
            identity = current_identity
        require(identity == current_identity, "Patch runtime identity changed")
        if previous is not None:
            require(all(stats[key] >= previous[key] for key in MONOTONIC), "Encoder counters reset")
        if label in ("ready", "warmup", *END_LABELS):
            require(stats["active"] == stats["waiting"] == 0, "Encoder was not drained")
        counters[label] = {key: stats[key] for key in ("limit", *INTEGER_COUNTERS, *TIMES)}
        previous = stats
    warmup = counters["warmup"]
    for label in END_LABELS:
        require(
            all(
                counters[label][key] - warmup[key] == 15600
                for key in ("calls_started", "calls_entered", "calls_completed")
            ),
            "Measured encoder-call denominator is not 15600",
        )
    peak = counters["after_20800"]["peak_active"]
    require(
        peak == 2 if limit == 2 else peak > 2, "Declared parallelism contrast was not exercised"
    )
    return {
        "identity": identity,
        "snapshots": counters,
        "measured_calls": 15600,
        "observed_peak_active": peak,
        "contrast_exercised": True,
        "measured_timing_deltas": {
            key: counters["after_20800"][key] - warmup[key]
            for key in ("wait_seconds_total", "execution_seconds_total")
        },
        "scope": (
            "Bounded aggregate counters. Native/encoder observations are sequential, not atomic."
        ),
    }


def execution_identity(case, report, setup):
    manifest = base.read(case / "execution-manifest.json")
    require(manifest == report["execution_manifest"], "Saved manifest differs from summary")
    limit = report["encoder_limit"]
    require(
        manifest.get("schema_version") == 1
        and manifest.get("variant") == "diagnostic_encoder_semaphore"
        and manifest.get("encoder_limit") == limit
        and manifest.get("actual_entry") == "diagnostic_encoder_case.executed.py"
        and manifest.get("base_copy_role")
        == "diagnostic_case.executed.py is an unexecuted base-protocol copy",
        "Actual derived-driver provenance is missing or ambiguous",
    )
    files = {
        "diagnostic_case.executed.py": "base_driver_sha256",
        "diagnostic_encoder_case.executed.py": "derived_driver_sha256",
        "encoder_concurrency_ablation.executed.py": "patch_sha256",
        "derived-driver.diff": "derived_diff_sha256",
        "override.yml": "base_override_sha256",
        "encoder.override.yml": "encoder_override_sha256",
    }
    hashes = {name: digest(local_path(case, name)) for name in files}
    require(
        all(hashes[name] == manifest[key] for name, key in files.items()),
        "Execution snapshot hash mismatch",
    )
    require(
        manifest["base_driver_sha256"] == setup["helper_sha256"]["diagnostic_case.py"],
        "Base driver differs from setup",
    )
    require(
        manifest["base_driver_sha256"] != manifest["derived_driver_sha256"],
        "Base hash must not masquerade as derived driver",
    )
    expected_diff = "".join(
        difflib.unified_diff(
            (case / "diagnostic_case.executed.py")
            .read_bytes()
            .decode("utf-8")
            .splitlines(keepends=True),
            (case / "diagnostic_encoder_case.executed.py")
            .read_bytes()
            .decode("utf-8")
            .splitlines(keepends=True),
            fromfile="diagnostic_case.py (frozen base)",
            tofile="diagnostic_encoder_case.py (actual driver)",
        )
    )
    require(
        (case / "derived-driver.diff").read_bytes()
        in {
            expected_diff.encode("utf-8"),
            expected_diff.replace("\n", "\r\n").encode("utf-8"),
        },
        "Recorded driver diff does not match actual base and derived source",
    )
    for name, key in (
        ("diagnostic_encoder_case.py", "derived_driver_sha256"),
        ("encoder_concurrency_ablation.py", "patch_sha256"),
    ):
        require(digest(local_path(ROOT, name)) == manifest[key], "Actual helper changed: " + name)
    expected_command = command(limit)
    patch_copy = case / "encoder_concurrency_ablation.executed.py"
    require(
        manifest["expected_command"] == expected_command
        and manifest["patch_target"] == TARGET
        and host_path(manifest["patch_host_path"]) == host_path(str(patch_copy)),
        "Manifest does not declare the exact expected patch command/mount",
    )
    override = base.read(case / "encoder.override.yml")
    require(
        override
        == {
            "services": {
                "api": {
                    "command": expected_command,
                    "volumes": [
                        {
                            "type": "bind",
                            "source": str(patch_copy),
                            "target": TARGET,
                            "read_only": True,
                        }
                    ],
                }
            }
        },
        "Unexpected factor in encoder override",
    )
    base_override = base.read(case / "override.yml")
    api = base_override["services"]["api"]
    require(
        set(base_override) == {"services"}
        and set(base_override["services"]) == {"api"}
        and set(api) == {"environment", "command", "volumes"},
        "Unexpected base override keys",
    )
    require(api["environment"] == report["process_native_environment"], "Base environment differs")
    expected_mounts = {TARGET: host_path(str(patch_copy))}
    require(len(api["volumes"]) == 2, "Unexpected base diagnostic mounts")
    for name in ("diagnose_allocator.py", "soak_memory.py"):
        target = "/app/scripts/" + name
        saved = ROOT / "setup" / (Path(name).stem + ".executed.py")
        require(
            {"type": "bind", "source": str(saved), "target": target, "read_only": True}
            in api["volumes"],
            "Base diagnostic mount differs",
        )
        expected_mounts[target] = host_path(str(saved))
    for field in ("container", "final_container"):
        container = report[field]
        require(
            container["command"] == expected_command
            and container["entrypoint"] is None
            and container["project"] == "sp-memory-diagnostic-20261026"
            and container["Image"] == setup["image"],
            "Wrong runtime identity or command",
        )
        require(
            mount_map(container["diagnostic_mounts"]) == expected_mounts, "Wrong runtime mounts"
        )
    runtime = manifest["runtime"]
    require(
        runtime
        == {
            key: report["container"][key]
            for key in ("Id", "Image", "command", "entrypoint", "diagnostic_mounts")
        },
        "Runtime manifest differs",
    )
    hashes["execution-manifest.json"] = digest(case / "execution-manifest.json")
    return manifest, hashes, base_override


def semantic_equality(left, right):
    require(
        len(left) == len(right) == 5200 and left.keys() == right.keys(),
        "Incomplete semantic groups",
    )
    require(all(left[key] == right[key] for key in left), "Cross-case semantic fingerprints differ")


def compare():
    setup = base.read(ROOT / "setup/summary.json")
    require(setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART", "Setup incomplete")
    records, originals, semantics, overrides = [], [], [], []
    for name, limit in CASES.items():
        case = local_path(ROOT, name)
        # The base auditor verifies only the unexecuted base-driver copy. Additional
        # checks below bind the actual derived entrypoint and runtime patch.
        audited, raw, queries, semantic = base.audit_case(name, "expanded1300")
        for field, setup_field in (
            ("input_sha256", "frozen_inputs"),
            ("source_sha256", "local_source_sha256"),
            ("helper_sha256", "helper_sha256"),
            ("executed_script_sha256", "executed_script_sha256"),
            ("public_config_sha256", "public_config_sha256"),
        ):
            require(raw[field] == setup[setup_field], "Setup provenance differs: " + field)
        require(
            len(queries) == raw["query_count"] == 1300
            and raw["encoder_limit"] == limit
            and raw["query_sha256"] == setup["query_sets"]["expanded1300"]["sha256"],
            "Wrong expanded-query control",
        )
        manifest, hashes, override = execution_identity(case, raw, setup)
        audited["encoder"] = check_encoder(
            raw, limit, manifest["patch_sha256"], raw["source_sha256"][SOURCE_KEY]
        )
        audited["execution_manifest"] = manifest
        audited["input_sha256"].update(hashes)
        records.append(audited)
        originals.append(raw)
        semantics.append(semantic)
        overrides.append(override)
    a, b = originals
    require(
        base.timestamp(a["finished_at"]) <= base.timestamp(b["started_at"]),
        "Controls are not sequential sham then cap2",
    )
    require(
        a["final_container"]["Id"] == b["previous_container"]["Id"]
        and a["container"]["Id"] != b["container"]["Id"],
        "API was not recreated between controls",
    )
    fixed = (
        "query_set",
        "query_sha256",
        "query_count",
        "input_sha256",
        "source_sha256",
        "helper_sha256",
        "executed_script_sha256",
        "public_config_sha256",
        "process_native_environment",
        "requests",
        "concurrency",
        "timeout",
        "limit",
        "idle_seconds",
        "health_period_seconds",
        "checkpoints",
    )
    require(
        all(a[key] == b[key] for key in fixed) and overrides[0] == overrides[1],
        "Unexpected cross-case factor",
    )
    for key in (
        "base_driver_sha256",
        "derived_driver_sha256",
        "patch_sha256",
        "derived_diff_sha256",
        "base_override_sha256",
    ):
        require(
            a["execution_manifest"][key] == b["execution_manifest"][key],
            "Different matched helper: " + key,
        )
    semantic_equality(*semantics)
    for field in ("input_sha256", "source_sha256"):
        require(
            all(digest(local_path(REPO, name)) == expected for name, expected in a[field].items()),
            "Frozen repository evidence changed: " + field,
        )
    for name, expected in a["public_config_sha256"].items():
        path = ROOT / "setup/public-env.txt" if name == ".env.example" else local_path(REPO, name)
        require(digest(path) == expected, "Public configuration changed: " + name)
    differences = []
    for left, right in (
        ("warmup", "after_20800"),
        ("after_400", "after_20800"),
        ("after_10400", "after_20800"),
        ("after_15600", "after_20800"),
        ("after_20800", "idle"),
        ("idle", "gc"),
        ("gc", "trim"),
    ):
        row = {"from": left, "to": right}
        for record in records:
            x, y = record["snapshots"][left], record["snapshots"][right]
            row[record["case"]] = {
                "process_rollup_delta_bytes": base.delta(
                    x["process_rollup_bytes"], y["process_rollup_bytes"]
                ),
                "mallinfo2_delta": base.delta(x["mallinfo2"], y["mallinfo2"]),
                "pymalloc_delta": base.delta(x["pymalloc"], y["pymalloc"]),
                "raw_smaps_delta_bytes": base.delta(
                    x["raw_smaps"]["total_bytes"], y["raw_smaps"]["total_bytes"]
                ),
            }
        differences.append(row)
    return {
        "schema_version": 1,
        "status": "PASSED",
        "status_scope": (
            "matched diagnostic protocol, intervention identity and semantic equivalence only"
        ),
        "case_order": list(CASES),
        "cases": records,
        "cross_case_semantic_groups": 5200,
        "all_result_ranking_model_fingerprints_equal": True,
        "within_case_deltas": differences,
        "changed_factor": (
            "encoder semaphore limit 32 to 2; identical wrapper and counter implementation"
        ),
        "efficacy_verdict": "NOT_AUTOMATICALLY_DETERMINED",
        "auditor_sha256": {
            "compare_encoder_controls.py": digest(Path(__file__)),
            "compare_diagnostics.py": digest(ROOT / "compare_diagnostics.py"),
        },
        "limitations": [
            "Both arms are instrumented diagnostic wrappers, not normal-entrypoint acceptance.",
            "Sequential execution, wall-clock duration and measured background differ; "
            "no statistical throughput causality.",
            "Encoder limiting changes inference, queueing and overlap downstream; "
            "it does not identify a library allocation owner.",
            "Native/encoder/smaps observations are sequential, non-atomic "
            "and have overlapping scopes; never sum them.",
            "Sham observed peak is reported, not forced to 32. Cap2 must actually reach 2.",
            "Protocol PASSED does not select a fix. Production change requires separate approval "
            "and full normal 7200-second validation.",
        ],
    }


def self_test():
    def toy(limit):
        snapshots = []
        calls = [1, 13, 313, 3913, 7813, 11713, 15613, 15613, 15613, 15613]
        for index, (label, count) in enumerate(zip(base.LABELS, calls, strict=True)):
            stats = {
                "limit": limit,
                "calls_started": count,
                "calls_entered": count,
                "calls_completed": count,
                "errors": 0,
                "active": 0,
                "waiting": 0,
                "peak_active": 1 if index < 2 else min(limit, 3),
                "peak_waiting": 1,
                "wait_seconds_total": count * 0.01,
                "wait_seconds_max": 0.01,
                "execution_seconds_total": count * 0.1,
                "execution_seconds_max": 0.1,
                "patch_sha256": "a" * 64,
                "original_source_sha256": "b" * 64,
                "original_module": "searchpilot.search.vector_index",
                "original_qualname": "SentenceTransformerQueryEncoder.__call__",
                "original_source_path": "/app/src/searchpilot/search/vector_index.py",
                "installed_at": "2026-10-26T00:00:00+00:00",
            }
            snapshots.append(
                {
                    "label": label,
                    "started_at": "2026-10-26T01:00:00+00:00",
                    "data": {"encoder_concurrency": stats},
                }
            )
        return {"encoder_limit": limit, "snapshots": snapshots}

    def run(report, limit=2):
        return check_encoder(report, limit, "a" * 64, "b" * 64)

    require(run(toy(2))["measured_calls"] == 15600, "Positive cap2 toy failed")
    require(run(toy(32), 32)["observed_peak_active"] == 3, "Sham peak was forced to 32")
    rejected = []
    for key, bad in (
        ("calls_started", 15612),
        ("calls_completed", True),
        ("errors", 1),
        ("peak_active", 3),
        ("active", 1),
        ("waiting", 1),
        ("patch_sha256", "c" * 64),
        ("original_source_sha256", "c" * 64),
        ("wait_seconds_total", float("nan")),
        ("installed_at", "2026-10-27T00:00:00+00:00"),
        ("limit", 32),
    ):
        report = toy(2)
        report["snapshots"][6]["data"]["encoder_concurrency"][key] = bad
        try:
            run(report)
        except ValueError:
            rejected.append(key)
        else:
            raise AssertionError("Counterexample passed: " + key)
    report = toy(2)
    report["snapshots"].pop(5)
    try:
        run(report)
    except ValueError:
        rejected.append("missing_checkpoint")
    else:
        raise AssertionError("Missing checkpoint passed")
    left = {(str(index), "vector"): ("a", "b", "model", 10) for index in range(5200)}
    semantic_equality(left, copy.deepcopy(left))
    changed = copy.deepcopy(left)
    changed[("4199", "vector")] = ("a", "b", "different-model", 10)
    try:
        semantic_equality(left, changed)
    except ValueError:
        rejected.append("one_of_5200_models_changed")
    else:
        raise AssertionError("Semantic mismatch passed")
    require(
        host_path("E:\\searchPilot\\patch.py")
        == host_path("/run/desktop/mnt/host/e/searchPilot/patch.py"),
        "Docker host mount normalization failed",
    )
    print(
        json.dumps(
            {
                "status": "PASSED",
                "toy_rejections": rejected,
                "positive_cases": [
                    "cap2",
                    "sham_actual_peak_3",
                    "all_5200_semantics",
                    "exact_mount_path",
                ],
                "real_requests": 0,
                "files_written": 0,
            }
        )
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    output = ROOT / "encoder-comparison.json"
    with output.open("x", encoding="utf-8") as sink:
        result = {"status": "RUNNING", "started_at": datetime.now(UTC).isoformat()}
        sink.write(json.dumps(result) + "\n")
    try:
        result = compare()
    except (OSError, ValueError, TypeError, KeyError, AssertionError) as exc:
        result = {
            "status": "FAILED",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "status_scope": "Incomplete/invalid evidence; no efficacy verdict",
        }
    result["finished_at"] = datetime.now(UTC).isoformat()
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(output)}))
    return int(result["status"] != "PASSED")


if __name__ == "__main__":
    raise SystemExit(main())
