"""Offline comparison of completed fixed-count diagnostic cases; never touches services.

Requires exact ledger pairing and input/source identities. Native stats, smaps and
external observations are separate non-atomic measurements, not additive scopes.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from scripts.bench_concurrent import MODES, read_queries, summarize

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
TOTAL, CONCURRENCY = 20800, 32
LABELS = (
    "ready",
    "warmup",
    "after_400",
    "after_5200",
    "after_10400",
    "after_15600",
    "after_20800",
    "idle",
    "gc",
    "trim",
)
METRICS = (
    "Rss",
    "Pss",
    "Anonymous",
    "Private_Clean",
    "Shared_Clean",
    "Private_Dirty",
    "Shared_Dirty",
    "AnonHugePages",
    "Swap",
)
HEADER = re.compile(r"^([0-9a-f]+)-([0-9a-f]+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)\s*(.*)$")
FIELD = re.compile(r"^([A-Za-z_]+):\s+(\d+)\s+kB$")
CHECKS = ("search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def timestamp(value):
    result = datetime.fromisoformat(value)
    require(result.tzinfo is not None, "Timestamp must include timezone")
    return result


def available(envelope, label):
    require(envelope.get("available") is True, "Unavailable observation: " + label)
    return envelope["data"]


def source(process, name):
    return available(process["sources"][name], name)


def process_identity(process):
    require(
        process.get("available") is True and process.get("identity_consistent") is True,
        "Unavailable or inconsistent process sample",
    )
    before, after = source(process, "stat"), source(process, "stat_after")
    require(process["pid"] == before["pid"] == after["pid"] == 1, "Not PID1")
    require(before["start_time_ticks"] == after["start_time_ticks"], "PID changed during sampling")
    return before["start_time_ticks"]


def ledger(case, report, queries):
    active, seen_pending, seen_result = {}, set(), set()
    measured, warmup, issue_sequence = [], [], []
    groups, repeats = defaultdict(set), Counter()
    peak, events = 0, 0
    previous_at = None
    path = case / "requests.jsonl"
    for line in path.open(encoding="utf-8"):
        event = json.loads(line)
        events += 1
        event_at = timestamp(event["at"])
        require(previous_at is None or event_at >= previous_at, "Ledger time moved backward")
        previous_at = event_at
        kind, rid = event["event"], event["request_id"]
        require(isinstance(rid, str) and rid, "Invalid request ID")
        if kind == "pending":
            require(
                rid not in seen_pending and rid not in seen_result, "Duplicate/out-of-order pending"
            )
            seen_pending.add(rid)
            active[rid] = event
            peak = max(peak, len(active))
            require(peak <= CONCURRENCY, "Client in-flight exceeds c32")
            index = event["index"]
            require(type(index) is int and index >= 0, "Noninteger request index")
            if event["phase"] == "measured":
                require(index == len(issue_sequence), "Measured index/order mismatch")
                require(
                    event["mode"] == MODES[index % len(MODES)]
                    and event["query"] == queries[(index // len(MODES)) % len(queries)],
                    "Measured query/mode order mismatch",
                )
                offset = event.get("dispatched_ms")
                require(
                    type(offset) in (int, float)
                    and math.isfinite(offset)
                    and 0 <= offset <= report["load_seconds"] * 1000,
                    "Invalid dispatch offset",
                )
                issue_sequence.append((event["query"], event["mode"]))
            else:
                require(
                    event["phase"] == "warmup" and 0 <= index < 16, "Invalid warmup phase/index"
                )
                require(
                    event["mode"] == MODES[index // 4] and event["query"] == queries[index % 4],
                    "Warmup workload mismatch",
                )
        elif kind == "result":
            require(
                rid in active and rid not in seen_result, "Orphan/duplicate/out-of-order result"
            )
            pending = active.pop(rid)
            seen_result.add(rid)
            require(
                all(
                    pending.get(k) == event.get(k)
                    for k in ("index", "phase", "mode", "query", "dispatched_ms")
                ),
                "Pair mismatch",
            )
            require(
                event.get("outcome") == "success"
                and event.get("status_code") == 200
                and type(event.get("result_count")) is int
                and 0 < event["result_count"] <= 10,
                "Failed/empty/invalid result",
            )
            require(
                type(event.get("elapsed_ms")) in (float, int)
                and math.isfinite(event["elapsed_ms"])
                and event["elapsed_ms"] >= 0,
                "Invalid measured latency",
            )
            require(
                all(
                    isinstance(event.get(k), str) and re.fullmatch(r"[0-9a-f]{64}", event[k])
                    for k in ("result_sha256", "ranking_sha256")
                ),
                "Invalid result fingerprint",
            )
            require(
                isinstance(event.get("model_version"), str) and event["model_version"],
                "Missing model version",
            )
            key = (event["query"], event["mode"])
            groups[key].add(
                (
                    event["result_sha256"],
                    event["ranking_sha256"],
                    event["model_version"],
                    event["result_count"],
                )
            )
            if event["phase"] == "measured":
                measured.append(event)
                repeats[key] += 1
            else:
                warmup.append(event)
        else:
            raise ValueError("Unknown ledger event kind")
    expected = {(query, mode) for query in queries for mode in MODES}
    require(
        not active and seen_pending == seen_result and len(measured) == TOTAL and len(warmup) == 16,
        "Incomplete unique paired ledger",
    )
    require({row["index"] for row in warmup} == set(range(16)), "Warmup indices incomplete")
    require(
        set(groups) == set(repeats) == expected
        and all(len(value) == 1 for value in groups.values()),
        "Missing or unstable semantic groups",
    )
    require(
        all(value == TOTAL // len(expected) for value in repeats.values()),
        "Unexpected repeat counts",
    )
    require(peak == report["peak_inflight"] == CONCURRENCY, "Observed peak is not configured c32")
    summary = summarize(measured, report["load_seconds"])
    require(summary == report["summary"], "Benchmark summary differs from exact raw ledger")
    canonical = [
        [query, mode, *next(iter(groups[(query, mode)]))] for query, mode in sorted(groups)
    ]
    return {
        "events": events,
        "unique_ids": len(seen_pending),
        "measured": summary,
        "warmup": summarize(warmup, 0),
        "peak_client_inflight": peak,
        "pending_at_end": 0,
        "measured_groups": len(expected),
        "repeat_histogram": dict(Counter(repeats.values())),
        "semantic_sha256": sha(json.dumps(canonical).encode()),
        "issued_sequence_sha256": sha(json.dumps(issue_sequence).encode()),
        "ledger_sha256": sha(path.read_bytes()),
    }, {key: next(iter(value)) for key, value in groups.items()}


def parse_smaps(text):
    mappings, current = {}, None
    for line in text.splitlines():
        header = HEADER.fullmatch(line)
        if header:
            identity = header.groups()
            require(identity not in mappings, "Duplicate VMA identity")
            current = {"identity": identity, "path": identity[-1], "bytes": {}}
            mappings[identity] = current
        elif current is not None:
            field = FIELD.fullmatch(line)
            if field:
                current["bytes"][field[1]] = int(field[2]) * 1024
    require(bool(mappings), "No smaps mappings")
    for mapping in mappings.values():
        require(all(key in mapping["bytes"] for key in METRICS), "Incomplete smaps mapping")
        require(mapping["bytes"]["Rss"] >= mapping["bytes"]["Anonymous"], "Invalid smaps RSS/anon")
    return mappings


def map_totals(mappings):
    totals = {metric: sum(row["bytes"][metric] for row in mappings.values()) for metric in METRICS}
    partitions = {}
    for row in mappings.values():
        path = row["path"]
        category = (
            "file_path"
            if path and not path.startswith("[")
            else "special_bracket"
            if path.startswith("[")
            and path not in ("[heap]", "[stack]")
            and not path.startswith("[anon")
            else "anonymous_or_heap_stack"
        )
        partition = partitions.setdefault(category, {metric: 0 for metric in METRICS})
        for metric in METRICS:
            partition[metric] += row["bytes"][metric]
    require(
        all(
            sum(group[metric] for group in partitions.values()) == totals[metric]
            for metric in METRICS
        ),
        "Backing partitions do not reconcile",
    )
    return {
        "mapping_count": len(mappings),
        "total_bytes": totals,
        "backing_path_partitions_bytes": partitions,
        "rss_minus_anonymous_bytes": totals["Rss"] - totals["Anonymous"],
        "file_path_nonanonymous_resident_bytes": partitions.get("file_path", {}).get("Rss", 0)
        - partitions.get("file_path", {}).get("Anonymous", 0),
        "interpretation": (
            "Anonymous is a page property. File-path RSS can include anonymous COW pages; "
            "RSS-minus-Anonymous also includes special/shared mappings, not only ordinary files. "
            "Clean/dirty and anonymous/backing-path are different axes, not additive scopes."
        ),
    }


def native_snapshot(snapshot):
    data = snapshot["data"].get("snapshot", snapshot["data"])
    process = available(data["process"], "snapshot process")
    identity = process_identity(process)
    external = snapshot["external_process"]
    require(
        process_identity(external) == identity,
        "Snapshot process identity differs across observations",
    )
    require(data["tracemalloc"]["enabled"] is False, "Unexpected tracing")
    mallinfo = available(data["allocator"]["mallinfo2"], "mallinfo2")
    malloc_info = available(data["allocator"]["malloc_info"], "malloc_info")
    xml = ET.fromstring(malloc_info["xml"])
    require(1 <= len(xml.findall("./heap")) <= 2, "glibc heap count exceeds arena2")
    root_values = {}
    for name, xpath in (
        ("system_current_bytes", "./system[@type='current']"),
        ("free_fast_bytes", "./total[@type='fast']"),
        ("free_rest_bytes", "./total[@type='rest']"),
        ("mmap_bytes", "./total[@type='mmap']"),
    ):
        element = xml.find(xpath)
        require(element is not None, "Missing malloc_info root total: " + name)
        root_values[name] = int(element.attrib["size"])
    pymalloc = available(data["pymalloc"], "pymalloc")
    require(not pymalloc["missing_fields"], "Missing pymalloc statistics")
    smaps = source(process, "smaps_rollup")
    require(
        source(process, "status")["THP_enabled"] == 0 and smaps["AnonHugePages_bytes"] == 0,
        "Unexpected THP/huge pages",
    )
    return {
        "pid_start_ticks": identity,
        "label": snapshot["label"],
        "at": snapshot["at"],
        "started_at": snapshot["started_at"],
        "action": snapshot["data"].get("action"),
        "action_result": snapshot["data"].get("result"),
        "trigger": snapshot.get("trigger"),
        "counts_before": snapshot["counts_before"],
        "counts_after": snapshot["counts_after"],
        "atomic": False,
        "mallinfo2": mallinfo,
        "malloc_info_root_totals": root_values,
        "glibc_heap_count": len(xml.findall("./heap")),
        "pymalloc": pymalloc["fields"],
        "python_threads": data["python_threads"],
        "linux_threads": source(external, "status")["Threads"],
        "task_ids": external["task_ids"],
        "process_rollup_bytes": {key: smaps[key + "_bytes"] for key in METRICS},
    }


def delta(before, after):
    require(before.keys() == after.keys(), "Metric schema differs between observations")
    return {key: after[key] - before[key] for key in before}


def compare_maps(before, after):
    partition = {
        name: {metric: 0 for metric in METRICS} for name in ("matched", "added", "removed")
    }
    changes = []
    for identity in before.keys() | after.keys():
        kind = (
            "matched"
            if identity in before and identity in after
            else "added"
            if identity in after
            else "removed"
        )
        values = {
            metric: after.get(identity, {}).get("bytes", {}).get(metric, 0)
            - before.get(identity, {}).get("bytes", {}).get(metric, 0)
            for metric in METRICS
        }
        for metric in METRICS:
            partition[kind][metric] += values[metric]
        changes.append({"change": kind, "identity": identity, "delta_bytes": values})
    totals = delta(map_totals(before)["total_bytes"], map_totals(after)["total_bytes"])
    require(
        all(
            sum(group[metric] for group in partition.values()) == totals[metric]
            for metric in METRICS
        ),
        "VMA delta partition does not reconcile",
    )
    return {
        "total_delta_bytes": totals,
        "partitions_delta_bytes": partition,
        "exact_reconciliation": True,
        "top_increases": sorted(changes, key=lambda row: row["delta_bytes"]["Rss"], reverse=True)[
            :12
        ],
        "top_decreases": sorted(changes, key=lambda row: row["delta_bytes"]["Rss"])[:12],
        "caveat": (
            "Exact address/perms/offset/device/inode/path identity only. "
            "Resizes/splits/merges appear "
            "as removed/added; neither alignment nor identity proves allocator owner or "
            "excludes address reuse."
        ),
    }


def sampled_observations(case, report):
    rows = [json.loads(line) for line in (case / "samples.jsonl").open(encoding="utf-8")]
    load = [row for row in rows if row["phase"] == "load"]
    require(len(load) >= 2, "Missing load samples")
    first = timestamp(report["load_started_at"])
    phase_health, identities, all_tasks, load_threads = {}, set(), set(), []
    loadavg, missing_loadavg = [], 0
    background = {
        "samples": len(rows),
        "stats_missing": 0,
        "other_present_samples": 0,
        "other_distinct_ids": set(),
        "max_other_in_one_sample": 0,
        "unresolved_records": 0,
        "cpu_missing_entries": 0,
        "max_known_other_cpu_percent_sum": 0.0,
    }
    for row in rows:
        phase = phase_health.setdefault(
            row["phase"], {"samples": 0, "live_success": 0, "ready_success": 0}
        )
        phase["samples"] += 1
        for kind in ("live", "ready"):
            good = row[kind].get("available") is True and row[kind].get("status") == 200
            if kind == "ready":
                good = good and all(
                    row[kind].get("body", {}).get("checks", {}).get(k) is True for k in CHECKS
                )
            phase[kind + "_success"] += bool(good)
            if row["phase"] == "load":
                require(good, "Load health failure")
        if row["phase"] in ("load", "idle", "post_load_snapshot"):
            process = row["server"]
            identities.add(process_identity(process))
            all_tasks.update(process["task_ids"])
            require(
                source(process, "status")["THP_enabled"] == 0
                and source(process, "smaps_rollup")["AnonHugePages_bytes"] == 0,
                "Observed THP enabled",
            )
            if row["phase"] == "load":
                load_threads.append(source(process, "status")["Threads"])
        try:
            value = float(row["server"]["host_loadavg"].split()[0])
            require(math.isfinite(value) and value >= 0, "Invalid Linux loadavg")
            loadavg.append(value)
        except (KeyError, ValueError, TypeError, IndexError):
            missing_loadavg += 1
        stats = row["stats"]
        if stats.get("available") is not True:
            background["stats_missing"] += 1
            continue
        others = []
        for item in stats["data"]:
            name, cid = item.get("Name"), item.get("ID")
            if not name or name == "--" or not cid or cid == "--":
                background["unresolved_records"] += 1
                continue
            if name.startswith("sp-memory-diagnostic-20261026-"):
                continue
            others.append(item)
            background["other_distinct_ids"].add(cid)
        background["other_present_samples"] += bool(others)
        background["max_other_in_one_sample"] = max(
            background["max_other_in_one_sample"], len(others)
        )
        cpu = 0.0
        for item in others:
            try:
                raw_cpu = item["CPUPerc"]
                require(isinstance(raw_cpu, str) and raw_cpu.endswith("%"), "Invalid CPU")
                value = float(raw_cpu.removesuffix("%"))
                require(math.isfinite(value) and value >= 0, "Invalid CPU value")
                cpu += value
            except (KeyError, ValueError, TypeError):
                background["cpu_missing_entries"] += 1
        background["max_known_other_cpu_percent_sum"] = max(
            background["max_known_other_cpu_percent_sum"], cpu
        )
    require(len(identities) == 1, "Process identity changed during load/idle")
    seconds = [(timestamp(row["at"]) - first).total_seconds() for row in load]
    gaps = [right - left for left, right in zip(seconds, seconds[1:], strict=False)]
    require(all(gap > 0 for gap in gaps), "Load sample time is not strictly increasing")
    background["other_distinct_ids"] = sorted(background["other_distinct_ids"])
    return {
        "health_by_phase": phase_health,
        "load_coverage": {
            "samples": len(load),
            "first_seconds": seconds[0],
            "last_seconds": seconds[-1],
            "max_gap_seconds": max(gaps),
            "endpoint_gap_seconds": report["load_seconds"] - seconds[-1],
        },
        "pid_start_ticks": next(iter(identities)),
        "observed_task_ids": sorted(all_tasks),
        "task_id_count": len(all_tasks),
        "load_threads_min": min(load_threads),
        "load_threads_max": max(load_threads),
        "background": background,
        "linux_host_loadavg_1m": {
            "minimum": min(loadavg) if loadavg else None,
            "maximum": max(loadavg) if loadavg else None,
            "samples": len(loadavg),
            "missing": missing_loadavg,
        },
        "scope": (
            "Task IDs sampled every ten seconds can miss short-lived threads. Background "
            "covers the whole load/idle/intervention capture, not full Windows host CPU."
        ),
    }


def audit_case(name, expected_set):
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]*", name), "Invalid case directory")
    case = ROOT / name
    report = read(case / "summary.json")
    require(
        report.get("status") == "COMPLETED" and report.get("query_set") == expected_set,
        "Case is incomplete or is the wrong query set: " + name,
    )
    require(
        report["requests"] == TOTAL
        and report["concurrency"] == CONCURRENCY
        and report["limit"] == 10
        and report["timeout"] == 10
        and report["idle_seconds"] == 120
        and report["health_period_seconds"] == 10
        and report["checkpoints"] == [400, 5200, 10400, 15600, 20800],
        "Workload protocol differs",
    )
    require(
        type(report["load_seconds"]) in (int, float)
        and math.isfinite(report["load_seconds"])
        and report["load_seconds"] > 0,
        "Invalid load duration",
    )
    queries, raw = read_queries(case / "queries.csv")
    require(
        len(queries) == (1300 if expected_set == "expanded1300" else 100)
        and sha(raw) == report["query_sha256"],
        "Case query bytes differ",
    )
    require(
        report["container"]["Id"] == report["final_container"]["Id"]
        and report["container"]["Id"] != report["previous_container"]["Id"]
        and report["final_container"]["RestartCount"] == 0
        and report["final_container"]["State"]["OOMKilled"] is False,
        "Container identity/restart issue",
    )
    require(
        report["container"]["native_env"]
        == report["process_native_environment"]
        == report["final_container"]["native_env"],
        "Native environment changed",
    )
    require(
        report["process_native_environment"]
        == {
            "MALLOC_ARENA_MAX": "2",
            "SEARCHPILOT_DISABLE_THP": "true",
            "GLIBC_TUNABLES": None,
            "LD_PRELOAD": None,
            "PYTHONMALLOC": None,
            "PYTHONTRACEMALLOC": None,
        },
        "Native environment differs from the declared policy",
    )
    raw_ledger, semantics = ledger(case, report, queries)
    snapshots = {row["label"]: row for row in report["snapshots"]}
    require(
        list(snapshots) == list(LABELS) and len(report["snapshots"]) == len(LABELS),
        "Checkpoint observations missing/duplicated/out of order",
    )
    require(
        (
            timestamp(snapshots["idle"]["started_at"]) - timestamp(report["idle_started_at"])
        ).total_seconds()
        >= 120,
        "Idle observation started before 120 seconds",
    )
    for label in ("gc", "trim"):
        require(
            snapshots[label]["data"].get("action") == "/" + label,
            "Incorrect diagnostic intervention",
        )
    for left, right in zip(LABELS, LABELS[1:], strict=False):
        require(
            timestamp(snapshots[left]["at"]) <= timestamp(snapshots[right]["started_at"]),
            "Overlapping or reordered snapshots",
        )
    native, mappings, files = {}, {}, {}
    for label in LABELS:
        row = snapshots[label]
        native[label] = native_snapshot(row)
        path = case / ("smaps-" + label + ".txt")
        data = path.read_bytes()
        mappings[label] = parse_smaps(data.decode("utf-8"))
        files[path.name] = sha(data)
        native[label]["raw_smaps"] = map_totals(mappings[label])
        if label.startswith("after_"):
            requested = int(label.split("_")[1])
            require(
                row["trigger"]["completed"] == requested
                and requested
                <= row["counts_before"]["completed"]
                <= row["counts_after"]["completed"]
                <= TOTAL,
                "Checkpoint trigger/actual counters invalid",
            )
        if label in ("after_20800", "idle", "gc", "trim"):
            require(
                row["counts_before"] == row["counts_after"] == {"completed": TOTAL, "inflight": 0},
                "Final/idle/intervention snapshot was not drained",
            )
    require(
        len({row["pid_start_ticks"] for row in native.values()}) == 1,
        "Snapshot process identity changed",
    )
    pairs = list(zip(LABELS, LABELS[1:], strict=False)) + [("after_400", "after_20800")]
    comparisons = []
    for left, right in pairs:
        comparisons.append(
            {
                "from": left,
                "to": right,
                "raw_smaps": compare_maps(mappings[left], mappings[right]),
                "mallinfo2_delta": delta(native[left]["mallinfo2"], native[right]["mallinfo2"]),
                "malloc_info_root_delta": delta(
                    native[left]["malloc_info_root_totals"],
                    native[right]["malloc_info_root_totals"],
                ),
                "pymalloc_delta": delta(native[left]["pymalloc"], native[right]["pymalloc"]),
                "process_rollup_delta_bytes": delta(
                    native[left]["process_rollup_bytes"], native[right]["process_rollup_bytes"]
                ),
            }
        )
    observations = sampled_observations(case, report)
    require(
        observations["pid_start_ticks"] == native["ready"]["pid_start_ticks"],
        "Sampler/snapshot process differs",
    )
    files.update(
        {
            filename: sha((case / filename).read_bytes())
            for filename in (
                "summary.json",
                "requests.jsonl",
                "queries.csv",
                "samples.jsonl",
                "override.yml",
            )
        }
    )
    for source_name, expected in report["executed_script_sha256"].items():
        filename = Path(source_name).stem + ".executed.py"
        require(sha((case / filename).read_bytes()) == expected, "Executed script hash mismatch")
        files[filename] = expected
    driver_hash = sha((case / "diagnostic_case.executed.py").read_bytes())
    require(
        driver_hash == report["helper_sha256"]["diagnostic_case.py"],
        "Executed driver hash mismatch",
    )
    files["diagnostic_case.executed.py"] = driver_hash
    return (
        {
            "case": name,
            "query_set": expected_set,
            "query_sha256": sha(raw),
            "status": "PASSED",
            "ledger": raw_ledger,
            "observations": observations,
            "snapshots": native,
            "within_case_deltas": comparisons,
            "input_sha256": files,
            "load_seconds": report["load_seconds"],
            "started_at": report["started_at"],
            "finished_at": report["finished_at"],
        },
        report,
        queries,
        semantics,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expanded", default="diagnostic-expanded-01")
    parser.add_argument("--original", default="diagnostic-original-01")
    parser.add_argument("--out", type=Path, default=ROOT / "comparison.json")
    args = parser.parse_args()
    output = args.out.resolve()
    require(
        output.parent == ROOT and output.suffix == ".json" and not output.exists(),
        "Use a fresh JSON output directly inside this experiment root",
    )
    setup = read(ROOT / "setup" / "summary.json")
    require(setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART", "Setup incomplete")
    a, a_raw, a_queries, a_sem = audit_case(args.expanded, "expanded1300")
    b, b_raw, b_queries, b_sem = audit_case(args.original, "original100")
    for case_report in (a_raw, b_raw):
        for field, setup_field in (
            ("input_sha256", "frozen_inputs"),
            ("source_sha256", "local_source_sha256"),
            ("helper_sha256", "helper_sha256"),
            ("executed_script_sha256", "executed_script_sha256"),
            ("public_config_sha256", "public_config_sha256"),
        ):
            require(case_report[field] == setup[setup_field], "Setup identity mismatch: " + field)
        require(case_report["container"]["Image"] == setup["image"], "Setup image mismatch")
        query_set = setup["query_sets"][case_report["query_set"]]
        require(case_report["query_sha256"] == query_set["sha256"], "Setup query mismatch")
    require(a_queries[:100] == b_queries, "Expanded fixture does not retain original texts/order")
    require(
        timestamp(a_raw["finished_at"]) <= timestamp(b_raw["started_at"]),
        "Expected sequential A then B",
    )
    require(
        a_raw["final_container"]["Id"] == b_raw["previous_container"]["Id"]
        and a_raw["container"]["Id"] != b_raw["container"]["Id"],
        "API was not force-recreated between cases",
    )
    for field in (
        "input_sha256",
        "source_sha256",
        "executed_script_sha256",
        "helper_sha256",
        "public_config_sha256",
        "process_native_environment",
        "requests",
        "concurrency",
        "timeout",
        "limit",
        "idle_seconds",
    ):
        require(a_raw[field] == b_raw[field], "Unexpected cross-case difference: " + field)
    for field in ("Image", "command", "entrypoint", "project", "native_env"):
        require(
            a_raw["container"][field] == b_raw["container"][field],
            "Container protocol differs: " + field,
        )
    for mapping in (a_raw["input_sha256"], a_raw["source_sha256"], a_raw["public_config_sha256"]):
        require(
            all(sha((REPO / name).read_bytes()) == value for name, value in mapping.items()),
            "Frozen repository input/source/config changed",
        )
    common = {(query, mode) for query in b_queries for mode in MODES}
    require(
        len(common) == 400 and all(a_sem[key] == b_sem[key] for key in common),
        "Common original query/mode fingerprints differ",
    )
    comparison = {
        "schema_version": 1,
        "status": "PASSED",
        "status_scope": (
            "completed diagnostic protocol and evidence accounting; not leak-free proof"
        ),
        "cases": [a, b],
        "common_query_mode_groups": len(common),
        "common_fingerprints_equal": True,
        "case_order": [args.expanded, args.original],
        "factors": {
            "changed": ["query fixture"],
            "fixed": [
                "image",
                "business source",
                "model/data",
                "THP off",
                "arena2",
                "c32",
                "20800 requests",
                "same fresh PG",
            ],
            "confounded_with_fixture": [
                "unique query count",
                "query/token length",
                "characters",
                "retrieval work",
            ],
        },
        "limitations": [
            (
                "No allocation owner follows from VMA address/alignment. File-path RSS can "
                "contain anonymous COW pages."
            ),
            (
                "mallinfo2 used/free and malloc_info root totals have allocator-specific "
                "scopes; do not sum with pymalloc or RSS."
            ),
            (
                "pymalloc allocated blocks measure pooled allocator blocks, not a complete "
                "Python live-object inventory. No tracemalloc was run."
            ),
            (
                "Probe/control allocations are included; native/smaps/task observations are "
                "sequential and non-atomic during continued load."
            ),
            (
                "Final trim reclaim is not identical to incremental workload growth; GC/trim "
                "are diagnostic interventions only."
            ),
            (
                "Only the 400 shared groups must match across fixtures; expanded/original "
                "changes uniqueness and length jointly."
            ),
            (
                "Sequential A/B with different durations and background load does not "
                "establish throughput causality or statistical noninferiority."
            ),
        ],
        "comparator_sha256": sha(Path(__file__).read_bytes()),
    }
    with output.open("x", encoding="utf-8") as sink:
        json.dump(comparison, sink, indent=2)
        sink.write("\n")
    print(
        json.dumps(
            {
                "status": comparison["status"],
                "output": str(output),
                "common_groups": len(common),
                "requests": [c["ledger"]["measured"]["total"] for c in (a, b)],
            }
        )
    )


if __name__ == "__main__":
    main()
