"""Read-only live progress. Partial observations never count as final acceptance."""
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'final-two-hour'

def rows(name):
    with (ROOT / name).open(encoding='utf-8') as stream:
        for line in stream:
            if not line.endswith('\n'):
                break
            yield json.loads(line)

counts = Counter()
groups = Counter()
fingerprints = {}
changed_groups = set()
first = last = None
failures = []
for row in rows('soak.requests.jsonl'):
    if row.get('phase') != 'measured':
        continue
    counts[row['event']] += 1
    if row['event'] == 'pending':
        first = first or row['at']
    else:
        counts[row['outcome']] += 1
        last = row['at']
        if row['outcome'] != 'success':
            failures.append({k: row.get(k) for k in ('index','mode','outcome','elapsed_ms','at')})
        else:
            key = (row['query'], row['mode'])
            groups[key] += 1
            value = tuple(row.get(k) for k in ('result_sha256','ranking_sha256','model_version','result_count'))
            if key in fingerprints and fingerprints[key] != value:
                changed_groups.add(key)
            fingerprints.setdefault(key, value)
samples = list(rows('samples.jsonl'))
load = [r for r in samples if r['phase'] == 'load']
latest = samples[-1]
source_names = set().union(*(set(r.get('server',{}).get('sources',{})) for r in load))
unavailable_sources = Counter(name for r in load for name in source_names
                              if r.get('server',{}).get('sources',{}).get(name,{}).get('available') is not True)
load_times = [datetime.fromisoformat(r['at']).timestamp() for r in load]
def metric(row, name):
    return row.get('server',{}).get('sources',{}).get('smaps_rollup',{}).get('data',{}).get(name)
summary = json.loads((ROOT / 'summary.json').read_text(encoding='utf-8'))
now = datetime.now(timezone.utc)
result = {
    'at': now.isoformat(), 'status': summary['status'],
    'scope': 'partial live observation; not final acceptance',
    'formal_started_at': first,
    'elapsed_minutes': round((now-datetime.fromisoformat(first)).total_seconds()/60,2) if first else None,
    'counts': dict(counts), 'outstanding': counts['pending']-counts['result'],
    'failure_records': failures,
    'successful_groups':len(groups),
    'group_success_min':min(groups.values(), default=0),
    'group_success_max':max(groups.values(), default=0),
    'changed_fingerprint_groups':len(changed_groups),
    'last_result_at': last, 'phase': latest['phase'],
    'last_sample_at': latest['at'],
    'rss_mib': metric(latest,'Rss_bytes')/1048576 if metric(latest,'Rss_bytes') is not None else None,
    'anonymous_mib': metric(latest,'Anonymous_bytes')/1048576 if metric(latest,'Anonymous_bytes') is not None else None,
    'load_samples':len(load),
    'observed_server_source_count':len(source_names),
    'unavailable_load_sources':dict(unavailable_sources),
    'identity_inconsistent_samples':sum(r.get('server',{}).get('identity_consistent') is not True for r in load),
    'maximum_load_sample_gap_seconds':max((b-a for a,b in zip(load_times,load_times[1:])),default=None),
    'bad_load_health':sum(r.get('live',{}).get('status')!=200 or r.get('ready',{}).get('status')!=200 for r in load),
}
print(json.dumps(result))
