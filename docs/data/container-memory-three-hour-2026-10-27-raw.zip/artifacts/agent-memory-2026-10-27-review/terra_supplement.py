"""Independent completion-only evidence completeness supplement; no HTTP or Docker."""

import argparse
import collections
import datetime as dt
import hashlib
import json
import math
import re
from pathlib import Path

DURATION = 10800
MODES = {"bm25", "vector", "hybrid", "ltr"}
PROJECT = "sp-agent-memory-20261027"
EVENT_KEYS = {"low", "high", "max", "oom", "oom_kill", "oom_group_kill"}


def need(value, message):
    if not value:
        raise ValueError(message)


def number(value, minimum=0):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum


def stamp(value):
    value = dt.datetime.fromisoformat(value)
    need(value.tzinfo is not None, "timestamp lacks timezone")
    return value.timestamp()


def formal(rows, start, observer=False):
    result = []
    for row in rows:
        t = stamp(row["pid1_runtime"]["started_at"] if observer else row["at"]) - start
        if 0 <= t < DURATION:
            result.append((t, row))
    ts = [t for t, _ in result]
    need(
        len(ts) >= 1078
        and ts[0] <= 10
        and ts[-1] >= DURATION - 10
        and all(0 < b - a <= 15 for a, b in zip(ts, ts[1:])),
        "formal coverage incomplete",
    )
    return result


def container_stats(record, expected, *, allow_extra=False):
    need(
        record.get("available") is True and isinstance(record.get("data"), list),
        "stats unavailable",
    )
    rows = record["data"]
    need(all(isinstance(x, dict) for x in rows), "invalid container entry")
    names = [x.get("Name") for x in rows]
    ids = [x.get("ID") for x in rows]
    need(all(isinstance(name, str) and name for name in names), "container name missing")
    need(
        all(isinstance(ident, str) and re.fullmatch(r"[0-9a-f]{12,64}", ident) for ident in ids),
        "container ID missing",
    )
    need(len(set(names)) == len(names), "duplicate container name")
    need(
        all(not (a.startswith(b) or b.startswith(a)) for i, a in enumerate(ids) for b in ids[i + 1:]),
        "duplicate container ID",
    )
    need(set(expected) <= set(names) and (allow_extra or set(names) == set(expected)),
         "container stats membership")
    for x in rows:
        ident = x["ID"]
        if x["Name"] in expected:
            need(expected[x["Name"]].startswith(ident), "container ID mismatch")
        for field in ("CPUPerc", "MemPerc"):
            text = x.get(field)
            need(
                isinstance(text, str) and re.fullmatch(r"\d+(?:\.\d+)?%", text) is not None,
                "container percent missing",
            )
        need(
            isinstance(x.get("PIDs"), str) and x["PIDs"].isdigit() and int(x["PIDs"]) > 0,
            "container PIDs missing",
        )
        for field in ("MemUsage", "NetIO", "BlockIO"):
            text = x.get(field)
            need(
                isinstance(text, str)
                and re.fullmatch(
                    r"\d+(?:\.\d+)?\s*[kMGTPE]?i?B\s*/\s*\d+(?:\.\d+)?\s*[kMGTPE]?i?B", text, re.I
                )
                is not None,
                "container byte pair missing",
            )


def inspect(bench, summary, samples, background, events):
    need(
        bench.get("status") == "COMPLETED" and summary.get("status") == "COMPLETED",
        "run not completed",
    )
    need(
        bench.get("config", {}).get("warmup") == 4
        and set(bench.get("requested_modes", [])) == MODES,
        "warmup configuration differs",
    )
    warm = [e for e in events if e.get("phase") == "warmup"]
    for event in ("pending", "result"):
        subset = [e for e in warm if e.get("event") == event]
        need(
            len(subset) == 16
            and collections.Counter(e.get("mode") for e in subset) == {m: 4 for m in MODES},
            "warmup counts differ",
        )
    pending = {e["request_id"]: e for e in warm if e.get("event") == "pending"}
    results = {e["request_id"]: e for e in warm if e.get("event") == "result"}
    need(
        len(pending) == len(results) == 16 and pending.keys() == results.keys(),
        "warmup pairing differs",
    )
    need(
        all(
            r.get("outcome") == "success"
            and r.get("status_code") == 200
            and r.get("mode") == pending[k].get("mode")
            for k, r in results.items()
        ),
        "warmup unsuccessful",
    )
    states = summary["initial_state"]
    expected = {r["Name"].lstrip("/"): r["Id"] for r in states}
    need(
        set(expected) == {PROJECT + "-api-1", PROJECT + "-db-1"}
        and all(isinstance(v, str) and re.fullmatch("[0-9a-f]{64}", v) for v in expected.values()),
        "initial identity missing",
    )
    need(
        {r["Name"].lstrip("/"): r["Id"] for r in summary["final_state"]} == expected,
        "container identity changed",
    )
    start = stamp(bench["runs"][0]["started_at"])
    fs, fb = formal(samples, start), formal(background, start, True)
    clients = set()
    for _, row in fs:
        need(row.get("phase") == "load", "non-load sample")
        container_stats(row["stats"], expected)
        client = row["client"]
        need(
            client.get("available") is True
            and type(client.get("pid")) is int
            and client["pid"] > 0
            and not client.get("errors"),
            "client unavailable",
        )
        clients.add(client["pid"])
        mem = client["sources"]["memory"]
        need(
            mem.get("available") is True
            and all(
                type(mem["data"].get(k)) is int and mem["data"][k] > 0
                for k in ("rss_bytes", "private_bytes", "peak_rss_bytes")
            ),
            "client memory missing",
        )
        source = row["server"]["sources"]["cgroup_memory_events"]
        data = source["data"]
        need(
            source.get("available") is True
            and EVENT_KEYS <= data.keys()
            and all(type(data[k]) is int and data[k] == 0 for k in EVENT_KEYS),
            "cgroup events incomplete or nonzero",
        )
    need(len(clients) == 1, "client process identity changed")
    for _, row in fb:
        host = row["windows_host"]
        need(
            host.get("available") is True
            and all(
                number(host.get(k))
                for k in (
                    "memory_load_percent",
                    "available_physical_bytes",
                    "total_physical_bytes",
                    "system_total_cpu_seconds",
                    "system_idle_cpu_seconds",
                    "logical_processors",
                    "interval_cpu_busy_percent",
                )
            ),
            "host metrics unavailable",
        )
        need(
            0 <= host["memory_load_percent"] <= 100
            and 0 <= host["interval_cpu_busy_percent"] <= 100
            and host["total_physical_bytes"] > 0
            and host["available_physical_bytes"] <= host["total_physical_bytes"]
            and host["logical_processors"] > 0
            and host["system_idle_cpu_seconds"] <= host["system_total_cpu_seconds"],
            "host metrics invalid",
        )
        container_stats(row["containers"], expected, allow_extra=True)
        load = row["linux_loadavg"]
        need(
            load.get("available") is True
            and isinstance(load.get("data"), str)
            and re.fullmatch(r"\d+(?:\.\d+)? \d+(?:\.\d+)? \d+(?:\.\d+)? \d+/\d+ \d+", load["data"])
            is not None,
            "linux loadavg missing",
        )
    return {
        "status": "PASSED",
        "scope": "supplemental_completion_integrity_only",
        "formal_samples": len(fs),
        "formal_observations": len(fb),
        "warmup_successes": 16,
        "client_pid": next(iter(clients)),
        "containers": expected,
        "limits_changed": False,
        "resource_thresholds_evaluated": False,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input-dir", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    need(
        args.out.resolve().parent == Path(__file__).resolve().parent and not args.out.exists(),
        "output must be new file in review directory",
    )
    names = [
        "soak.json",
        "summary.json",
        "samples.jsonl",
        "background.jsonl",
        "soak.requests.jsonl",
    ]
    try:
        raw = {n: (args.input_dir / n).read_bytes() for n in names}
        bench, summary = (json.loads(raw[n]) for n in names[:2])
        samples, background, events = (
            [json.loads(line) for line in raw[n].splitlines()] for n in names[2:]
        )
        result = inspect(bench, summary, samples, background, events)
        result["input_sha256"] = {n: hashlib.sha256(data).hexdigest() for n, data in raw.items()}
    except (ValueError, KeyError, TypeError, OSError, IndexError) as exc:
        result = {
            "status": "FAILED",
            "scope": "incomplete_or_invalid_supplement_evidence",
            "errors": [f"{type(exc).__name__}: {exc}"],
            "resource_thresholds_evaluated": False,
        }
    with args.out.open("x", encoding="utf-8") as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write("\n")
    print(json.dumps({"status": result["status"], "scope": result["scope"]}))
    return int(result["status"] != "PASSED")


if __name__ == "__main__":
    raise SystemExit(main())
