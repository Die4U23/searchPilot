import hashlib
import json
import shutil
import subprocess
from pathlib import Path

repo = Path('E:/searchPilot')
root = repo / 'artifacts/agent-memory-2026-10-27'
review = repo / 'artifacts/agent-memory-2026-10-27-review'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prep = read(root / 'preparation-release.json')
files = dict(prep['source_sha256'])
for name in ['Dockerfile', '.env.example', 'docker-compose.yml', 'pyproject.toml']:
    assert sha(repo / name) == prep['bound_files'][name]
    files[name] = sha(repo / name)
destination = root / 'frozen-source'
destination.mkdir(exist_ok=False)
for name, expected in files.items():
    assert sha(repo / name) == expected
    target = destination / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
    assert sha(target) == expected
(root / 'frozen-source-manifest.json').write_text(json.dumps(files, indent=2), encoding='utf-8')
patch = subprocess.run(['git', 'diff', '--', 'Dockerfile', '.env.example', 'docker-compose.yml'],
    cwd=repo, capture_output=True, check=True).stdout
with (review / 'rejected-arena1-candidate.patch').open('xb') as f:
    f.write(patch)
a = read(root / 'audit-result.json')
r = read(review / 'resources-after-run.json')
assert a['resource_stability'] == {k:v for k,v in r.items() if k != 'inputs'}
measured = a['ledger']['phases']['measured']
summary = {'status': 'FAILED_STABILITY_CANDIDATE_NOT_PROMOTED',
    'collection_status': read(root / 'launcher.json')['status'],
    'workload_status': a['ledger']['status'],
    'supplement_status': read(review / 'terra-supplement-result.json')['status'],
    'image': prep['image'], 'duration_seconds': 10800, 'concurrency': 32,
    'formal_requests': {k:measured[k] for k in ['issued','paired','success','failed','unknown','empty_successes']},
    'warmup_successes': a['ledger']['phases']['warmup']['success'],
    'latency_success': measured['latency_success'],
    'health': a['health'], 'business': a['business'], 'semantics': a['semantics'],
    'pid1_runtime': a['pid1_runtime'], 'resource_stability': r,
    'additional_windows': a['additional_windows'],
    'candidate_malloc_arena_max': 1, 'production_malloc_arena_max': 2,
    'external_llm_calls': 0, 'no_leak_proved': False,
    'audit_sha256': sha(root / 'audit-result.json'),
    'ledger_sha256': sha(review / 'ledger-after-run.json'),
    'supplement_sha256': sha(review / 'terra-supplement-result.json')}
with (repo / 'docs/data/container-memory-three-hour-2026-10-27-summary.json').open('x',encoding='utf-8') as f:
    json.dump(summary, f, indent=2)
shutil.copyfile(review / 'three-hour-memory-release.png', repo / 'docs/data/container-memory-three-hour-2026-10-27.png')
print(json.dumps({'sources_copied': len(files), 'status': summary['status'], 'requests': measured['success']}))
