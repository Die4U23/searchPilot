"""Completion-only scientific memory plot; independent JSON audits decide acceptance.

No Docker, HTTP, models, interpolation, smoothing or gap filling. This renderer
does not compute acceptance gates and never edits measurement evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

DURATION = 10800
STABLE_START = 3600
MIB, GIB = 1024**2, 1024**3
MAX_GAP_SECONDS = 15
PHASE_COLORS = {
    "startup": "#e2e8f0",
    "baseline": "#e0f2fe",
    "load": "#eef2ff",
    "recovery": "#dcfce7",
    "restart": "#fef3c7",
}
PHASE_LABELS = {
    "startup": "Startup",
    "baseline": "Baseline",
    "load": "Formal load",
    "recovery": "Recovery",
    "restart": "Planned restart",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def reject_constant(value):
    raise ValueError("Nonfinite JSON number: " + value)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=reject_constant)


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line, parse_constant=reject_constant) for line in stream]


def timestamp(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.tzinfo is not None, "All observation times must include a timezone")
    return parsed.timestamp()


def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def mapping(value):
    return value if isinstance(value, dict) else {}


def source(owner, name):
    envelope = mapping(mapping(owner.get("sources")).get(name))
    return mapping(envelope.get("data")) if envelope.get("available") is True else {}


def server_identity(server):
    before, after = source(server, "stat"), source(server, "stat_after")
    ticks = before.get("start_time_ticks")
    if (
        server.get("available") is not True
        or server.get("identity_consistent") is not True
        or any(
            type(owner.get("pid")) is not int or owner["pid"] != 1
            for owner in (server, before, after)
        )
        or type(ticks) is not int
        or ticks < 0
        or type(after.get("start_time_ticks")) is not int
        or after["start_time_ticks"] != ticks
    ):
        return None
    return 1, ticks


def observation_rows(samples, anchor):
    rows, previous = [], None
    for raw in samples:
        elapsed = timestamp(raw["at"]) - anchor
        require(previous is None or elapsed > previous, "Sample timestamps are not increasing")
        previous = elapsed
        server, client = mapping(raw.get("server")), mapping(raw.get("client"))
        identity = server_identity(server)
        smaps = source(server, "smaps_rollup")
        values = {}
        for name, key in (("rss", "Rss_bytes"), ("anonymous", "Anonymous_bytes")):
            value = smaps.get(key)
            values[name] = value / MIB if identity is not None and number(value) else None
        pid = client.get("pid")
        valid_client = client.get("available") is True and type(pid) is int and pid > 0
        rss = source(client, "memory").get("rss_bytes")
        rows.append(
            {
                "seconds": elapsed,
                "phase": str(raw.get("phase", "unknown")),
                "identity": identity,
                "values": values,
                "client_identity": pid if valid_client else None,
                "client_rss": rss / MIB if valid_client and number(rss) else None,
            }
        )
    require(rows, "No sample rows available")
    return rows


def host_rows(background, anchor):
    rows, previous = [], None
    for raw in background:
        elapsed = timestamp(raw["at"]) - anchor
        require(previous is None or elapsed > previous, "Background timestamps are not increasing")
        previous = elapsed
        host = mapping(raw.get("windows_host"))
        value = host.get("available_physical_bytes")
        rows.append(
            {
                "seconds": elapsed,
                "available_gib": value / GIB
                if host.get("available") is True and number(value)
                else None,
            }
        )
    require(rows, "No host observations available")
    return rows


def segmented(points):
    """Explicit NaNs break unavailable values, long gaps and process identity changes."""
    xs, ys = [], []
    previous_time = previous_identity = None
    for elapsed, value, identity in points:
        if previous_time is not None and (
            elapsed - previous_time > MAX_GAP_SECONDS or identity != previous_identity
        ):
            xs.append((previous_time + elapsed) / 120)
            ys.append(math.nan)
        xs.append(elapsed / 60)
        ys.append(value if value is not None else math.nan)
        previous_time, previous_identity = elapsed, identity
    return xs, ys


def phase_intervals(rows, collection_end):
    intervals = []
    for index, row in enumerate(rows):
        start = row["seconds"]
        end = rows[index + 1]["seconds"] if index + 1 < len(rows) else collection_end
        if intervals and intervals[-1][0] == row["phase"]:
            intervals[-1][2] = end
        else:
            intervals.append([row["phase"], start, end])
    return intervals


def validate_completion(bench, harness, launcher, audit):
    require(
        bench.get("status") == harness.get("status") == launcher.get("status") == "COMPLETED",
        "Refuse PARTIAL/RUNNING/FAILED collection; bench, harness and launcher must complete",
    )
    require(
        launcher.get("exit_code") == launcher.get("final_process_exit_code") == 0
        and launcher.get("observer_stopped") is True
        and launcher.get("observer_errors") == [],
        "Launcher exit and observer completion are required",
    )
    require(harness.get("soak_exit_code") == 0, "Benchmark process did not exit successfully")
    runs = bench.get("runs")
    require(
        isinstance(runs, list) and len(runs) == 1, "Exactly one completed benchmark run required"
    )
    run = runs[0]
    require(
        run.get("mode") == "mixed"
        and run.get("dispatch_window_seconds") == DURATION
        and bench.get("config", {}).get("duration_seconds") == DURATION,
        "Expected the declared 10800-second mixed dispatch window",
    )
    anchor, finished = timestamp(run["started_at"]), timestamp(run["finished_at"])
    require(finished - anchor >= DURATION, "Completed benchmark timing is too short")
    require(
        isinstance(audit, dict) and audit.get("status") in {"PASSED", "FAILED"},
        "Supply an independent audit JSON with an explicit terminal verdict",
    )
    # A failed memory verdict remains renderable; collection completion is a separate condition.
    return anchor


def make_figure(rows, host, reference, audit_name, collection_bounds):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    figure, axes = plt.subplots(
        4, 1, figsize=(14, 14), gridspec_kw={"height_ratios": [1.3, 1.3, 1, 1]}
    )
    colors = {"rss": "#1d4ed8", "anonymous": "#b45309"}
    labels = {"rss": "PID 1 RSS", "anonymous": "PID 1 anonymous"}
    stable_rows = [row for row in rows if STABLE_START <= row["seconds"] < DURATION]
    require(stable_rows, "No observations in the predeclared stable window")
    for axis, selected in ((axes[0], rows), (axes[1], stable_rows)):
        for metric in ("rss", "anonymous"):
            points = [
                (
                    row["seconds"],
                    row["values"][metric] - reference["values"][metric]
                    if row["values"][metric] is not None
                    else None,
                    row["identity"],
                )
                for row in selected
            ]
            axis.plot(
                *segmented(points),
                color=colors[metric],
                linewidth=1.4,
                label=labels[metric],
                zorder=3,
            )
        axis.axhline(0, color="#64748b", linewidth=0.8, linestyle=":")
        axis.set_ylabel("Delta from first formal sample [MiB]")
        axis.legend(loc="best", frameon=False)
    axes[0].set_title(
        "A. Full collection: startup, baseline, 3-hour load, recovery and planned restart",
        loc="left",
        fontsize=11,
    )
    axes[1].set_title(
        "B. Predeclared detail window [60, 180) min; same reference as panel A",
        loc="left",
        fontsize=11,
    )
    axes[1].set_xlim(STABLE_START / 60, DURATION / 60)
    axes[1].set_xlabel("Elapsed minutes from actual benchmark started_at")
    axes[2].plot(
        *segmented((row["seconds"], row["client_rss"], row["client_identity"]) for row in rows),
        color="#7e22ce",
        linewidth=1.3,
    )
    axes[2].set_ylabel("Client RSS [MiB]")
    axes[2].set_title(
        "C. Load-generator process memory; a separate process and memory scope",
        loc="left",
        fontsize=11,
    )
    axes[3].plot(
        *segmented((row["seconds"], row["available_gib"], "host") for row in host),
        color="#047857",
        linewidth=1.3,
    )
    axes[3].set_ylabel("Available physical memory [GiB]")
    axes[3].set_title(
        "D. Windows host available physical memory; includes other host activity",
        loc="left",
        fontsize=11,
    )
    axes[3].set_xlabel("Elapsed minutes from actual benchmark started_at")
    intervals = phase_intervals(rows, collection_bounds[1])
    full_limits = collection_bounds
    for axis in (axes[0], axes[2], axes[3]):
        for phase, left, right in intervals:
            axis.axvspan(
                left / 60,
                right / 60,
                facecolor=PHASE_COLORS.get(phase, "#f1f5f9"),
                alpha=0.5,
                zorder=0,
            )
        for boundary in (0, STABLE_START, DURATION):
            axis.axvline(boundary / 60, color="#94a3b8", linewidth=0.75, linestyle="--", zorder=1)
        axis.set_xlim(full_limits[0] / 60, full_limits[1] / 60)
    phases = list(dict.fromkeys(row["phase"] for row in rows))
    axes[0].legend(
        handles=[
            Patch(
                facecolor=PHASE_COLORS.get(phase, "#f1f5f9"),
                alpha=0.5,
                label=PHASE_LABELS.get(phase, "Other recorded phase"),
            )
            for phase in phases
        ],
        loc="upper left",
        ncols=3,
        frameon=False,
        fontsize=8,
        bbox_to_anchor=(0, 1.01),
    )
    # Keep metric labels visible independently of the phase legend.
    axes[0].text(
        0.99,
        0.04,
        "Blue: PID 1 RSS   Brown: PID 1 anonymous",
        transform=axes[0].transAxes,
        ha="right",
        fontsize=9,
        color="#334155",
    )
    for axis in axes:
        axis.grid(axis="y", color="#cbd5e1", alpha=0.6, linewidth=0.6)
        axis.spines[["top", "right"]].set_visible(False)
    figure.suptitle("Three-hour normal-entrypoint memory observations", fontsize=16, y=0.985)
    figure.text(
        0.06,
        0.018,
        "Finite sampled workload only; no claim of zero leaks. Threshold verdicts: "
        + audit_name
        + "\n"
        "Sample dispatch timestamps are non-atomic. Missing data, gaps >15 s and PID changes "
        "break lines; memory scopes are never added.",
        fontsize=9,
        color="#334155",
    )
    figure.subplots_adjust(left=0.09, right=0.98, top=0.95, bottom=0.075, hspace=0.48)
    return figure, matplotlib.__version__


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run-root",
        type=Path,
        required=True,
        help="Parent containing launcher.json and final-three-hour/",
    )
    parser.add_argument(
        "--audit",
        type=Path,
        required=True,
        help="Independent JSON verdict, including FAILED memory verdicts",
    )
    parser.add_argument("--out", type=Path, required=True, help="New PNG path; never overwritten")
    args = parser.parse_args(argv)
    run_root, output = args.run_root.resolve(), args.out.resolve()
    require(output.suffix.lower() == ".png", "Output must be a PNG")
    manifest_path = output.with_suffix(".manifest.json")
    require(not output.exists() and not manifest_path.exists(), "Output or manifest already exists")
    paths = {
        "bench": run_root / "final-three-hour/soak.json",
        "harness": run_root / "final-three-hour/summary.json",
        "launcher": run_root / "launcher.json",
        "samples": run_root / "final-three-hour/samples.jsonl",
        "background": run_root / "final-three-hour/background.jsonl",
        "audit": args.audit.resolve(),
        "script": Path(__file__).resolve(),
    }
    require(
        output not in paths.values() and manifest_path not in paths.values(),
        "Output aliases an input",
    )
    before = {
        name: {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}
        for name, path in paths.items()
    }
    bench, harness, launcher, audit = (
        read_json(paths[name]) for name in ("bench", "harness", "launcher", "audit")
    )
    anchor = validate_completion(bench, harness, launcher, audit)
    rows = observation_rows(read_jsonl(paths["samples"]), anchor)
    host = host_rows(read_jsonl(paths["background"]), anchor)
    formal = [row for row in rows if row["phase"] == "load" and 0 <= row["seconds"] < DURATION]
    require(formal, "No formal observations")
    reference = formal[0]
    require(
        reference["identity"] is not None
        and all(reference["values"][name] is not None for name in ("rss", "anonymous")),
        "The first formal sample has no valid reference; do not substitute a later sample",
    )
    collection_bounds = [
        min(
            timestamp(launcher["started_at"]) - anchor,
            timestamp(harness["started_at"]) - anchor,
            rows[0]["seconds"],
            host[0]["seconds"],
        ),
        max(
            timestamp(launcher["finished_at"]) - anchor,
            timestamp(harness["finished_at"]) - anchor,
            rows[-1]["seconds"],
            host[-1]["seconds"],
        ),
    ]
    figure, version = make_figure(rows, host, reference, paths["audit"].name, collection_bounds)
    record = {
        "status": "RENDERING",
        "created_at": datetime.now(UTC).isoformat(),
        "inputs": before,
        "scope": "descriptive_plot_only; independent audit JSON decides thresholds",
        "zero_leaks_proved": False,
        "matplotlib_version": version,
        "actual_benchmark_started_at": bench["runs"][0]["started_at"],
        "reference_sample": reference,
        "phase_counts": dict(Counter(row["phase"] for row in rows)),
        "full_sample_interval_seconds": [rows[0]["seconds"], rows[-1]["seconds"]],
        "full_collection_interval_seconds": collection_bounds,
        "stable_detail_window_seconds": [STABLE_START, DURATION],
        "missing_values_are_gaps": True,
        "maximum_connected_gap_seconds": MAX_GAP_SECONDS,
        "process_identity_changes_break_lines": True,
        "memory_scopes_added": False,
        "clock": "sample/background row at minus actual benchmark started_at; non-atomic",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    # Both handles are exclusively created. Failed output remains explicitly incomplete.
    with output.open("xb") as image, manifest_path.open("x+", encoding="utf-8") as manifest:
        json.dump(record, manifest, indent=2, allow_nan=False)
        manifest.flush()
        os.fsync(manifest.fileno())
        try:
            figure.savefig(image, format="png", dpi=180, facecolor="white")
            image.flush()
            os.fsync(image.fileno())
            require(
                all(sha(path) == before[name]["sha256"] for name, path in paths.items()),
                "An input changed during rendering",
            )
            record.update(
                status="COMPLETED",
                output={"path": str(output), "sha256": sha(output), "bytes": output.stat().st_size},
            )
        except BaseException as exc:
            record.update(status="FAILED", error_type=type(exc).__name__)
            raise
        finally:
            import matplotlib.pyplot as plt

            plt.close(figure)
            manifest.seek(0)
            manifest.truncate()
            json.dump(record, manifest, indent=2, allow_nan=False)
            manifest.flush()
            os.fsync(manifest.fileno())
    print(
        json.dumps({"status": record["status"], "png": str(output), "manifest": str(manifest_path)})
    )


if __name__ == "__main__":
    main()
