from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from verify_archive import verify


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        self.path = Path(self.temporary.name) / "fixture.zip"

    def tearDown(self):
        self.temporary.cleanup()

    def fixture(self, *, wrong_hash=False, extra=False, unsafe=False):
        name = "../unsafe.txt" if unsafe else "raw/requests.jsonl"
        content = b'{"status":"fixture_only"}\n'
        manifest = {name: "0" * 64 if wrong_hash else hashlib.sha256(content).hexdigest()}
        with ZipFile(self.path, "x") as archive:
            archive.writestr(name, content)
            archive.writestr("MANIFEST-SHA256.json", json.dumps(manifest))
            if extra:
                archive.writestr("unmanifested.txt", "not allowed")
        return hashlib.sha256(self.path.read_bytes()).hexdigest()

    def test_round_trip(self):
        sha = self.fixture()
        report = verify(self.path, sha)
        self.assertEqual(report["status"], "VERIFIED")
        self.assertEqual(report["members"], 2)
        self.assertFalse(report["secrets_absence_certified"])

    def test_whole_hash(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, "Whole ZIP"):
            verify(self.path, "0" * 64)

    def test_member_hash(self):
        sha = self.fixture(wrong_hash=True)
        with self.assertRaisesRegex(ValueError, "Member SHA256"):
            verify(self.path, sha)

    def test_manifest_membership(self):
        sha = self.fixture(extra=True)
        with self.assertRaisesRegex(ValueError, "membership"):
            verify(self.path, sha)

    def test_unsafe_path(self):
        sha = self.fixture(unsafe=True)
        with self.assertRaisesRegex(ValueError, "unsafe archive path"):
            verify(self.path, sha)


if __name__ == "__main__":
    unittest.main()
