# Arena1 筛选与三小时发布版运行独立复审

日期：2026-10-27。范围：只读既有报告与公开原始证据；未启动负载、模型请求或容器，
未修改运行目录、冻结源码、公共配置、验收计划或 helper。当前三小时运行仍在进行，
本复审不授予完成或稳定性通过结论。

本轮重新执行了筛选原始证据审计；模型文件映射及晚期台阶的机制判断同时引用既有描述审计，
没有重新逐VMA解析全部历史37项输入。旧报告记载的ZIP归档校验亦未在本轮重新执行。

## 已实际复核

从 `artifacts/arena-count-2026-10-26/compare_arena_controls.py` 的 `compare()`
重新解析原两组完整证据。按该协议本来采用的JSON序列化规范化后，结果与保存的
`arena-comparison.json` 完全相等。Python内部整数mapping key与JSON字符串key不同，
未经JSON规范化的对象比较不适合当作字节或协议差异；没有据此改动原结果。

- `status=PASSED`，`candidate_eligible=true`，两组case均PASSED，无failures。
- 两组各20,800/20,800正式成功、16/16预热，5200组完整result/ranking/model/count相等。
- after20800 Anonymous增量：控制40,165,376 bytes，处理29,081,600 bytes，少11,083,776 bytes。
- idle Anonymous增量：控制34,168,832 bytes，处理22,806,528 bytes，少11,362,304 bytes。
- 处理组后段额外增长712,704 bytes，仍有增长，但小于原1MiB回归上限。
- 吞吐比0.9757279997134757，p95比1.0262013265046448，原0.8/1.25门槛通过。
- comparator SHA256：`2dc8fda364d50cc08cce728e8f8dc6219b576531443f87f5bc689662db3b1020`。
- 保存comparison SHA256：`9f5ef3f922aaf4551257517b9ea8db87d11620c4e9ad96fea97963a6a6b05085`。

一次完整规范化复核耗时5.718秒。另两次只读复核用于排查Python对象/JSON key类型差异；
这些短暂本地CPU/磁盘活动属于当前共享宿主背景，不能声称当前负载独占宿主。

## 根因证据强弱

| 判断 | 证据 | 可以支持的结论 | 仍不能支持 |
|---|---|---|---|
| 文件resident增长定位较强 | 同一VMA约39.554688MiB clean文件页增长、Anonymous为0；inode/symlink对应bge模型safetensors | 已定位一部分非匿名RSS增量到模型文件驻留页 | 某条查询触发哪些页、全部RSS增长都来自权重 |
| 分配器保留机制支持较强 | 同VMA扩大5104KiB，malloc_info heap容量及mallinfo2 arena增量精确对应；used下降/free增加；idle/GC后仍驻留、trim后下降 | glibc分配区空闲驻留页保留对晚期台阶有贡献，比仅凭映射形状猜测更强 | 直接heap到VMA的API证明、分配调用栈、库所有者、所有增长均为可回收空闲内存 |
| arena1工程筛选有效 | 相同镜像/源码/模型/查询/协议，仅2→1；十个snapshot实际heap数2/1；两组完整对账与指纹一致 | 在这两组匹配诊断中通过预声明内存收益和回归门槛，有资格正常入口复验 | 生产长期平台、零泄漏、任意负载均改善 |
| 吞吐因果证据弱 | 仅一组固定顺序2→1，宿主共享，未随机化/重复交叉 | 本次吞吐/p95没有超过预声明回归限制 | arena1导致吞吐加速或独立容量SLA |
| 启动差异归因不足 | 查询前A/B约102.324219MiB匿名差，落在三块相似1GiB映射 | 启动基线差异确实存在，应使用各自warmup增量 | 将查询前差异解释为expanded查询效果或精确分配对象身份 |

这些口径可能重叠，不将glibc used/free、pymalloc、VMA及RSS相加。
malloc_info/smaps/task IDs顺序采集，并非原子快照。线程数稳定也不排除task ID更替。
trim仅为既有诊断干预，当前正常入口不主动GC/trim。

## 对照可比性与历史失败

原arena2→1是同一不可变e858镜像、THP-off、HTTP c32、1300条相同查询、四模式和同一PG，
各新API进程；派生wrapper及十个快照均绑定，模型与原始labels未变。按各自warmup比较
Anonymous增量，避免跨进程启动绝对RSS差误导。固定先2后1、只有一轮、诊断wrapper、
顺序非原子观测和不完整宿主争用隔离仍限制外推。旧background分类包含本项目自身，
不得把其other计数直接解读为外部负载数量。

其他候选仍须保留拒绝：encoder2有3次timeout；OMP=1有275/5200组完整result指纹不同。
相同排名或HTTP成功不能覆盖完整结果门槛；没有原始分数，不能断言只是可忽略舍入误差。
original100及encoder2缺失idle/GC/trim，必须保持未执行。

`docs/data/container-memory-stability-2026-10-26.md` 保留旧草稿状态：第3/18行仍说旧arena1
两小时RUNNING；第229行“没有通过的候选修复”容易与第167–187行已通过筛选冲突。
后续发布应明确“arena1筛选通过；正常入口验收仍待定”，并单独保留原失败/中断历史。
本复审不修改这份原文。

原正常入口arena2基线97868/97868搜索成功，但第二小时RSS/Anonymous各+5.222656MiB、
OLS约0.120903MiB/分钟，以及1次live timeout，稳定性验收失败。旧arena1两小时没有
launcher/harness/bench完整收尾；已有101547/101547账本和720个load样本仅是中断诊断。
诊断第二小时OLS0.030591>0.03，不能用末二十分钟下降抵消；其时间原点为推定，
不冒充完整正式验收。宿主进程为何终止仍UNKNOWN，不能将后来重启相关性当因果。

当前三小时镜像 `sha256:b8c42b9b10d167dbd4fc9cd5fa4cbbfd6cae4e40102ee4343347978b27903b08`
使用新的Agent发布源码与补充的httpx/httpcore/certifi依赖，属于这一发布版的正常入口验证。
它不是旧两组之间唯一改变arena数的重复试验，不能把新旧RSS差全部归因于arena1。
模型/查询不变及5200组完整指纹比较可约束业务行为；独立新卷和image/source绑定约束来源。

## 当前待定的固定门槛

当前运行参数10800秒、c32、16预热、基线60秒、恢复600秒，项目/端口/新卷均独立。
稳定窗口固定 `[3600,10800)`，RSS和Anonymous分别要求全部满足：端点<=2MiB、
OLS<=0.03MiB/分钟、稳定期首末十分钟中位数差<=2MiB、全部24个五分钟中位数范围<=2MiB、
全部21个滑动二十分钟增长<=2MiB且OLS<=0.1MiB/分钟。每窗至少floor(duration/10)-2点，
边界<=10秒、最大gap<=15秒；保留前三小时及前两小时完整报告，不挑最后窗口。

另外必须：三层完成/退出0、observer停止且无错；严格账本零失败/unknown/遗留/空成功；
5200组各至少12次成功且与筛选组完整指纹相等；客户端峰值32；全部load健康、七组件和
11来源可用；PID1身份一致、THP/swap/OOM为0；17业务检查、计划重启与反馈持久性通过。
HTTP 200、CI通过、资源窗口通过都不能替代其他门槛。

## 完成后的核验与归档顺序

1. 等待launcher终态、observer_stopped=true及退出状态完整，核对harness/bench完成。
   若中断或任一项失败，保留FAILED/INTERRUPTED/UNKNOWN，不重试覆盖旧目录。
2. 使用冻结完整审计器生成一个全新的输出名：

   ```powershell
   .venv/Scripts/python.exe artifacts/agent-memory-2026-10-27/audit.py --out artifacts/agent-memory-2026-10-27/audit-release.json
   ```

3. 原始账本和资源独立审计应另存本复审目录的新文件，便于即使其他门槛失败仍披露资源：

   ```powershell
   .venv/Scripts/python.exe -m scripts.summarize_soak --bench artifacts/agent-memory-2026-10-27/final-three-hour/soak.json --ledger artifacts/agent-memory-2026-10-27/final-three-hour/soak.requests.jsonl --samples artifacts/agent-memory-2026-10-27/final-three-hour/samples.jsonl --queries artifacts/arena1-normal-2026-10-26/fixture/queries.csv --duration-seconds 10800 --min-repeats 12 --out artifacts/agent-memory-2026-10-27-review/ledger-after-run.json
   .venv/Scripts/python.exe -m scripts.audit_memory_stability --bench artifacts/agent-memory-2026-10-27/final-three-hour/soak.json --samples artifacts/agent-memory-2026-10-27/final-three-hour/samples.jsonl --duration-seconds 10800 --stable-after-seconds 3600 --out artifacts/agent-memory-2026-10-27-review/resources-after-run.json
   ```

4. 只在所有写入进程停止后生成归档。包含完整成功/失败账本、原样query快照、samples/background、
   launcher/progress、summary/soak、preparation-release、计划/helper执行字节、release源码快照、
   build-summary、公开配置、上述审计结果及EVIDENCE-SCOPE，按原路径封装，逐项SHA256。
   scope明确完成与通过分别何值，有限观察不证明零泄漏。原始container/console日志先检查
   凭据再决定公开；私有.env、API key、私人配置不入包。仅模式扫描不能证明不存在凭据。
5. 生成 `MANIFEST-SHA256.json`（bare object，成员路径→SHA256，不列manifest自身），
   计算完整ZIP的外部SHA256，再以本目录只读验证器检查whole ZIP hash、CRC、成员集合、
   路径/重复项与逐成员SHA。验证器不解压、不修改、不证明“无凭据”。
   命令：`.venv/Scripts/python.exe artifacts/agent-memory-2026-10-27-review/verify_archive.py --zip $archivePath --expected-sha256 $expectedSha256`，
   两个变量须来自归档创建后的实际路径及独立计算值，不使用推测值。
6. 归档独立存放并回读验证前，不清理任何运行容器/卷；后续清理另核对精确ID/label，
   保留原项目卷与其他项目。无论通过与否都保留原始失败，不把新通过合并成历史全通过。

以上完成后命令尚未执行。本复审当前只检查既有证据，不预报当前三小时最终状态。
