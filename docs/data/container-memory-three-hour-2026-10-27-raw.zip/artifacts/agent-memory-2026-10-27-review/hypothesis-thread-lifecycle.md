# 晚期增长下一步假设：请求执行线程更替与原生分配器保留

日期：2026-10-27。结论：**有可验证的线程生命周期假设，尚未证明根因，更未证明修复。**
本轮只读仓库、安装库源码和历史diagnostic JSON；没有修改冻结文件、脚手架、配置，
没有运行模型、编码、线程试验、压测、探针或构建。当前三小时运行继续完成；其既定门槛
不因本假设改变，任何已发生的失败都须保留。

## 1. 已查到的实际调用链

`src/searchpilot/api/routes_search.py:54` 的 `/search` 是同步 `def search`，直接调用
共享service；vector/hybrid/ltr最终经 `SentenceTransformerQueryEncoder.__call__`
调用共享模型的 `encode`。实例 `_model` 只在首次加载时发布，锁只保护构造，不串行推理
（`src/searchpilot/search/vector_index.py:263–291`）。

本机实际安装源码显示：

1. FastAPI `routing.py:351–364`：同步endpoint调用 `run_in_threadpool`。
2. Starlette `concurrency.py:35–37`：该函数调用 `anyio.to_thread.run_sync`。
3. FastAPI `dependencies/utils.py:615–680`：dependency cache在一次依赖解析开始时
   新建并在本请求递归传递；同步依赖也逐项进入threadpool。仓库Settings/Search/Items等
   getter都是同步函数，不能假定“一个HTTP请求一直绑定一个Python线程”。
4. `/health/live` 与 `/health/ready` 也都是同步def，ready还有同步依赖和probe。
   因此短依赖、健康调用及长编码会共享既有AnyIO执行资源，不能只看搜索HTTP c32就
   推定总worker数或worker亲和性。

本机源码实测版本（只读取distribution metadata，没有import torch/执行推理）：
AnyIO4.15.1、Starlette1.7.0、FastAPI0.142.4、PyTorch2.14.1、
Sentence Transformers6.1.0、httpx0.28.1。

**重要版本边界：**历史容器的已落盘 `container_packages` 是PyTorch2.14.1+cpu、
Sentence Transformers6.2.0、FastAPI0.159.1；没有记录AnyIO/Starlette版本。
Windows宿主并不等于Linux容器；本机源码只能证明本机机制，不能凭接近版本认定
正在运行的镜像采用完全相同实现、OpenMP runtime或缓存策略。下一轮任何干预前，
必须从目标不可变镜像采集相关库实际文件/版本/哈希及native build信息；本轮没有做
容器内源码探针，也不借当前运行临时增加它。

## 2. AnyIO确实可能裁剪闲置worker，但不是每十秒统一重建

本机 `.venv/Lib/site-packages/anyio/_backends/_asyncio.py`：

- `WorkerThread:1044`，`MAX_IDLE_TIME=10`秒；队列为 `Queue(2)`。
- `_report_result:1067` 将完成worker的idle_since更新为当前时间，并append到idle deque。
- `run_sync_in_worker_thread:2650–2708`：没有idle worker才新建；有则从deque尾部pop，
  再从头部检查**其他**闲置至少10秒的worker并stop。这是LIFO复用加派发触发的剪枝，
  不是定时器每十秒杀掉所有线程；本次选中的worker也不会被同一剪枝循环检查。
- `current_default_thread_limiter:3158–3164` 的本机默认token为40，限制同时运行的
  offload，不是HTTP并发数，也不是PyTorch内部线程数。实际容器容量尚需核对。
- `WorkerThread.run:1086–1117` 处理完后显式删除result、exception、item、context、func、
  args、future、cancel_scope；cancel_scope threadlocal在finally删除。由这份源码
  **没有发现**idle worker无限保留上一批请求参数/结果的明显问题。
- `to_thread.run_sync` 默认 `abandon_on_cancel=False`；Python同步调用不能由HTTP客户端
  超时强行中止。即使主动abandon，底层线程仍会继续执行。新的有界执行方案必须把
  尚未实际完成的任务计入容量，不得在客户端超时即释放许可并无限继续submit。

可能的因果链仅为：短/长任务混合及LIFO复用 → 部分旧worker超过idle阈值被裁剪 →
以后需求增加时新worker进入PyTorch/native库 → 新的thread-local初始化/并行资源、
不同尺寸的瞬时分配与释放 → glibc碎片或空闲resident高水位变化。
目前没有把这条链的每个箭头接起来，尤其没有证明原96个Linux task就是AnyIO worker。

## 3. PyTorch有线程本地状态，不等于已证实CPU缓存泄漏

本机PyTorch `include/ATen/Parallel.h:31–39` 有thread_local初始化标志，第一次parallel
调用会执行 `init_num_threads()`；`Parallel-inl.h:22/60`实际调用该lazy初始化。
`ParallelOpenMP.h:24`含OpenMP并行区；`ThreadLocalState.h`保存和恢复调度/自动求导等状态。
这支持“调用线程身份可能影响native初始化与执行上下文”的假设。

但这些头文件没有记录生产wheel内部哪些算子走哪个backend、哪个allocation被哪个
线程拥有，也不能证明“每新建一个Python worker必然永久多占X MiB”。本机有
`c10/mobile/CPUCachingAllocator.h`，其注释明确仅支持mobile并需guard启用；
`c10/core/CPUAllocator.h`亦将CPU caching allocator标为experimental/StaticRuntime。
**不能因为头文件里有ThreadLocalCachingAllocator就认定普通CPU BGE推理启用了它。**
CUDA缓存解释也不适用于本轮CPU容器。

本机Sentence Transformers的实际encode实现位于
`sentence_transformers/sentence_transformer/model.py:752–1001`，不是旧文件名：
入口有 `@torch.inference_mode()`，调用 `self.to(device)`、`self.eval()`；
`all_embeddings`、features、out_features是单次调用局部变量，最终返回NumPy结果。
本路径没有看到把每次embedding追加到model全局历史列表的代码，也没有正常构建训练
autograd图的直接证据。共享model仍可能调用原生库缓存或有限shape cache；这部分
没有通过Python源码排除，更不能外推到不同版本的容器实现。

## 4. 历史线程与内存数字不支持简单一一对应

从 `late-anonymous-step-audit.json` 的cases/stages/comparisons本轮重新提取：

| case，10400→15600 | 起止线程数 | task加入/退出 | Anonymous增量KiB | 8MiB+guard几何类Anonymous增量KiB | pymalloc arenas |
|---|---:|---:|---:|---:|---:|
| expanded | 269→269 | 96/96 | 5008 | -96 | 641→641 |
| original100 | 269→269 | 78/78 | 0 | 0 | 638→638 |
| encoder32 | 269→269 | 54/54 | 280 | 0 | 641→641 |
| encoder2，整组失败 | 269→269 | 78/78 | 1508 | 0 | 636→636 |
| OMP default | 269→269 | 66/66 | 836 | 0 | 643→643 |
| OMP1，语义候选拒绝 | 61→61 | 6/6 | 12528 | 0 | 635→635 |

96等恰为6的倍数，而历史OMP default getter确实观测到intra=6；这值得联接线程族，
但并不等于“16个AnyIO worker各带5个OpenMP子线程”已经得到证明。原TID列表只有
集合差，没有每个线程的Python名字、父/子工作关系、调用事件或分配栈；TID还可能重用。
original在较多线程更替时没有这段Anonymous增长，OMP1更替较少却增长更多；后者又
同时改变了并行设置和数值指纹，不能当同条件反证，但足以阻止按task数量线性归因。

expanded主要台阶的既有更强证据仍是同VMA扩展5104KiB与heap1/system/arena容量相等、
used下降/free上升、idle/GC不降而trim后resident下降。8MiB+guard几何类净减96KiB，
因此不能把主要5008KiB增长直接称作新增线程栈。线程更替最多是尚待测试的触发因素；
分配器保留已有机制证据，但还没有allocation调用栈和库所有权证据。

## 5. 应用层无界缓存/请求残留检查的实际边界

限定检查了search服务、BM25、vector、normalize、API依赖、middleware、启动注入：

- service保留的index/model/物品位置/类别映射随固定数据集构造；请求的candidates、scores、
  signals、query_vec、特征矩阵和返回hits均为局部变量，没有看到按query无限增长的全局容器。
- BM25 `_okapi_idf` 是按固定field建立的整个固定词表缓存，并非每个未知查询词都插入；
  默认lucene路径不使用该Okapi表。它可能有有限初始化成本，不能按名称当无界缓存。
- normalize共享Snowball对象有锁；安装的 `basestemmer.py:274–280` 单词处理只覆盖
  current/cursor等状态并返回列表，没有看到词干历史字典。对象可保留最后一个词，
  但请求/数据长度有界，不能解释按累计请求无限增加。
- middleware在finally中reset request-id ContextVar；FastAPI dependency cache是本请求
  的解析结果缓存。既有AnyIO worker也会删掉单次调用的Python引用。
- bootstrap的app.state服务是长生命周期单例，closers列表在启动时追加，不随每次search扩展。
- 压测客户端确实保存全部请求records并逐条写ledger；这是另一个宿主进程，不能归到
  API PID1的RSS。当前/search负载没有执行Agent的model/tool循环。

结论只能是“在已审阅的Python热路径没有发现明显的无界query缓存或请求历史链”，
不能升级成heap census、弱引用存活证明或原生分配器无泄漏证明。库内部有限缓存、
碎片、不同shape瞬时高水位仍保留为竞争假设。

## 6. 最小下一步：先测线程身份，再只改变idle裁剪

以下是**未执行的受控设计**，不修改当前运行，也不自动启动未来实验。

### 先决条件与相同观测

1. 固定目标Linux image、源码、模型、29项输入、1300查询SHA、arena1/THP-off及实际
   AnyIO/Starlette/FastAPI/ST/PyTorch文件哈希、native backend/线程配置；不拿宿主版本代替。
2. 两组使用同一只读诊断wrapper，仅改变idle裁剪时间；共同记录AnyIO worker的
   start/stop及native_id、OS task的 `(tid,start_time_ticks,comm)`，并在实际执行线程内记录
   search/encode begin/end、PyTorch getter。按真实事件联接，不能只看每10秒thread count。
3. 日志流式写盘或固定大小ring buffer；worker计数/队列长度取标量，不引入新的无界
   每请求内存列表。绑定request_id仅作联接，不保存tensor/embedding或异常traceback对象。
   观测开销两组一致，基线与处理组均先完整校验wrapper/源码哈希。

### 两组干预

第一步不另造新executor架构。若目标AnyIO实际源码确认与本机机制一致：

- A：原idle阈值（本机为10秒；以目标镜像真实值为准）。
- B：只将idle阈值设为大于整次负载和恢复时间，例如21600秒；保留**相同**limiter容量、
  idle deque复用策略、endpoint/依赖/health调用链及native线程设置。不同时改OMP、
  编码信号量、arena、trim/mmap、batch size、query缓存或模型。

两组同c32、四模式、20800正式请求、16预热、limit10、timeout10、同查询顺序、无重试；
每组新API进程、相同数据库初始条件。完成400/5200/10400/15600/20800检查点和
idle120/GC/trim仅沿用相同诊断协议，非原子时间/计数如实保存。
保持各自warmup和after5200锚点，不能将为保活付出的额外resident藏进未报告启动成本。
至少做反向顺序复验以减少共享宿主顺序混杂，不能把一次A→B提升直接当因果结论。

有效的机制观察必须是：A实际出现可联接的AnyIO idle裁剪及后续new-worker/native初始化；
B对应裁剪消失，且后段native身份更替/分配区扩展或Anonymous增长随之减小。
若A根本无裁剪、或裁剪减少而增长照旧，本假设在该负载不获支持，应停止推广。
worker长驻也可能提高空闲RSS，或仅把初始化移到前段；因此load与idle两端都必须报告。

### 预声明通过/拒绝门槛

- 两组20800/20800与16/16成功、所有健康预算不变、零failed/unknown/遗留/空成功、
  client peak32；active/排队/超时后仍运行任务都计数，不重复补发掩盖失败。
- 5200个query×mode组各4次成功，轮内及跨组完整 `result_sha256/ranking_sha256/
  model_version/result_count` 精确一致；任一差异即拒绝，排名相同不能放过分数差异。
- 沿用arena筛选强度：本组warmup→after20800及warmup→idle的Anonymous增量，处理组
  均比控制少至少2MiB且20%；控制增量<=0则证据不足；after5200→20800不得额外恶化
  超过1MiB。用整数bytes，不择更低快照口径；RSS、Anonymous、glibc、pymalloc分开。
- 成功吞吐>=控制80%、成功p95<=控制125%，仅1e-9舍入容差；不降低并发、不提高
  10秒请求超时或既有3秒健康预算。共享宿主活动完整记录，不宣称容量SLA。
- 即使筛选通过，也只授予下一轮正常入口资格。最终必须重新冻结并完成原三小时协议：
  `[3600,10800)` RSS/Anonymous端点<=2MiB、OLS<=.03、首末十分钟中位数差<=2MiB、
  全24个五分钟中位数范围<=2MiB、全21个二十分钟增长<=2MiB且OLS<=.1，
  每窗coverage/gap/边界保持原值，另满足全部业务、重启、健康和完整指纹门槛。

## 7. 固定长生命周期有界执行池的评价

从机制上可能减少调用线程更替，但**目前只能列为待验证方案，不能称修复**。
本机Python3.12 `concurrent/futures/thread.py:69–110/153–204` 的ThreadPoolExecutor
复用idle线程，等待队列没有idle超时；然而其内部是 `queue.SimpleQueue()`，
`max_workers=32`只限制运行线程，不限制排队任务。直接换成它并不自动得到“有界执行池”。

若上述单变量诊断先支持假设，才值得另评估显式生命周期、固定worker上限、有限admission/
排队、ContextVar传播和shutdown的实现。不能在现有同步endpoint的AnyIO线程里再
`submit(...).result()`，那会占住两套线程并改变等待/超时行为；改async边界后又会改变
依赖与序列化调度，因此它比只改idle策略更难归因，应作为后续独立工程变更。
取消Future不等于停止已经开始的CPU推理；容量许可要在真实完成后回收，避免超时后
继续堆积native工作。任何新池若增加内存、数值差异或健康超时，即使线程更少也拒绝。

## 本机源码哈希与可复核入口

本轮读取的实际文件SHA256如下；它们不是Linux镜像的源码证明：

| 本机文件（相对E:/searchPilot） | SHA256 |
|---|---|
| .venv/Lib/site-packages/anyio/_backends/_asyncio.py | 56acbb3b5ca6984a714e23f37a14ae042553ce21802cd57e05bb0845a297b20e |
| .venv/Lib/site-packages/starlette/concurrency.py | 3e9e245d060ef39716c58ed754db7995c62f8581d4aaec8b82e09e73b84a2a83 |
| .venv/Lib/site-packages/fastapi/routing.py | 6d8beeb5642f477d7076ec8bf58c57f79f131e2bc8e6bfd5b90224e1ba859ec2 |
| .venv/Lib/site-packages/fastapi/dependencies/utils.py | 13693375ab95e32424e5434c21f928463634af5ee1261cf3e04031381bdf47d9 |
| .venv/Lib/site-packages/torch/include/ATen/Parallel.h | 41bdda41e9481a0acb4105d27642a20c7a8200a1a391d9dfdf02e9cbca1d5b2f |
| .venv/Lib/site-packages/torch/include/c10/mobile/CPUCachingAllocator.h | 04a886017bc8e20a98e68ba2bd32830a6706dde70986ef4f6a6881f7587dc457 |
| .venv/Lib/site-packages/sentence_transformers/sentence_transformer/model.py | 3d677757bf3e684c45d3634ae67918cd9a67cee6aac6760e5fa1c72dfe820650 |

历史数字入口：`artifacts/extended-memory-2026-10-26/late-anonymous-step-audit.json`
的 `/cases/*/stages/after_10400`、`after_15600` 及
`/cases/*/comparisons/after_10400_to_after_15600`；版本对照入口为
`artifacts/arena-count-2026-10-26/setup/summary.json` 的 `/container_packages`。
