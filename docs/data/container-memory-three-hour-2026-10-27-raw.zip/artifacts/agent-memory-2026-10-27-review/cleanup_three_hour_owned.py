"""Prepare bounded cleanup of only this three-hour Compose project.

Requires a completed archive and verifies it before any mutations. --check-only
is read-only and does not produce output. No resource stability gate is assumed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from verify_archive import verify

REPO = Path('E:/searchPilot')
ROOT = REPO / 'artifacts/agent-memory-2026-10-27'
REVIEW = Path(__file__).resolve().parent
PROJECT = 'sp-agent-memory-20261027'
VOL = PROJECT + '_pgdata'
NETWORK = PROJECT + '_default'
PROTECTED = 'searchpilot_pgdata'
DOCKER = r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def docker(*args):
    result = subprocess.run([DOCKER, *args], capture_output=True, text=True, encoding='utf-8', timeout=60)
    if result.returncode:
        raise ValueError('Docker command failed: ' + ' '.join(args[:3]))
    return result.stdout


def inspect(kind, name):
    data = json.loads(docker(kind, 'inspect', name))
    need(len(data) == 1, 'inspect did not return exactly one resource')
    return data[0]


def listing(kind, *args):
    return set(docker(kind, 'ls', *args, '--format', '{{.ID}}' if kind in ('container','network') else '{{.Name}}').splitlines())


def scan_archive(path, expected):
    result = verify(path, expected)
    patterns = [
        re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
        re.compile(rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b'),
        re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{20,}\b'),
    ]
    with zipfile.ZipFile(path) as archive:
        manifest = json.loads(archive.read('MANIFEST-SHA256.json'))
        prefix = 'artifacts/agent-memory-2026-10-27/'
        current = {p.relative_to(REPO).as_posix(): p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.zip'}}
        need(current and set(current) <= set(manifest), 'archive lacks current run files')
        for name, file in current.items():
            need(sha(file) == manifest[name], 'run evidence differs from archive: ' + name)
        for info in archive.infolist():
            if info.is_dir():
                continue
            parts = info.filename.lower().split('/')
            need(not any(part == '.env' or part.startswith('.env.') and part != '.env.example' for part in parts), 'private env file archived')
            with archive.open(info) as stream:
                tail = b''
                while chunk := stream.read(1024 * 1024):
                    data = tail + chunk
                    need(not any(pattern.search(data) for pattern in patterns), 'private-material pattern found in ' + info.filename)
                    tail = data[-1024:]
        need(any(n.startswith(prefix) for n in manifest), 'run archive is empty')
    return {'zip_sha256': result['zip_sha256'], 'members': result['members'], 'run_files': len(current), 'sensitive_scan': 'PASSED_PATTERN_SCAN_ONLY'}


def snapshot():
    launcher = json.loads((ROOT / 'launcher.json').read_text(encoding='utf-8'))
    summary = json.loads((ROOT / 'final-three-hour/summary.json').read_text(encoding='utf-8'))
    need(launcher.get('status') in {'COMPLETED','FAILED','INTERRUPTED'} and launcher.get('observer_stopped') is True, 'launcher or observer not terminal')
    need(summary.get('status') in {'COMPLETED','FAILED','INTERRUPTED'}, 'harness not terminal')
    initial = {x['Name'].lstrip('/'): x['Id'] for x in summary['initial_state']}
    final = {x['Name'].lstrip('/'): x['Id'] for x in summary['final_state']}
    need(set(initial) == {PROJECT+'-api-1', PROJECT+'-db-1'} and final == initial and all(re.fullmatch('[a-f0-9]{64}',v) for v in initial.values()), 'initial/final IDs not bound')
    actual = listing('container', '-a', '--no-trunc', '--filter', 'label=com.docker.compose.project='+PROJECT)
    need(actual == set(initial.values()), 'unknown or missing project container')
    containers = []
    for name, ident in sorted(initial.items()):
        c = inspect('container', ident)
        labels = c['Config'].get('Labels') or {}
        need(c['Id'] == ident and c['Name'].lstrip('/') == name and labels.get('com.docker.compose.project') == PROJECT, 'container identity/label mismatch')
        containers.append({'id':ident,'name':name,'running':c['State']['Running'],'project':labels['com.docker.compose.project']})
    own_volumes = listing('volume', '--filter','label=com.docker.compose.project='+PROJECT)
    need(own_volumes == {VOL}, 'unknown or missing project volume')
    v = inspect('volume', VOL)
    need(v['Name'] == VOL and (v.get('Labels') or {}).get('com.docker.compose.project') == PROJECT and (v.get('Labels') or {}).get('com.docker.compose.volume') == 'pgdata', 'volume identity/label mismatch')
    nets = listing('network','--no-trunc','--filter','label=com.docker.compose.project='+PROJECT)
    n = inspect('network', NETWORK)
    need(n['Name'] == NETWORK and (n.get('Labels') or {}).get('com.docker.compose.project') == PROJECT and (n.get('Labels') or {}).get('com.docker.compose.network') == 'default' and nets == {n['Id']}, 'network identity/label mismatch')
    need(set((n.get('Containers') or {}).keys()) <= set(initial.values()), 'network has unknown attached containers')
    protected = inspect('volume', PROTECTED)
    need(protected['Name'] == PROTECTED, 'protected original volume missing')
    return {'launcher_status':launcher['status'],'harness_status':summary['status'],'containers':containers,'volume':{'name':VOL,'project':PROJECT,'compose_volume':'pgdata'},'network':{'id':n['Id'],'name':NETWORK,'project':PROJECT,'compose_network':'default'},'protected_volume':{k:protected.get(k) for k in ('Name','Driver','Mountpoint','Labels','Scope')},'inventory':{'containers':sorted(listing('container','-a','--no-trunc')),'volumes':sorted(listing('volume')),'networks':sorted(listing('network','--no-trunc'))}}


def save(path, record):
    with path.open('w',encoding='utf-8') as f:
        json.dump(record,f,indent=2)
        f.flush()


def verify_private_scan(path, archive_sha256):
    record = json.loads(path.read_text(encoding='utf-8'))
    need(record.get('status') == 'PASSED' and record.get('archive_sha256') == archive_sha256
         and record.get('matched_file_names') == []
         and type(record.get('credential_values_checked')) is int
         and record['credential_values_checked'] > 0,
         'private exact-value scan missing, failed, or does not bind this archive')
    return {'status': 'PASSED', 'archive_sha256': archive_sha256,
            'credential_values_checked': record['credential_values_checked'],
            'scan_record_sha256': sha(path)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--archive-sha256',required=True)
    p.add_argument('--private-scan',type=Path,required=True)
    p.add_argument('--check-only',action='store_true')
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    if args.check_only:
        need(args.out is None, '--check-only does not write output')
    else:
        need(args.out is not None and args.out.resolve().parent == REVIEW and not args.out.exists(), 'new output in review directory required')
    archive=scan_archive(args.archive,args.archive_sha256)
    private_scan=verify_private_scan(args.private_scan,args.archive_sha256)
    before=snapshot()
    if args.check_only:
        print(json.dumps({'status':'READY_READ_ONLY','archive':archive,'private_scan':private_scan,'resources':before},ensure_ascii=False))
        return 0
    with args.out.open('x',encoding='utf-8') as f:
        json.dump({'status':'PREPARED','archive':archive,'private_scan':private_scan,'before':before,'operations':[]},f,indent=2)
    record={'status':'RUNNING','archive':archive,'private_scan':private_scan,'before':before,'operations':[]}
    save(args.out,record)
    try:
        need(sha(args.archive)==args.archive_sha256 and sha(args.private_scan)==private_scan['scan_record_sha256'] and snapshot()==before, 'state changed since preflight')
        for c in before['containers']:
            if c['running']:
                docker('stop',c['id'])
                record['operations'].append({'stop':c['id']}); save(args.out,record)
        for c in before['containers']:
            docker('rm',c['id'])
            record['operations'].append({'remove_container':c['id']}); save(args.out,record)
        need(not listing('container','-a','--no-trunc','--filter','label=com.docker.compose.project='+PROJECT), 'project containers remain')
        volume = inspect('volume', VOL)
        need(volume['Name'] == VOL and (volume.get('Labels') or {}).get('com.docker.compose.project') == PROJECT and (volume.get('Labels') or {}).get('com.docker.compose.volume') == 'pgdata', 'volume changed before removal')
        docker('volume','rm',VOL)
        record['operations'].append({'remove_volume':VOL}); save(args.out,record)
        network = inspect('network', NETWORK)
        need(network['Id'] == before['network']['id'] and (network.get('Labels') or {}).get('com.docker.compose.project') == PROJECT and not network.get('Containers'), 'network changed or remains attached')
        docker('network','rm',before['network']['id'])
        record['operations'].append({'remove_network':before['network']['id']}); save(args.out,record)
        after={'containers':sorted(listing('container','-a','--no-trunc')),'volumes':sorted(listing('volume')),'networks':sorted(listing('network','--no-trunc'))}
        need(PROTECTED in after['volumes'] and {k:inspect('volume',PROTECTED).get(k) for k in ('Name','Driver','Mountpoint','Labels','Scope')} == before['protected_volume'], 'protected volume changed')
        for kind, removed in [('containers',{c['id'] for c in before['containers']}),('volumes',{VOL}),('networks',{before['network']['id']})]:
            need(set(before['inventory'][kind])-removed <= set(after[kind]) and not (removed & set(after[kind])), 'inventory changed unexpectedly: '+kind)
        record.update(status='COMPLETED',after=after)
    except Exception as exc:
        record.update(status='FAILED',error=type(exc).__name__+': '+str(exc))
        save(args.out,record)
        raise
    save(args.out,record)
    print(json.dumps({'status':record['status'],'out':str(args.out)}))
    return 0

if __name__=='__main__':
    sys.exit(main())
