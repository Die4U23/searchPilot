import copy
import datetime as dt
import json
from pathlib import Path
import pytest
import terra_supplement as s

ROOT = Path(__file__).resolve().parents[1] / 'agent-memory-2026-10-27' / 'final-three-hour'


def fixture():
    samples = [json.loads(x) for x in (ROOT/'samples.jsonl').read_text(encoding='utf-8').splitlines()]
    sample = next(x for x in samples if x['phase'] == 'load' and x['client']['available'])
    background = [json.loads(x) for x in (ROOT/'background.jsonl').read_text(encoding='utf-8').splitlines()]
    observer = next(x for x in background if x['windows_host'].get('interval_cpu_busy_percent') is not None)
    summary = json.loads((ROOT/'summary.json').read_text(encoding='utf-8'))
    summary['status'] = 'COMPLETED'
    summary['final_state'] = copy.deepcopy(summary['initial_state'])
    start = dt.datetime(2026,10,27,tzinfo=dt.timezone.utc)
    bench = {'status':'COMPLETED','config':{'warmup':4},'requested_modes':sorted(s.MODES),'runs':[{'started_at':start.isoformat()}]}
    samples, background = [], []
    for i in range(1080):
        at = (start+dt.timedelta(seconds=10*i)).isoformat()
        a,b = copy.deepcopy(sample),copy.deepcopy(observer)
        a['at'] = at
        b['pid1_runtime']['started_at'] = at
        samples.append(a); background.append(b)
    events=[]
    for mode in s.MODES:
        for i in range(4):
            key=f'{mode}-{i}'
            events.extend([{'event':'pending','phase':'warmup','mode':mode,'request_id':key}, {'event':'result','phase':'warmup','mode':mode,'request_id':key,'outcome':'success','status_code':200}])
    return bench,summary,samples,background,events


def test_complete_schema_passes():
    report=s.inspect(*fixture())
    assert report['status']=='PASSED' and report['formal_samples']==1080 and report['resource_thresholds_evaluated'] is False


@pytest.mark.parametrize('fault', ['unfinished','warmup_count','warmup_mode','warmup_pair','warmup_failed','sample_gap','stats_missing','stats_id','stats_values','client_missing','client_value','client_pid','cgroup_missing','cgroup_oom','observer_missing','host_missing','host_range','containers_missing','containers_id','load_missing'])
def test_missing_or_invalid_evidence_fails(fault):
    b,summ,sa,bg,ev=fixture()
    if fault=='unfinished': b['status']='RUNNING'
    elif fault=='warmup_count': b['config']['warmup']=3
    elif fault=='warmup_mode': ev[0]['mode']='other'
    elif fault=='warmup_pair': ev[1]['request_id']='unknown'
    elif fault=='warmup_failed': ev[1]['outcome']='failure'
    elif fault=='sample_gap': del sa[500]
    elif fault=='stats_missing': sa[500]['stats']['available']=False
    elif fault=='stats_id': sa[500]['stats']['data'][0]['ID']='x'*12
    elif fault=='stats_values': sa[500]['stats']['data'][0]['MemUsage']='unknown'
    elif fault=='client_missing': sa[500]['client']['available']=False
    elif fault=='client_value': del sa[500]['client']['sources']['memory']['data']['rss_bytes']
    elif fault=='client_pid': sa[500]['client']['pid']+=1
    elif fault=='cgroup_missing': del sa[500]['server']['sources']['cgroup_memory_events']['data']['oom']
    elif fault=='cgroup_oom': sa[500]['server']['sources']['cgroup_memory_events']['data']['oom']=1
    elif fault=='observer_missing': del bg[500]
    elif fault=='host_missing': bg[500]['windows_host']['available_physical_bytes']=None
    elif fault=='host_range': bg[500]['windows_host']['interval_cpu_busy_percent']=101
    elif fault=='containers_missing': bg[500]['containers']['data'].pop()
    elif fault=='containers_id': bg[500]['containers']['data'][0]['ID']='x'*12
    elif fault=='load_missing': bg[500]['linux_loadavg']['data']='unknown'
    with pytest.raises((ValueError,KeyError)):
        s.inspect(b,summ,sa,bg,ev)


def test_observer_permits_extra_host_container():
    b, summ, sa, bg, ev = fixture()
    extra = copy.deepcopy(bg[500]['containers']['data'][0])
    extra.update(Name='unrelated-service', ID='a' * 12)
    bg[500]['containers']['data'].append(extra)
    assert s.inspect(b, summ, sa, bg, ev)['status'] == 'PASSED'


@pytest.mark.parametrize('fault', ['missing_project', 'changed_identity', 'duplicate_name', 'duplicate_id', 'invalid_extra', 'sample_extra'])
def test_container_membership_and_extra_validation(fault):
    b, summ, sa, bg, ev = fixture()
    extra = copy.deepcopy(bg[500]['containers']['data'][0])
    extra.update(Name='unrelated-service', ID='a' * 12)
    bg[500]['containers']['data'].append(extra)
    if fault == 'missing_project': bg[500]['containers']['data'].pop(0)
    elif fault == 'changed_identity': bg[500]['containers']['data'][0]['ID'] = 'b' * 12
    elif fault == 'duplicate_name': extra['Name'] = bg[500]['containers']['data'][0]['Name']
    elif fault == 'duplicate_id': extra['ID'] = bg[500]['containers']['data'][0]['ID']
    elif fault == 'invalid_extra': extra['CPUPerc'] = 'unknown'
    elif fault == 'sample_extra': sa[500]['stats']['data'].append(extra)
    with pytest.raises(ValueError):
        s.inspect(b, summ, sa, bg, ev)
