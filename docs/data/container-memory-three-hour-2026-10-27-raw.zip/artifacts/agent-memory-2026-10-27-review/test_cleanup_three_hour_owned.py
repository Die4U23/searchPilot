import importlib.util
import json
import sys
from pathlib import Path
import pytest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cleanup_three_hour_owned',HERE/'cleanup_three_hour_owned.py')
c=importlib.util.module_from_spec(spec)
sys.path.insert(0,str(HERE))
spec.loader.exec_module(c)


def test_check_only_never_mutates(monkeypatch, capsys):
    monkeypatch.setattr(c,'scan_archive',lambda *a:{'zip_sha256':'a'*64})
    monkeypatch.setattr(c,'verify_private_scan',lambda *a:{'status':'PASSED'})
    monkeypatch.setattr(c,'snapshot',lambda:{'containers':[]})
    monkeypatch.setattr(c,'docker',lambda *a:pytest.fail('unexpected docker mutation'))
    monkeypatch.setattr(sys,'argv',['cleanup','--archive','unused','--archive-sha256','a'*64,'--private-scan','scan.json','--check-only'])
    assert c.main()==0
    assert json.loads(capsys.readouterr().out)['status']=='READY_READ_ONLY'


def test_failed_archive_never_preflights_or_mutates(monkeypatch):
    def fail(*args): raise ValueError('bad archive')
    monkeypatch.setattr(c,'scan_archive',fail)
    monkeypatch.setattr(c,'snapshot',lambda:pytest.fail('snapshot after failed verification'))
    monkeypatch.setattr(sys,'argv',['cleanup','--archive','unused','--archive-sha256','a'*64,'--private-scan','scan.json','--check-only'])
    with pytest.raises(ValueError,match='bad archive'): c.main()


def test_refuses_output_reuse(monkeypatch,tmp_path):
    monkeypatch.setattr(c,'REVIEW',tmp_path)
    output=tmp_path/'prior.json'; output.write_text('unchanged')
    monkeypatch.setattr(c,'scan_archive',lambda *a:pytest.fail('archive checked despite output collision'))
    monkeypatch.setattr(sys,'argv',['cleanup','--archive','unused','--archive-sha256','a'*64,'--private-scan','scan.json','--out',str(output)])
    with pytest.raises(ValueError,match='new output'): c.main()
    assert output.read_text()=='unchanged'


def test_snapshot_rejects_extra_project_container(monkeypatch, tmp_path):
    root = tmp_path/'run'; (root/'final-three-hour').mkdir(parents=True)
    (root/'launcher.json').write_text(json.dumps({'status':'COMPLETED','observer_stopped':True}))
    ids=['a'*64,'b'*64]
    states=[{'Name':'/'+c.PROJECT+'-api-1','Id':ids[0]}, {'Name':'/'+c.PROJECT+'-db-1','Id':ids[1]}]
    (root/'final-three-hour'/'summary.json').write_text(json.dumps({'status':'COMPLETED','initial_state':states,'final_state':states}))
    monkeypatch.setattr(c,'ROOT',root)
    monkeypatch.setattr(c,'listing',lambda *args: set(ids)|{'c'*64})
    monkeypatch.setattr(c,'inspect',lambda *args:pytest.fail('inspection after unexpected container'))
    with pytest.raises(ValueError,match='unknown or missing project container'):
        c.snapshot()


def test_snapshot_rejects_running_or_unstopped(monkeypatch,tmp_path):
    root=tmp_path/'run'; (root/'final-three-hour').mkdir(parents=True)
    (root/'launcher.json').write_text(json.dumps({'status':'RUNNING','observer_stopped':False}))
    (root/'final-three-hour'/'summary.json').write_text('{}')
    monkeypatch.setattr(c,'ROOT',root)
    monkeypatch.setattr(c,'listing',lambda *args:pytest.fail('docker used for active run'))
    with pytest.raises(ValueError,match='not terminal'):
        c.snapshot()


def test_literal_token_rejected_and_source_expression_accepted(monkeypatch, tmp_path):
    import hashlib
    import zipfile
    root=tmp_path/'run'; root.mkdir()
    source=root/'source.py'
    monkeypatch.setattr(c,'ROOT',root)
    monkeypatch.setattr(c,'REPO',tmp_path)
    def make_zip(content, name):
        source.write_bytes(content)
        member='run/source.py'
        manifest={member:hashlib.sha256(content).hexdigest()}
        archive=tmp_path/name
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr(member,content)
            z.writestr('MANIFEST-SHA256.json',json.dumps(manifest))
            z.writestr('artifacts/agent-memory-2026-10-27/anchor.txt',b'anchor')
        # Include the required anchor in the same complete manifest.
        with zipfile.ZipFile(archive,'w') as z:
            z.writestr(member,content)
            z.writestr('artifacts/agent-memory-2026-10-27/anchor.txt',b'anchor')
            manifest['artifacts/agent-memory-2026-10-27/anchor.txt']=hashlib.sha256(b'anchor').hexdigest()
            z.writestr('MANIFEST-SHA256.json',json.dumps(manifest))
        return archive,hashlib.sha256(archive.read_bytes()).hexdigest()
    path,digest=make_zip(b'api_key=settings.agent_llm_api_key.get_secret_value','source.zip')
    assert c.scan_archive(path,digest)['sensitive_scan']=='PASSED_PATTERN_SCAN_ONLY'
    path,digest=make_zip(b'sk-proj-' + b'A'*30,'token.zip')
    with pytest.raises(ValueError,match='private-material pattern'):
        c.scan_archive(path,digest)


@pytest.mark.parametrize('change', ['status','hash','matches','zero','boolean'])
def test_private_scan_rejects_invalid_record(tmp_path, change):
    value={'status':'PASSED','archive_sha256':'a'*64,'matched_file_names':[],'credential_values_checked':1}
    if change=='status': value['status']='FAILED'
    elif change=='hash': value['archive_sha256']='b'*64
    elif change=='matches': value['matched_file_names']=['member']
    elif change=='zero': value['credential_values_checked']=0
    elif change=='boolean': value['credential_values_checked']=True
    path=tmp_path/'scan.json'; path.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='private exact-value scan'):
        c.verify_private_scan(path,'a'*64)


def test_private_scan_accepts_bound_passing_record(tmp_path):
    path=tmp_path/'scan.json'
    path.write_text(json.dumps({'status':'PASSED','archive_sha256':'a'*64,'matched_file_names':[],'credential_values_checked':2}))
    assert c.verify_private_scan(path,'a'*64)['credential_values_checked']==2
