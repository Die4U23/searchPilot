"""Launch exactly one declared three-hour run; --check is local/offline only."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from common import (
    BASE_IMAGE,
    BASELINE,
    DURATION,
    OLD,
    OUT,
    OUTER_TIMEOUT,
    PROJECT,
    QUERY,
    QUERY_SHA,
    RECOVERY,
    REPO,
    ROOT,
    load,
    now,
    read,
    require,
    sha,
    verify_local,
)


def command(image):
    return [
        sys.executable,
        "-m",
        "scripts.validate_container_soak",
        "--out",
        str(OUT),
        "--project",
        PROJECT,
        "--image",
        image,
        "--api-port",
        "18236",
        "--db-port",
        "15636",
        "--duration-seconds",
        str(DURATION),
        "--concurrency",
        "32",
        "--baseline-seconds",
        str(BASELINE),
        "--recovery-seconds",
        str(RECOVERY),
        "--queries",
        str(QUERY),
    ]


def atomic_record(path, record):
    temporary = path.with_suffix(".writing")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def progress_record(process):
    files = {}
    for name in (
        "summary.json",
        "soak.json",
        "soak.requests.jsonl",
        "samples.jsonl",
        "background.jsonl",
        "soak-console.txt",
    ):
        path = OUT / name
        if path.exists():
            stat = path.stat()
            files[name] = {"bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}
    # Do not repeatedly load the large benchmark JSON while finalization writes it.
    return {
        "at": now(),
        "harness_launcher_pid": process.pid,
        "harness_launcher_exit_code": process.poll(),
        "files": files,
    }


def image_configuration(image, observer, env):
    result = subprocess.run(
        [observer.DOCKER, "image", "inspect", image],
        cwd=REPO,
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=20,
        check=True,
        creationflags=observer.FLAGS,
    )
    info = json.loads(result.stdout)[0]
    config = info["Config"]
    native = dict(value.split("=", 1) for value in config.get("Env", []) if "=" in value)
    require(info["Id"] == image, "Image ID resolved differently")
    require(
        config.get("Cmd") == ["python", "scripts/docker_entrypoint.py"]
        and not config.get("Entrypoint"),
        "Normal entrypoint required",
    )
    expected = {"MALLOC_ARENA_MAX": "1", "SEARCHPILOT_DISABLE_THP": "true"}
    require(
        all(native.get(key) == value for key, value in expected.items()),
        "Image native environment is not arena1/THP-off",
    )
    for key in (
        "GLIBC_TUNABLES",
        "LD_PRELOAD",
        "PYTHONMALLOC",
        "PYTHONTRACEMALLOC",
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
    ):
        require(native.get(key) is None, "Unexpected native override: " + key)
        expected[key] = None
    return {
        "Id": image,
        "cmd": config["Cmd"],
        "entrypoint": config.get("Entrypoint"),
        "native_env": expected,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--image")
    parser.add_argument("--build-summary", type=Path)
    parser.add_argument("--preparation", type=Path, default=ROOT / "preparation-release.json")
    args = parser.parse_args(argv)
    require(args.preparation.resolve().parent == ROOT, "Preparation must be in artifact root")
    frozen = verify_local(args.preparation)
    if args.check:
        require(args.image is None, "--check never accepts an image or launches anything")
        print(
            json.dumps(
                {
                    "status": "PREPARED_NOT_LAUNCHED",
                    "sources": len(frozen["source_sha256"]),
                    "inputs": len(frozen["inputs_sha256"]),
                    "duration_seconds": DURATION,
                    "query_sha256": QUERY_SHA,
                    "external_calls": 0,
                }
            )
        )
        return 0
    require(
        isinstance(args.image, str) and re.fullmatch(r"sha256:[0-9a-f]{64}", args.image),
        "Supply an immutable --image ID after root builds it",
    )
    require(
        not frozen.get("image") or args.image == frozen["image"],
        "Image differs from release preparation binding",
    )
    require(args.build_summary is not None, "Root build evidence required via --build-summary")
    build = read(args.build_summary)
    require(
        build["image"] == args.image and build["base_image"] == BASE_IMAGE,
        "Build manifest image/base binding differs",
    )
    observer = load(OLD / "run_stability.py", "agent_memory_observer")
    observer.OUT, observer.PROJECT = OUT, PROJECT
    env = observer.clean_environment()
    env["PYTHONPATH"] = str(REPO)
    env["TMP"] = env["TEMP"] = str(REPO / ".tmp")
    config = image_configuration(args.image, observer, env)
    record_path, console_path = ROOT / "launcher.json", ROOT / "launcher-console.txt"
    pid_path, stop_path = ROOT / "harness.pid", ROOT / "harness.stop"
    progress_path = ROOT / "progress.jsonl"
    require(
        not any(
            path.exists()
            for path in (OUT, record_path, console_path, pid_path, stop_path, progress_path)
        ),
        "Refuse to reuse prior output or project evidence",
    )
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "stage": "preflight_complete",
        "project": PROJECT,
        "out": str(OUT),
        "image": args.image,
        "image_configuration": config,
        "command": command(args.image),
        "preparation": str(args.preparation.resolve()),
        "preparation_sha256": sha(args.preparation),
        "build_summary": str(args.build_summary.resolve()),
        "build_summary_sha256": sha(args.build_summary),
        "external_llm_calls": 0,
        "private_env_read": False,
        "outer_timeout_seconds": OUTER_TIMEOUT,
    }
    with record_path.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
    process = observer_thread = None
    stop, errors = threading.Event(), []
    try:
        wrapper = (
            "import os,sys,runpy,threading,time,_thread;from pathlib import Path;"
            f"p=Path({str(pid_path)!r});s=Path({str(stop_path)!r});"
            "p.open('x',encoding='ascii').write(str(os.getpid()));"
            "\ndef watch():\n while not s.exists(): time.sleep(0.2)\n _thread.interrupt_main()\n"
            "threading.Thread(target=watch,daemon=True).start();"
            "sys.argv=['scripts.validate_container_soak',*sys.argv[1:]];"
            "runpy.run_module('scripts.validate_container_soak',run_name='__main__')"
        )
        with (
            console_path.open("x", encoding="utf-8") as console,
            progress_path.open("x", encoding="utf-8") as progress,
        ):
            process = subprocess.Popen(
                [sys.executable, "-u", "-c", wrapper, *record["command"][3:]],
                cwd=REPO,
                env=env,
                stdout=console,
                stderr=subprocess.STDOUT,
                creationflags=observer.FLAGS,
            )
            registration = time.monotonic() + 15
            while not pid_path.exists() or not pid_path.read_text(encoding="ascii"):
                require(
                    process.poll() is None and time.monotonic() < registration,
                    "Harness worker failed to register",
                )
                time.sleep(0.1)
            pid = int(pid_path.read_text(encoding="ascii"))
            observer.bind_windows_worker(process, pid)
            record.update(stage="harness_registered", launcher_pid=process.pid, harness_pid=pid)
            atomic_record(record_path, record)
            observer_thread = threading.Thread(
                target=observer.observe,
                args=(stop, env, errors),
                name="memory-observer",
                daemon=True,
            )
            observer_thread.start()
            deadline = time.monotonic() + OUTER_TIMEOUT
            while True:
                checkpoint = progress_record(process)
                progress.write(json.dumps(checkpoint) + "\n")
                progress.flush()
                os.fsync(progress.fileno())
                record.update(stage="observing", last_progress=checkpoint)
                atomic_record(record_path, record)
                if process.poll() is not None:
                    break
                require(not errors, "Background observer failed")
                if time.monotonic() >= deadline:
                    raise TimeoutError("Outer harness deadline exceeded")
                stop.wait(10)
            record.update(stage="harness_exited", exit_code=process.returncode)
            atomic_record(record_path, record)
            require(
                process.returncode == 0 and read(OUT / "summary.json")["status"] == "COMPLETED",
                "Harness did not complete successfully",
            )
            require(read(OUT / "soak.json")["status"] == "COMPLETED", "Benchmark incomplete")
            require(
                verify_local(args.preparation) == frozen, "Frozen sources/inputs changed during run"
            )
            record["status"] = "COMPLETED"
    except BaseException as exc:
        record.update(
            status="INTERRUPTED" if isinstance(exc, KeyboardInterrupt) else "FAILED",
            error_type=type(exc).__name__,
        )
        if process is not None and process.poll() is None:
            stop_path.touch(exist_ok=False)
            try:
                process.wait(timeout=180)
                record["exception_shutdown"] = "cooperative"
            except subprocess.TimeoutExpired:
                record["exception_shutdown"] = "forced; retained evidence requires inspection"
        raise
    finally:
        if process is not None:
            try:
                observer.stop_owned_process(process)
            except BaseException as exc:
                record.update(status="FAILED", cleanup_error=type(exc).__name__)
            record["final_process_exit_code"] = process.poll()
        stop.set()
        if observer_thread is not None:
            observer_thread.join(timeout=20)
        record.update(
            observer_stopped=observer_thread is None or not observer_thread.is_alive(),
            observer_errors=errors,
            finished_at=now(),
            stage="finished",
        )
        if errors or not record["observer_stopped"]:
            record["status"] = "FAILED"
        atomic_record(record_path, record)
        print(json.dumps({"status": record["status"], "finished_at": record["finished_at"]}))
    return int(record["status"] != "COMPLETED")


if __name__ == "__main__":
    raise SystemExit(main())
