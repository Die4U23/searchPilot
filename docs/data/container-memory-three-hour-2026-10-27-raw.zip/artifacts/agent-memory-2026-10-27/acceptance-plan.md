# Agent 当前源码与 arena1 正常入口三小时验证

状态：PREPARED_NOT_LAUNCHED。准备不代表构建、运行或验收通过。

固定参数：10800 秒正式闭环负载、c32、四模式轮转、limit10、每请求总超时10秒、
16次独立预热、基线60秒、恢复600秒。使用1300条冻结查询，SHA256
`7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6`。
新项目 `sp-agent-memory-20261027`，API18236/PG15636、新独立卷，输出 `final-three-hour`。
全部输出独占创建；保留旧两小时原始证据；任何容器/卷清理均须先完成独立归档与校验。

根线程构建并传入不可变镜像ID：在不可变e858基镜像上COPY当前冻结src/scripts，
MALLOC_ARENA_MAX=1、SEARCHPILOT_DISABLE_THP=true，正常docker_entrypoint。
继承原依赖/模型，仅补充基镜像缺少的已声明Agent依赖httpx0.28.1、httpcore1.0.9、
certifi2026.10.23；不下载模型、不加载私有.env、不调用外部LLM，不改变线程环境默认值。
显式PYTHONPATH=/app/src使用新复制源码。Agent冻结来源使用
`artifacts/agent-multistep-2026-10-27-release/source-snapshot.json`，原v1/v2/final及准备记录保留。
本次绑定镜像为
`sha256:b8c42b9b10d167dbd4fc9cd5fa4cbbfd6cae4e40102ee4343347978b27903b08`；
使用新的 `preparation-release.json`，发布评分器修正不冒充新增模型调用或旧实验通过。
运行前核对Agent source-snapshot、完整src/scripts集合、公开配置、原29项数据/模型输入、
查询字节、镜像ID/Cmd/native environment；保留构建清单与镜像配置白名单。

正式窗口严格[0,10800)，稳定窗口固定[3600,10800)，RSS和Anonymous分别全部满足：

1. 稳定窗口端点增长<=2MiB，OLS<=0.03MiB/分钟。
2. 稳定窗口首10分钟与末10分钟中位数之差<=2MiB。
3. 稳定窗口全部24个固定5分钟窗口中位数最大减最小<=2MiB。
4. 从3600开始每300秒滑动的全部21个20分钟窗口，增长<=2MiB、OLS<=0.1MiB/分钟。
5. 每个固定/滑动窗口至少floor(duration/10)-2点，首末误差<=10秒、最大间隔<=15秒。

完整报告前三小时、每小时、原前两小时、每5/20分钟、所有稳定滑窗、末10/20分钟及恢复。
不排除前两小时，不因末窗回落放宽门槛。PSS/VmData/cgroup/客户端资源分别描述。
有限固定负载筛查不证明零泄漏、任意部署稳定或容量SLA。

独立宿主观察线程每约10秒记录PID1身份/公开环境、全部Docker stats、Linux loadavg、
Windows CPU/内存；该观察器不发HTTP。harness执行原采样、健康探针、17项业务与重启持久性。
PID1实际读取时刻位于docker exec started_at..finished_at；宿主派发时刻不是原子采样时刻。
正式观察至少1078点，首末/间隔同上，PID1 start ticks须与正式内存样本一致；
所有正式来源、health七组件、THP/swap/OOM/restart均按完整证据检查，不补零。

必须launcher/harness/bench全部完成且退出0、observer_stopped=true且observer_errors=[]，
然后从原始账本重算全部请求配对、预热、失败、unknown、并发32、1300x4=5200组；
每组至少12次正式成功、每组result/ranking/model/count指纹稳定，并与arena1筛选组逐组相同。
外层持久化progress.jsonl每10秒记录子进程状态及输出文件尺寸/修改时间，定期原子保存launcher。
中断保留RUNNING/FAILED/INTERRUPTED及最后进度，绝不伪造完成或回填缺失结果。
旧终止根因仍UNKNOWN；本轮没有修改benchmark，也不宣称修复了未经复现的旧故障。

准备检查：`python artifacts/agent-memory-2026-10-27/launch.py --check`。
根线程交付镜像后：`python artifacts/agent-memory-2026-10-27/launch.py --image sha256:... --build-summary ...`。
完整运行后：`python artifacts/agent-memory-2026-10-27/audit.py --out artifacts/agent-memory-2026-10-27/audit-result.json`。
audit输出独占创建；失败后选择新文件名复核，不覆盖原判定。
