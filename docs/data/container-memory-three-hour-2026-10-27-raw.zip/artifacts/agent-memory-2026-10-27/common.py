"""Frozen evidence helpers. Imports do not launch containers, HTTP or applications."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
sys.path.insert(0, str(REPO))
OLD = REPO / "artifacts/arena1-normal-2026-10-26"
SOURCE_SNAPSHOT = REPO / "artifacts/agent-multistep-2026-10-27-release/source-snapshot.json"
QUERY = OLD / "fixture/queries.csv"
QUERY_SHA = "7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6"
BASE_IMAGE = "sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1"
PROJECT = "sp-agent-memory-20261027"
OUT = ROOT / "final-three-hour"
DURATION, BASELINE, RECOVERY = 10800, 60, 600
OUTER_TIMEOUT = DURATION + BASELINE + RECOVERY + 1800


def now():
    return datetime.now(UTC).isoformat()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, "Cannot import offline helper")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_local(preparation=ROOT / "preparation-release.json"):
    frozen = read(preparation)
    snapshot = REPO / frozen.get(
        "agent_source_snapshot_path", str(SOURCE_SNAPSHOT.relative_to(REPO))
    )
    require(sha(QUERY) == QUERY_SHA, "Frozen query bytes changed")
    for name, digest in frozen["bound_files"].items():
        require(sha(REPO / name) == digest, "Bound file changed: " + name)
    paths = sorted([*REPO.glob("src/**/*.py"), *REPO.glob("scripts/*.py")])
    actual = {path.relative_to(REPO).as_posix(): sha(path) for path in paths}
    require(actual == frozen["source_sha256"], "Complete src/scripts membership or bytes changed")
    require(read(snapshot) == frozen["agent_source_snapshot"], "Agent snapshot changed")
    for name, digest in frozen["agent_source_snapshot"].items():
        require(sha(REPO / name) == digest, "Agent source changed: " + name)
    for name, digest in frozen["inputs_sha256"].items():
        require(sha(REPO / name) == digest, "Frozen input changed: " + name)
    return frozen
