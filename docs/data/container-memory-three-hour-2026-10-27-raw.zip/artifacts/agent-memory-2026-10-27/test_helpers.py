"""Offline adversarial fixtures; no Docker, external HTTP, models or loads."""

from __future__ import annotations

import copy
import json
from datetime import UTC, datetime, timedelta

import audit as acceptance
import launch
import pytest
from common import DURATION
from scripts.audit_memory_stability import MIB, audit

START = datetime(2026, 10, 27, tzinfo=UTC)


def at(seconds):
    return (START + timedelta(seconds=seconds)).isoformat()


def evidence():
    requests = [{"dispatched_ms": second * 1000, "elapsed_ms": 1000} for second in range(DURATION)]
    bench = {
        "status": "COMPLETED",
        "config": {"duration_seconds": DURATION},
        "runs": [
            {
                "mode": "mixed",
                "dispatch_window_seconds": DURATION,
                "started_at": at(0),
                "finished_at": at(DURATION),
                "last_dispatch_seconds": DURATION - 1,
                "summary": {"elapsed_seconds": DURATION, "total": len(requests)},
                "requests": requests,
            }
        ],
    }
    samples, background = [], []
    environment = {
        key: None
        for key in (
            "GLIBC_TUNABLES",
            "LD_PRELOAD",
            "PYTHONMALLOC",
            "PYTHONTRACEMALLOC",
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
        )
    }
    environment.update(MALLOC_ARENA_MAX="1", SEARCHPILOT_DISABLE_THP="true")
    for second in range(0, DURATION, 10):
        identity = {"pid": 1, "start_time_ticks": 1234}
        sources = {
            "stat": identity.copy(),
            "stat_after": identity.copy(),
            "smaps_rollup": {
                "Rss_bytes": 1000 * MIB,
                "Pss_bytes": 990 * MIB,
                "Anonymous_bytes": 900 * MIB,
            },
            "status": {"VmData_bytes": 3000 * MIB, "THP_enabled": 0, "VmSwap_bytes": 0},
            "cgroup_memory_current": {"bytes": 1100 * MIB},
            "cgroup_memory_events": {"oom": 0},
            "cmdline": {},
            "fd": {},
            "cgroup_membership": {},
            "cgroup_memory_peak": {},
            "cgroup_memory_stat": {},
        }
        checks = {
            key: True
            for key in ("search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database")
        }
        samples.append(
            {
                "at": at(second),
                "phase": "load",
                "server": {
                    "pid": 1,
                    "at": at(second + 0.1),
                    "available": True,
                    "identity_consistent": True,
                    "sources": {
                        key: {"available": True, "data": value} for key, value in sources.items()
                    },
                    "errors": {},
                },
                "live": {"available": True, "status": 200},
                "ready": {"available": True, "status": 200, "body": {"checks": checks}},
            }
        )
        background.append(
            {
                "at": at(second),
                "observation_seconds": 0.5,
                "pid1_runtime": {
                    "available": True,
                    "started_at": at(second + 0.1),
                    "finished_at": at(second + 0.4),
                    "seconds": 0.3,
                    "data": json.dumps({**identity, "environment": environment}),
                },
                **{
                    key: {"available": True}
                    for key in ("windows_host", "containers", "linux_loadavg")
                },
            }
        )
    return bench, samples, background


def test_three_hours_retain_all_original_limits_and_windows():
    bench, samples, _ = evidence()
    report = audit(bench, samples, duration_seconds=DURATION, stable_after_seconds=3600)
    assert report["status"] == "PASSED"
    assert report["windows"]["full_dispatch"]["count"] == 1080
    assert report["windows"]["stable"]["count"] == 720
    assert len(report["windows"]["stable_five_minutes"]) == 24
    assert len(report["windows"]["rolling_twenty_minutes"]) == 21
    assert report["limits"]["stable_ols_mib_per_minute"] == 0.03
    assert report["limits"]["stable_growth_mib"] == 2


@pytest.mark.parametrize("metric", ["Rss_bytes", "Anonymous_bytes"])
def test_second_hour_failure_cannot_hide_in_flat_final_hour(metric):
    bench, samples, _ = evidence()
    for row in samples[420:480]:
        row["server"]["sources"]["smaps_rollup"]["data"][metric] += 5 * MIB
    report = audit(bench, samples, duration_seconds=DURATION)
    name = "rss" if metric == "Rss_bytes" else "anonymous"
    assert report["windows"]["last_twenty"]["metrics"][name]["growth_mib"] == 0
    assert report["status"] == "FAILED"
    assert report["gates"][name]["checks"]["five_minute_median_range"] is False


def test_missing_middle_coverage_cannot_pass():
    bench, samples, _ = evidence()
    del samples[500]
    assert audit(bench, samples, duration_seconds=DURATION)["status"] == "FAILED"


def test_pid1_identity_and_full_three_hour_coverage():
    _, samples, background = evidence()
    report = acceptance.pid1_probes(background, samples, START.timestamp())
    assert report["count"] == 1080 and report["window"] == [0, 10800]


@pytest.mark.parametrize("fault", ["missing", "environment", "identity", "gap", "background"])
def test_bad_independent_observer_fails(fault):
    _, samples, background = evidence()
    if fault == "missing":
        background = background[:-10]
    elif fault == "gap":
        del background[500]
    elif fault == "background":
        background[500]["windows_host"]["available"] = False
    else:
        data = json.loads(background[500]["pid1_runtime"]["data"])
        if fault == "environment":
            data["environment"]["MALLOC_ARENA_MAX"] = "2"
        else:
            data["start_time_ticks"] = 5678
        background[500]["pid1_runtime"]["data"] = json.dumps(data)
    with pytest.raises(ValueError):
        acceptance.pid1_probes(background, samples, START.timestamp())


@pytest.mark.parametrize("fault", ["ready", "source", "thp", "swap", "oom"])
def test_bad_health_and_memory_source_fails(fault):
    _, samples, _ = evidence()
    row = samples[500]
    if fault == "ready":
        row["ready"]["body"]["checks"]["ltr"] = False
    elif fault == "source":
        row["server"]["sources"]["fd"]["available"] = False
    elif fault == "oom":
        row["server"]["sources"]["cgroup_memory_events"]["data"]["oom"] = 1
    else:
        key = "THP_enabled" if fault == "thp" else "VmSwap_bytes"
        row["server"]["sources"]["status"]["data"][key] = 1
    with pytest.raises(ValueError):
        acceptance.health(samples, START.timestamp())


def test_fingerprints_match_every_group_with_minimum_repeats():
    expected = {
        (f"q{index}", mode): ("result", "ranking", "model", 10)
        for index in range(1300)
        for mode in ("bm25", "vector", "hybrid", "ltr")
    }

    def events(repeats):
        for (query, mode), values in expected.items():
            for _ in range(repeats):
                yield {
                    "event": "result",
                    "phase": "measured",
                    "outcome": "success",
                    "query": query,
                    "mode": mode,
                    **dict(
                        zip(
                            ("result_sha256", "ranking_sha256", "model_version", "result_count"),
                            values,
                            strict=True,
                        )
                    ),
                }

    assert acceptance.fingerprints(events(12), expected)["groups"] == 5200
    with pytest.raises(ValueError, match="12 successes"):
        acceptance.fingerprints(events(11), expected)
    mismatched = copy.deepcopy(expected)
    mismatched[("q0", "bm25")] = ("wrong", "ranking", "model", 10)
    with pytest.raises(ValueError, match="comparison differs"):
        acceptance.fingerprints(events(12), mismatched)


def test_check_mode_does_not_invoke_docker(monkeypatch, capsys):
    monkeypatch.setattr(
        launch, "verify_local", lambda *args: {"source_sha256": {}, "inputs_sha256": {}}
    )
    monkeypatch.setattr(launch.subprocess, "run", lambda *a, **k: pytest.fail("Docker called"))
    assert launch.main(["--check"]) == 0
    assert json.loads(capsys.readouterr().out)["status"] == "PREPARED_NOT_LAUNCHED"


def test_incomplete_outer_launcher_cannot_pass(monkeypatch):
    monkeypatch.setattr(acceptance, "verify_local", lambda: {})
    monkeypatch.setattr(acceptance, "read", lambda path: {"status": "RUNNING"})
    with pytest.raises(ValueError, match="outer launcher"):
        acceptance.audit_folder()


def test_launch_parameters_are_exact():
    argv = launch.command("sha256:" + "0" * 64)
    assert argv[argv.index("--duration-seconds") + 1] == "10800"
    assert argv[argv.index("--concurrency") + 1] == "32"
    assert argv[argv.index("--project") + 1] == "sp-agent-memory-20261027"
    assert argv[argv.index("--api-port") + 1] == "18236"
    assert argv[argv.index("--db-port") + 1] == "15636"


@pytest.mark.parametrize("changed", [False, True])
def test_image_preflight_checks_exact_id_and_native_settings(monkeypatch, changed):
    class Observer:
        DOCKER = "unused-offline"
        FLAGS = 0

    class Result:
        stdout = json.dumps(
            [
                {
                    "Id": "sha256:" + "a" * 64,
                    "Config": {
                        "Cmd": ["python", "scripts/docker_entrypoint.py"],
                        "Entrypoint": None,
                        "Env": [
                            "MALLOC_ARENA_MAX=" + ("2" if changed else "1"),
                            "SEARCHPILOT_DISABLE_THP=true",
                        ],
                    },
                }
            ]
        )

    monkeypatch.setattr(launch.subprocess, "run", lambda *a, **kw: Result())
    if changed:
        with pytest.raises(ValueError, match="arena1"):
            launch.image_configuration("sha256:" + "a" * 64, Observer(), {})
    else:
        assert (
            launch.image_configuration("sha256:" + "a" * 64, Observer(), {})["native_env"][
                "MALLOC_ARENA_MAX"
            ]
            == "1"
        )
