"""Strict offline acceptance for one completed three-hour run; never invokes Docker/HTTP."""

from __future__ import annotations

import argparse
import json
import math
from datetime import datetime
from pathlib import Path

from common import (
    DURATION,
    OLD,
    OUT,
    PROJECT,
    QUERY,
    QUERY_SHA,
    REPO,
    ROOT,
    load,
    read,
    require,
    sha,
    verify_local,
)
from scripts.audit_memory_stability import audit as audit_resources
from scripts.audit_memory_stability import window
from scripts.summarize_soak import summarize


def timestamp(value):
    parsed = datetime.fromisoformat(value)
    require(parsed.tzinfo is not None, "Timestamp requires timezone")
    return parsed.timestamp()


def read_lines(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def pid1_probes(background, samples, start):
    probes, previous = [], None
    expected = {
        key: None
        for key in (
            "GLIBC_TUNABLES",
            "LD_PRELOAD",
            "PYTHONMALLOC",
            "PYTHONTRACEMALLOC",
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
        )
    }
    expected.update(MALLOC_ARENA_MAX="1", SEARCHPILOT_DISABLE_THP="true")
    for row in background:
        row_at = timestamp(row["at"])
        require(previous is None or row_at > previous, "Observer rows not strictly increasing")
        previous = row_at
        probe = row["pid1_runtime"]
        began, ended = timestamp(probe["started_at"]), timestamp(probe["finished_at"])
        elapsed = began - start
        if not 0 <= elapsed < DURATION:
            continue
        seconds, whole = probe["seconds"], row["observation_seconds"]
        require(
            all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in (seconds, whole))
            and row_at <= began <= ended <= row_at + whole + 1
            and abs(ended - began - seconds) <= 1,
            "PID1 probe interval inconsistent",
        )
        require(probe.get("available") is True, "Formal PID1 probe missing")
        data = json.loads(probe["data"]) if isinstance(probe["data"], str) else probe["data"]
        require(
            type(data.get("pid")) is int
            and data["pid"] == 1
            and data.get("environment") == expected,
            "Actual PID1 environment changed",
        )
        ticks = data.get("start_time_ticks")
        require(type(ticks) is int and ticks >= 0, "PID1 identity absent")
        require(not probes or elapsed > probes[-1][0], "Probe times not strictly increasing")
        require(
            all(
                row.get(name, {}).get("available") is True
                for name in ("windows_host", "containers", "linux_loadavg")
            ),
            "Formal independent background observation missing",
        )
        probes.append((elapsed, ticks))
    require(len(probes) >= 1078, "Fewer than 1078 independent formal PID1 observations")
    gaps = [b[0] - a[0] for a, b in zip(probes, probes[1:], strict=False)]
    require(
        probes[0][0] <= 10 and probes[-1][0] >= 10790 and all(0 < gap <= 15 for gap in gaps),
        "PID1 boundary/gap coverage incomplete",
    )
    identities = {
        row["server"]["sources"]["stat"]["data"]["start_time_ticks"]
        for row in samples
        if 0 <= timestamp(row["at"]) - start < DURATION
    }
    require(
        identities == {value for _, value in probes} and len(identities) == 1,
        "Independent probes and memory samples identify different/changing PID1",
    )
    return {
        "count": len(probes),
        "start_time_ticks": probes[0][1],
        "first_seconds": probes[0][0],
        "last_seconds": probes[-1][0],
        "maximum_gap_seconds": max(gaps),
        "window": [0, DURATION],
        "scope": "Actual read occurs inside exec started_at..finished_at",
    }


def business(summary, frozen):
    require(
        summary["status"] == "COMPLETED" and summary["soak_exit_code"] == 0,
        "Harness completion/benchmark exit missing",
    )
    config = summary["config"]
    require(
        config["project"] == PROJECT
        and config["duration_seconds"] == DURATION
        and config["concurrency"] == 32
        and config["baseline_seconds"] == 60
        and config["recovery_seconds"] == 600
        and config["api_port"] == 18236
        and config["db_port"] == 15636,
        "Harness configuration differs",
    )
    requests = summary["requests"]
    require(
        len(requests) == 17
        and len({row["label"] for row in requests}) == 17
        and all(
            row["status"] == "completed" and row["http_status"] == row["expected_status"]
            for row in requests
        ),
        "All 17 distinct business checks must complete",
    )
    by_label = {row["label"]: row["response"] for row in requests}
    for mode in ("bm25", "vector", "hybrid", "ltr"):
        left, right = by_label["initial_" + mode], by_label["recovery_" + mode]
        require(
            {k: v for k, v in left.items() if k != "request_id"}
            == {k: v for k, v in right.items() if k != "request_id"},
            "Recovery search changed: " + mode,
        )
    created = by_label["feedback_create"]
    require(created["replayed"] is False, "Initial feedback unexpectedly replayed")
    for name in ("feedback_replay", "feedback_after_restart"):
        require(
            by_label[name]["replayed"] is True
            and by_label[name]["event_id"] == created["event_id"],
            "Feedback idempotence/restart persistence failed",
        )
    require(
        summary["final_counts"] == {**summary["initial_counts"], "feedback_events": 1},
        "Unexpected final database counts",
    )
    require(
        summary["stopped_state"][0]["State"]["ExitCode"] == 0,
        "Planned API stop did not exit cleanly",
    )
    for state_name in ("initial_state", "final_state"):
        states = summary[state_name]
        require(len(states) == 2, "Expected API and database container states")
        api = next(row for row in states if row["Name"].lstrip("/") == PROJECT + "-api-1")
        require(
            api["Image"] == summary["image"]
            and api["native_env"]["MALLOC_ARENA_MAX"] == "1"
            and api["native_env"]["SEARCHPILOT_DISABLE_THP"] == "true",
            "Actual API image/native configuration differs",
        )
    for row in summary["final_state"]:
        require(
            row["State"]["Running"] is True
            and row["State"]["OOMKilled"] is False
            and row["RestartCount"] == 0,
            "Unexpected final container state",
        )
    require(
        summary["local_source_sha256"] == frozen["source_sha256"],
        "Harness measured different local source",
    )
    expected = {
        name: value
        for name, value in frozen["source_sha256"].items()
        if name.startswith("src/")
        or name
        in {
            "scripts/" + name
            for name in (
                "docker_entrypoint.py",
                "docker_seed.py",
                "seed_items.py",
                "seed_catalog.py",
            )
        }
    }
    require(summary["container_source_sha256"] == expected, "Container source mismatch")
    require(
        summary["imported_source"]["sha256"]
        == {name: value for name, value in expected.items() if name.startswith("src/")},
        "Imported package source mismatch",
    )
    return {"checks": 17, "feedback_restart_persistent": True, "source_verified": True}


def health(samples, start):
    formal = [row for row in samples if 0 <= timestamp(row["at"]) - start < DURATION]
    for row in formal:
        require(row["phase"] == "load", "Nonload sample in formal window")
        require(
            all(
                row[endpoint].get("available") is True and row[endpoint]["status"] == 200
                for endpoint in ("live", "ready")
            ),
            "Formal health failed",
        )
        checks = row["ready"]["body"]["checks"]
        require(
            set(checks)
            == {"search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database"}
            and all(value is True for value in checks.values()),
            "Ready seven-component check failed",
        )
        server = row["server"]
        require(
            not server["errors"]
            and len(server["sources"]) == 11
            and all(source["available"] is True for source in server["sources"].values()),
            "Formal memory source unavailable",
        )
        status = server["sources"]["status"]["data"]
        require(
            all(
                type(status[key]) is int and status[key] == 0
                for key in ("THP_enabled", "VmSwap_bytes")
            ),
            "Formal THP/swap changed",
        )
        require(
            all(
                type(value) is int and value == 0
                for value in server["sources"]["cgroup_memory_events"]["data"].values()
            ),
            "Formal cgroup memory event nonzero",
        )
    return {"formal_samples": len(formal), "all_health_and_sources_available": True}


def fingerprints(events, expected):
    actual, counts = {}, {}
    for row in events:
        if row.get("event") != "result":
            continue
        require(row.get("outcome") == "success", "Unsuccessful result")
        key = row["query"], row["mode"]
        value = tuple(
            row[name]
            for name in ("result_sha256", "ranking_sha256", "model_version", "result_count")
        )
        require(key not in actual or actual[key] == value, "Fingerprint unstable")
        actual[key] = value
        if row["phase"] == "measured":
            counts[key] = counts.get(key, 0) + 1
    require(actual == expected and len(actual) == 5200, "Screening fingerprint comparison differs")
    require(
        set(counts) == set(expected) and min(counts.values()) >= 12,
        "Every formal query-mode group needs at least 12 successes",
    )
    return {
        "groups": len(actual),
        "minimum_formal_successes": min(counts.values()),
        "all_result_ranking_model_count_equal": True,
    }


def screening_expected():
    gate = load(OLD / "candidate_gate.py", "agent_memory_screening_gate")
    binding = gate.screening_binding(gate.CONTROL / "arena-comparison.json", replay=True)
    require(binding == read(OLD / "screening-binding.json"), "Historical screening binding changed")
    tool = gate.comparator()
    _, _, expected = tool.audit_case(
        gate.CONTROL,
        "arena1-treatment-01",
        1,
        tool.frozen_setup(gate.CONTROL),
        tool.load_base(gate.CONTROL),
    )
    return expected, binding


def audit_folder(folder=OUT):
    launcher = read(ROOT / "launcher.json")
    require(
        launcher["status"] == "COMPLETED"
        and launcher["exit_code"] == 0
        and launcher["final_process_exit_code"] == 0
        and launcher["observer_stopped"] is True
        and launcher["observer_errors"] == [],
        "Complete outer launcher required",
    )
    preparation = Path(launcher["preparation"])
    require(preparation.resolve().parent == ROOT, "Preparation path escaped artifact root")
    frozen = verify_local(preparation)
    require(
        launcher["preparation_sha256"] == sha(preparation)
        and sha(Path(launcher["build_summary"])) == launcher["build_summary_sha256"],
        "Launcher input bindings changed",
    )
    progress = read_lines(ROOT / "progress.jsonl")
    require(
        progress
        and progress[-1]["harness_launcher_exit_code"] == 0
        and all(row["harness_launcher_pid"] == launcher["launcher_pid"] for row in progress),
        "Durable launcher progress/exit identity missing",
    )
    times = [timestamp(row["at"]) for row in progress]
    require(
        timestamp(launcher["started_at"])
        <= times[0]
        <= times[-1]
        <= timestamp(launcher["finished_at"])
        and all(b > a for a, b in zip(times, times[1:], strict=False)),
        "Launcher progress timestamps inconsistent",
    )
    bench, summary = read(folder / "soak.json"), read(folder / "summary.json")
    require(bench["status"] == "COMPLETED", "Complete benchmark required")
    require(
        summary["image"] == launcher["image"] == launcher["image_configuration"]["Id"],
        "Actual container image differs from launcher",
    )
    require(
        sha(folder / "queries.csv") == sha(folder / "soak.queries.csv") == QUERY_SHA,
        "Executed query snapshot differs",
    )
    start = timestamp(bench["runs"][0]["started_at"])
    events = read_lines(folder / "soak.requests.jsonl")
    samples, background = (
        read_lines(folder / "samples.jsonl"),
        read_lines(folder / "background.jsonl"),
    )
    ledger = summarize(
        bench, events, duration_seconds=DURATION, samples=samples, queries=QUERY, min_repeats=12
    )
    require(
        ledger["status"] == "PASSED"
        and ledger["coverage"]["verified"] is True
        and ledger["inflight"]["peak"] == 32,
        "Recomputed ledger/coverage/concurrency failed",
    )
    for phase in ("warmup", "measured"):
        counts = ledger["phases"][phase]
        require(
            counts["issued"] == counts["success"] > 0
            and counts["unknown"] == counts["failed"] == 0,
            "Failed or unknown requests in " + phase,
        )
    resource = audit_resources(bench, samples, duration_seconds=DURATION, stable_after_seconds=3600)
    expected, binding = screening_expected()
    # Resource failure is reported alongside complete accounting, without relaxing any gate.
    report = {
        "status": "PASSED" if resource["status"] == "PASSED" else "FAILED",
        "scope": "finite_three_hour_normal_container_acceptance",
        "resource_stability": resource,
        "ledger": ledger,
        "screening_binding": binding,
        "semantics": fingerprints(events, expected),
        "business": business(summary, frozen),
        "health": health(samples, start),
        "pid1_runtime": pid1_probes(background, samples, start),
        "external_llm_calls": 0,
        "production_memory_leak_absence_proved": False,
    }
    normalized = [
        {
            "seconds": timestamp(row["at"]) - start,
            "values": {
                name: row["server"]["sources"][source]["data"][key] / 1048576
                for name, (source, key) in {
                    "rss": ("smaps_rollup", "Rss_bytes"),
                    "anonymous": ("smaps_rollup", "Anonymous_bytes"),
                    "pss": ("smaps_rollup", "Pss_bytes"),
                    "vmdata": ("status", "VmData_bytes"),
                    "cgroup_current": ("cgroup_memory_current", "bytes"),
                }.items()
            },
        }
        for row in samples
        if row["phase"] == "load"
    ]
    report["additional_windows"] = {
        "first_two_hours": window(normalized, 0, 7200),
        "hours": [window(normalized, start, start + 3600) for start in range(0, DURATION, 3600)],
        "fixed_twenty_minutes": [
            window(normalized, start, start + 1200) for start in range(0, DURATION, 1200)
        ],
    }
    report["evidence_sha256"] = {
        path.relative_to(REPO).as_posix(): sha(path)
        for path in [
            ROOT / "launcher.json",
            ROOT / "progress.jsonl",
            preparation,
            folder / "soak.json",
            folder / "summary.json",
            folder / "soak.requests.jsonl",
            folder / "samples.jsonl",
            folder / "background.jsonl",
        ]
    }
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    require(
        args.out.resolve().parent == ROOT and not args.out.exists(),
        "Audit output must be a new file directly in artifact folder",
    )
    try:
        report = audit_folder()
    except (ValueError, KeyError, TypeError, OSError, IndexError, StopIteration) as exc:
        report = {
            "status": "FAILED",
            "scope": "incomplete_or_invalid_evidence",
            "errors": [type(exc).__name__ + ": " + str(exc)],
            "production_memory_leak_absence_proved": False,
        }
    with args.out.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(json.dumps({"status": report["status"], "scope": report["scope"]}))
    return int(report["status"] != "PASSED")


if __name__ == "__main__":
    raise SystemExit(main())
