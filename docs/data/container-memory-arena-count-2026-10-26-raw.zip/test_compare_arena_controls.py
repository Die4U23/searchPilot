"""Bounded offline counterexamples; never starts a service or makes a request."""

import ast
import copy
import json
import sys
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_arena_controls as audit  # noqa: E402


def test_expected_command_matches_actual_driver_entry():
    tree = ast.parse((audit.ROOT / "diagnostic_arena_case.py").read_text(encoding="utf-8"))
    prefixes = [
        ast.literal_eval(node.value)
        for node in ast.walk(tree)
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "prefix" for target in node.targets)
    ]
    assert len(prefixes) == 1
    assert ["python", "-c", prefixes[0]] == audit.COMMAND


def values():
    return (
        {
            "warmup": 100 * audit.MIB,
            "after_5200": 107 * audit.MIB,
            "after_20800": 110 * audit.MIB,
            "idle": 110 * audit.MIB,
            "throughput": 100,
            "p95_ms": 100,
        },
        {
            "warmup": 200 * audit.MIB,
            "after_5200": 205 * audit.MIB,
            "after_20800": 208 * audit.MIB,
            "idle": 208 * audit.MIB,
            "throughput": 80,
            "p95_ms": 125,
        },
    )


def test_exact_thresholds_inclusive():
    assert audit.screening(*values())["passed"]


@pytest.mark.parametrize("endpoint", ["after_20800", "idle"])
def test_one_byte_short_rejected(endpoint):
    control, treatment = values()
    treatment[endpoint] += 1
    assert "MEMORY_BENEFIT:" + endpoint in audit.screening(control, treatment)["failures"]


def test_two_mib_is_not_twenty_percent_for_large_baseline():
    control, treatment = values()
    control["after_20800"] += 10 * audit.MIB
    treatment["after_20800"] += 10 * audit.MIB
    assert "MEMORY_BENEFIT:after_20800" in audit.screening(control, treatment)["failures"]


@pytest.mark.parametrize("delta", [0, -1])
def test_nonpositive_baseline_not_eligible(delta):
    control, treatment = values()
    control["idle"] = control["warmup"] + delta
    treatment["idle"] = 0
    assert "INSUFFICIENT_BASELINE_GROWTH:idle" in audit.screening(control, treatment)["failures"]


def test_late_growth_boundary_is_inclusive():
    control, treatment = values()
    treatment["after_5200"] = 204 * audit.MIB
    assert audit.screening(control, treatment)["passed"]
    treatment["after_5200"] -= 1
    assert "LATE_MEMORY_REGRESSION" in audit.screening(control, treatment)["failures"]


@pytest.mark.parametrize(
    "field,value,reason",
    [
        ("throughput", 79.999999, "THROUGHPUT_REGRESSION"),
        ("p95_ms", 125.000001, "P95_REGRESSION"),
    ],
)
def test_performance_gate_not_rounded(field, value, reason):
    control, treatment = values()
    treatment[field] = value
    assert reason in audit.screening(control, treatment)["failures"]


@pytest.mark.parametrize(
    "field,value",
    [
        ("idle", None),
        ("idle", float("nan")),
        ("idle", True),
        ("idle", -1),
        ("p95_ms", 0),
        ("throughput", float("inf")),
    ],
)
def test_missing_or_invalid_metric_cannot_pass(field, value):
    control, treatment = values()
    treatment[field] = value
    with pytest.raises(ValueError):
        audit.screening(control, treatment)


@pytest.mark.parametrize("raw", ['{"a":1,"a":2}', '{"x":NaN}', '{"x":Infinity}'])
def test_ambiguous_json_rejected(raw):
    with pytest.raises(ValueError):
        audit.parse(raw)


@pytest.fixture
def base(tmp_path):
    setup = tmp_path / "setup"
    setup.mkdir()
    source = audit.ROOT / "baseline-sources/scripts/bench_concurrent.py"
    (setup / "bench_concurrent.executed.py").write_bytes(source.read_bytes())
    before = set(sys.modules)
    result = audit.load_base(tmp_path)
    assert "scripts.bench_concurrent" not in set(sys.modules) - before
    return result


def test_frozen_parser_preserves_real_20800_ledger_contract(base, tmp_path):
    queries = ["query-" + str(i) for i in range(1300)]
    events, measured = [], []
    at = "2026-10-26T00:00:00+00:00"

    def record(i, phase):
        mode = base.MODES[i % 4] if phase == "measured" else base.MODES[i // 4]
        query = queries[(i // 4) % 1300] if phase == "measured" else queries[i % 4]
        return {
            "request_id": phase + str(i),
            "index": i,
            "phase": phase,
            "mode": mode,
            "query": query,
            "at": at,
            "dispatched_ms": i if phase == "measured" else None,
        }

    def pending(r):
        events.append({**r, "event": "pending", "outcome": "pending"})

    def complete(r):
        row = {
            **r,
            "event": "result",
            "outcome": "success",
            "status_code": 200,
            "result_count": 10,
            "elapsed_ms": 10,
            "model_version": "toy",
            "result_sha256": "a" * 64,
            "ranking_sha256": "b" * 64,
        }
        events.append(row)
        if r["phase"] == "measured":
            measured.append(row)

    for i in range(16):
        r = record(i, "warmup")
        pending(r)
        complete(r)
    active = []
    for i in range(20800):
        r = record(i, "measured")
        pending(r)
        active.append(r)
        if len(active) == 32:
            complete(active.pop(0))
    for r in active:
        complete(r)
    path = tmp_path / "requests.jsonl"
    path.write_text("".join(json.dumps(x) + "\n" for x in events), encoding="utf-8")
    report = {"load_seconds": 30, "peak_inflight": 32, "summary": base.summarize(measured, 30)}
    result, semantics = base.ledger(tmp_path, report, queries)
    assert result["measured"]["successes"] == 20800 and len(semantics) == 5200
    assert result["repeat_histogram"] == {4: 5200}
    # A preserved successful summary cannot mask a changed raw final result.
    events[-1]["outcome"] = "timeout"
    path.write_text("".join(json.dumps(x) + "\n" for x in events), encoding="utf-8")
    with pytest.raises(ValueError, match="Failed/empty"):
        base.ledger(tmp_path, report, queries)


def test_sampling_long_gap_and_missing_source_rejected(base, tmp_path, monkeypatch):
    report = {"load_started_at": "2026-10-26T00:00:00+00:00", "load_seconds": 60}
    rows = [
        {"phase": "load", "at": f"2026-10-26T00:00:{s:02d}+00:00", "server": {}}
        for s in (0, 10, 20, 40, 50)
    ]
    path = tmp_path / "samples.jsonl"
    path.write_text("".join(json.dumps(x) + "\n" for x in rows), encoding="utf-8")
    with pytest.raises(ValueError, match="sampling coverage"):
        audit.observations(base, tmp_path, report)
    rows.insert(3, {"phase": "load", "at": "2026-10-26T00:00:30+00:00", "server": {}})
    path.write_text("".join(json.dumps(x) + "\n" for x in rows), encoding="utf-8")
    with pytest.raises(ValueError, match="process sample"):
        audit.observations(base, tmp_path, report)


@pytest.fixture
def comparison(monkeypatch, tmp_path):
    vals = values()
    setup = {
        "root_evidence_sha256": {},
        "helper_sha256": {},
        "owned_resources": {"api": {"Id": "setup"}},
    }
    records, reports = [], []
    for i, (name, val) in enumerate(zip(audit.CASES, vals, strict=True)):
        records.append(
            {
                "case": name,
                "status": "PASSED",
                "snapshots": {
                    k: {"process_rollup_bytes": {"Anonymous": val[k]}}
                    for k in ("warmup", "after_5200", "after_20800", "idle")
                },
                "ledger": {
                    "measured": {
                        "successful_requests_per_second": val["throughput"],
                        "success_latency": {"p95_ms": val["p95_ms"]},
                    }
                },
            }
        )
        reports.append(
            {
                "previous_container": {"Id": "setup" if i == 0 else "control"},
                "final_container": {"Id": "control" if i == 0 else "treatment"},
                "started_at": f"2026-10-26T0{i}:00:00+00:00",
                "finished_at": f"2026-10-26T0{i}:30:00+00:00",
            }
        )
    semantics = [{i: "same" for i in range(5200)} for _ in range(2)]
    monkeypatch.setattr(audit, "frozen_setup", lambda root: setup)
    monkeypatch.setattr(
        audit, "load_base", lambda root: SimpleNamespace(timestamp=datetime.fromisoformat)
    )
    monkeypatch.setattr(audit, "digest", lambda path: "a" * 64)

    def case(root, name, arena, setup, base):
        i = list(audit.CASES).index(name)
        return copy.deepcopy(records[i]), reports[i], semantics[i]

    monkeypatch.setattr(audit, "audit_case", case)
    return tmp_path, records, reports, semantics


def test_candidate_requires_both_complete_protocols(comparison):
    root, records, _, _ = comparison
    assert audit.compare(root)["candidate_eligible"]
    records[1]["status"] = "FAILED"
    assert not audit.compare(root)["candidate_eligible"]


def test_full_semantic_difference_and_missing_group_rejected(comparison):
    root, _, _, semantics = comparison
    semantics[1][5199] = "different"
    assert not audit.compare(root)["candidate_eligible"]
    del semantics[1][5199]
    assert not audit.compare(root)["candidate_eligible"]


def test_cross_case_chain_rejected(comparison):
    root, _, reports, _ = comparison
    reports[1]["previous_container"]["Id"] = "unrelated"
    assert not audit.compare(root)["candidate_eligible"]


def test_missing_setup_is_failed_not_na(tmp_path):
    result = audit.compare(tmp_path)
    assert result["status"] == "FAILED" and result["candidate_eligible"] is False


def test_timing_integrity_cannot_inflate_throughput(tmp_path):
    events = [
        {
            "phase": "measured",
            "event": "pending",
            "dispatched_ms": 0,
            "at": "2026-10-26T00:00:00+00:00",
        },
        {
            "phase": "measured",
            "event": "result",
            "dispatched_ms": 0,
            "elapsed_ms": 100,
            "at": "2026-10-26T00:00:00.100000+00:00",
        },
    ]
    path = tmp_path / "requests.jsonl"
    path.write_text("".join(json.dumps(row) + "\n" for row in events), encoding="utf-8")
    base = SimpleNamespace(
        timestamp=datetime.fromisoformat,
        ledger=lambda *args: ({"warmup": {"successes": 16}}, {"q": "same"}),
    )
    report = {
        "status": "COMPLETED",
        "workload_status": "PASSED",
        "load_seconds": 0.1,
        "load_started_at": "2026-10-26T00:00:00+00:00",
        "warmup": {"successes": 16},
    }
    assert audit.ledger_evidence(base, tmp_path, report, ["q"])[0]["warmup"]["successes"] == 16
    report["load_seconds"] = 10
    with pytest.raises(ValueError, match="drain duration"):
        audit.ledger_evidence(base, tmp_path, report, ["q"])
    report["load_seconds"] = 0.1
    events[1]["at"] = "2026-10-26T00:00:04+00:00"
    path.write_text("".join(json.dumps(row) + "\n" for row in events), encoding="utf-8")
    with pytest.raises(ValueError, match="Completion wall"):
        audit.ledger_evidence(base, tmp_path, report, ["q"])
