"""Seal completed diagnostic screening evidence, never production acceptance.

No Docker/HTTP or private .env access. --check is read-only; outputs are exclusive.
Credential checks cover patterns/structured fields, not unknown private secret values.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

import compare_arena_controls as audit

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DESTINATION = REPO / "docs/data/container-memory-arena-count-2026-10-26-raw.zip"
MANIFEST = ROOT / "archive-sha256.json"
VERIFICATION = ROOT / "archive-verification.json"
MAX_BYTES = 90 * 1024 * 1024
ROOT_REQUIRED = {
    "acceptance-plan.md",
    "preflight.json",
    "inputs-sha256.json",
    "sources-sha256.json",
    "frozen-input-copy.json",
    "freeze_preflight.py",
    "setup_arena_controls.py",
    "diagnostic_arena_case.py",
    "compare_arena_controls.py",
    "offline_driver_check.py",
    "test_compare_arena_controls.py",
    "package_arena_evidence.py",
    "cleanup_arena_controls.py",
    "arena-comparison.json",
    "offline-execution-contract.json",
    "setup-console.txt",
    "arena2-control-01-console.txt",
    "arena1-treatment-01-console.txt",
}
ROOT_OPTIONAL = {
    "local-checks.json",
    "independent-review.json",
    "arena-controls-review.json",
    "setup-console.txt",
    "arena2-control-01-console.txt",
    "arena1-treatment-01-console.txt",
    "arena2-control-01-launcher.json",
    "arena1-treatment-01-launcher.json",
    "producer-contract-check.json",
    "packaging-review.json",
}
CASE_REQUIRED = {
    "summary.json",
    "requests.jsonl",
    "samples.jsonl",
    "queries.csv",
    "api.log",
    "diagnostic_case.base.py",
    "diagnostic_arena_case.executed.py",
    "derived-driver.diff",
    "override.yml",
    "execution-manifest.json",
}
LABELS = (
    "ready",
    "warmup",
    "after_400",
    "after_5200",
    "after_10400",
    "after_15600",
    "after_20800",
    "idle",
    "gc",
    "trim",
)
TOKEN_PATTERNS = (
    rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b",
    rb"\bgh[pousr]_[A-Za-z0-9]{20,}\b",
    rb"\bgithub_pat_[A-Za-z0-9_]{30,}\b",
    rb"\bAKIA[A-Z0-9]{16}\b",
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
    rb"(?i)\bBearer\s+[A-Za-z0-9._~-]{16,}",
)
# Reviewed synthetic URL credentials in immutable unit-test fixtures only.
SYNTHETIC_URL_SOURCES = {
    "baseline-sources/tests/" + name: expected
    for name, expected in (
        ("conftest.py", "07170e77f56aa7e0763257bdea2c5b8df1366cd435fdf4631de3aa38d5d933cc"),
        (
            "test_api_bootstrap.py",
            "5ac421ae788614c4f0b9ac4ce4582fede0f7ed2cb8af5b44e40c6104d706fc23",
        ),
        (
            "test_bench_concurrent.py",
            "0d74d299e2acb787ab00e6f3283f8bdb9964b84a38cbbd5e06ee8a7b0720a699",
        ),
        ("test_core_config.py", "27a2a02625587c1a15c442a23b07c1cb9bdbb12c1bde9406bc785cfb7d902dcc"),
        (
            "test_db_connection.py",
            "7ea838ddd2d2925301ee2ea7415363c0b6739cf46947809e2589d19cef5200c3",
        ),
        ("test_docker_seed.py", "426cce59e64cde42cbb05f31bfb92a02f9c735ffd9d46f3c32d8044321bb44f4"),
    )
}
SECRET_KEY = re.compile(r"(?:^|_)(?:API_KEY|ACCESS_TOKEN|AUTH_TOKEN|SECRET|PASSWORD)$", re.I)
SAFE_VALUES = {"", "searchpilot", "NOT_SET", "UNKNOWN", "REDACTED", "<redacted>"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_path(root, name):
    relative = Path(name)
    require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe member path")
    require(not any(p.startswith(".env") for p in relative.parts), "Environment file excluded")
    path = root / relative
    require(path.resolve().is_relative_to(root.resolve()), "Member escapes evidence root")
    for component in (path, *path.parents):
        if component == root.parent:
            break
        require(not component.is_symlink() and not component.is_junction(), "Linked evidence")
    return path


def credential_scan(name, data):
    for pattern in TOKEN_PATTERNS:
        require(re.search(pattern, data) is None, "Credential pattern: " + name)
    text = data.decode("utf-8-sig")
    for match in re.finditer(r"[a-zA-Z][a-zA-Z0-9+.-]*://[^\s\"'<>]+", text):
        try:
            parsed = urlsplit(match.group())
            password = unquote(parsed.password or "")
        except ValueError:
            continue
        public_db = (
            parsed.scheme in {"postgres", "postgresql"}
            and parsed.username == password == "searchpilot"
            and parsed.hostname in {"db", "localhost", "127.0.0.1"}
        )
        require(
            not password
            or public_db
            or "{" in password
            or "$" in password
            or SYNTHETIC_URL_SOURCES.get(name) == sha(data),
            "Unexpected URL credential: " + name,
        )

    def inspect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if SECRET_KEY.search(key) and isinstance(item, str):
                    require(
                        item in SAFE_VALUES or item.startswith("${"), "Credential field: " + name
                    )
                inspect(item)
        elif isinstance(value, list):
            for item in value:
                inspect(item)

    if name.endswith(".json"):
        inspect(audit.parse(data))
    elif name.endswith(".jsonl"):
        for line in data.splitlines():
            if line.strip():
                inspect(audit.parse(line))
    if name.endswith((".txt", ".yml", "Dockerfile")):
        for line in text.splitlines():
            match = re.fullmatch(r"\s*([A-Z][A-Z0-9_]*)\s*[=:]\s*(.*?)\s*", line)
            if match and SECRET_KEY.search(match[1]):
                value = match[2].strip("\"'")
                require(
                    value in SAFE_VALUES or value.startswith("${"), "Credential assignment: " + name
                )


def json_value(value):
    """Match the JSON data model, including integer histogram keys, without dropping fields."""
    return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))


def validate_evidence():
    """Recompute without timestamps; reject incomplete/failed audits, retain screened rejection."""
    setup = audit.frozen_setup(ROOT)
    for name in ("inputs-sha256.json", "sources-sha256.json"):
        for path, expected in audit.read(ROOT / name).items():
            # Only explicitly frozen repository paths are read; never discover .env.
            require(audit.digest(safe_path(REPO, path)) == expected, "Current source/input changed")
    for current, saved_name in (
        ("Dockerfile", "Dockerfile"),
        ("docker-compose.yml", "docker-compose.yml"),
        ("pyproject.toml", "pyproject.toml"),
        (".env.example", "public-env.txt"),
    ):
        require(
            (REPO / current).read_bytes() == (ROOT / "source-config" / saved_name).read_bytes(),
            "Current public configuration changed: " + current,
        )
    saved = audit.read(ROOT / "arena-comparison.json")
    replay = json_value(audit.compare(ROOT))
    require(saved == replay, "Saved comparison differs from exact offline replay")
    require(
        saved["status"] in {"PASSED", "REJECTED_SCREENING"},
        "Failed/incomplete audit requires separate failure reconciliation",
    )
    require(
        len(saved["cases"]) == 2 and all(r["status"] == "PASSED" for r in saved["cases"]),
        "Both case evidence audits must be complete",
    )
    for name in audit.CASES:
        report = audit.read(ROOT / name / "summary.json")
        require(report["collection_status"] == "COMPLETED", "Unfinished diagnostic collection")
    return setup, saved


def select_members(setup):
    expected = set(ROOT_REQUIRED)
    expected |= {"fixture/queries.csv", "fixture/manifest.json"}
    expected |= {
        "source-config/" + n
        for n in ("Dockerfile", "docker-compose.yml", "pyproject.toml", "public-env.txt")
    }
    expected |= {"baseline-sources/" + n for n in setup["frozen_source_sha256"]}
    expected |= {"setup/" + n for n in setup["setup_artifact_sha256"]}
    expected |= {"setup/summary.json", "setup/diagnostic_case.base.py"}
    scripts = {Path(n).stem + ".executed.py" for n in setup["executed_script_sha256"]}
    expected |= {"setup/" + n for n in scripts}
    for case in audit.CASES:
        expected |= {case + "/" + n for n in CASE_REQUIRED | scripts}
        expected |= {case + "/smaps-" + label + ".txt" for label in LABELS}
    expected |= {n for n in ROOT_OPTIONAL if (ROOT / n).is_file()}
    paths = {name: safe_path(ROOT, name) for name in sorted(expected)}
    require(all(p.is_file() for p in paths.values()), "A required archive member is missing")
    legacy = audit.OLD / "compare_diagnostics.py"
    require(audit.digest(legacy) == audit.BASE_SHA, "Legacy pure parser changed")
    paths["reference/compare_diagnostics.py"] = legacy
    found = {
        p.relative_to(ROOT).as_posix()
        for p in ROOT.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts
    }
    excluded = sorted(found - expected)
    for name in excluded:
        require(
            not any(name.startswith(case + "/") for case in audit.CASES)
            and not name.startswith("setup/"),
            "Unknown raw evidence member: " + name,
        )
    return paths, excluded


def inventory(paths):
    members = {}
    for name, path in paths.items():
        data = path.read_bytes()
        credential_scan(name, data)
        members[name] = {"bytes": len(data), "sha256": sha(data)}
    return members


def verify_archive(*, require_record=True):
    setup, comparison = validate_evidence()
    paths, _ = select_members(setup)
    members = audit.read(MANIFEST)
    require(set(members) == set(paths), "Archive/current member set differs")
    require(DESTINATION.stat().st_size <= MAX_BYTES, "Archive exceeds 90 MiB")
    with zipfile.ZipFile(DESTINATION) as archive:
        require(archive.testzip() is None, "CRC verification failed")
        require(
            len(archive.namelist()) == len(members) + 1
            and set(archive.namelist()) == set(members) | {"SHA256SUMS.json"},
            "Archive members differ or repeat",
        )
        require(
            archive.read("SHA256SUMS.json") == MANIFEST.read_bytes(), "Manifest readback differs"
        )
        for name, expected in members.items():
            data = archive.read(name)
            require(
                len(data) == expected["bytes"] and sha(data) == expected["sha256"],
                "Archive member hash mismatch: " + name,
            )
            require(
                paths[name].read_bytes() == data, "Current evidence differs from archive: " + name
            )
            credential_scan(name, data)
    result = {
        "status": "VERIFIED",
        "scope": comparison["scope"],
        "production_acceptance": False,
        "screening_status": comparison["status"],
        "candidate_eligible": comparison["candidate_eligible"],
        "path": DESTINATION.relative_to(REPO).as_posix(),
        "sha256": audit.digest(DESTINATION),
        "bytes": DESTINATION.stat().st_size,
        "files": len(members),
        "manifest_sha256": audit.digest(MANIFEST),
        "comparison_sha256": audit.digest(ROOT / "arena-comparison.json"),
        "crc_and_member_sha256_verified": True,
        "current_bytes_match": True,
        "credential_scan": "patterns_and_structured_fields",
        "synthetic_url_fixture_allowlist": SYNTHETIC_URL_SOURCES,
        "private_env_read": False,
    }
    if require_record:
        require(
            audit.read(VERIFICATION) == result, "Verification record differs from fresh readback"
        )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    require(not (args.check and args.verify), "Choose one read-only mode")
    if args.verify:
        print(json.dumps(verify_archive()))
        return
    require(
        not any(p.exists() for p in (DESTINATION, MANIFEST, VERIFICATION)),
        "Refuse to replace existing/failed archive outputs",
    )
    setup, comparison = validate_evidence()
    paths, excluded = select_members(setup)
    members = inventory(paths)
    if args.check:
        print(
            json.dumps(
                {
                    "status": "READY_TO_PACKAGE",
                    "files": len(members),
                    "screening_status": comparison["status"],
                    "production_acceptance": False,
                    "excluded_files": excluded,
                }
            )
        )
        return
    with MANIFEST.open("x", encoding="utf-8", newline="\n") as sink:
        json.dump(members, sink, indent=2)
        sink.write("\n")
    with zipfile.ZipFile(
        DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as archive:
        for name, path in paths.items():
            data = path.read_bytes()
            require(sha(data) == members[name]["sha256"], "Evidence changed during archive write")
            archive.writestr(name, data)
        archive.writestr("SHA256SUMS.json", MANIFEST.read_bytes())
    result = verify_archive(require_record=False)
    with VERIFICATION.open("x", encoding="utf-8") as sink:
        json.dump(result, sink, indent=2)
        sink.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
