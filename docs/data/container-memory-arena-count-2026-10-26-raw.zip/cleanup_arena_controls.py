"""Remove only sealed arena-control resources. Default is read-only verification.

No prune, Compose down, image removal, private .env, or implicit retry. An attempt
record is exclusive and failures remain for reconciliation. Run before config changes.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from datetime import UTC, datetime

import package_arena_evidence as evidence
from diagnostic_arena_case import clean_thread_environment

ROOT, REPO = evidence.ROOT, evidence.REPO
PROJECT = "sp-memory-arena-count-20261026"
VOLUME, NETWORK = PROJECT + "_pgdata", PROJECT + "_default"
ORIGINAL = "searchpilot_pgdata"
DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
require = evidence.require


def now():
    return datetime.now(UTC).isoformat()


def expected_resources():
    setup = evidence.audit.read(ROOT / "setup/summary.json")
    final = evidence.audit.read(ROOT / "arena1-treatment-01/summary.json")
    require(setup["config"]["project"] == PROJECT, "Wrong setup project")
    require(final["collection_status"] == "COMPLETED", "Final collection incomplete")
    expected = {
        PROJECT + "-api-1": final["final_container"]["Id"],
        PROJECT + "-db-1": setup["owned_resources"]["db"]["Id"],
    }
    require(
        all(re.fullmatch(r"[a-f0-9]{64}", value) for value in expected.values()),
        "Expected full immutable container IDs",
    )
    return expected, setup["owned_resources"]["volume"]


def validate_resources(containers, volume, network, expected, saved_volume):
    """Pure ownership checks. Never retain full container environment in output."""
    require(VOLUME != ORIGINAL and PROJECT == evidence.audit.PROJECT, "Unsafe cleanup target")
    require(
        len(containers) == 2
        and {c["Name"] for c in containers} == {"/" + name for name in expected},
        "Unexpected containers",
    )
    require(
        {key: volume[key] for key in saved_volume} == saved_volume,
        "Owned volume differs from setup",
    )
    require(
        volume["Name"] == VOLUME
        and volume["Labels"].get("com.docker.compose.project") == PROJECT
        and volume["Labels"].get("com.docker.compose.volume") == "pgdata",
        "Volume identity/labels differ",
    )
    require(
        network["Name"] == NETWORK
        and network["Labels"].get("com.docker.compose.project") == PROJECT
        and network["Labels"].get("com.docker.compose.network") == "default",
        "Network identity/labels differ",
    )
    require(re.fullmatch(r"[a-f0-9]{64}", network["Id"]) is not None, "Invalid network ID")
    require(
        set(network.get("Containers", {})) == set(expected.values()),
        "Network has missing or unknown containers",
    )
    for container in containers:
        name = container["Name"].lstrip("/")
        role = "api" if name == PROJECT + "-api-1" else "db"
        labels = container["Config"]["Labels"]
        require(
            container["Id"] == expected[name]
            and labels.get("com.docker.compose.project") == PROJECT
            and labels.get("com.docker.compose.service") == role
            and labels.get("com.docker.compose.container-number") == "1",
            "Container ID/labels differ",
        )
        networks = container["NetworkSettings"]["Networks"]
        require(
            set(networks) == {NETWORK} and networks[NETWORK]["NetworkID"] == network["Id"],
            "Container attached to unexpected/replaced network",
        )
        if role == "db":
            volumes = [m["Name"] for m in container["Mounts"] if m.get("Type") == "volume"]
            require(volumes == [VOLUME], "DB has unexpected volume attachment")
        else:
            require(container["Image"] == evidence.audit.IMAGE, "API image differs")
    return {
        "containers": expected,
        "volume": saved_volume,
        "network": {key: network[key] for key in ("Name", "Id", "Labels")},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Delete after all identity gates")
    parser.add_argument("--attempt", default="01")
    args = parser.parse_args()
    require(re.fullmatch(r"[a-z0-9-]{1,32}", args.attempt) is not None, "Invalid attempt suffix")
    # Disk-only archive/member/current-source/replay verification precedes even Docker reads.
    verified = evidence.verify_archive()
    expected, saved_volume = expected_resources()
    path = ROOT / ("cleanup-arena-" + args.attempt + ".json")
    record = {
        "status": "RUNNING",
        "started_at": now(),
        "project": PROJECT,
        "archive_verification": verified,
        "commands": [],
        "deleted_containers": [],
        "deleted_volumes": [],
        "deleted_networks": [],
        "private_env_read": False,
    }
    if args.execute:
        with path.open("x", encoding="utf-8") as sink:
            json.dump(record, sink, indent=2)

    def save():
        if args.execute:
            path.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")

    def command(arguments, timeout=60):
        row = {"argv": [DOCKER, *arguments], "started_at": now()}
        record["commands"].append(row)
        save()
        try:
            result = subprocess.run(
                row["argv"],
                cwd=REPO,
                env=clean_thread_environment(),
                check=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=timeout,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            row["exit_code"] = result.returncode
            return result.stdout
        except BaseException as exc:
            row["error_type"] = type(exc).__name__
            raise
        finally:
            row["finished_at"] = now()
            save()

    def inspect(kind, identity):
        rows = json.loads(command([kind, "inspect", identity]))
        require(len(rows) == 1, "Inspection returned unexpected resource count")
        return rows[0]

    def listings():
        label = "label=com.docker.compose.project=" + PROJECT
        return {
            "containers": set(command(["ps", "-aq", "--no-trunc", "--filter", label]).splitlines()),
            "volumes": set(
                command(["volume", "ls", "--filter", label, "--format", "{{.Name}}"]).splitlines()
            ),
            "networks": set(
                command(
                    ["network", "ls", "--no-trunc", "--filter", label, "--format", "{{.ID}}"]
                ).splitlines()
            ),
        }

    try:
        preflight = evidence.audit.read(ROOT / "preflight.json")
        original = inspect("volume", ORIGINAL)
        require(original == preflight["original_volume"], "Protected original volume changed")
        containers = [inspect("container", name) for name in expected]
        owned, network = inspect("volume", VOLUME), inspect("network", NETWORK)
        selected = validate_resources(containers, owned, network, expected, saved_volume)
        require(
            listings()
            == {
                "containers": set(expected.values()),
                "volumes": {VOLUME},
                "networks": {network["Id"]},
            },
            "Unknown project resources exist",
        )
        require(
            set(command(["ps", "-aq", "--no-trunc", "--filter", "volume=" + VOLUME]).splitlines())
            == {expected[PROJECT + "-db-1"]},
            "Unexpected volume consumer",
        )
        record["verified_resources"] = selected
        record["original_volume_before"] = original
        save()
        if not args.execute:
            print(
                json.dumps(
                    {
                        "status": "READY_TO_CLEAN",
                        "project": PROJECT,
                        "archive_sha256": verified["sha256"],
                        "resources": selected,
                    }
                )
            )
            return
        # Recheck bytes and ownership immediately before any mutation.
        require(evidence.verify_archive() == verified, "Archive/source changed before cleanup")
        validate_resources(
            [inspect("container", identity) for identity in expected.values()],
            inspect("volume", VOLUME),
            inspect("network", network["Id"]),
            expected,
            saved_volume,
        )
        for name, identity in expected.items():
            current = inspect("container", identity)
            require(
                current["Id"] == identity
                and current["Name"] == "/" + name
                and current["Config"]["Labels"].get("com.docker.compose.project") == PROJECT,
                "Container changed before deletion",
            )
            command(["stop", "--time", "30", identity], 60)
            command(["rm", identity])
            record["deleted_containers"].append(identity)
            save()
        require(inspect("volume", VOLUME) == owned, "Owned volume changed before deletion")
        require(inspect("volume", ORIGINAL) == original, "Protected volume changed")
        command(["volume", "rm", VOLUME])
        record["deleted_volumes"].append(VOLUME)
        save()
        current_network = inspect("network", network["Id"])
        require(
            current_network["Id"] == network["Id"]
            and current_network["Name"] == NETWORK
            and current_network["Labels"] == network["Labels"]
            and not current_network.get("Containers"),
            "Network changed/still attached",
        )
        command(["network", "rm", network["Id"]])
        record["deleted_networks"].append(network["Id"])
        require(
            listings() == {"containers": set(), "volumes": set(), "networks": set()},
            "Owned resources remain",
        )
        require(inspect("volume", ORIGINAL) == original, "Protected original volume changed")
        require(evidence.verify_archive() == verified, "Archive/source changed during cleanup")
        record.update(status="COMPLETED", original_volume_metadata_unchanged=True)
    except BaseException as exc:
        record.update(status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        record["finished_at"] = now()
        save()
        if args.execute:
            print(json.dumps({"status": record["status"], "record": str(path)}))


if __name__ == "__main__":
    main()
