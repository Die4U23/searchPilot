"""Offline arena-count screening; collection completion is not candidate acceptance.

Only archived measurement functions are loaded. No service, Docker or HTTP calls.
"""

from __future__ import annotations

import argparse
import ast
import csv
import difflib
import hashlib
import io
import json
import math
import types
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "extended-memory-2026-10-26"
BASE_SHA = "48edc5fc0dcc2d071f7185f730ff7ae831fe71d3757fff88cc682c40c429363b"
BENCH_SHA = "2460eba68b8b9b561cf46a851faf357dc09908ae46117a5457c4461db87baee9"
IMAGE = "sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1"
QUERY_SHA = "7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6"
PROJECT = "sp-memory-arena-count-20261026"
CASES = {"arena2-control-01": 2, "arena1-treatment-01": 1}
NATIVE = {
    "MALLOC_ARENA_MAX": "2",
    "SEARCHPILOT_DISABLE_THP": "true",
    "GLIBC_TUNABLES": None,
    "LD_PRELOAD": None,
    "PYTHONMALLOC": None,
    "PYTHONTRACEMALLOC": None,
}
THREAD_KEYS = [
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "OMP_THREAD_LIMIT",
    "OMP_DYNAMIC",
    "MKL_DYNAMIC",
    "NUMEXPR_NUM_THREADS",
    "NUMEXPR_MAX_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "OMP_MAX_ACTIVE_LEVELS",
    "OMP_NESTED",
    "OMP_PROC_BIND",
    "OMP_PLACES",
    "KMP_AFFINITY",
    "KMP_BLOCKTIME",
    "KMP_SETTINGS",
    "TOKENIZERS_PARALLELISM",
    "RAYON_NUM_THREADS",
]
COMMAND = [
    "python",
    "-c",
    "import ctypes;c=ctypes.CDLL(None,use_errno=True);"
    "r=c.prctl(41,1,0,0,0);assert r==0,ctypes.get_errno();"
    "assert c.prctl(42,0,0,0,0)==1;from scripts.diagnose_allocator import main;main()",
]
MIB = 1048576


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError("Non-finite JSON constant: " + value)


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject_constant)


def read(path):
    return parse(path.read_bytes())


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def local(base, name):
    path = base / name
    require(path.resolve().is_relative_to(base.resolve()), "Evidence path escapes root")
    require(not path.is_symlink(), "Symlink evidence is unsupported")
    return path


def tree_hashes(folder):
    return {
        p.relative_to(folder).as_posix(): digest(p)
        for p in sorted(folder.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
    }


def load_base(root):
    """Reuse frozen pure routines, never import a mutable production bench module."""
    old = OLD / "compare_diagnostics.py"
    bench = root / "setup/bench_concurrent.executed.py"
    require(digest(old) == BASE_SHA and digest(bench) == BENCH_SHA, "Frozen parser changed")
    names = {"read_queries", "latency_summary", "summarize"}
    nodes = [
        node
        for node in ast.parse(bench.read_text(encoding="utf-8")).body
        if isinstance(node, ast.FunctionDef) and node.name in names
    ]
    require({n.name for n in nodes} == names, "Frozen pure functions missing")
    future = ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, *nodes], type_ignores=[]))
    env = {"csv": csv, "io": io, "math": math, "Counter": Counter}
    exec(compile(module, str(bench), "exec"), env)
    source = ast.parse(old.read_text(encoding="utf-8"))
    source.body = [
        node
        for node in source.body
        if not (isinstance(node, ast.ImportFrom) and node.module == "scripts.bench_concurrent")
    ]
    base = types.ModuleType("frozen_arena_diagnostic_parser")
    base.__dict__.update(
        __file__=str(old),
        MODES=("bm25", "vector", "hybrid", "ltr"),
        read_queries=env["read_queries"],
        summarize=env["summarize"],
    )
    exec(compile(source, str(old), "exec"), base.__dict__)
    return base


def screening(control, treatment):
    """Integer byte gates; ratio tolerance is predeclared, never data-dependent."""
    errors, metrics = [], {}
    require(
        all(
            type(row[label]) is int and row[label] >= 0
            for row in (control, treatment)
            for label in ("warmup", "after_5200", "after_20800", "idle")
        ),
        "Missing/noninteger memory observations",
    )
    for endpoint in ("after_20800", "idle"):
        c = control[endpoint] - control["warmup"]
        t = treatment[endpoint] - treatment["warmup"]
        improvement = c - t
        passed = c > 0 and improvement >= 2 * MIB and 5 * improvement >= c
        metrics[endpoint] = {
            "control_delta_bytes": c,
            "treatment_delta_bytes": t,
            "improvement_bytes": improvement,
            "passed": passed,
        }
        if c <= 0:
            errors.append("INSUFFICIENT_BASELINE_GROWTH:" + endpoint)
        elif not passed:
            errors.append("MEMORY_BENEFIT:" + endpoint)
    late = (treatment["after_20800"] - treatment["after_5200"]) - (
        control["after_20800"] - control["after_5200"]
    )
    metrics["late_extra_growth_bytes"] = late
    if late > MIB:
        errors.append("LATE_MEMORY_REGRESSION")
    for field in ("throughput", "p95_ms"):
        require(
            all(finite(x[field]) and x[field] > 0 for x in (control, treatment)),
            "Missing/nonpositive throughput or p95",
        )
    metrics["throughput_ratio"] = treatment["throughput"] / control["throughput"]
    metrics["p95_ratio"] = treatment["p95_ms"] / control["p95_ms"]
    if metrics["throughput_ratio"] < 0.8 - 1e-9:
        errors.append("THROUGHPUT_REGRESSION")
    if metrics["p95_ratio"] > 1.25 + 1e-9:
        errors.append("P95_REGRESSION")
    return {"passed": not errors, "failures": errors, "metrics": metrics}


def frozen_setup(root):
    setup = read(root / "setup/summary.json")
    require(
        setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART" and setup["image"] == IMAGE,
        "Setup incomplete/image",
    )
    inputs, sources = read(root / "inputs-sha256.json"), read(root / "sources-sha256.json")
    require(len(inputs) == 29 and len(sources) == 187, "Frozen manifest counts differ")
    require(setup["frozen_inputs"] == inputs, "Setup input manifest differs")
    require(setup["frozen_source_sha256"] == sources, "Setup source manifest differs")
    require(
        all(sources.get(n) == v for n, v in setup["local_source_sha256"].items()),
        "Setup local sources differ from frozen copies",
    )
    expected_container = {
        n: v
        for n, v in sources.items()
        if n.startswith("src/")
        or n
        in {
            "scripts/docker_entrypoint.py",
            "scripts/docker_seed.py",
            "scripts/seed_items.py",
            "scripts/seed_catalog.py",
        }
    }
    require(
        setup["container_source_sha256"] == expected_container
        and setup["imported_source"]["sha256"]
        == {n: v for n, v in sources.items() if n.startswith("src/")},
        "Actual container/installed source differs",
    )
    for name, expected in sources.items():
        require(
            digest(local(root / "baseline-sources", name)) == expected, "Frozen source: " + name
        )
    for name, expected in setup["root_evidence_sha256"].items():
        require(digest(local(root, name)) == expected, "Root provenance changed: " + name)
    require(
        {"acceptance-plan.md", "preflight.json", "inputs-sha256.json", "sources-sha256.json"}
        <= setup["root_evidence_sha256"].keys(),
        "Root provenance missing",
    )
    for name, expected in setup["helper_sha256"].items():
        require(digest(local(root, name)) == expected, "Helper changed: " + name)
    require(
        {"diagnostic_arena_case.py", "compare_arena_controls.py", "setup_arena_controls.py"}
        <= setup["helper_sha256"].keys(),
        "Helper freeze incomplete",
    )
    for name, expected in setup["setup_artifact_sha256"].items():
        require(digest(local(root / "setup", name)) == expected, "Setup artifact changed: " + name)
    for name, expected in setup["public_config_sha256"].items():
        snapshot = "public-env.txt" if name == ".env.example" else name
        require(digest(root / "source-config" / snapshot) == expected, "Public config changed")
    preflight = read(root / "preflight.json")
    require(
        preflight["status"] == "PASSED"
        and preflight["image"] == IMAGE
        and preflight["query_sha256"] == QUERY_SHA
        and preflight["plan_sha256"] == digest(root / "acceptance-plan.md")
        and preflight["helper_sha256"] == setup["helper_sha256"],
        "Preflight differs",
    )
    for name, expected in setup["executed_script_sha256"].items():
        require(
            digest(root / "setup" / (Path(name).stem + ".executed.py")) == expected,
            "Executed snapshot changed: " + name,
        )
    require(
        setup["executed_script_sha256"]["bench_concurrent.py"] == BENCH_SHA,
        "Unexpected benchmark implementation",
    )
    require(digest(root / "fixture/queries.csv") == QUERY_SHA, "Fixture changed")
    return setup


def execution(root, case, report, setup, arena):
    expected_env = {**NATIVE, "MALLOC_ARENA_MAX": str(arena)}
    threads = dict.fromkeys(THREAD_KEYS)
    manifest = read(case / "execution-manifest.json")
    require(report["execution_manifest"] == manifest, "Manifest differs from summary")
    require(
        manifest["variant"] == "arena_count"
        and manifest["arena_max"] == arena
        and manifest["actual_entry"] == "diagnostic_arena_case.executed.py"
        and manifest["class_patch"] is None,
        "Wrong diagnostic entry/intervention",
    )
    for filename, field in (
        ("diagnostic_case.base.py", "base_driver_sha256"),
        ("diagnostic_arena_case.executed.py", "derived_driver_sha256"),
        ("derived-driver.diff", "derived_diff_sha256"),
        ("override.yml", "override_sha256"),
    ):
        require(
            digest(case / filename) == manifest[field], "Execution snapshot changed: " + filename
        )
    require(
        manifest["derived_driver_sha256"] == setup["helper_sha256"]["diagnostic_arena_case.py"]
        and manifest["base_driver_sha256"] == digest(root / "setup/diagnostic_case.base.py"),
        "Derivation is not frozen setup",
    )
    expected_diff = "".join(
        difflib.unified_diff(
            (case / "diagnostic_case.base.py").read_text().splitlines(keepends=True),
            (case / "diagnostic_arena_case.executed.py").read_text().splitlines(keepends=True),
            fromfile="diagnostic_case.py (unexecuted base)",
            tofile="diagnostic_arena_case.py (entry)",
        )
    )
    require((case / "derived-driver.diff").read_text() == expected_diff, "Derived diff mismatch")
    require(
        manifest["expected_command"] == COMMAND
        and manifest["expected_image"] == IMAGE
        and manifest["expected_project"] == PROJECT
        and manifest["expected_native_environment"] == expected_env
        and manifest["expected_thread_environment"] == threads,
        "Runtime declaration mismatch",
    )
    for field, setupfield in (
        ("input_sha256", "frozen_inputs"),
        ("source_sha256", "local_source_sha256"),
        ("executed_script_sha256", "executed_script_sha256"),
        ("public_config_sha256", "public_config_sha256"),
        ("helper_sha256", "helper_sha256"),
    ):
        require(report[field] == setup[setupfield], "Matched frozen identity changed: " + field)
    require(
        manifest["root_evidence_sha256"] == setup["root_evidence_sha256"], "Manifest roots differ"
    )
    require(
        manifest["diagnostic_wrapper_sha256"]
        == setup["executed_script_sha256"]["diagnose_allocator.py"],
        "Diagnostic wrapper differs",
    )
    expected_runtime = {
        name: setup["executed_script_sha256"][name]
        for name in ("diagnose_allocator.py", "soak_memory.py")
    }
    require(
        manifest["runtime_script_sha256"] == report["runtime_script_sha256"] == expected_runtime,
        "Container mounted script bytes differ",
    )
    require(
        report["frozen_source_sha256"] == setup["frozen_source_sha256"]
        and report["root_evidence_sha256"] == setup["root_evidence_sha256"],
        "Case source/root manifest differs",
    )
    for name, expected in setup["executed_script_sha256"].items():
        require(
            digest(case / (Path(name).stem + ".executed.py")) == expected, "Executed script differs"
        )
    require(
        report["process_native_environment"] == expected_env
        and report["process_thread_environment"] == threads,
        "Process env differs",
    )
    current, final = report["container"], report["final_container"]
    require(
        current["Id"] == final["Id"] != report["previous_container"]["Id"],
        "Container chain differs",
    )
    require(
        current["State"]["StartedAt"] == final["State"]["StartedAt"],
        "API restarted during collection",
    )
    for state in (current, final):
        require(
            state["Image"] == IMAGE
            and state["project"] == PROJECT
            and state["service"] == "api"
            and state["command"] == COMMAND
            and state["entrypoint"] is None
            and state["native_env"] == expected_env
            and state["thread_environment"] == threads
            and state["RestartCount"] == 0
            and state["State"]["OOMKilled"] is False,
            "Actual runtime not matched normal diagnostic",
        )
        for name in ("diagnose_allocator.py", "soak_memory.py"):
            mounts = [
                m for m in state["diagnostic_mounts"] if m["Destination"] == "/app/scripts/" + name
            ]
            require(
                len(mounts) == 1 and mounts[0]["Type"] == "bind" and mounts[0]["RW"] is False,
                "Missing/read-write diagnostic bind",
            )
            require(
                Path(mounts[0]["Source"]).resolve()
                == (root / "setup" / (Path(name).stem + ".executed.py")).resolve(),
                "Wrong diagnostic bind",
            )
    require(
        manifest["runtime"] == {key: current[key] for key in manifest["runtime"]}
        and set(manifest["runtime"])
        == {
            "Id",
            "Image",
            "command",
            "entrypoint",
            "project",
            "diagnostic_mounts",
            "native_env",
            "thread_environment",
        },
        "Runtime projection differs",
    )
    override = read(case / "override.yml")
    require(
        set(override) == {"services"} and set(override["services"]) == {"api"},
        "Extra override service",
    )
    api = override["services"]["api"]
    require(
        set(api) == {"environment", "command", "volumes"}
        and api["environment"] == {**expected_env, **threads}
        and api["command"] == COMMAND,
        "Override changes another variable",
    )
    expected_volumes = [
        {
            "type": "bind",
            "source": str(root / "setup" / (Path(n).stem + ".executed.py")),
            "target": "/app/scripts/" + n,
            "read_only": True,
        }
        for n in ("diagnose_allocator.py", "soak_memory.py")
    ]
    require(api["volumes"] == expected_volumes, "Additional/wrong override mount")
    for state in (report["resources_before"], report["resources_after"]):
        require(
            state["db"]["Id"] == setup["owned_resources"]["db"]["Id"]
            and state["volume"] == setup["owned_resources"]["volume"],
            "DB/volume chain changed",
        )
    require(
        report["resources_before"]["api"]["Id"] == report["previous_container"]["Id"]
        and report["resources_after"]["api"]["Id"] == final["Id"],
        "Resource/API chain mismatch",
    )
    return manifest


def valid_process(base, process):
    identity = base.process_identity(process)
    require(
        type(identity) is int and identity >= 0 and type(process["pid"]) is int,
        "Invalid process identity type",
    )
    for name in (
        "stat",
        "status",
        "smaps_rollup",
        "cmdline",
        "fd",
        "cgroup_membership",
        "cgroup_memory_current",
        "cgroup_memory_peak",
        "cgroup_memory_stat",
        "cgroup_memory_events",
        "stat_after",
    ):
        base.source(process, name)
    for name, keys in (
        ("status", ("VmSwap_bytes", "THP_enabled")),
        ("smaps_rollup", ("AnonHugePages_bytes", "Swap_bytes", "SwapPss_bytes")),
        ("cgroup_memory_events", ("oom", "oom_kill", "oom_group_kill")),
    ):
        require(
            all(
                type(base.source(process, name)[k]) is int and base.source(process, name)[k] == 0
                for k in keys
            ),
            "Swap/THP/OOM evidence invalid",
        )
    require(base.source(process, "cmdline")["argv"] == COMMAND, "Observed PID command differs")
    return identity


def observations(base, case, report):
    rows = [parse(line) for line in (case / "samples.jsonl").read_bytes().splitlines()]
    load = [r for r in rows if r["phase"] == "load"]
    start = base.timestamp(report["load_started_at"])
    xs = [(base.timestamp(r["at"]) - start).total_seconds() for r in load]
    duration = report["load_seconds"]
    require(
        len(xs) >= max(2, math.floor(duration / 10) - 2)
        and abs(xs[0]) <= 10
        and abs(duration - xs[-1]) <= 10
        and all(0 < b - a <= 15 for a, b in zip(xs, xs[1:], strict=False)),
        "Incomplete load sampling coverage",
    )
    ids = {valid_process(base, r["server"]) for r in load}
    require(len(ids) == 1, "Sample PID changed")
    # Old helper's project prefix is historical: keep raw background, relabel its scope explicitly.
    result = base.sampled_observations(case, report)
    result["background"]["classification_note"] = (
        "Legacy grouping includes this arena project; it is not an external-load count."
    )
    return result


def ledger_evidence(base, case, report, queries):
    events = [parse(line) for line in (case / "requests.jsonl").read_bytes().splitlines()]
    require(all(isinstance(row, dict) for row in events), "Malformed ledger record")
    require(
        report["status"] == "COMPLETED" and report["workload_status"] == "PASSED",
        "Workload reported failure",
    )
    result, semantics = base.ledger(case, report, queries)
    start = base.timestamp(report["load_started_at"])
    completed = []
    for row in events:
        if row["phase"] != "measured":
            continue
        dispatched = row["dispatched_ms"] / 1000
        wall = (base.timestamp(row["at"]) - start).total_seconds()
        if row["event"] == "pending":
            require(abs(wall - dispatched) <= 1, "Dispatch wall/monotonic time differs")
        else:
            finished = dispatched + row["elapsed_ms"] / 1000
            require(abs(wall - finished) <= 1, "Completion wall/monotonic time differs")
            completed.append(finished)
    require(
        abs(max(completed) - report["load_seconds"]) <= 1,
        "Last completion does not corroborate drain duration",
    )
    require(report["warmup"] == result["warmup"], "Warmup summary differs from ledger")
    return result, semantics


def snapshots(base, case, report, arena):
    rows = report["snapshots"]
    require([r["label"] for r in rows] == list(base.LABELS), "Missing/duplicate/reordered snapshot")
    by_label = {r["label"]: r for r in rows}
    require(
        (
            base.timestamp(by_label["idle"]["started_at"])
            - base.timestamp(report["idle_started_at"])
        ).total_seconds()
        >= 120,
        "Short idle",
    )
    native = {}
    for left, right in zip(rows, rows[1:], strict=False):
        require(
            base.timestamp(left["at"]) <= base.timestamp(right["started_at"]), "Snapshot overlap"
        )
    for row in rows:
        label = row["label"]
        data = row["data"].get("snapshot", row["data"])
        valid_process(base, data["process"]["data"])
        valid_process(base, row["external_process"])
        value = base.native_snapshot(row)
        require(
            value["glibc_heap_count"] == row["observed_glibc_heaps"] == arena,
            "Actual heap count differs: " + label,
        )
        require(
            all(type(v) is int and v >= 0 for v in value["process_rollup_bytes"].values()),
            "Invalid native memory metric",
        )
        if label.startswith("after_"):
            n = int(label.split("_")[1])
            require(
                row["trigger"]["completed"]
                == n
                <= row["counts_before"]["completed"]
                <= row["counts_after"]["completed"]
                <= 20800,
                "Invalid checkpoint counters",
            )
        if label in ("after_20800", "idle", "gc", "trim"):
            require(
                row["counts_before"] == row["counts_after"] == {"completed": 20800, "inflight": 0},
                "Undrained terminal snapshot",
            )
        if label in ("gc", "trim"):
            require(row["data"]["action"] == "/" + label, "Wrong intervention")
        mappings = base.parse_smaps((case / ("smaps-" + label + ".txt")).read_text())
        value["raw_smaps"] = base.map_totals(mappings)
        require(
            value["raw_smaps"]["mapping_count"] > 0
            and value["raw_smaps"]["total_bytes"]["AnonHugePages"] == 0
            and value["raw_smaps"]["total_bytes"]["Swap"] == 0,
            "Raw smaps THP/swap/empty",
        )
        native[label] = value
    require(len({v["pid_start_ticks"] for v in native.values()}) == 1, "Native PID changed")
    return native


def audit_case(root, name, arena, setup, base):
    case = root / name
    before = tree_hashes(case)
    report = read(case / "summary.json")
    record = {
        "case": name,
        "recorded_status": report.get("status"),
        "collection_status": report.get("collection_status"),
        "reported_workload_status": report.get("workload_status"),
        "reported_summary": report.get("summary"),
        "failures": [],
        "input_sha256": before,
    }
    require(report["case"] == name and report["arena_max"] == arena, "Case identity differs")
    require(report["collection_status"] == "COMPLETED", "Collection incomplete")
    require(
        report["requests"] == 20800
        and report["concurrency"] == 32
        and report["timeout"] == report["limit"] == 10
        and report["idle_seconds"] == 120
        and report["health_period_seconds"] == 10
        and report["checkpoints"] == [400, 5200, 10400, 15600, 20800]
        and report["external_llm_calls"] == 0
        and report["private_env_read"] is False,
        "Protocol changed",
    )
    require(finite(report["load_seconds"]) and report["load_seconds"] > 0, "Invalid load duration")
    wall = (
        base.timestamp(report["load_finished_at"]) - base.timestamp(report["load_started_at"])
    ).total_seconds()
    require(abs(wall - report["load_seconds"]) <= 1, "Load wall/elapsed time differs")
    require(
        report["query_set"] == "expanded1300"
        and report["query_count"] == 1300
        and report["query_sha256"] == digest(case / "queries.csv") == QUERY_SHA,
        "Query mismatch",
    )
    queries, _ = base.read_queries(case / "queries.csv")
    require(len(queries) == 1300, "Missing queries")
    semantics = None
    for category, operation in (
        ("PROVENANCE", lambda: execution(root, case, report, setup, arena)),
        ("WORKLOAD_OR_SEMANTICS", lambda: ledger_evidence(base, case, report, queries)),
        ("NATIVE_OR_CHECKPOINT", lambda: snapshots(base, case, report, arena)),
        ("HEALTH_OR_SAMPLING", lambda: observations(base, case, report)),
    ):
        try:
            if category == "WORKLOAD_OR_SEMANTICS":
                record["ledger"], semantics = operation()
            else:
                record[
                    {
                        "PROVENANCE": "execution",
                        "NATIVE_OR_CHECKPOINT": "snapshots",
                        "HEALTH_OR_SAMPLING": "observations",
                    }[category]
                ] = operation()
        except Exception as exc:
            record["failures"].append({"category": category, "error": str(exc)})
    if "snapshots" in record and "observations" in record:
        require(
            record["snapshots"]["ready"]["pid_start_ticks"]
            == record["observations"]["pid_start_ticks"],
            "Sampler/native PID differs",
        )
    require(tree_hashes(case) == before, "Case evidence changed during audit")
    record["status"] = "PASSED" if not record["failures"] else "FAILED"
    return record, report, semantics


def compare(root=ROOT):
    result = {
        "schema_version": 1,
        "status": "FAILED",
        "candidate_eligible": False,
        "scope": "Diagnostic screening only; not production stability acceptance",
        "case_order": list(CASES),
        "cases": [],
        "failures": [],
    }
    try:
        setup = frozen_setup(root)
        base = load_base(root)
        root_names = (
            set(setup["root_evidence_sha256"])
            | set(setup["helper_sha256"])
            | {"setup/summary.json"}
        )
        root_hashes = {n: digest(local(root, n)) for n in sorted(root_names)}
        result["root_input_sha256"] = root_hashes
        result["parser_sha256"] = {
            "compare_diagnostics.py": BASE_SHA,
            "bench_concurrent.executed.py": BENCH_SHA,
        }
        reports, semantics = [], []
        for name, arena in CASES.items():
            try:
                record, report, semantic = audit_case(root, name, arena, setup, base)
                result["cases"].append(record)
                reports.append(report)
                semantics.append(semantic)
            except Exception as exc:
                result["cases"].append(
                    {
                        "case": name,
                        "status": "FAILED",
                        "failures": [{"category": "EVIDENCE_OR_PROTOCOL", "error": str(exc)}],
                    }
                )
        require(
            len(reports) == 2 and all(r["status"] == "PASSED" for r in result["cases"]),
            "One or both complete case audits failed",
        )
        require(
            reports[0]["previous_container"]["Id"] == setup["owned_resources"]["api"]["Id"]
            and reports[1]["previous_container"]["Id"] == reports[0]["final_container"]["Id"],
            "Cross-case container chain differs",
        )
        require(
            base.timestamp(reports[0]["finished_at"]) <= base.timestamp(reports[1]["started_at"]),
            "Cases overlap or reordered",
        )
        require(
            semantics[0] == semantics[1] and len(semantics[0]) == 5200,
            "CROSS_CASE_SEMANTIC_DIFFERENCE",
        )
        result["common_successful_groups"] = 5200
        result["full_semantics_equal"] = True
        values = []
        for record in result["cases"]:
            values.append(
                {
                    **{
                        label: record["snapshots"][label]["process_rollup_bytes"]["Anonymous"]
                        for label in ("warmup", "after_5200", "after_20800", "idle")
                    },
                    "throughput": record["ledger"]["measured"]["successful_requests_per_second"],
                    "p95_ms": record["ledger"]["measured"]["success_latency"]["p95_ms"],
                }
            )
        result["screening"] = screening(*values)
        result["failures"].extend({"category": code} for code in result["screening"]["failures"])
        require(
            all(digest(local(root, n)) == sha for n, sha in root_hashes.items()),
            "Root evidence changed",
        )
        result["candidate_eligible"] = result["screening"]["passed"]
        result["status"] = "PASSED" if result["candidate_eligible"] else "REJECTED_SCREENING"
    except Exception as exc:
        result["failures"].append({"category": "EVIDENCE_PROTOCOL_OR_SEMANTICS", "error": str(exc)})
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args(argv)
    require(not args.out.exists(), "Refuse to replace an existing comparison")
    result = compare()
    with args.out.open("x", encoding="utf-8") as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write("\n")
    print(
        json.dumps({"status": result["status"], "candidate_eligible": result["candidate_eligible"]})
    )
    return 0 if result["candidate_eligible"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
