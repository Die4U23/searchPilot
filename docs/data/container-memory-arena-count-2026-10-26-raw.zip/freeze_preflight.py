"""Freeze the single-variable arena controls only after the failed baseline is sealed."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OLD = ROOT.parent / "extended-memory-2026-10-26"
sys.path.insert(0, str(REPO))
from diagnostic_arena_case import IMAGE, PROJECT, QUERY_SHA256, THREAD_ENV_KEYS  # noqa: E402

DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
HELPERS = ("setup_arena_controls.py", "diagnostic_arena_case.py", "compare_arena_controls.py")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def docker(*args):
    return subprocess.run(
        [DOCKER, *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=True,
        timeout=60,
        creationflags=subprocess.CREATE_NO_WINDOW,
    ).stdout


def main():
    require(not (ROOT / "preflight.json").exists(), "Refuse preflight overwrite")
    baseline = read(OLD / "final-two-hour/failed-stability-reconciliation.json")
    require(
        baseline["status"] == "FAILED_STABILITY_RECONCILED"
        and baseline["production_acceptance"] is False,
        "Full failed baseline required",
    )
    archive = read(OLD / "baseline-archive-verification.json")
    require(
        archive["status"] == "VERIFIED"
        and archive["production_acceptance"] is False
        and sha(REPO / archive["path"]) == archive["sha256"],
        "Sealed failed archive required",
    )
    cleaned = read(OLD / "cleanup-failed-normal-01.json")
    require(
        cleaned["status"] == "COMPLETED" and cleaned["original_volume_metadata_unchanged"] is True,
        "Failed normal resources must finish verified cleanup first",
    )
    private_scan = read(REPO / ".tmp/extended-memory-baseline-private-scan.json")
    require(
        private_scan["status"] == "PASSED" and private_scan["archive_sha256"] == archive["sha256"],
        "Archive private-value scan must match sealed archive",
    )
    protected = {}
    for name in ("inputs-sha256.json", "sources-sha256.json"):
        values = read(ROOT / name)
        require(
            all(sha(REPO / p) == value for p, value in values.items()),
            "Frozen bytes changed: " + name,
        )
        protected[name] = len(values)
    require(
        protected == {"inputs-sha256.json": 29, "sources-sha256.json": 187},
        "Unexpected frozen sets",
    )
    require(sha(ROOT / "fixture/queries.csv") == QUERY_SHA256, "Query differs")
    for actual, saved in (
        ("Dockerfile", "Dockerfile"),
        ("docker-compose.yml", "docker-compose.yml"),
        ("pyproject.toml", "pyproject.toml"),
        (".env.example", "public-env.txt"),
    ):
        require(
            sha(REPO / actual) == sha(ROOT / "source-config" / saved),
            "Public configuration changed",
        )
    require(
        not docker("ps", "-aq", "--filter", "label=com.docker.compose.project=" + PROJECT).strip(),
        "New control project already exists",
    )
    volume_names = docker("volume", "ls", "--format", "{{.Name}}").splitlines()
    require(PROJECT + "_pgdata" not in volume_names, "New control volume already exists")
    original_volume = json.loads(docker("volume", "inspect", "searchpilot_pgdata"))[0]
    require(
        original_volume == read(OLD / "preflight.json")["original_volume"],
        "Original volume changed",
    )
    image = json.loads(docker("image", "inspect", IMAGE))[0]
    require(
        image["Id"] == IMAGE
        and image["Config"]["Cmd"] == ["python", "scripts/docker_entrypoint.py"],
        "Wrong baseline image/command",
    )
    image_env = dict(
        value.split("=", 1) for value in image["Config"].get("Env", []) if "=" in value
    )
    extras = (
        "MALLOC_TRIM_THRESHOLD_",
        "MALLOC_MMAP_THRESHOLD_",
        "MALLOC_TOP_PAD_",
        "MALLOC_MMAP_MAX_",
        "GLIBC_TUNABLES",
        "LD_PRELOAD",
        "PYTHONMALLOC",
        "PYTHONTRACEMALLOC",
    )
    selected = {
        key: image_env.get(key)
        for key in (*THREAD_ENV_KEYS, *extras, "MALLOC_ARENA_MAX", "SEARCHPILOT_DISABLE_THP")
    }
    require(
        selected["MALLOC_ARENA_MAX"] == "2" and selected["SEARCHPILOT_DISABLE_THP"] == "true",
        "Wrong allocator base",
    )
    require(
        all(selected[key] is None for key in (*THREAD_ENV_KEYS, *extras)),
        "Unexpected native override",
    )
    record = {
        "status": "PASSED",
        "at": datetime.now(UTC).isoformat(),
        "image": IMAGE,
        "project": PROJECT,
        "query_sha256": QUERY_SHA256,
        "plan_sha256": sha(ROOT / "acceptance-plan.md"),
        "helper_sha256": {name: sha(ROOT / name) for name in HELPERS},
        "protected_counts": protected,
        "source_manifest_sha256": sha(ROOT / "sources-sha256.json"),
        "input_manifest_sha256": sha(ROOT / "inputs-sha256.json"),
        "baseline_reconciliation_sha256": sha(
            OLD / "final-two-hour/failed-stability-reconciliation.json"
        ),
        "baseline_archive_sha256": archive["sha256"],
        "baseline_cleanup_sha256": sha(OLD / "cleanup-failed-normal-01.json"),
        "original_volume": original_volume,
        "selected_image_environment": selected,
        "disk_free_bytes": shutil.disk_usage(REPO).free,
        "private_env_read": False,
        "external_llm_calls": 0,
        "scope": "Preflight only; no control workload has started",
        "freezer_sha256": sha(Path(__file__)),
    }
    with (ROOT / "preflight.json").open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
    print(
        json.dumps({"status": record["status"], "project": PROJECT, "helper_count": len(HELPERS)})
    )


if __name__ == "__main__":
    main()
