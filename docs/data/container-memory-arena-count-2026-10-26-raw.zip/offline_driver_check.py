"""Bounded mocked producer checks; never calls Docker or HTTP."""

import asyncio
import copy
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import diagnostic_arena_case as driver

ROOT = Path(__file__).resolve().parent
REAL_SLEEP = asyncio.sleep


async def no_idle(delay, *args, **kwargs):
    return await REAL_SLEEP(0 if delay == 120 else delay, *args, **kwargs)


def environment_and_ownership():
    poison = dict.fromkeys((*driver.THREAD_ENV_KEYS, *driver.ENVIRONMENT), "ambient-test")
    with patch.dict(os.environ, poison):
        clean = driver.clean_thread_environment()
        assert not any(key in clean for key in poison if key != "SEARCHPILOT_DISABLE_THP")

    def raw(name, service):
        return {
            "Id": name,
            "Name": "/" + name,
            "Image": driver.IMAGE,
            "RestartCount": 0,
            "State": {"OOMKilled": False},
            "Config": {
                "Cmd": ["python"],
                "Entrypoint": None,
                "Env": ["PRIVATE_KEY=sentinel", "OMP_NUM_THREADS", "MALLOC_ARENA_MAX=2"],
                "Labels": {
                    "com.docker.compose.project": driver.PROJECT,
                    "com.docker.compose.service": service,
                },
            },
            "Mounts": [],
        }

    rows = [raw(driver.API, "api"), raw(driver.DB, "db")]
    volume = {
        "Name": driver.PROJECT + "_pgdata",
        "Driver": "local",
        "Labels": {"com.docker.compose.project": driver.PROJECT},
        "CreatedAt": "toy",
    }
    rows[1]["Mounts"] = [
        {"Type": "volume", "Name": volume["Name"], "Destination": "/var/lib/postgresql/data"}
    ]
    assert "sentinel" not in json.dumps(driver.validate_owned_resources(rows, volume))
    rows[0]["Config"]["Labels"]["com.docker.compose.project"] = "unowned"
    try:
        driver.validate_owned_resources(rows, volume)
    except ValueError:
        pass
    else:
        raise AssertionError("Accepted unowned resource")


async def exercise(*, fail=False, exception=False, arena=2):
    with tempfile.TemporaryDirectory(prefix="offline-mock-", dir=ROOT) as directory:
        root = Path(directory)
        setup_dir = root / "setup"
        setup_dir.mkdir()
        (setup_dir / "expanded1300.queries.csv").write_bytes(
            (ROOT / "fixture/queries.csv").read_bytes()
        )
        (setup_dir / "diagnostic_case.base.py").write_bytes(driver.BASE_DRIVER.read_bytes())
        hashes = {}
        for name in ("diagnose_allocator", "soak_memory"):
            target = setup_dir / (name + ".executed.py")
            target.write_text("# toy frozen script")
            hashes[name + ".py"] = driver.digest(target)
        safe = {
            "Id": "before",
            "Name": "/" + driver.API,
            "Image": driver.IMAGE,
            "RestartCount": 0,
            "State": {"OOMKilled": False},
            "project": driver.PROJECT,
            "service": "api",
            "command": None,
            "entrypoint": None,
            "native_env": {**driver.ENVIRONMENT, "MALLOC_ARENA_MAX": str(arena)},
            "thread_environment": dict.fromkeys(driver.THREAD_ENV_KEYS),
            "diagnostic_mounts": [],
        }
        initial = {"api": safe, "db": {"Id": "fixed-db"}, "volume": {"Name": "toy-volume"}}
        setup = {
            "status": "READY_FOR_DIAGNOSTIC_RESTART",
            "image": driver.IMAGE,
            "query_sets": {
                "expanded1300": {
                    "snapshot": "expanded1300.queries.csv",
                    "sha256": driver.QUERY_SHA256,
                }
            },
            "executed_script_sha256": hashes,
            "owned_resources": initial,
            **dict.fromkeys(
                (
                    "frozen_inputs",
                    "frozen_source_sha256",
                    "root_evidence_sha256",
                    "local_source_sha256",
                    "public_config_sha256",
                    "helper_sha256",
                ),
                {},
            ),
        }
        (setup_dir / "summary.json").write_text(json.dumps(setup))
        state = {"new": False, "calls": 0, "active": 0, "max": 0, "logs": 0}
        case_name = "arena2-control-01" if arena == 2 else "arena1-treatment-01"
        case = root / case_name
        if arena == 1:
            previous = root / "arena2-control-01"
            previous.mkdir()
            (previous / "summary.json").write_text(
                json.dumps(
                    {
                        "collection_status": "COMPLETED",
                        "final_container": safe,
                    }
                )
            )

        def current():
            result = copy.deepcopy(safe)
            if state["new"]:
                result["Id"] = "after"
                override = json.loads((case / "override.yml").read_text())["services"]["api"]
                result["command"] = override["command"]
                result["diagnostic_mounts"] = [
                    {"Type": "bind", "Source": v["source"], "Destination": v["target"], "RW": False}
                    for v in override["volumes"]
                ]
            return result

        def owned():
            return {**initial, "api": current()}

        def command(argv, timeout=120):
            if "compose" in argv:
                state["new"] = True
                return ""
            if "cat" in argv:
                return "toy smaps"
            if "stats" in argv:
                return ""
            code = argv[-1]
            if "/proc/1/environ" in code:
                return json.dumps({**safe["native_env"], **dict.fromkeys(driver.THREAD_ENV_KEYS)})
            if "hashlib.sha256" in code:
                return json.dumps(hashes)
            if "sample_linux_process" in code:
                return "{}"
            raise AssertionError(argv)

        def control(*args):
            return {
                "allocator": {
                    "mallinfo2": {"available": True},
                    "malloc_info": {
                        "available": True,
                        "data": {"xml": "<malloc>" + "<heap/>" * arena + "</malloc>"},
                    },
                },
                "pymalloc": {"available": True},
                "tracemalloc": {"enabled": False},
            }

        async def health(*args):
            return {
                "available": True,
                "status": 200,
                "body": {"checks": dict.fromkeys(driver.READY_CHECKS, True)},
            }

        async def request(*args, **kwargs):
            state["calls"] += 1
            state["active"] += 1
            state["max"] = max(state["max"], state["active"])
            try:
                await REAL_SLEEP(0)
                measured = kwargs["phase"] == "measured"
                if exception and measured and kwargs["index"] == 45:
                    raise RuntimeError("toy request exception")
                failed = fail and measured and kwargs["index"] == 42
                row = {
                    "outcome": "timeout" if failed else "success",
                    "result_count": 0 if failed else 10,
                    "status_code": None if failed else 200,
                    "elapsed_ms": 10000 if failed else 1,
                    "model_version": "toy",
                }
                kwargs["event_sink"]({"event": "toy_result", "index": kwargs["index"], **row})
                return row
            finally:
                state["active"] -= 1

        def logs():
            state["logs"] += 1
            return "toy logs"

        with (
            patch.object(driver, "ROOT", root),
            patch.object(driver, "verify_frozen", lambda _: None),
            patch.object(driver, "command", command),
            patch.object(driver, "owned_resources", owned),
            patch.object(driver, "inspect_api", current),
            patch.object(driver, "control", control),
            patch.object(driver, "probe_health", health),
            patch.object(driver, "request_once", request),
            patch.object(driver, "capture_logs", logs),
            patch.object(driver.asyncio, "sleep", no_idle),
        ):
            try:
                await driver.main(
                    type(
                        "Args",
                        (),
                        {
                            "arena_max": arena,
                            "query_set": "expanded1300",
                            "case": case_name,
                        },
                    )()
                )
            except ExceptionGroup:
                assert exception
            report = json.loads((case / "summary.json").read_text())
        assert state["active"] == 0 and state["logs"] == 1
        if exception:
            assert report["status"] == report["collection_status"] == "FAILED"
        else:
            assert state["calls"] == 20816 and state["max"] == 32
            assert report["collection_status"] == "COMPLETED"
            assert report["workload_status"] == ("FAILED" if fail else "PASSED")
            assert report["summary"]["failures"] == int(fail)
            assert [r["label"] for r in report["snapshots"]] == [
                "ready",
                "warmup",
                "after_400",
                "after_5200",
                "after_10400",
                "after_15600",
                "after_20800",
                "idle",
                "gc",
                "trim",
            ]
            assert report["status"] == ("COMPLETED_WITH_WORKLOAD_FAILURES" if fail else "COMPLETED")
            assert (
                report["execution_manifest"]["actual_entry"] == "diagnostic_arena_case.executed.py"
            )
        return {
            "scenario": "exception" if exception else ("timeout" if fail else "all_success"),
            "status": report["status"],
            "calls": state["calls"],
            "active_after_cleanup": 0,
            "arena_max": arena,
        }


async def main():
    environment_and_ownership()
    results = [
        await exercise(**args) for args in ({}, {"fail": True}, {"exception": True}, {"arena": 1})
    ]
    print(
        json.dumps(
            {
                "offline_only": True,
                "no_http_or_docker": True,
                "environment_and_ownership": "PASSED",
                "scenarios": results,
            }
        )
    )


if __name__ == "__main__":
    asyncio.run(main())
