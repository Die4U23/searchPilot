# arena 数量对照与修复版两小时验收：运行前固定方案

日期：2026-10-26。本计划在本目录任何 setup / HTTP 负载前保存。
原正常入口两小时实验仍继续完成，原始目录为 ../extended-memory-2026-10-26/。
其已结束的 [3600,5400) 六个固定五分钟窗口中，RSS / Anonymous 中位数范围
均为 2.21875 MiB，超过原计划 2 MiB 上限；观察记录是 PARTIAL，不能代替
完整 7200 秒及恢复期验收。保留原报告、失败、源码和全部对照，不覆盖它们。

## 问题与单变量选择

已有 smaps / malloc_info / mallinfo2 对照支持次级分配区空闲驻留页保留：
晚期匿名台阶主要映射扩展与 heap1/arena 容量增量一致，used 下降而 free 上升，
idle/GC 后仍驻留，显式 trim 后可回收。该对应关系不是分配调用栈或库所有权证明。
编码并发2因超时拒绝；OMP=1因完整结果指纹不同且更多内存占用拒绝。
本次只检验 MALLOC_ARENA_MAX 从2到1，其他模型、线程、阈值、查询和服务源码不变。
不同时设置 trim/mmap 阈值，不在服务中添加主动 GC/trim。

## 匹配诊断筛选

- 顺序 arena2-control-01 → arena1-treatment-01；各新建 API 进程，同一全新 PG。
  项目 sp-memory-arena-count-20261026，API18234/PG15634，独立新卷。
- 镜像 sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1。
  同一 diagnose_allocator wrapper，THP-off；无 encoder 信号量、OMP getter 注入。
  唯一处理变量 MALLOC_ARENA_MAX=2→1，实际启动环境与 malloc_info heap 数必须核验。
- 同一1300查询字节 SHA256 7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6。
  c32、四模式轮转、limit10、timeout10、16预热、20800正式请求，无重试。
- ready/warmup/完成400/5200/10400/15600/20800时采集原生分配器、完整smaps、task IDs。
  中途不排空；采样非原子，记录实际完成计数。客户端全部结束后 idle120，再GC、trim
  各一次，仅作诊断；客户端结束不证明超时服务端同步工作已结束。
- 每10秒健康、PID、资源及背景观测；不读取私有.env，只使用公开配置和环境白名单。
  实际执行入口、派生源码、输入、环境、image ID、container链与项目资源均绑定SHA/ID。
- 两组必须各20800/20800及16/16成功，5200组各4次、组内和跨组完整结果/排名/模型/
  数量指纹一致，实际HTTP峰值32；零失败/未知/遗留/空成功。两组load健康及身份完整，
  THP/swap/OOM为零。baseline原生heap数量实际为2，treatment实际为1。
  heap数要求覆盖全部10个已声明snapshot，而非只取末点。负载健康/身份完整性按真实
  正式请求开始至最后排空的时间区间检查：load采样首末离边界≤10秒、最大gap≤15秒，
  至少floor(完整正式时长/10)-2点，全部相关来源可用；不能用仅两个健康点代替完整覆盖。
- 处理组 warmup→after20800 与 warmup→idle 的 Anonymous 增量，均须比控制减少至少
  2 MiB且至少20%；处理组 after5200→after20800 Anonymous 增长不得比控制多1 MiB。
  比较各组自身增量，不用跨进程绝对RSS差抵消启动差异。
  上述门槛统一使用 native snapshot 中 process.sources.smaps_rollup 的 Anonymous_bytes；
  顺序采集的完整smaps仅作复核，不在两份非原子观测中择低。控制端点增量必须为正，
  否则该比较标记 INSUFFICIENT_BASELINE_GROWTH、候选不合格。以整数bytes判定：
  improvement=control_delta-treatment_delta，要求 improvement≥2097152且
  5*improvement≥control_delta；后段要求 treatment_delta-control_delta≤1048576（含等号）。
- 处理组成功吞吐不得低于控制的80%，成功p95不得高于控制的125%；任何超时/错误或
  指纹差异均拒绝。它们是本次共享宿主的接受限制，不构成因果加速或容量SLA声明。
  吞吐分母为完整正式请求时长（含最终排空、不含idle/GC/trim）；两组采用同一延迟
  汇总算法。比值比较仅允许1e-9的浮点舍入容差，不四舍五入后判定。
- 采集完成、失败对账与候选通过分别记录。失败不重试掩盖、不提高timeout/降低并发。
  筛选通过只允许进入生产候选验证，不能等同长期内存稳定。

## 生产候选与正常入口验收

只有上述筛选通过才将正常 Docker/Compose 默认 arena 改为1，并同步公开示例与相关测试。
保留显式覆盖回2或0的能力；模型、labels、依赖和源数据继续冻结。
修复版源码及新不可变镜像在启动前重新冻结，原失败证据先完成独立归档。

- 独立全新项目 sp-memory-arena1-normal-20261026，API18235/PG15635；正常docker_entrypoint。
  无诊断包装、tracing、主动GC/trim。完整7200秒、c32、同一1300查询、四模式、limit10、
  timeout10、16预热、基线60秒、恢复600秒；无重试、负载期间不改源码/配置。
- 全部正式请求严格配对成功，5200组至少各12次，组内及与筛选结果指纹一致，客户端峰值32。
  所有load live/ready成功、7组件为真、全11资源来源可用、PID1身份一致、THP/swap/OOM零，
  无意外重启；17项业务及计划重启反馈持久性通过。
- 原两小时稳定性标准逐项保持：只取严格[0,7200)，整个[3600,7200)的RSS和Anonymous
  各自增长≤2MiB且OLS≤0.03MiB/分钟；[3600,4200)与[6600,7200)中位数差≤2MiB；
  第二小时12个固定5分钟中位数范围≤2MiB；从3600至6000每300秒起算的全部20分钟窗
  增长≤2MiB且OLS≤0.1MiB/分钟。每窗边界误差≤10秒、最大gap≤15秒、最少floor(时长/10)-2点。
- 全两小时、每5/20分钟、两个小时、末10/20分钟、恢复期全部披露；RSS/Anonymous/PSS/
  VmData/cgroup/客户端分别报告。没有数据不填零，所有失败及背景干扰保留。
- 原始账本重算、精确输入与审计源码SHA绑定、压缩包CRC及逐成员SHA回读、凭据排除后发布。
  旧失败与新通过不能合并成全通过；本次结果不证明无限运行无泄漏。

## 资源与交付

仅清理本轮已核验ID/label且完整证据已保存的专属项目；保留原searchpilot_pgdata和其他项目。
真实外部LLM调用0；私有.env不入Git。使用用户Git身份，无AI共同作者或贡献者署名。
完成本地验证和独立审查后提交PR，精确head CI全通过再自主合并，并检查main CI和署名。
