"""Fixed-count c32 diagnostic; no intermediate drain and no implicit GC/trim.

Only MALLOC_ARENA_MAX changes between cases. No encoder or OMP class patch.
All slow control/proc/Docker observations run off the client event loop.
"""

from __future__ import annotations

import argparse
import asyncio
import difflib
import hashlib
import json
import re
import subprocess
import time
import xml.etree.ElementTree as ET
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path

import httpx
from scripts.bench_concurrent import MODES, Config, read_queries, request_once, summarize
from scripts.validate_container_soak import clean_environment, probe_health

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = "sp-memory-arena-count-20261026"
API = PROJECT + "-api-1"
DB = PROJECT + "-db-1"
IMAGE = "sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1"
QUERY_SHA256 = "7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6"
BASE_DRIVER = REPO / "artifacts/extended-memory-2026-10-26/diagnostic_case.py"
BASE_URL = "http://127.0.0.1:18234"
DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
TOTAL, CONCURRENCY = 20800, 32
CHECKPOINTS = (400, 5200, 10400, 15600, 20800)
ENVIRONMENT = {
    "MALLOC_ARENA_MAX": "2",
    "SEARCHPILOT_DISABLE_THP": "true",
    "GLIBC_TUNABLES": None,
    "LD_PRELOAD": None,
    "PYTHONMALLOC": None,
    "PYTHONTRACEMALLOC": None,
}
THREAD_ENV_KEYS = (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "OMP_THREAD_LIMIT",
    "OMP_DYNAMIC",
    "MKL_DYNAMIC",
    "NUMEXPR_NUM_THREADS",
    "NUMEXPR_MAX_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "OMP_MAX_ACTIVE_LEVELS",
    "OMP_NESTED",
    "OMP_PROC_BIND",
    "OMP_PLACES",
    "KMP_AFFINITY",
    "KMP_BLOCKTIME",
    "KMP_SETTINGS",
    "TOKENIZERS_PARALLELISM",
    "RAYON_NUM_THREADS",
)
THREAD_ENV_PREFIXES = (
    "OMP_",
    "MKL_",
    "OPENBLAS_",
    "NUMEXPR_",
    "VECLIB_",
    "KMP_",
    "TOKENIZERS_",
    "RAYON_",
)


def clean_thread_environment():
    return {
        key: value
        for key, value in clean_environment().items()
        if not key.upper().startswith(THREAD_ENV_PREFIXES)
    }


READY_CHECKS = ("search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database")
SAMPLE_CODE = (
    "import json;from pathlib import Path;from scripts.soak_memory import sample_linux_process;"
    "r=sample_linux_process(1);"
    "r['task_ids']=sorted(int(p.name) for p in Path('/proc/1/task').iterdir());"
    "r['host_loadavg']=Path('/proc/loadavg').read_text().strip();print(json.dumps(r))"
)


def now():
    return datetime.now(UTC).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def command(argv, timeout=120):
    return subprocess.run(
        argv,
        cwd=REPO,
        env=clean_thread_environment(),
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    ).stdout


def safe_container(raw):
    config = raw["Config"]
    env = dict(item.split("=", 1) for item in config.get("Env", []) if "=" in item)
    return {
        **{key: raw[key] for key in ("Id", "Name", "Image", "RestartCount", "State")},
        "command": config.get("Cmd"),
        "entrypoint": config.get("Entrypoint"),
        "project": config["Labels"].get("com.docker.compose.project"),
        "native_env": {key: env.get(key) for key in ENVIRONMENT},
        "thread_environment": {key: env.get(key) for key in THREAD_ENV_KEYS},
        "service": config["Labels"].get("com.docker.compose.service"),
        "diagnostic_mounts": [
            {key: mount[key] for key in ("Type", "Source", "Destination", "RW")}
            for mount in raw.get("Mounts", [])
            if mount["Destination"]
            in (
                "/app/scripts/diagnose_allocator.py",
                "/app/scripts/soak_memory.py",
                "/tmp/soak_memory.py",
            )
        ],
    }


def validate_owned_resources(rows, volume):
    require(
        len(rows) == 2 and {row["Name"] for row in rows} == {"/" + API, "/" + DB},
        "Unexpected resource names",
    )
    require(
        all(row["Config"]["Labels"].get("com.docker.compose.project") == PROJECT for row in rows),
        "Resource outside owned project",
    )
    require(
        volume["Name"] == PROJECT + "_pgdata"
        and volume["Labels"].get("com.docker.compose.project") == PROJECT,
        "Volume outside owned project",
    )
    require(
        all(
            row["Config"]["Labels"].get("com.docker.compose.service")
            == ("api" if row["Name"] == "/" + API else "db")
            for row in rows
        ),
        "Owned resource service labels differ",
    )
    db = next(row for row in rows if row["Name"] == "/" + DB)
    require(
        any(
            mount.get("Type") == "volume" and mount.get("Name") == volume["Name"]
            for mount in db.get("Mounts", [])
        ),
        "DB is not using the owned volume",
    )
    return {
        "api": safe_container(next(row for row in rows if row["Name"] == "/" + API)),
        "db": safe_container(db),
        "volume": {key: volume[key] for key in ("Name", "Driver", "Labels", "CreatedAt")},
    }


def owned_resources():
    rows = json.loads(command([DOCKER, "inspect", API, DB]))
    volume = json.loads(command([DOCKER, "volume", "inspect", PROJECT + "_pgdata"]))[0]
    return validate_owned_resources(rows, volume)


def inspect_api():
    return safe_container(json.loads(command([DOCKER, "inspect", API]))[0])


def capture_logs():
    result = subprocess.run(
        [DOCKER, "logs", API],
        cwd=REPO,
        env=clean_thread_environment(),
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return result.stdout + result.stderr


def control(path="/snapshot", payload=None):
    body = json.dumps(payload).encode() if payload is not None else None
    code = (
        "import urllib.request; r=urllib.request.Request('http://127.0.0.1:8779' + "
        + repr(path)
        + ",data="
        + repr(body)
        + ",headers={'Content-Type':'application/json'});"
        "print(urllib.request.urlopen(r,timeout=60).read().decode())"
    )
    return json.loads(command([DOCKER, "exec", API, "python", "-c", code], 75))


def ready(probe):
    return (
        probe.get("available") is True
        and probe.get("status") == 200
        and all(probe.get("body", {}).get("checks", {}).get(k) is True for k in READY_CHECKS)
    )


def verify_frozen(setup):
    for mapping in (
        setup["frozen_inputs"],
        setup["local_source_sha256"],
        setup["public_config_sha256"],
        setup["frozen_source_sha256"],
    ):
        require(
            all(digest(REPO / name) == value for name, value in mapping.items()),
            "Frozen repository input/source/config changed",
        )
    require(
        all(digest(ROOT / name) == value for name, value in setup["helper_sha256"].items()),
        "Frozen diagnostic helper changed",
    )
    require(
        digest(ROOT / "setup/diagnostic_case.base.py") == setup["base_driver_sha256"],
        "Unexecuted base driver snapshot changed",
    )
    for name, expected in setup["setup_artifact_sha256"].items():
        require(digest(ROOT / "setup" / name) == expected, "Setup artifact changed: " + name)
    for name, expected in setup["root_evidence_sha256"].items():
        require(digest(ROOT / name) == expected, "Root plan/preflight/input changed: " + name)
    for name, expected in setup["executed_script_sha256"].items():
        require(
            digest(ROOT / "setup" / (Path(name).stem + ".executed.py")) == expected,
            "Executed script snapshot changed: " + name,
        )


async def main(args):
    require(
        args.arena_max in (1, 2) and args.query_set == "expanded1300",
        "Use the declared arena count protocol",
    )
    expected_case = "arena2-control-01" if args.arena_max == 2 else "arena1-treatment-01"
    require(args.case == expected_case, "Use the declared sequential case names")
    environment = {**ENVIRONMENT, "MALLOC_ARENA_MAX": str(args.arena_max)}
    thread_environment = {key: None for key in THREAD_ENV_KEYS}
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]*", args.case), "Use a unique lowercase case name")
    setup = read(ROOT / "setup/summary.json")
    require(setup.get("status") == "READY_FOR_DIAGNOSTIC_RESTART", "Diagnostic setup is not ready")
    for path in ROOT.glob("*/summary.json"):
        previous = read(path)
        require(
            not (previous.get("query_set") and previous.get("status") == "RUNNING"),
            "Another diagnostic case is still RUNNING; preserve/reconcile it first",
        )
    verify_frozen(setup)
    previous_case = None
    if args.arena_max == 1:
        previous_case = read(ROOT / "arena2-control-01/summary.json")
        require(
            previous_case.get("collection_status") == "COMPLETED",
            "Finish and retain arena2 collection before arena1",
        )
    queries, query_raw = read_queries(
        ROOT / "setup" / setup["query_sets"][args.query_set]["snapshot"]
    )
    query_sha = hashlib.sha256(query_raw).hexdigest()
    require(query_sha == setup["query_sets"][args.query_set]["sha256"], "Query snapshot changed")
    require(query_sha == QUERY_SHA256 and len(queries) == 1300, "Wrong frozen query fixture")
    out = ROOT / args.case
    out.mkdir(exist_ok=False)
    (out / "queries.csv").write_bytes(query_raw)
    for name in setup["executed_script_sha256"]:
        source = ROOT / "setup" / (Path(name).stem + ".executed.py")
        (out / source.name).write_bytes(source.read_bytes())
    base_bytes = (ROOT / "setup/diagnostic_case.base.py").read_bytes()
    driver_bytes = Path(__file__).read_bytes()
    (out / "diagnostic_case.base.py").write_bytes(base_bytes)
    (out / "diagnostic_arena_case.executed.py").write_bytes(driver_bytes)
    (out / "derived-driver.diff").write_text(
        "".join(
            difflib.unified_diff(
                base_bytes.decode()
                .replace("\r\n", "\n")
                .replace("\r", "\n")
                .splitlines(keepends=True),
                driver_bytes.decode()
                .replace("\r\n", "\n")
                .replace("\r", "\n")
                .splitlines(keepends=True),
                fromfile="diagnostic_case.py (unexecuted base)",
                tofile="diagnostic_arena_case.py (entry)",
            )
        ),
        encoding="utf-8",
    )
    prefix = (
        "import ctypes;c=ctypes.CDLL(None,use_errno=True);"
        "r=c.prctl(41,1,0,0,0);assert r==0,ctypes.get_errno();"
        "assert c.prctl(42,0,0,0,0)==1;from scripts.diagnose_allocator import main;main()"
    )
    override = {
        "services": {
            "api": {
                "environment": {**environment, **thread_environment},
                "command": ["python", "-c", prefix],
                "volumes": [
                    {
                        "type": "bind",
                        "source": str(ROOT / "setup" / (Path(name).stem + ".executed.py")),
                        "target": "/app/scripts/" + name,
                        "read_only": True,
                    }
                    for name in ("diagnose_allocator.py", "soak_memory.py")
                ],
            }
        }
    }
    (out / "override.yml").write_text(json.dumps(override, indent=2), encoding="utf-8")
    compose = [
        DOCKER,
        "compose",
        "--env-file",
        str(ROOT / "setup/public-env.txt"),
        "-p",
        PROJECT,
        "-f",
        str(REPO / "docker-compose.yml"),
        "-f",
        str(ROOT / "setup/compose.override.yml"),
        "-f",
        str(out / "override.yml"),
    ]
    manifest = {
        "schema_version": 1,
        "variant": "arena_count",
        "arena_max": args.arena_max,
        "actual_entry": "diagnostic_arena_case.executed.py",
        "base_copy_role": "diagnostic_case.base.py is an unexecuted derivation reference",
        "base_driver_sha256": hashlib.sha256(base_bytes).hexdigest(),
        "derived_driver_sha256": hashlib.sha256(driver_bytes).hexdigest(),
        "derived_diff_sha256": digest(out / "derived-driver.diff"),
        "override_sha256": digest(out / "override.yml"),
        "diagnostic_wrapper_sha256": setup["executed_script_sha256"]["diagnose_allocator.py"],
        "class_patch": None,
        "expected_command": override["services"]["api"]["command"],
        "expected_native_environment": environment,
        "expected_thread_environment": thread_environment,
        "expected_project": PROJECT,
        "expected_image": IMAGE,
        "root_evidence_sha256": setup["root_evidence_sha256"],
    }
    report = {
        "status": "RUNNING",
        "collection_status": "RUNNING",
        "workload_status": "UNDETERMINED",
        "arena_max": args.arena_max,
        "execution_manifest": manifest,
        "drain_scope": "Client pending/result completion only. No encoder/handler counter patch; "
        "after a timeout this cannot establish all synchronous server work ended.",
        "started_at": now(),
        "case": args.case,
        "query_set": args.query_set,
        "query_sha256": query_sha,
        "query_count": len(queries),
        "requests": TOTAL,
        "concurrency": CONCURRENCY,
        "timeout": 10,
        "limit": 10,
        "checkpoints": list(CHECKPOINTS),
        "idle_seconds": 120,
        "health_period_seconds": 10,
        "external_llm_calls": 0,
        "private_env_read": False,
        "input_sha256": setup["frozen_inputs"],
        "frozen_source_sha256": setup["frozen_source_sha256"],
        "root_evidence_sha256": setup["root_evidence_sha256"],
        "compose_command": compose,
        "source_sha256": setup["local_source_sha256"],
        "executed_script_sha256": setup["executed_script_sha256"],
        "public_config_sha256": setup["public_config_sha256"],
        "helper_sha256": setup["helper_sha256"],
        "checkpoint_triggers": [],
        "snapshots": [],
        "method": "Arena-count-only intervention; no encoder or OMP monkeypatch. "
        "Fixed-count round-robin query x four modes; 32 continuous workers, "
        "no intermediate drain. Snapshots sequential/non-atomic while issuing continues; "
        "explicit idle120, GC, trim only after drain. Same fresh DB, force-recreated API; "
        "same expanded query fixture and default thread policy. All-container Docker stats "
        "and Linux loadavg are not complete Windows-host CPU monitoring.",
    }
    phase, completed, inflight, peak = "startup", 0, 0, 0
    stop = asyncio.Event()
    monitor = observer = None
    owned_api_verified = False

    def save():
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    async def snap(label, path="/snapshot", payload=None, trigger=None):
        before = {"completed": completed, "inflight": inflight}
        started = now()
        value = await asyncio.to_thread(control, path, payload)
        smaps = await asyncio.to_thread(command, [DOCKER, "exec", API, "cat", "/proc/1/smaps"])
        external = json.loads(
            await asyncio.to_thread(command, [DOCKER, "exec", API, "python", "-c", SAMPLE_CODE])
        )
        after = {"completed": completed, "inflight": inflight}
        row = {
            "label": label,
            "started_at": started,
            "at": now(),
            "data": value,
            "counts_before": before,
            "counts_after": after,
            "trigger": trigger,
            "external_process": external,
            "atomic": False,
        }
        await asyncio.to_thread(
            (out / ("smaps-" + label + ".txt")).write_text, smaps, encoding="utf-8"
        )
        report["snapshots"].append(row)
        frozen_report = json.dumps(report, indent=2) + "\n"
        await asyncio.to_thread((out / "summary.json").write_text, frozen_report, encoding="utf-8")
        native = value.get("snapshot", value)
        require(
            native["allocator"]["mallinfo2"]["available"] is True
            and native["allocator"]["malloc_info"]["available"] is True
            and native["pymalloc"]["available"] is True,
            "Native diagnostic unavailable",
        )
        require(native["tracemalloc"]["enabled"] is False, "Unexpected tracing intervention")
        require("encoder_concurrency" not in native, "Unexpected class patch")
        xml = ET.fromstring(native["allocator"]["malloc_info"]["data"]["xml"])
        row["observed_glibc_heaps"] = len(xml.findall("./heap"))
        # Persist the derived heap count as well as the original native snapshot.
        frozen_report = json.dumps(report, indent=2) + "\n"
        await asyncio.to_thread((out / "summary.json").write_text, frozen_report, encoding="utf-8")
        require(
            row["observed_glibc_heaps"] == args.arena_max,
            "Actual glibc heap count does not match arena control",
        )

    async def observation(argv, lines=False):
        try:
            raw_output = await asyncio.to_thread(command, argv, 8)
            return {
                "available": True,
                "data": [json.loads(line) for line in raw_output.splitlines()]
                if lines
                else json.loads(raw_output),
            }
        except Exception as exc:
            return {"available": False, "error_type": type(exc).__name__}

    async def sample(client):
        with (out / "samples.jsonl").open("x", encoding="utf-8") as sink:
            while not stop.is_set():
                clock = time.perf_counter()
                row = {"at": now(), "phase": phase, "completed": completed, "inflight": inflight}
                server, stats, live, health = await asyncio.gather(
                    observation([DOCKER, "exec", API, "python", "-c", SAMPLE_CODE]),
                    observation([DOCKER, "stats", "--no-stream", "--format", "{{json .}}"], True),
                    probe_health(client, "live"),
                    probe_health(client, "ready"),
                )
                row.update(
                    server=server.get("data", server),
                    stats=stats,
                    live=live,
                    ready=health,
                    sample_seconds=time.perf_counter() - clock,
                )
                sink.write(json.dumps(row) + "\n")
                sink.flush()
                with suppress(TimeoutError):
                    await asyncio.wait_for(stop.wait(), max(0.01, 10 - row["sample_seconds"]))

    save()
    try:
        resources = await asyncio.to_thread(owned_resources)
        before = resources["api"]
        require(
            before["project"] == PROJECT and before["Image"] == IMAGE,
            "Existing API does not match owned project/image",
        )
        expected_previous = (
            previous_case["final_container"]["Id"]
            if previous_case
            else setup["owned_resources"]["api"]["Id"]
        )
        require(before["Id"] == expected_previous, "Sequential API container chain differs")
        require(
            resources["db"]["Id"] == setup["owned_resources"]["db"]["Id"]
            and resources["volume"] == setup["owned_resources"]["volume"],
            "Owned DB/volume changed",
        )
        report["resources_before"] = resources
        report["previous_container"] = before
        report["compose_output"] = await asyncio.to_thread(
            command,
            compose + ["up", "-d", "--no-deps", "--no-build", "--force-recreate", "api"],
            180,
        )
        current = await asyncio.to_thread(inspect_api)
        report["container"] = current
        require(
            current["project"] == PROJECT and current["Image"] == IMAGE,
            "Recreated API project/image mismatch",
        )
        owned_api_verified = True
        require(
            current["command"] == manifest["expected_command"] and current["service"] == "api",
            "Unexpected diagnostic entry",
        )
        for target in ("/app/scripts/diagnose_allocator.py", "/app/scripts/soak_memory.py"):
            mounts = [m for m in current["diagnostic_mounts"] if m["Destination"] == target]
            require(
                len(mounts) == 1 and mounts[0]["Type"] == "bind" and mounts[0]["RW"] is False,
                "Frozen diagnostic mount missing or writable",
            )
        hash_code = (
            "import json,hashlib;from pathlib import Path;names="
            + repr(["diagnose_allocator.py", "soak_memory.py"])
            + ";print(json.dumps({n:hashlib.sha256("
            "(Path('/app/scripts')/n).read_bytes()).hexdigest() for n in names}))"
        )
        report["runtime_script_sha256"] = json.loads(
            await asyncio.to_thread(command, [DOCKER, "exec", API, "python", "-c", hash_code])
        )
        require(
            report["runtime_script_sha256"]
            == {
                name: setup["executed_script_sha256"][name]
                for name in ("diagnose_allocator.py", "soak_memory.py")
            },
            "Runtime diagnostic source differs from frozen mounted scripts",
        )
        manifest["runtime_script_sha256"] = report["runtime_script_sha256"]
        manifest["runtime"] = {
            key: current[key]
            for key in (
                "Id",
                "Image",
                "command",
                "entrypoint",
                "project",
                "diagnostic_mounts",
                "native_env",
                "thread_environment",
            )
        }
        with (out / "execution-manifest.json").open("x", encoding="utf-8") as sink:
            json.dump(manifest, sink, indent=2)
            sink.write("\n")
        require(
            current["Id"] != before["Id"]
            and current["Image"] == setup["image"]
            and current["project"] == PROJECT,
            "API identity/image mismatch",
        )
        require(current["native_env"] == environment, "Container native environment mismatch")
        env_code = (
            "import json;from pathlib import Path;keys="
            + repr([*ENVIRONMENT, *THREAD_ENV_KEYS])
            + ";"
            "parts=Path('/proc/1/environ').read_bytes().split(b'\\0');"
            "values={k.decode():v.decode() for p in parts if b'=' in p "
            "for k,v in [p.split(b'=',1)] if k.decode() in keys};"
            "print(json.dumps({k:values.get(k) for k in keys}))"
        )
        process_environment = json.loads(
            await asyncio.to_thread(command, [DOCKER, "exec", API, "python", "-c", env_code])
        )
        report["process_native_environment"] = {
            key: process_environment[key] for key in ENVIRONMENT
        }
        report["process_thread_environment"] = {
            key: process_environment[key] for key in THREAD_ENV_KEYS
        }
        require(
            current["thread_environment"]
            == report["process_thread_environment"]
            == thread_environment,
            "Thread environment contaminated",
        )
        require(
            report["process_native_environment"] == environment, "PID1 native environment mismatch"
        )
        async with (
            httpx.AsyncClient(
                base_url=BASE_URL,
                trust_env=False,
                timeout=10,
                limits=httpx.Limits(
                    max_connections=CONCURRENCY, max_keepalive_connections=CONCURRENCY
                ),
            ) as client,
            httpx.AsyncClient(base_url=BASE_URL, trust_env=False, timeout=10) as health,
        ):
            async with asyncio.timeout(240):
                while not ready(await probe_health(health, "ready")):
                    await asyncio.sleep(0.5)
            await snap("ready")
            config = Config(
                base_url=BASE_URL,
                requests=TOTAL,
                concurrency=CONCURRENCY,
                timeout=10,
                warmup=4,
                limit=10,
            )
            results, warmup = [], []
            with (out / "requests.jsonl").open("x", encoding="utf-8") as ledger:

                def event_sink(event):
                    ledger.write(json.dumps({"at": now(), **event}) + "\n")
                    ledger.flush()

                for mode_index, mode in enumerate(MODES):
                    for index in range(4):
                        warmup.append(
                            await request_once(
                                client,
                                config,
                                index=mode_index * 4 + index,
                                mode=mode,
                                query=queries[index],
                                phase="warmup",
                                event_sink=event_sink,
                            )
                        )
                report["warmup"] = summarize(warmup, 0)
                require(
                    all(row["outcome"] == "success" and row["result_count"] > 0 for row in warmup),
                    "Warmup failed; evidence preserved",
                )
                await snap("warmup")
                phase = "load"
                report["load_started_at"] = now()
                load_clock = time.perf_counter()
                queue = asyncio.Queue()
                monitor = asyncio.create_task(sample(health))

                async def checkpoints():
                    for expected in CHECKPOINTS:
                        trigger = await queue.get()
                        require(trigger["completed"] == expected, "Checkpoint sequence mismatch")
                        await snap("after_" + str(expected), trigger=trigger)
                        print(
                            json.dumps(
                                {
                                    "case": args.case,
                                    "trigger_completed": expected,
                                    "actual_completed": completed,
                                }
                            ),
                            flush=True,
                        )

                observer = asyncio.create_task(checkpoints())
                indices = iter(range(TOTAL))

                async def worker():
                    nonlocal completed, inflight, peak
                    for index in indices:
                        dispatched_ms = (time.perf_counter() - load_clock) * 1000
                        inflight += 1
                        peak = max(peak, inflight)
                        try:
                            result = await request_once(
                                client,
                                config,
                                index=index,
                                mode=MODES[index % len(MODES)],
                                query=queries[(index // len(MODES)) % len(queries)],
                                phase="measured",
                                dispatched_ms=dispatched_ms,
                                event_sink=event_sink,
                            )
                        finally:
                            inflight -= 1
                        results.append(result)
                        completed += 1
                        if completed in CHECKPOINTS:
                            trigger = {
                                "completed": completed,
                                "at": now(),
                                "elapsed_seconds": time.perf_counter() - load_clock,
                            }
                            report["checkpoint_triggers"].append(trigger)
                            queue.put_nowait(trigger)
                        if monitor.done():
                            monitor.result()
                            raise RuntimeError("Sampler stopped before load completed")
                        if observer.done():
                            observer.result()

                # Await cancelled workers before closing their ledger on any worker/probe failure.
                async with asyncio.timeout(3600):
                    async with asyncio.TaskGroup() as group:
                        for _ in range(CONCURRENCY):
                            group.create_task(worker())
                report["load_seconds"] = time.perf_counter() - load_clock
                report["load_finished_at"] = now()
                report["peak_inflight"] = peak
                report["summary"] = summarize(results, report["load_seconds"])
                phase = "post_load_snapshot"
                await observer
                require(len(results) == TOTAL, "Incomplete client request denominator")
                report["workload_status"] = (
                    "PASSED"
                    if all(
                        row["outcome"] == "success" and row["result_count"] > 0 for row in results
                    )
                    else "FAILED"
                )
            phase = "idle"
            report["idle_started_at"] = now()
            await asyncio.sleep(120)
            await snap("idle")
            phase = "intervention"
            await snap("gc", "/gc", {})
            await snap("trim", "/trim", {})
            report["ready_after"] = await probe_health(health, "ready")
            require(ready(report["ready_after"]), "Final readiness failed")
            stop.set()
            await monitor
        report["final_container"] = await asyncio.to_thread(inspect_api)
        require(
            report["final_container"]["Id"] == current["Id"]
            and report["final_container"]["RestartCount"] == 0
            and report["final_container"]["State"]["OOMKilled"] is False,
            "API identity/OOM/restart changed",
        )
        verify_frozen(setup)
        final_resources = await asyncio.to_thread(owned_resources)
        report["resources_after"] = final_resources
        require(
            final_resources["db"]["Id"] == resources["db"]["Id"]
            and final_resources["volume"] == resources["volume"],
            "DB/volume changed",
        )
        require(
            report["final_container"]["command"] == current["command"]
            and report["final_container"]["native_env"] == environment
            and report["final_container"]["thread_environment"] == thread_environment
            and report["final_container"]["diagnostic_mounts"] == current["diagnostic_mounts"],
            "Runtime configuration changed",
        )
        require(
            digest(out / "override.yml") == manifest["override_sha256"]
            and digest(Path(__file__)) == manifest["derived_driver_sha256"],
            "Executed driver/override changed",
        )
        report["collection_status"] = "COMPLETED"
        report["status"] = (
            "COMPLETED"
            if report["workload_status"] == "PASSED"
            else "COMPLETED_WITH_WORKLOAD_FAILURES"
        )
    except BaseException as exc:
        report.update(status="FAILED", collection_status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        stop.set()
        for task in (monitor, observer):
            if task is not None and not task.done():
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
        report["finished_at"] = now()
        save()
        try:
            if owned_api_verified:
                output = await asyncio.to_thread(capture_logs)
                (out / "api.log").write_text(output, encoding="utf-8")
            else:
                report["log_skipped"] = "Owned recreated API identity not verified"
                save()
        except Exception as exc:
            report["log_error"] = type(exc).__name__
            report["status"] = "FAILED"
            report["collection_status"] = "FAILED"
            save()
    require(report["collection_status"] == "COMPLETED", "Diagnostic collection/log capture failed")
    print(
        json.dumps({"case": args.case, "status": report["status"], "summary": report["summary"]}),
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True)
    parser.add_argument("--query-set", default="expanded1300", choices=("expanded1300",))
    parser.add_argument("--arena-max", required=True, type=int, choices=(2, 1))
    asyncio.run(main(parser.parse_args()))
