import argparse, ctypes, hashlib, importlib.util, json, os, time
from pathlib import Path
from searchpilot.recommend.history import load_user_history
p=argparse.ArgumentParser(); p.add_argument('--source',required=True); p.add_argument('--users',type=int,default=0); p.add_argument('--out',required=True); a=p.parse_args()
source=Path(a.source); data=Path('data/processed/d3a904f41240/user_history.parquet')
spec=importlib.util.spec_from_file_location('bench_itemcf',source); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
t=time.monotonic(); histories=load_user_history(data)
if a.users: histories=dict(list(histories.items())[:a.users])
load=time.monotonic()-t
model=mod.ItemCFModel(); t=time.monotonic(); model.fit(histories); elapsed=time.monotonic()-t
class PMC(ctypes.Structure):
 _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage']]
ctypes.windll.kernel32.GetCurrentProcess.restype=ctypes.c_void_p
m=PMC(); m.cb=ctypes.sizeof(m)
assert ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(ctypes.windll.kernel32.GetCurrentProcess()),ctypes.byref(m),m.cb)
encoded=json.dumps(model.to_dict(),sort_keys=True,separators=(',',':')).encode()
predictions=[model.predict(h,frozenset(),10) for h in histories.values()]
record={'status':'completed','pid':os.getpid(),'users':len(histories),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'data_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),'load_seconds':load,'fit_seconds':elapsed,'process_peak_working_set_bytes_at_fit_end':m.PeakWorkingSetSize,'process_peak_pagefile_bytes_at_fit_end':m.PeakPagefileUsage,'model_sha256_canonical':hashlib.sha256(encoded).hexdigest(),'prediction_sha256_canonical':hashlib.sha256(json.dumps(predictions,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'prediction_count':len(predictions)}
Path(a.out).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8'); print(json.dumps(record),flush=True)
