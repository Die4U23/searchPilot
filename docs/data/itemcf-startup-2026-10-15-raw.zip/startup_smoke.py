import hashlib, json, math, os, socket, subprocess, sys, time
from pathlib import Path
import httpx
from searchpilot.recommend.history import load_user_history
root=Path('artifacts/itemcf-startup-2026-10-15'); run=root/'startup-001'; run.mkdir(exist_ok=False)
histories=load_user_history(Path('data/processed/d3a904f41240/user_history.parquet'))
user=next(u for u,h in histories.items() if len(h)>=3)
with socket.socket() as sock: sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
env=os.environ.copy()
for key in list(env):
 if key.startswith(('SEARCHPILOT_','OPENAI_','ARCBENCH_')): del env[key]
env.update(SEARCHPILOT_DATABASE_URL='',SEARCHPILOT_API_TOKEN='',SEARCHPILOT_DATA_DIR=str(Path('data').resolve()),SEARCHPILOT_ARTIFACT_DIR=str(Path('artifacts').resolve()),SEARCHPILOT_DATA_VERSION='d3a904f41240',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONPATH=str(Path('src').resolve()))
stop=run/'stop'; state=run/'state.json'; started=time.monotonic(); records=[]; result={'database_mode':'disabled; in-memory feedback','startup_deadline_seconds':120,'business_deadline_seconds':60,'port':port,'status':'running'}
log=(run/'server.log').open('w',encoding='utf-8'); p=subprocess.Popen([sys.executable,str(root/'server.py'),'--port',str(port),'--stop',str(stop),'--state',str(state)],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
result['launcher_pid']=p.pid
try:
 with httpx.Client(base_url=f'http://127.0.0.1:{port}',trust_env=False,timeout=1) as client:
  while time.monotonic()-started<120:
   if p.poll() is not None: raise RuntimeError('server_exited_before_ready')
   try:
    res=client.get('/health/ready')
    if res.status_code==200: break
   except httpx.HTTPError: pass
   time.sleep(0.2)
  else: raise TimeoutError('startup_deadline')
  result.update(ready_seconds=time.monotonic()-started,ready=res.json(),server=json.loads(state.read_text(encoding='utf-8')))
  assert all(result['ready']['checks'].get(k) is True for k in ['search','recommend','feedback','vector_index','ltr','ctr'])
  assert client.get('/health/live').status_code==200
  def call(label,path,payload=None):
   t=time.monotonic(); record={'label':label,'status':'pending'}; records.append(record)
   (run/'requests.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
   try:
    res=client.post(path,json=payload,timeout=60) if payload is not None else client.get(path,timeout=60)
    record.update(http_status=res.status_code,elapsed_seconds=time.monotonic()-t,status='returned')
    body=res.json(); record['response']=body
    assert res.status_code==200
    record['status']='completed'; return body
   except Exception as exc:
    record.update(status='failed',error=type(exc).__name__,elapsed_seconds=time.monotonic()-t); raise
   finally: (run/'requests.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
  for mode in ['bm25','vector','hybrid','ltr']:
   body=call('search_'+mode,'/search',{'query':'microsoft','mode':mode,'limit':5}); assert len(body['results'])==5
  warm=call('recommend_existing_user','/recommend',{'user_id':user,'limit':5})
  assert warm['channel']=='itemcf' and warm['cold_start'] is False
  cold=call('recommend_unknown_user','/recommend',{'user_id':'startup-validation-unknown-user','limit':5})
  assert cold['channel']=='popular' and cold['cold_start'] is True
  for body in [warm,cold]:
   assert len(body['results'])==5 and len({v['item_id'] for v in body['results']})==5
   assert [v['rank'] for v in body['results']]==list(range(1,6))
  ctr=call('ctr','/ctr/score',{'user_id':user,'candidates':[{'item_id':warm['results'][0]['item_id'],'bid':1.0}]})
  assert ctr['model_version'] and ctr['calibrator_version']
  assert all(math.isfinite(v[k]) and 0<=v[k]<=1 for v in ctr['results'] for k in ['pctr','pctr_calibrated'])
  registry=json.loads(Path('artifacts/experiments/registry.json').read_text(encoding='utf-8'))
  # Registry serialization is read-only; choose an existing experiment from its records.
  experiment=(registry['records'] if isinstance(registry,dict) else registry)[0]['experiment_id']
  call('experiment','/experiments/'+experiment)
  result['final_ready']=client.get('/health/ready').json(); assert result['final_ready']['status']=='ready'
  assert client.get('/health/live').status_code==200
  result['status']='completed'
except Exception as exc: result.update(status='failed',error=type(exc).__name__,reason=str(exc))
finally:
 stop.touch()
 try: result['exit_code']=p.wait(timeout=15); result['shutdown']='graceful'
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True); p.wait(); result.update(exit_code=p.returncode,shutdown='forced')
 log.close()
 with socket.socket() as sock: result['port_closed']=sock.connect_ex(('127.0.0.1',port))!=0
 result['requests_attempted']=len(records); result['requests_completed']=sum(r['status']=='completed' for r in records)
 result['elapsed_seconds']=time.monotonic()-started
 (run/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); print(json.dumps(result),flush=True)
