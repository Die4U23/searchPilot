"""Matched THP-off arena controls; only --arena-max changes the target environment.

Each case force-recreates the API; the prepared fresh PostgreSQL stays unchanged.
Four workers continue across observation checkpoints; native statistics and smaps
are non-atomic while requests run. GC/trim follow the post-load 120-second idle.
"""
import argparse
import asyncio
import csv
import hashlib
import json
import re
import shutil
import subprocess
import time
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path

import httpx
from scripts.bench_concurrent import Config, MODES, request_once, summarize
from scripts.validate_container_soak import clean_environment, probe_health

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PROJECT = "sp-allocator-20261025"
API = PROJECT + "-api-1"
DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
BASE_URL = "http://127.0.0.1:18085"
CHECKPOINTS = (400, 4000, 8000, 12000, 16000)
SAMPLE_CODE = (
    "import json; from pathlib import Path; from scripts.soak_memory import sample_linux_process; "
    "r=sample_linux_process(1); r['task_ids']=sorted(int(p.name) for p in Path('/proc/1/task').iterdir()); "
    "r['host_loadavg']=Path('/proc/loadavg').read_text().strip(); print(json.dumps(r))"
)


def now():
    return datetime.now(UTC).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(args, timeout=120):
    env = clean_environment()
    for key in ("MALLOC_ARENA_MAX", "GLIBC_TUNABLES", "LD_PRELOAD", "PYTHONTRACEMALLOC"):
        env.pop(key, None)
    return subprocess.run(args, cwd=REPO, env=env, capture_output=True, text=True,
                          encoding="utf-8", timeout=timeout, check=True,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout


def control(path="/snapshot", payload=None):
    code = ("import urllib.request; r=urllib.request.Request('http://127.0.0.1:8779' + "
            + repr(path) + ", data=" + repr(json.dumps(payload).encode() if payload is not None else None)
            + ", headers={'Content-Type':'application/json'}); "
            "print(urllib.request.urlopen(r, timeout=60).read().decode())")
    return json.loads(command([DOCKER, "exec", API, "python", "-c", code]))


async def main(args):
    assert re.fullmatch(r"[a-z0-9][a-z0-9-]*", args.case)
    setup = json.loads((ROOT / "setup/summary.json").read_text())
    assert setup["status"] == "READY_FOR_DIAGNOSTIC_RESTART"
    frozen = json.loads((ROOT / "setup/inputs-sha256.json").read_text())
    assert all(digest(REPO / p) == value for p, value in frozen.items())
    out = ROOT / args.case
    out.mkdir(exist_ok=False)
    sources = [Path(__file__), REPO / "scripts/diagnose_allocator.py", REPO / "scripts/soak_memory.py",
               REPO / "scripts/bench_concurrent.py", REPO / "scripts/validate_container_soak.py"]
    for source in sources:
        shutil.copyfile(source, out / (source.stem + ".executed.py"))
    # Null removes inherited/image environment values; caller env is also scrubbed.
    environment = {"MALLOC_ARENA_MAX": None if args.arena_max == "unset" else "2",
                   "GLIBC_TUNABLES": None, "LD_PRELOAD": None, "PYTHONTRACEMALLOC": None,
                   "SEARCHPILOT_DISABLE_THP": "true"}
    prefix = ("import ctypes; c=ctypes.CDLL(None,use_errno=True); "
              "r=c.prctl(41,1,0,0,0); assert r == 0, ctypes.get_errno(); "
              "assert c.prctl(42,0,0,0,0) == 1; "
              "from scripts.diagnose_allocator import main; main()")
    override = {"services": {"api": {"environment": environment,
        "command": ["python", "-c", prefix], "volumes": [
            {"type": "bind", "source": str(out / (Path(name).stem + ".executed.py")),
             "target": "/app/scripts/" + name, "read_only": True}
            for name in ("diagnose_allocator.py", "soak_memory.py")]}}}
    (out / "override.yml").write_text(json.dumps(override, indent=2), encoding="utf-8")
    compose = [DOCKER, "compose", "--env-file", str(REPO / ".env.example"), "-p", PROJECT,
               "-f", str(REPO / "docker-compose.yml"), "-f", str(ROOT / "setup/compose.override.yml"),
               "-f", str(out / "override.yml")]
    report = {"status": "RUNNING", "started_at": now(), "config": vars(args),
              "checkpoints": CHECKPOINTS, "requests": 16000, "concurrency": 4,
              "health_period_seconds": 10, "idle_seconds": 120, "external_llm_calls": 0,
              "background_observation": "All-container docker stats + Linux host loadavg at each 10s sample; "
                                        "no changes to any other container; task IDs observed externally",
              "blocks": [], "snapshots": [], "input_sha256": frozen,
              "executed_sha256": {source.name: digest(source) for source in sources},
              "method": "100 queries x 4 modes x 40 repeats; fixed global issue index; 16 sequential warmups; "
                        "four continuously issuing workers, no intermediate drain; non-atomic allocator/smaps "
                        "checkpoints while load continues; health + PID sampler + Docker stats every 10s; "
                        "no tracing, GC or trim during load/idle; normal Docker healthcheck retained; "
                        "same fresh database, force-recreated API for each case"}
    phase = "startup"
    stop = asyncio.Event()
    monitor = None
    observer = None
    completed = 0
    inflight = 0

    def save():
        (out / "summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    async def snap(label, path="/snapshot", payload=None):
        started = now()
        counts_before = {"completed": completed, "inflight": inflight}
        value = await asyncio.to_thread(control, path, payload)
        mapping = await asyncio.to_thread(command, [DOCKER, "exec", API, "cat", "/proc/1/smaps"])
        await asyncio.to_thread((out / ("smaps-" + label + ".txt")).write_text,
                                mapping, encoding="utf-8")
        report["snapshots"].append({"label": label, "started_at": started, "at": now(), "data": value,
                                   "counts_before": counts_before,
                                   "counts_after": {"completed": completed, "inflight": inflight},
                                   "atomic": False})
        # Serialize on the event loop to freeze one coherent report value, then
        # perform the file I/O outside the issuing workers' event loop.
        serialized = json.dumps(report, indent=2) + "\n"
        await asyncio.to_thread((out / "summary.json").write_text, serialized, encoding="utf-8")

    async def observed_command(argv, lines=False):
        try:
            raw = await asyncio.to_thread(command, argv, 8)
            return {"available": True, "data": [json.loads(s) for s in raw.splitlines()] if lines else json.loads(raw)}
        except Exception as exc:
            return {"available": False, "error_type": type(exc).__name__}

    async def sample(client):
        with (out / "samples.jsonl").open("x", encoding="utf-8") as sink:
            while not stop.is_set():
                started = time.perf_counter()
                row = {"at": now(), "phase": phase}
                server, stats, live, ready = await asyncio.gather(
                    observed_command([DOCKER, "exec", API, "python", "-c", SAMPLE_CODE]),
                    observed_command([DOCKER, "stats", "--no-stream", "--format", "{{json .}}"], True),
                    probe_health(client, "live"), probe_health(client, "ready"))
                row.update(server=server.get("data", server), stats=stats, live=live, ready=ready,
                           sample_seconds=time.perf_counter() - started)
                sink.write(json.dumps(row) + "\n")
                sink.flush()
                with suppress(TimeoutError):
                    await asyncio.wait_for(stop.wait(), max(.01, 10 - row["sample_seconds"]))

    save()
    try:
        before = json.loads(command([DOCKER, "inspect", API]))[0]
        assert before["Config"]["Labels"]["com.docker.compose.project"] == PROJECT
        report["previous_container_id"] = before["Id"]
        report["compose_output"] = await asyncio.to_thread(command, compose + ["up", "-d", "--no-deps", "--no-build", "--force-recreate", "api"])
        container = json.loads(command([DOCKER, "inspect", API]))[0]
        report["container"] = container
        assert container["Id"] != before["Id"]
        assert container["Image"] == setup["image"]
        assert container["Config"]["Labels"]["com.docker.compose.project"] == PROJECT
        # Compose null entries can remain as bare names in Config.Env; inspect
        # the four whitelisted variables inside a child sharing container env.
        configured_env = dict(item.split("=", 1) for item in container["Config"]["Env"] if "=" in item)
        env_code = ("import os,json; print(json.dumps({k:os.environ.get(k) for k in "
                    "['MALLOC_ARENA_MAX','GLIBC_TUNABLES','LD_PRELOAD','PYTHONTRACEMALLOC']}))")
        actual_env = json.loads(command([DOCKER, "exec", API, "python", "-c", env_code]))
        report["allocator_environment"] = actual_env
        assert actual_env["MALLOC_ARENA_MAX"] == (None if args.arena_max == "unset" else "2")
        assert configured_env.get("MALLOC_ARENA_MAX") == actual_env["MALLOC_ARENA_MAX"]
        assert all(actual_env[k] is None for k in ("GLIBC_TUNABLES", "LD_PRELOAD", "PYTHONTRACEMALLOC"))
        async with httpx.AsyncClient(base_url=BASE_URL, trust_env=False,
                limits=httpx.Limits(max_connections=4, max_keepalive_connections=4), timeout=10) as client, \
                httpx.AsyncClient(base_url=BASE_URL, trust_env=False, timeout=10) as health:
            async with asyncio.timeout(240):
                while True:
                    ready = await probe_health(health, "ready")
                    if ready.get("status") == 200 and all(ready["body"]["checks"].values()):
                        break
                    await asyncio.sleep(.5)
            await snap("ready")
            with (REPO / "data/queries/queries.csv").open(encoding="utf-8") as source:
                queries = [row["query_text"] for row in csv.DictReader(source)]
            assert len(queries) == 100
            config = Config(base_url=BASE_URL, concurrency=4, timeout=10, limit=10)
            results = []
            with (out / "requests.jsonl").open("x", encoding="utf-8") as ledger:
                def sink(event):
                    ledger.write(json.dumps({"at": now(), **event}) + "\n")
                    ledger.flush()
                warm = []
                for mode in MODES:
                    for i in range(4):
                        warm.append(await request_once(client, config, index=i, mode=mode,
                                                       query=queries[i], phase="warmup", event_sink=sink))
                report["warmup"] = summarize(warm, 0)
                assert all(row["outcome"] == "success" for row in warm)
                await snap("warmup")
                phase = "load"
                report["load_started_at"] = now()
                load_clock = time.perf_counter()
                monitor = asyncio.create_task(sample(health))
                checkpoint_queue = asyncio.Queue()
                indices = iter(range(16000))
                block_start = 0
                block_clock = load_clock
                async def observe_checkpoints():
                    for expected in CHECKPOINTS:
                        trigger = await checkpoint_queue.get()
                        assert trigger["completed"] == expected
                        report.setdefault("checkpoint_triggers", []).append(trigger)
                        await snap("after_" + str(expected))
                        print(json.dumps({"case": args.case, "trigger_completed": expected,
                                          "actual_completed": completed}), flush=True)
                observer = asyncio.create_task(observe_checkpoints())
                async def worker():
                    nonlocal completed, inflight, block_start, block_clock
                    for i in indices:
                        inflight += 1
                        try:
                            row = await request_once(client, config, index=i, mode=MODES[i % 4],
                                query=queries[(i // 4) % 100], phase="measured", event_sink=sink)
                        finally:
                            inflight -= 1
                        results.append(row)
                        completed += 1
                        if completed in CHECKPOINTS:
                            current_clock = time.perf_counter()
                            report["blocks"].append({"start_completed": block_start, "end_completed": completed,
                                "summary": summarize(results[block_start:completed], current_clock - block_clock)})
                            checkpoint_queue.put_nowait({"completed": completed, "at": now(),
                                                       "elapsed_seconds": current_clock - load_clock})
                            block_start, block_clock = completed, current_clock
                        if monitor.done():
                            monitor.result()
                            raise RuntimeError("sampler stopped early")
                        if observer.done():
                            observer.result()
                await asyncio.gather(*(worker() for _ in range(4)))
                report["load_seconds"] = time.perf_counter() - load_clock
                report["load_finished_at"] = now()
                phase = "post_load_snapshot"
                await observer
                report["summary"] = summarize(results, report["load_seconds"])
                assert all(row["outcome"] == "success" for row in results), "Preserving failed request evidence"
            phase = "idle"
            report["idle_started_at"] = now()
            await asyncio.sleep(120)
            await snap("idle")
            phase = "intervention"
            await snap("gc", "/gc", {})
            await snap("trim", "/trim", {})
            report["ready_after"] = await probe_health(health, "ready")
            assert report["ready_after"].get("status") == 200
            assert all(report["ready_after"]["body"]["checks"].values())
            stop.set()
            await monitor
            report["final_container"] = json.loads(command([DOCKER, "inspect", API]))[0]
            assert report["final_container"]["Id"] == container["Id"]
            assert report["final_container"]["RestartCount"] == 0
            assert all(digest(REPO / p) == value for p, value in frozen.items())
            report["status"] = "COMPLETED"
    except BaseException as exc:
        report.update(status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        stop.set()
        if monitor is not None and not monitor.done():
            monitor.cancel()
            with suppress(asyncio.CancelledError):
                await monitor
        if observer is not None and not observer.done():
            observer.cancel()
            with suppress(asyncio.CancelledError):
                await observer
        report["finished_at"] = now()
        save()
        logs = subprocess.run([DOCKER, "logs", API], capture_output=True, text=True, encoding="utf-8", timeout=30)
        (out / "api.log").write_text(logs.stdout + logs.stderr, encoding="utf-8")
    print(json.dumps({"case": args.case, "status": report["status"], "summary": report["summary"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    parser.add_argument("--arena-max", required=True, choices=("unset", "2"))
    asyncio.run(main(parser.parse_args()))
