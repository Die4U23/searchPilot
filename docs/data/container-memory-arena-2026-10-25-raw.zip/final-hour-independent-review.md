# 最终一小时独立原始证据审计

结论：**PASSED_WITH_DOCUMENTED_COUNT_VARIATION**。独立重建原始请求账本并计算资源窗口，未使用 `summarize_soak` 或 `report_final_hour` 的函数得出判定；完成计算后再与它们交叉核对，结果一致。此次为离线审查，没有请求 API、修改服务或清理容器。

结构化结果：`final-hour-independent-audit.json`。原始证据：`final-hour/`。harness 最终于 UTC **2026-10-25 05:14:04.247463** 完成，benchmark 也为 COMPLETED。

## 账本及功能

- 正式请求 **53,650 / 53,650 成功**，另有 **16 / 16 预热成功**；共 53,666 个唯一 pending 与 53,666 个 result 一一配对，零遗留、零失败、零重复或孤立事件，重建并发峰值为 4。
- 正式全局 index 连续，逐请求模式与查询顺序符合固定轮转规则，dispatch 均在 [0,3600) 秒内。实际 wall 为 3600.203094 秒，排空为 0.203041900 秒；最后一次派发为 3599.972092400 秒。预热与排空没有计入固定 3600 秒调度窗口。
- bm25 / vector 各 13,413 次，hybrid / ltr 各 13,412 次。400 个查询/模式组均存在，其中 50 组重复 135 次，350 组重复 134 次；各组完整结果、排名、模型版本指纹均稳定，并与 benchmark 保存的结果指纹一致。
- 17 / 17 业务检查通过，包括预期的 201 / 409 / 404，恢复搜索结果与初始参考一致。feedback create、replay 和 restart 后 replay 的 event_id 均为 `f950890d-23c5-47cd-9387-2a8445a3765d`。
- 数据库其他计数保持不变，feedback_events 从 0 变为 1。负载后及重启后 readiness 的七项组件均为 true；主动停止退出码为 0。负载前后 API StartedAt 一致，计划中的重启后 StartedAt 改变；没有意外重启计数或 Docker OOMKilled。

审计器初稿曾误把请求 `limit=10` 理解为必须返回恰好 10 条，导致 271 条虚假标记；实际契约是最多 10 条。核对发现它们全部为合法非空成功：Omer Yurtseven 的 BM25 为 2 条、Bloodhound LSR 为 6 条。更正为 `0 < result_count <= 10` 后无真实失败，结构化审计保留了这一审计假设修正记录。

## 健康采样的名义计数偏差

不修改预先计划，不删除边界记录，也不将结果强写为 360。

- phase=load 实际 **361 轮**，live 和 ready 均 **361 / 361 成功**；ready 七项检查全真。
- 相对正式开始时间，首轮 sample.at 为 **-0.762622 秒**，末轮为 **3601.666050 秒**；[0,3600) 内有 **359 轮**，另有紧邻两侧的 2 轮。
- 相邻轮间隔 **9.979383–10.029266 秒**，严格递增，两端覆盖整个正式窗口，没有漏轮形成的缺口。
- `nominal_health_count_match=false`，`full_window_health_coverage=true`。主代理明确裁定：360 是 60 分钟 / 10 秒的名义轮数，实际完整覆盖且全部成功的额外边界采样不构成功能失败。该偏差单列保留，内存门槛及正式时间窗均未改变。

## 独立内存门槛

只使用 phase=load 且正式 elapsed ∈ [2400,3600) 的 PID1 RSS，独立计算真实时间 OLS：

| 指标 | 实测 | 原门槛 |
| --- | ---: | ---: |
| 有效样本 | 120，缺失/无效 0 | 至少 118 |
| 首/末 elapsed | 2400.899931 / 3591.645520 秒 | 固定末 20 分钟 |
| 时间跨度 | 1190.745589 秒 | 至少 1180 秒 |
| 最大相邻间隔 | 10.029266 秒 | 不超过 15 秒 |
| RSS OLS | 0.034865284800 MiB/分钟 | 不超过 0.1 |
| RSS 首末增长 | 0.6875 MiB（720896 字节） | 不超过 2 MiB |

该门槛通过。以上斜率和字节差值与随后生成的正式报告精确一致，严格账本分析也为 PASSED。

## 资源完整性与限制

- 全部 361 个 load 样本的 11 个 server 来源均 available；PID=1，identity_consistent=true，stat / stat_after 启动 tick 恒为 316977。
- THP_enabled、AnonHugePages、Swap、SwapPss、VmSwap 全部完整且为 0；oom、oom_kill、oom_group_kill 三个计数全部完整且为 0。没有换出掩盖 RSS 增长的证据。
- phase-load RSS 首末为 2393.261719→2421.304688 MiB，匿名页为 2124.914062→2132.679688 MiB；首末包含前述边界采样，不等同精确 0 秒/3600 秒瞬时值。
- VmData 首末为 5530.253906→5859.644531 MiB，含启动负载初期增长和后续波动。固定末 20 分钟 VmData 首末增长 0.683594 MiB；不把虚拟映射大小等同物理 RSS 或活跃对象大小。
- FD 样本范围为 16–21；负载完成后连接关闭导致末点为 16。恢复期 12 点 RSS 首末下降 0.152344 MiB；load 末点到恢复末点下降 0.953125 MiB，明确区分两种端点。
- 26 个冻结输入、112 个本地生产/测量源文件、77 个容器源文件、73 个安装源文件均与运行记录匹配；4 个测量脚本快照和保存的 Dockerfile / Compose / 公开环境样例均与当前文件一致。
- 运行期间的白名单配置记录确认正常 `python scripts/docker_entrypoint.py` 入口、MALLOC_ARENA_MAX=2、SEARCHPILOT_DISABLE_THP=true；LD_PRELOAD、GLIBC_TUNABLES、PYTHONTRACEMALLOC 均未设置。实际 image 为 `sha256:a97dc62115f0b617d962423739a45f71dfc7a93ec05c4e055575fe7d65a710d1`。外部 LLM 调用为 0。

这是单进程、并发 4、固定 100 查询和一小时观察的工程验收。采样不是连续峰值，门槛通过不证明无限运行无泄漏，也不提供容量或 SLA 结论。CI、提交、合并及资源清理由主代理按后续流程独立处理。
