"""Build the runtime configuration candidate without replacing dependencies or models."""
import hashlib
import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from scripts.validate_container_soak import clean_environment

root = Path(__file__).resolve().parent
repo = root.parents[1]
docker = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
base = "searchpilot-validation:2026-10-23-thp"
tag = "searchpilot-validation:2026-10-25-arena2"
env = clean_environment()
def command(args):
    result = subprocess.run([docker, *args], cwd=repo, env=env, capture_output=True,
                            text=True, encoding="utf-8", timeout=180, check=True)
    return result.stdout
expected = json.loads((root / "setup/summary.json").read_text())["image"]
assert json.loads(command(["image", "inspect", base]))[0]["Id"] == expected
context = root / "image-context"
(context / "scripts").mkdir(parents=True, exist_ok=False)
for path in (repo / "scripts").glob("*.py"):
    shutil.copyfile(path, context / "scripts" / path.name)
(context / "Dockerfile").write_text(
    f"FROM {base}\nCOPY scripts /app/scripts\nENV SEARCHPILOT_DISABLE_THP=true MALLOC_ARENA_MAX=2\n")
inputs = json.loads((root / "setup/inputs-sha256.json").read_text())
assert all(hashlib.sha256((repo / p).read_bytes()).hexdigest() == value for p, value in inputs.items())
(root / "inputs-sha256.json").write_text(json.dumps(inputs, indent=2))
config = root / "final-config"
config.mkdir(exist_ok=False)
for name, target in (("Dockerfile", "Dockerfile"), ("docker-compose.yml", "docker-compose.yml"),
                     (".env.example", "public-env.txt")):
    shutil.copyfile(repo / name, config / target)
manifest = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in (context, config) for p in folder.rglob("*") if p.is_file()}
(root / "image-context-manifest.json").write_text(json.dumps(manifest, indent=2))
result = subprocess.run([docker, "build", "--pull=false", "-t", tag, str(context)],
                        cwd=repo, env=env, capture_output=True, text=True, encoding="utf-8", timeout=180)
(root / "build.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
result.check_returncode()
image = json.loads(command(["image", "inspect", tag]))[0]
settings = dict(item.split("=", 1) for item in image["Config"]["Env"] if "=" in item)
assert settings["MALLOC_ARENA_MAX"] == "2"
assert settings["SEARCHPILOT_DISABLE_THP"] == "true"
assert image["Config"]["Cmd"] == ["python", "scripts/docker_entrypoint.py"]
record = {"at": datetime.now(UTC).isoformat(), "tag": tag, "image": image["Id"],
          "base_image": expected, "runtime_environment": {k: settings[k] for k in
          ("MALLOC_ARENA_MAX", "SEARCHPILOT_DISABLE_THP")}, "cmd": image["Config"]["Cmd"],
          "dependency_or_model_rebuild": False, "frozen_input_count": len(inputs)}
(root / "build-summary.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record))
