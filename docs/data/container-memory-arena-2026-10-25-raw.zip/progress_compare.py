"""Read-only progress and matched-control audit. Prints JSON, never changes evidence."""
import argparse
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIB = 1024 ** 2


def mib(value):
    return round(value / MIB, 6) if isinstance(value, (float, int)) else None


def read_lines(path):
    if not path.exists():
        return []
    rows = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if not line.endswith("\n"):
                break  # A live writer's unfinished final line is not evidence yet.
            rows.append(json.loads(line))
    return rows


def source(process, name):
    value = process.get("sources", {}).get(name, {})
    return value.get("data", {}) if value.get("available") else {}


def process_metrics(process):
    status = source(process, "status")
    smaps = source(process, "smaps_rollup")
    return {"rss_mib": mib(smaps.get("Rss_bytes")),
            "anon_mib": mib(smaps.get("Anonymous_bytes")),
            "thp_mib": mib(smaps.get("AnonHugePages_bytes")),
            "thp_enabled": status.get("THP_enabled"),
            "threads": status.get("Threads"), "vmdata_mib": mib(status.get("VmData_bytes")),
            "pid_start_ticks": source(process, "stat").get("start_time_ticks"),
            "fd": source(process, "fd").get("count")}


def snapshot_metrics(snapshot):
    data = snapshot["data"]
    data = data.get("snapshot", data)  # Explicit GC/trim wrap their after snapshot.
    process = data.get("process", {}).get("data", {})
    allocator = data.get("allocator", {})
    native = allocator.get("mallinfo2", {}).get("data", {})
    py = data.get("pymalloc", {}).get("data", {}).get("fields", {})
    return {"label": snapshot["label"], "at": snapshot["at"],
            "counts_before": snapshot.get("counts_before"), "counts_after": snapshot.get("counts_after"),
            **process_metrics(process),
            "glibc_used_mib": mib(native.get("uordblks")), "glibc_free_mib": mib(native.get("fordblks")),
            "glibc_arena_mib": mib(native.get("arena")), "glibc_mmap_mib": mib(native.get("hblkhd")),
            "glibc_heap_count": allocator.get("malloc_info", {}).get("data", {}).get("heap_count"),
            "pymalloc_current_arenas": py.get("arenas_current"),
            "pymalloc_allocated_blocks_mib": mib(py.get("allocated_blocks_bytes")),
            "pymalloc_available_blocks_mib": mib(py.get("available_blocks_bytes"))}


def window(rows, seconds):
    valid = [(datetime.fromisoformat(row["at"]).timestamp(), process_metrics(row.get("server", {})))
             for row in rows if row.get("phase") == "load"]
    valid = [(at, data) for at, data in valid if data["rss_mib"] is not None]
    if not valid:
        return {"samples": 0}
    selected = [(at, data) for at, data in valid if at >= valid[-1][0] - seconds]
    x = [(at - selected[0][0]) / 60 for at, _ in selected]
    y = [data["rss_mib"] for _, data in selected]
    xm, ym = sum(x) / len(x), sum(y) / len(y)
    variance = sum((value - xm) ** 2 for value in x)
    slope = sum((a - xm) * (b - ym) for a, b in zip(x, y)) / variance if variance else None
    return {"samples": len(selected), "observed_seconds": selected[-1][0] - selected[0][0],
            "requested_window_seconds": seconds, "rss_first_mib": y[0], "rss_last_mib": y[-1],
            "rss_delta_mib": y[-1] - y[0], "rss_ols_mib_per_minute": slope}


def audit(case):
    path = ROOT / case
    try:
        summary = json.loads((path / "summary.json").read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {"case": case, "summary": "not yet available; may be mid-write"}
    outcomes, pending, active, peak = Counter(), Counter(), set(), 0
    groups, group_counts = defaultdict(set), Counter()
    issue_sequence = []
    latest_event = None
    for row in read_lines(path / "requests.jsonl"):
        latest_event = row.get("at")
        request = row["request_id"]
        if row["event"] == "pending":
            active.add(request)
            peak = max(peak, len(active))
            pending[row["phase"]] += 1
            if row["phase"] == "measured":
                issue_sequence.append((row["index"], row["mode"], row["query"]))
        elif row["event"] == "result":
            active.discard(request)
            outcomes[row["phase"] + ":" + row["outcome"]] += 1
            if row["phase"] == "measured" and row["outcome"] == "success":
                key = (row["mode"], row["query"])
                groups[key].add(row.get("result_sha256"))
                group_counts[key] += 1
    samples = read_lines(path / "samples.jsonl")
    health, failures, missing = Counter(), [], Counter()
    seen_tasks, previous, joined, departed = set(), None, 0, 0
    for row in samples:
        for endpoint in ("live", "ready"):
            result = row.get(endpoint, {})
            state = str(result.get("status", "unavailable"))
            health[row["phase"] + ":" + endpoint + ":" + state] += 1
            body_valid = (endpoint != "ready" or bool(result.get("body", {}).get("checks"))
                          and all(result["body"]["checks"].values()))
            if result.get("status") != 200 or not body_valid:
                failures.append({"at": row["at"], "phase": row["phase"], "endpoint": endpoint,
                                 "status": result.get("status"), "error_type": result.get("error_type")})
        process = row.get("server", {})
        for name in ("status", "smaps_rollup"):
            if not source(process, name):
                missing[name] += 1
        tids = process.get("task_ids")
        if tids is not None:
            current = set(tids)
            seen_tasks.update(current)
            if previous is not None:
                joined += len(current - previous)
                departed += len(previous - current)
            previous = current
    canonical = [[mode, query, sorted(values, key=lambda v: str(v))]
                 for (mode, query), values in sorted(groups.items())]
    return {"case": case, "status": summary["status"], "config": summary["config"],
            "started_at": summary["started_at"], "latest_event": latest_event,
            "pending_counts": dict(pending), "outcomes": dict(outcomes), "active_requests": len(active),
            "observed_peak_inflight": peak, "checkpoint_trigger_times": summary.get("checkpoint_triggers", []),
            "checkpoints": [snapshot_metrics(row) for row in summary.get("snapshots", [])],
            "latest_sample": ({"at": samples[-1]["at"], "phase": samples[-1]["phase"],
                               **process_metrics(samples[-1].get("server", {}))} if samples else None),
            "sample_count": len(samples), "sample_missing": dict(missing), "health": dict(health),
            "health_failure_count": len(failures), "health_failures_first_20": failures[:20],
            "task_ids_observed_cumulative": len(seen_tasks), "task_ids_last_count": len(previous) if previous is not None else None,
            "task_join_transitions": joined, "task_depart_transitions": departed,
            "last_5_minutes": window(samples, 300), "last_10_minutes": window(samples, 600),
            "semantic_groups": len(groups), "unstable_groups": sum(len(v) != 1 or None in v for v in groups.values()),
            "group_repeat_min": min(group_counts.values(), default=None), "group_repeat_max": max(group_counts.values(), default=None),
            "result_groups_sha256": hashlib.sha256(json.dumps(canonical, ensure_ascii=True).encode()).hexdigest(),
            "issued_sequence_sha256": hashlib.sha256(json.dumps(issue_sequence, ensure_ascii=True).encode()).hexdigest(),
            "issued_global_indices_in_order": [r[0] for r in issue_sequence] == list(range(len(issue_sequence))),
            "latency_and_throughput": summary.get("summary"),
            "image": summary.get("container", {}).get("Image"),
            "container_id": summary.get("container", {}).get("Id"),
            "allocator_environment": summary.get("allocator_environment"),
            "executed_sha256": summary.get("executed_sha256"), "input_sha256": summary.get("input_sha256")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", nargs="+")
    args = parser.parse_args()
    reports = [audit(case) for case in args.cases]
    complete = [report for report in reports if report.get("status") == "COMPLETED"]
    comparison = {"completed_cases": len(complete)}
    if len(complete) > 1:
        for key in ("image", "executed_sha256", "input_sha256", "result_groups_sha256", "issued_sequence_sha256"):
            comparison["identical_" + key] = all(row[key] == complete[0][key] for row in complete[1:])
        comparison["distinct_container_ids"] = len({row["container_id"] for row in complete}) == len(complete)
    print(json.dumps({"cases": reports, "comparison": comparison}, indent=2))
