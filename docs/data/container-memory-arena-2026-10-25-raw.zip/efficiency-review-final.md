# Efficiency lens review of the final memory-policy increment

Read-only review completed after both continuous allocator controls finished.
Reviewed `.env.example`, `Dockerfile`, `docker-compose.yml`,
`scripts/docker_entrypoint.py`, `scripts/diagnose_allocator.py`, and the associated
entrypoint/benchmark test changes. No source, service, model, or test was modified
by this review.

**No actionable efficiency issue found.**

- `MALLOC_ARENA_MAX=2` is supplied by image/Compose before Python starts. It adds
  no application task, timer, polling loop, request callback, retained cache, or
  extra Python allocator call. The Docker default supports direct image use;
  the Compose default also permits an explicit runtime override. Keeping both
  does not duplicate runtime work.
- THP configuration makes one SET and one GET `prctl` call at container startup,
  before model/migration imports, and emits one small JSON record. The existing
  `execvp` replaces that startup process; the temporary ctypes/JSON startup
  objects are not a second long-lived application process. There is no THP
  polling or per-request intervention.
- The normal image CMD remains `python scripts/docker_entrypoint.py`, which
  execs the unchanged uvicorn factory. A search across production `src/` and
  this entrypoint found no import of `diagnose_allocator`, no malloc_trim hook,
  no tracemalloc start, and no explicit per-request GC. Copying the diagnostic
  script into the image does not execute its control server.
- The opt-in diagnostic wrapper's control thread and synchronous native
  snapshots exist only under its explicit alternative command. Native output
  capture closes the duplicated FILE descriptor and temporary file on normal
  and exception paths; reads are limited to 1 MiB. Its explicit GC/trim actions
  are not scheduled automatically. The final one-hour image must continue to
  use the normal entrypoint, as planned.
- Benchmark timeout-test widening affects the test only and retains a bounded
  total timeout check; it does not change the production or benchmark-client
  timeout implementation.

Arena limiting can trade allocator parallelism for memory retention. The A/B
control observed 13.961 versus 13.677 requests/s, with different background load;
this is neither a proven arena-caused regression nor evidence of zero latency
cost. Final normal-entrypoint hour validation remains the acceptance evidence.
No speculative extra runtime machinery is warranted by this efficiency review.
