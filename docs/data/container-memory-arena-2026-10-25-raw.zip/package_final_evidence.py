"""Archive explicitly owned completed evidence; never overwrite a prior archive."""
import hashlib
import json
import re
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
DESTINATION = REPO / "docs/data/container-memory-arena-2026-10-25-raw.zip"
ALLOWED_DIRS = {
    "setup", "no-thp-default-01", "no-thp-default-02", "no-thp-arena2-01",
    "final-hour", "image-context", "control-config", "final-config",
}
ALLOWED_SUFFIXES = {".json", ".jsonl", ".txt", ".py", ".md", ".yml", ".diff", ".png", ".log", ".pid", ".start"}
ALLOWED_ROOT_FILES = {
    "acceptance-plan.md", "arena2-completed-maps.json", "baseline-completed-audit.json",
    "baseline-completed-maps.json", "baseline-completed-review.md", "baseline-final.json",
    "baseline-midpoint-review.md", "bench_concurrent.executed.py", "build_candidate.py",
    "build-summary.json", "build.txt", "cleanup_owned.py", "cleanup-controls.json",
    "cleanup-hour.json", "cleanup_hour.py", "compare_completed_controls.py",
    "comparison-final.json", "comparison-review.md", "config-check.json",
    "default02-maps-4000.json", "design.md", "efficiency-review-final.md", "experiment.py",
    "final-hour-console.txt", "hour_progress.py", "image-context-manifest.json",
    "inputs-sha256.json", "maps_compare.py", "no-thp-arena2-01-console.txt",
    "no-thp-default-01-console.txt", "no-thp-default-02-console.txt", "progress_compare.py",
    "report_final_hour.py", "report-helper-identity-fixture-check.json",
    "report-helper-independent-review.md", "setup-console.txt", "setup.py",
    "soak_memory.executed.py", "source-retention-review.md", "summarize_soak.executed.py",
    "validate_container_soak.executed.py", "verify_final_integrity.py", "package_final_evidence.py",
    "final-hour-analysis.json", "final-hour-summary.json", "final-hour-memory.png", "final-integrity.json",
    "integration-final.txt", "unit-final.txt", "quality-final.txt", "linux-smoke.json",
    "linux-smoke.txt", "final-hour-independent-review.md", "final-hour-independent-audit.json",
    "publication-helper-check.json", "publication-helper-check-final.json",
    "altitude-review-final.md", "comparison-file-integrity.json",
    "report-draft.md", "final-hour-midpoint-review.md",
}
REQUIRED = {
    "acceptance-plan.md", "comparison-final.json", "final-hour/summary.json",
    "final-hour/soak.json", "final-hour/soak.requests.jsonl", "final-hour/samples.jsonl",
    "final-hour-analysis.json", "final-hour-summary.json", "final-hour-memory.png",
    "final-integrity.json", "cleanup-hour.json",
}


def read_json(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def credential_values():
    # Values exist only in memory. Never log, serialize or include the private file.
    values = set()
    for key, value in dotenv_values(REPO / ".env", interpolate=False).items():
        if not value:
            continue
        if re.search(r"KEY|TOKEN|SECRET|PASSWORD", key, re.I) and value != "searchpilot":
            values.add(value.encode("utf-8"))
        if "URL" in key.upper():
            try:
                password = urlsplit(value).password
            except ValueError:
                password = None
            if password and password != "searchpilot":
                values.update((password.encode("utf-8"), unquote(password).encode("utf-8")))
    return values


def selected_names():
    names = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if "__pycache__" in relative.parts:
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError("Linked or out-of-root evidence is not allowed: " + str(relative))
        if path.is_dir():
            if relative.parts[0] not in ALLOWED_DIRS:
                raise ValueError("Unrecognized evidence directory: " + str(relative))
            continue
        if not path.is_file():
            raise ValueError("Unrecognized evidence object: " + str(relative))
        if path.name in {"archive-verification.json", "monitor.json", "arena2-progress.json"} or (
                path.name.startswith("progress") and path.suffix == ".json"):
            continue
        if len(relative.parts) == 1 and path.name not in ALLOWED_ROOT_FILES:
            raise ValueError("Unrecognized root evidence file: " + str(relative))
        if len(relative.parts) > 1 and relative.parts[0] not in ALLOWED_DIRS:
            raise ValueError("Unrecognized evidence directory: " + str(relative))
        # Explicit names handle Dockerfile and .pid/.start runtime evidence without guessing suffixes.
        if path.suffix not in ALLOWED_SUFFIXES and path.name != "Dockerfile":
            raise ValueError("Unrecognized evidence type: " + str(relative))
        names.append(relative.as_posix())
    missing = REQUIRED - set(names)
    if missing:
        raise ValueError("Required evidence missing: " + ", ".join(sorted(missing)))
    return names


def main():
    record_path = ROOT / "archive-verification.json"
    if DESTINATION.exists() or record_path.exists():
        raise FileExistsError("Refuse to overwrite archive or verification record")
    if read_json("final-hour/summary.json").get("status") != "COMPLETED":
        raise ValueError("Formal harness not complete")
    if read_json("final-hour/soak.json").get("status") != "COMPLETED":
        raise ValueError("Formal benchmark not complete")
    if read_json("final-hour-analysis.json").get("status") != "PASSED":
        raise ValueError("Strict ledger acceptance did not pass")
    if read_json("final-hour-summary.json").get("memory_gate", {}).get("status") != "PASSED":
        raise ValueError("Predeclared memory gate did not pass")
    if read_json("final-integrity.json").get("passed") is not True:
        raise ValueError("Final integrity verification did not pass")
    if not (ROOT / "cleanup-hour.json").is_file():
        raise ValueError("Missing owned-hour cleanup record")
    for case in ("no-thp-default-02", "no-thp-arena2-01"):
        if read_json(case + "/summary.json").get("status") != "COMPLETED":
            raise ValueError("Required completed control is incomplete: " + case)
    if read_json("no-thp-default-01/summary.json").get("status") != "FAILED":
        raise ValueError("Expected preserved first failed setup/control attempt")
    names = selected_names()
    secrets = credential_values()
    manifest = {}
    for name in names:
        data = (ROOT / name).read_bytes()
        if any(value in data for value in secrets):
            raise ValueError("Private credential value found in evidence: " + name)
        manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    with zipfile.ZipFile(DESTINATION, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in names:
            # Recheck the actual bytes written, rejecting concurrent evidence changes.
            data = (ROOT / name).read_bytes()
            if hashlib.sha256(data).hexdigest() != manifest[name]["sha256"]:
                raise ValueError("Evidence changed while packaging: " + name)
            archive.writestr(name, data)
        archive.writestr("SHA256SUMS.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(DESTINATION) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(names) | {"SHA256SUMS.json"}:
            raise ValueError("Archive membership or CRC verification failed")
        if json.loads(archive.read("SHA256SUMS.json")) != manifest:
            raise ValueError("Archive manifest differs")
        for name in names:
            data = archive.read(name)
            if len(data) != manifest[name]["bytes"] or hashlib.sha256(data).hexdigest() != manifest[name]["sha256"]:
                raise ValueError("Archive member checksum failed: " + name)
            if any(value in data for value in secrets):
                raise ValueError("Private credential found after archive readback: " + name)
    record = {"path": DESTINATION.relative_to(REPO).as_posix(), "files": len(names),
              "bytes": DESTINATION.stat().st_size,
              "sha256": hashlib.sha256(DESTINATION.read_bytes()).hexdigest(),
              "every_member_hash_verified": True, "private_credential_matches": 0}
    with record_path.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
