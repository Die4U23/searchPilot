# Baseline 02 中点独立审查

审查范围：`no-thp-default-02` 已保存的 after_400、after_4000、after_8000 checkpoint、对应 smaps，以及当时的 `progress-current.json`。仅离线读取，未调用服务、未修改 case 文件，也未重复全请求账本审计。运行尚未结束，以下不是最终验收结论。

## 判断

**现有证据已较强地支持“glibc arena 内空闲内存留存是这一时段匿名 RSS 增长的主要贡献者”，但尚不足以证明全部剩余增长已解释、应用没有泄漏，或 arena=2 的生产配置有效。** 相比此前只看 RSS 的推测，本次有同一 PID 的 malloc_info / mallinfo2 直接证据，且增长量级与匿名页吻合。

| 区间 | smaps RSS 增量 MiB | smaps Anonymous 增量 MiB | glibc arena 增量 MiB | glibc free 增量 MiB | glibc used 增量 MiB |
| --- | ---: | ---: | ---: | ---: | ---: |
| 400→4000 | 14.54297 | 14.51562 | 13.75000 | 13.06174 | 0.68826 |
| 4000→8000 | 6.59766 | 6.59766 | 6.43750 | 6.48013 | -0.04263 |
| 400→8000 | 21.14062 | 21.11328 | 20.18750 | 19.54187 | 0.64563 |

这里 glibc free / used 分别取 mallinfo2 的 fordblks / uordblks。不能把它们与 RSS、pymalloc 相加，也不能把近似相等当作逐页归属证明。checkpoint 内部和 smaps 的读取顺序不同，活跃负载下不是原子快照；因此该表的 smaps RSS 与 progress 中 checkpoint RSS 差值不完全相同。

具体支持证据：

- THP 始终为 0，PID start ticks 一致为 35853。
- glibc mmap 分配总量稳定为 95.949219 MiB；malloc_info 的 system_current 增量与 mallinfo2 arena 增量相同，root free-bin 增量也接近 mallinfo2 free 增量，减少单一字段解释失真的疑虑。
- 4000→8000 时 heap 数量固定为 77，glibc used 基本不变，free 增长 6.48 MiB。这支持“已有 arena 的已释放空间继续留在进程”，不只是“创建新 arena 导致总量增加”。
- 同时段 malloc_info 中 heap 序号 13、25 的 system 分别增长约 2.688、2.539 MiB，rest-bin 分别增长约 2.455、2.236 MiB。序号只是 XML 内序号，不等同稳定线程 ID，也没有映射到具体 VMA；但它显示空闲空间增长分布在多个 heap，而不是只能从总量猜测。
- pymalloc current arenas 始终为 642，arena 总字节稳定。400→4000 活跃块仅增长约 0.120 MiB；4000→8000 活跃块增长约 1.960 MiB，同时 available 块下降约 1.976 MiB。这是已有 arena 内占用变化，尚未观察到 Python arena 持续扩张。
- smaps 4000→8000 虚拟地址总长度没有增长，RSS 增长约 6.598 MiB。大量主要变化表现为同起点、不同终点的匿名 VMA 被移除/新增，不能将它们当成完全新建且额外叠加的分配；exact identity 匹配 VMA 的净 RSS 增量只有 0.0625 MiB。

## 仍需验证的具体疑点

1. **中点都是活跃负载。** 三个 checkpoint 采集前后分别为 400→419、4000→4019、8000→8015 完成请求，前后均有 4 个 inflight。它们不是相同算子或相同查询执行位置。8000 时增加的约 2 MiB pymalloc 活跃块可能是临时对象，也可能包含留存；需要 16000、idle、GC 的一致口径观察才能区分，不能提前认定。
2. **统计没有完整覆盖所有原生 allocator。** glibc 增量能解释主要量级，但未归属的小额匿名页、线程栈和其他库分配仍存在；还没有把 anonymous VMA 与实际 allocator 指针映射起来。
3. **线程更替是解释候选，不是已确认驱动因素。** 当时采样累计观察到 195 个 task ID，当前 101；此证据支持有线程更替，但无法区分 AnyIO、OpenMP、其他库线程，也不能证明哪个线程触发了哪一个 heap 扩张。
4. **非原子测量存在小额出入。** malloc_info free-bin 与 mallinfo2 free 数字不完全一致。执行中的分配/释放、统计覆盖差异均可能导致差别；应保留原始值，不能人为调齐。
5. **尚无干预结果。** 目前没有 arena=2 的同协议对照，也没有本轮结束后的 trim 响应。低 used 增量和高 free 增量支持留存，但不能替代对照实验，更不能推出最终小时尾部已稳定。

## 后续结果的判读标准

按原计划完成 16k + 120 秒 idle，再运行 arena=2 同协议对照是合理的。若默认组末段 arena/free 继续上升而 used 与 pymalloc arena 稳定，idle 不能回收、后续 trim 可释放相应量级，再且 arena=2 抑制相同趋势，glibc 留存解释将明显增强。仍应同时检查吞吐、尾延迟、健康探针、语义一致性、实际 elapsed 与健康请求次数，避免将降低吞吐引起的不同观察暴露量当成内存修复。

本审查没有建议在完成该对照之前修改生产默认值。
