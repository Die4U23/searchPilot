# 最终小时报告工具独立复审

结论：此前的内存门槛身份/来源校验阻断已修复，无新增阻断。

本记录保存已完成的复审和离线兼容性检查，不重新运行任何检查。被审查工具为 `report_final_hour.py`，当时 SHA-256：`fd70429cee5afbaed0f3d8b8f915e8f346e755ea093b7623c9438f25a80baee1`。

## 修复检查

`memory_sample_errors` 要求 server 可用、PID 为 1、identity_consistent 为 true，stat / stat_after 来源均可用、PID 为 1、启动 tick 为有效且相同的整数，以及 smaps 来源可用、RSS 为有限非负数且不是 bool。`endpoints` 不再丢弃无效点后拟合；窗口出现无效点即拒绝拟合。跨点进程身份变化也不能通过内存门槛。

## 真实历史 schema 兼容性

使用 AST 仅提取实际的 `memory_sample_errors`、`endpoints`、`evaluate_memory_gate` 三个函数，离线读取 `artifacts/allocator-2026-10-23/hour-001/samples.jsonl` 和同目录 `soak.json`。没有执行报告脚本顶层，没有访问尚不存在的正式小时输出，没有调用服务。

| 阶段 | 样本数 | 校验有效 | 校验无效 |
| --- | ---: | ---: | ---: |
| startup | 5 | 4 | 1 |
| baseline | 6 | 6 | 0 |
| load | 360 | 360 | 0 |
| recovery | 12 | 12 | 0 |
| restart | 4 | 4 | 0 |

startup 中无效的 1 条为服务尚未启动的最初采样，正确被拒绝。真实 `stat_after.data` 含有 pid 字段，不存在因错误假设 schema 而将负载期全部样本拒绝的问题。restart 样本单点有效不表示重启前后是同一进程；它们不被纳入 load 内存门槛。

## 历史末 20 分钟结果

- 点数 120；缺失 0、无效 0，同一进程身份。
- 首点 elapsed 2404.064399 秒，末点 3595.011311 秒，跨度 1190.946912 秒。
- 最大相邻间隔 10.028450 秒，coverage_passed 为 true。
- RSS 首值 2738987008 字节，末值 2757910528 字节，差值 18923520 字节，即 **18.046875 MiB**。
- OLS 斜率 **0.8640893272966833 MiB/分钟**。
- 使用未修改的预定阈值，memory_gate 正确为 **FAILED**，并未把该历史增长曲线误报为 PASSED。

此前沟通消息中的 18.0478 MiB 为笔误，本记录按实际输出字节差值更正为 18.046875 MiB。该历史检查仅验证工具兼容性及判定行为，不代表本轮候选的正式一小时结果。
