"""Remove only a completed, explicitly owned validation project and its volume."""
import argparse
import json
import subprocess
from pathlib import Path
from scripts.validate_container_soak import clean_environment

root = Path(__file__).resolve().parent
repo = root.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=("controls", "hour"))
phase = parser.parse_args().phase
project, folder = (("sp-allocator-20261025", "setup") if phase == "controls"
                   else ("sp-arena-hour-20261025", "final-hour"))
required = (["no-thp-default-02", "no-thp-arena2-01"] if phase == "controls" else ["final-hour"])
for name in required:
    assert json.loads((root / name / "summary.json").read_text())["status"] == "COMPLETED"
docker = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
def command(args):
    return subprocess.run([docker, *args], cwd=repo, env=clean_environment(), capture_output=True,
                          text=True, encoding="utf-8", timeout=90, check=True).stdout
volume = project + "_pgdata"
owned = json.loads(command(["volume", "inspect", volume]))[0]
assert owned["Name"] == volume and owned["Labels"]["com.docker.compose.project"] == project
before = json.loads(command(["volume", "inspect", "searchpilot_pgdata"]))[0]
for name in (project + "-api-1", project + "-db-1"):
    c = json.loads(command(["inspect", name]))[0]
    assert c["Config"]["Labels"]["com.docker.compose.project"] == project
output = command(["compose", "--env-file", str(repo / ".env.example"), "-p", project,
                  "-f", str(repo / "docker-compose.yml"), "-f", str(root / folder / "compose.override.yml"),
                  "down", "--volumes"])
after = json.loads(command(["volume", "inspect", "searchpilot_pgdata"]))[0]
assert before == after
assert volume not in command(["volume", "ls", "--format", "{{.Name}}"]).splitlines()
assert not command(["ps", "-aq", "--filter", "label=com.docker.compose.project=" + project]).strip()
record = {"removed_project": project, "removed_volume": volume,
          "original_volume_metadata_unchanged": True, "output": output}
(root / f"cleanup-{phase}.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record))
