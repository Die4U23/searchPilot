"""Offline same-case smaps accounting; never inspect or mutate a live service.

Exact mapping identity means address range, permissions, offset, device, inode,
and path. It does not prove allocator ownership or exclude address reuse between
observations. Resized/split/merged mappings appear in added/removed partitions.
"""
import argparse
import hashlib
import json
import runpy
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PARSER_PATH = ROOT.parent / "allocator-2026-10-23/maps.py"
PARSER = runpy.run_path(str(PARSER_PATH))
MIB = 1024 ** 2
DEFAULT_TARGETS = ("after_4000", "after_8000", "after_12000", "after_16000", "idle", "gc", "trim")


def mib(value):
    return value / MIB if value is not None else None


def native(snapshot):
    if snapshot is None:
        return {"available": False, "reason": "snapshot not yet recorded"}
    data = snapshot["data"].get("snapshot", snapshot["data"])
    process = data.get("process", {}).get("data", {})
    stat = process.get("sources", {}).get("stat", {}).get("data", {})
    allocator = data.get("allocator", {})
    info = allocator.get("malloc_info", {})
    xml_totals = {"available": False, "reason": "malloc_info unavailable"}
    if info.get("available"):
        root = ET.fromstring(info["data"]["xml"])
        system = root.find("./system[@type='current']")
        fast = root.find("./total[@type='fast']")
        rest = root.find("./total[@type='rest']")
        mmap = root.find("./total[@type='mmap']")
        xml_totals = {"available": True, "heap_count": len(root.findall("./heap")),
                      "system_current_bytes": int(system.attrib["size"]) if system is not None else None,
                      "fast_bin_bytes": int(fast.attrib["size"]) if fast is not None else None,
                      "rest_bin_bytes": int(rest.attrib["size"]) if rest is not None else None,
                      "mmap_bytes": int(mmap.attrib["size"]) if mmap is not None else None}
        xml_totals["fast_plus_rest_bin_bytes"] = (
            xml_totals["fast_bin_bytes"] + xml_totals["rest_bin_bytes"]
            if fast is not None and rest is not None else None)
    return {"available": True, "at": snapshot["at"], "counts_before": snapshot.get("counts_before"),
            "counts_after": snapshot.get("counts_after"), "pid": data.get("pid"),
            "pid_start_ticks": stat.get("start_time_ticks"),
            "identity_consistent": process.get("identity_consistent"),
            "mallinfo2": allocator.get("mallinfo2", {}), "malloc_info_root_totals": xml_totals,
            "pymalloc_fields": data.get("pymalloc", {}).get("data", {}).get("fields", {})}


def dictionary_delta(before, after):
    return {key: after.get(key) - before.get(key)
            if isinstance(before.get(key), (float, int)) and not isinstance(before.get(key), bool)
            and isinstance(after.get(key), (float, int)) and not isinstance(after.get(key), bool)
            else None for key in before.keys() | after.keys()}


def compact_mapping(row):
    return {**row, "rss_delta_mib": row["delta_bytes"]["Rss"] / MIB
            if row["delta_bytes"]["Rss"] is not None else None}


def compare(case, left_label, right_label, summary, top):
    left_path, right_path = (case / ("smaps-" + label + ".txt") for label in (left_label, right_label))
    raw_left, raw_right = left_path.read_bytes(), right_path.read_bytes()
    left = PARSER["parse_smaps"](raw_left.decode("utf-8"))
    right = PARSER["parse_smaps"](raw_right.decode("utf-8"))
    compared = PARSER["compare"](left, right)
    changes = compared.pop("mappings_by_rss_increase")
    partition = {}
    for kind in ("matched", "added", "removed"):
        rows = [row for row in changes if row["change"] == kind]
        partition[kind] = {"mapping_count": len(rows), "delta_bytes": {
            metric: sum(row["delta_bytes"][metric] for row in rows)
            if all(row["delta_bytes"][metric] is not None for row in rows) else None
            for metric in PARSER["METRICS"]}}
    reconciliation = {}
    for metric, delta in compared["delta_bytes"].items():
        values = [partition[kind]["delta_bytes"][metric] for kind in partition]
        calculated = sum(values) if all(value is not None for value in values) else None
        reconciliation[metric] = {"whole_file_delta_bytes": delta,
                                  "partition_sum_delta_bytes": calculated,
                                  "exact_match": calculated == delta if delta is not None else None}
        assert delta is None or delta == calculated, "Mapping partitions must exactly reconcile"
    snapshots = {row["label"]: row for row in summary.get("snapshots", [])}
    before, after = native(snapshots.get(left_label)), native(snapshots.get(right_label))
    pid_same = (before.get("pid_start_ticks") is not None
                and before.get("pid_start_ticks") == after.get("pid_start_ticks")
                and before.get("pid") == after.get("pid"))
    if before.get("available") and after.get("available"):
        assert pid_same, "Do not compare smaps across process identities"
    increasing = [row for row in changes if (row["delta_bytes"]["Rss"] or 0) > 0]
    decreasing = sorted((row for row in changes if (row["delta_bytes"]["Rss"] or 0) < 0),
                        key=lambda row: row["delta_bytes"]["Rss"])
    matched_growth = [row for row in increasing if row["change"] == "matched"]
    return {"from": left_label, "to": right_label, "inputs": {
                "before": {"path": str(left_path), "sha256": hashlib.sha256(raw_left).hexdigest()},
                "after": {"path": str(right_path), "sha256": hashlib.sha256(raw_right).hexdigest()}},
            "same_snapshot_process_identity": pid_same, "smaps": compared,
            "partitions": partition, "exact_reconciliation": reconciliation,
            "top_rss_increases": [compact_mapping(row) for row in increasing[:top]],
            "top_rss_decreases": [compact_mapping(row) for row in decreasing[:top]],
            "top_exact_identity_rss_increases": [compact_mapping(row) for row in matched_growth[:top]],
            "native_before": before, "native_after": after,
            "native_observation_delta": {
                "mallinfo2": dictionary_delta(before.get("mallinfo2", {}).get("data", {}),
                                              after.get("mallinfo2", {}).get("data", {})),
                "malloc_info_root_totals": dictionary_delta(before.get("malloc_info_root_totals", {}),
                                                            after.get("malloc_info_root_totals", {})),
                "pymalloc_fields": dictionary_delta(before.get("pymalloc_fields", {}), after.get("pymalloc_fields", {}))},
            "interpretation": "Native and smaps observations are sequential and non-atomic while requests may run. "
                              "RSS, anonymous pages, native allocator totals and pymalloc overlap; do not add scopes. "
                              "malloc_info root system/free-bin changes may be compared with mapping growth as supporting "
                              "evidence, but cannot label individual anonymous VMAs. 64-MiB size/alignment is not ownership proof."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", required=True, help="Case directory name under this artifact root")
    parser.add_argument("--from-label", default="after_400")
    parser.add_argument("--to-label", nargs="*", default=None)
    parser.add_argument("--top", type=int, default=10)
    parser.add_argument("--out", type=Path, help="Optional NEW JSON file inside this artifact root")
    args = parser.parse_args()
    if args.top < 1:
        parser.error("--top must be positive")
    case = ROOT / args.case
    if not case.resolve().is_relative_to(ROOT.resolve()):
        parser.error("case must stay inside the new artifact root")
    summary = json.loads((case / "summary.json").read_text(encoding="utf-8"))
    targets = args.to_label if args.to_label is not None else list(DEFAULT_TARGETS)
    available, missing = [], []
    recorded = {row["label"] for row in summary.get("snapshots", [])}
    for label in targets:
        if label in recorded and (case / ("smaps-" + label + ".txt")).is_file():
            available.append(label)
        else:
            missing.append(label)
    if args.from_label not in recorded or not (case / ("smaps-" + args.from_label + ".txt")).is_file():
        parser.error("before smaps file not yet available")
    report = {"schema_version": 1, "case": args.case, "case_status": summary["status"],
              "method": __doc__, "parser_sha256": hashlib.sha256(PARSER_PATH.read_bytes()).hexdigest(),
              "parser_path": str(PARSER_PATH), "missing_target_snapshots": missing,
              "comparisons": [compare(case, args.from_label, target, summary, args.top) for target in available]}
    raw = json.dumps(report, indent=2) + "\n"
    if args.out is not None:
        output = args.out.resolve()
        if not output.is_relative_to(ROOT.resolve()) or output.exists():
            parser.error("output must be a new file inside this artifact root")
        with output.open("x", encoding="utf-8") as sink:
            sink.write(raw)
        print(json.dumps({"out": str(output), "missing": missing,
                          "comparisons": [{"from": row["from"], "to": row["to"],
                              "rss_delta_mib": mib(row["smaps"]["delta_bytes"]["Rss"]),
                              "anon_delta_mib": mib(row["smaps"]["delta_bytes"]["Anonymous"]),
                              "partition_rss_delta_mib": {key: mib(value["delta_bytes"]["Rss"])
                                                          for key, value in row["partitions"].items()},
                              "all_known_deltas_reconcile": all(value["exact_match"] is not False
                                                               for value in row["exact_reconciliation"].values()),
                              "top_growth": [{key: item[key] for key in ("change", "range", "path", "rss_delta_mib")}
                                             for item in row["top_rss_increases"][:3]],
                              "native_delta": row["native_observation_delta"]}
                             for row in report["comparisons"]]}, indent=2))
    else:
        print(raw, end="")


if __name__ == "__main__":
    main()
