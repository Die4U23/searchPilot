"""Prepare one fresh, public-env-only diagnostic project. Never cleans resources."""
import asyncio
import hashlib
import json
import shutil
from argparse import Namespace
from pathlib import Path

import httpx
from scripts.validate_container_soak import Harness

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


async def main():
    frozen = json.loads((REPO / "artifacts/container-hour-2026-10-23/inputs-sha256.json").read_text())
    assert all(hashlib.sha256((REPO / p).read_bytes()).hexdigest() == digest for p, digest in frozen.items())
    h = Harness(Namespace(out=ROOT / "setup", project="sp-allocator-20261025",
                          image="searchpilot-validation:2026-10-23-thp", api_port=18085,
                          db_port=15436, data_version="d3a904f41240", duration_seconds=3600,
                          concurrency=4, baseline_seconds=60, recovery_seconds=120))
    # Remove experiment-sensitive inherited shell variables even though Compose
    # does not normally forward them. No private .env file is opened.
    for key in ("MALLOC_ARENA_MAX", "GLIBC_TUNABLES", "LD_PRELOAD", "PYTHONTRACEMALLOC"):
        h.env.pop(key, None)
    h.prepare()
    shutil.copyfile(__file__, h.out / "setup.executed.py")
    (h.out / "inputs-sha256.json").write_text(json.dumps(frozen, indent=2))
    expected = json.loads((REPO / "artifacts/allocator-2026-10-23/hour-001/summary.json").read_text())["image"]
    assert h.report["image"] == expected, "Image tag changed since the completed hour"
    try:
        h.command(h.compose + ["up", "-d", "--no-build"], timeout=180)
        async with httpx.AsyncClient(base_url=h.base, trust_env=False) as client:
            h.report["ready"] = await h.readiness(client)
        h.report["counts"] = h.counts()
        assert h.report["counts"]["items"] == 65238
        assert h.report["counts"]["queries"] == 100
        assert h.report["counts"]["relevance_labels"] == 1012
        assert h.report["counts"]["feedback_events"] == 0
        h.provenance()
        h.report["state"] = h.state()
        h.report["status"] = "READY_FOR_DIAGNOSTIC_RESTART"
    except BaseException as exc:
        h.report.update(status="FAILED", error_type=type(exc).__name__)
        raise
    finally:
        h.save()
    print(json.dumps({"status": h.report["status"], "counts": h.report["counts"]}), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
