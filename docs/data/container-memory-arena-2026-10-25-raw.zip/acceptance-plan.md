# 最终一小时验证预先验收方案

本方案在正式一小时验证启动前固定。当前状态：**尚未启动，须由主代理确认 arena2
对照的因果证据及最终配置后启动**。本文不预填实验结果，也不授权本文件的编写者
启动服务。任一门槛未达到，继续调查并保留失败证据，不事后放宽标准。

## 候选与固定条件

- 只有 arena2 对照有效且主代理确认后，才使用正常 `scripts/docker_entrypoint.py`
  入口、`SEARCHPILOT_DISABLE_THP=true`、`MALLOC_ARENA_MAX=2` 的最终镜像。
- 独立项目 `sp-arena-hour-20261025`，API 端口 18086，PG 端口 15437，
  独立新卷；保留 `searchpilot_pgdata` 与其他项目容器及卷。
- 输出 `artifacts/allocator-2026-10-25/final-hour`，拒绝覆写已有结果。
- 复用 `scripts.validate_container_soak`：60 秒基线、3600 秒正式调度窗口、
  持续闭环并发 4、固定 100 查询 × 4 模式、16 次预热、120 秒恢复、重启检查。
- 最终 image ID、构建文件、完整命令、公开配置、依赖版本、26 个冻结输入哈希、
  生产及测量脚本快照均在运行前保存，运行结束后复核。不得在运行中改源码或镜像。
- 不启用诊断控制服务、tracemalloc、主动 GC/trim；除原有健康和只读资源采样外，
  不引入请求内的观测补丁。私有 `.env` 不用于运行或归档，外部 LLM 调用为 0。

准备好最终镜像后由主代理执行（`FINAL_IMAGE` 必须替换成已核验标签或 digest）：

```powershell
.venv/Scripts/python.exe -m scripts.validate_container_soak --out artifacts/allocator-2026-10-25/final-hour --project sp-arena-hour-20261025 --image FINAL_IMAGE --duration-seconds 3600 --concurrency 4 --api-port 18086 --db-port 15437
```

## 功能与证据完整性门槛

1. harness 与 benchmark 均 `COMPLETED`；调度窗口为完整 3600 秒，排空与恢复
   时间分别记录，不能把预热或恢复算进正式窗口。
2. 严格账本分析为 `PASSED`：所有 pending/result 完整配对，零失败、零未知、
   零遗留请求；并发峰值 4。报告实际请求分母，不预设吞吐或请求数。
3. 400 个查询/模式组合均有结果，完整结果、排名及模型版本指纹在每组内稳定。
   16/16 预热成功。记录各组重复次数，不能仅检查 HTTP 200。
4. 负载期 10 秒健康采样 live/ready 各 360 次全部成功，ready 各组件检查全真；
   不能忽略探针缺失或错误。若采样调度漏点，作为证据不足调查而非填零补齐。
5. 17 项业务检查全部通过，包括预期拒绝状态码和重启后同一反馈 event_id 幂等
   重放、数据库持久性；区分启动窗口 Docker health 与实际 HTTP readiness。
6. 运行前后 26 个冻结输入及生产、测量源码一致，容器与安装源文件匹配；
   核验正常入口和目标环境配置真实生效，负载期 `THP_enabled=0`、THP 字节为 0。
7. 负载期同一 PID 启动身份，容器未意外重启、未 OOM；cgroup OOM 计数完整且
   无增长，Docker OOMKilled 为 false。身份变化或缺失不能当成零 OOM。

## 内存工程门槛

以 benchmark 正式开始时间为锚点，仅选择 `phase=load` 且 elapsed ∈ [2400,3600)
的 PID1 `smaps_rollup.Rss_bytes`；不混入恢复或重启后的新进程，不挑较平坦子窗口。
对真实采样时间（分钟）做普通最小二乘回归，并同时计算窗口首末差值。

- **末 20 分钟 OLS RSS 斜率 ≤ 0.1 MiB/分钟。**
- **末 20 分钟首末 RSS 增长 ≤ 2 MiB。**
- RSS 与时间字段必须完整、同一进程，至少 118 个点、首末覆盖至少 1180 秒，
  相邻采样间隔不超过 15 秒；未满足则门槛为证据不足，不能判通过。
- 同时展示全小时、末 10/20 分钟、全部五分钟窗口及恢复期，不能只报告通过窗口。
  PID1、cgroup 和客户端内存分开，缺失数据标记缺失，不能填零。

这两个数值是本轮预先约定的工程验收门槛，**不是 SLA，也不是无泄漏证明**。
有限查询集、并发 4、单进程及一小时观察不能覆盖无限运行、其他流量或部署环境。
若失败，保留当前报告与原始账本，继续根因实验；修复后用新目录重跑完整一小时。

## 离线分析与交付

先运行严格分析（新文件不存在时才执行）：

```powershell
.venv/Scripts/python.exe -m scripts.summarize_soak --bench artifacts/allocator-2026-10-25/final-hour/soak.json --ledger artifacts/allocator-2026-10-25/final-hour/soak.requests.jsonl --samples artifacts/allocator-2026-10-25/final-hour/samples.jsonl --out artifacts/allocator-2026-10-25/final-hour-analysis.json --duration-seconds 3600 --window-seconds 300
.venv/Scripts/python.exe artifacts/allocator-2026-10-25/report_final_hour.py
```

后一个脚本只读取完成证据，生成独立 `final-hour-summary.json` 与
`final-hour-memory.png`，不依赖 10 月 23 日对照摘要，也不修改容器。
其 memory_gate 只覆盖内存数值和采样完整性，不能替代上述全部功能/源码/运行时门槛。
完成独立复核、本地检查及最新提交 CI 后，按既有授权提交并合并；署名仅使用用户身份。
