"""Strict offline audit of the two completed controls. Writes NEW reports only."""
import hashlib
import json
import runpy
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROGRESS = runpy.run_path(str(ROOT / "progress_compare.py"))
MAPS = runpy.run_path(str(ROOT / "maps_compare.py"))
CASES = ("no-thp-default-02", "no-thp-arena2-01")


def ledger_audit(path):
    events = [json.loads(line) for line in (path / "requests.jsonl").open(encoding="utf-8")]
    pending, results = {}, {}
    groups, counts, issue_sequence = defaultdict(set), Counter(), []
    for event in events:
        store = pending if event["event"] == "pending" else results
        assert event["event"] in ("pending", "result")
        assert event["request_id"] not in store, "Duplicate ledger event"
        store[event["request_id"]] = event
        if event["event"] == "pending" and event["phase"] == "measured":
            issue_sequence.append((event["index"], event["mode"], event["query"]))
    assert len(pending) == len(results) == 16016
    assert set(pending) == set(results)
    phases = Counter()
    for request_id, end in results.items():
        start = pending[request_id]
        assert all(start[key] == end[key] for key in ("phase", "index", "mode", "query"))
        assert datetime.fromisoformat(start["at"]) <= datetime.fromisoformat(end["at"])
        assert end["outcome"] == "success" and end["status_code"] == 200 and 0 < end["result_count"] <= 10
        phases[end["phase"]] += 1
        if end["phase"] == "measured":
            key = (end["mode"], end["query"])
            fingerprint = (end["result_sha256"], end["ranking_sha256"], end["model_version"])
            assert all(fingerprint)
            groups[key].add(fingerprint)
            counts[key] += 1
    assert phases == {"warmup": 16, "measured": 16000}
    assert [index for index, _, _ in issue_sequence] == list(range(16000))
    assert len(groups) == 400 and set(counts.values()) == {40}
    assert all(len(value) == 1 for value in groups.values())
    canonical = [[*key, list(next(iter(value)))] for key, value in sorted(groups.items())]
    return {"pending": len(pending), "results": len(results), "unique_ids": len(pending),
            "all_pairs_match": True, "phases": dict(phases), "semantic_groups": 400,
            "repeats_per_group": 40, "group_result_ranking_version_sha256": hashlib.sha256(
                json.dumps(canonical, ensure_ascii=True).encode()).hexdigest(),
            "issued_sequence_sha256": hashlib.sha256(json.dumps(issue_sequence, ensure_ascii=True).encode()).hexdigest(),
            "ledger_sha256": hashlib.sha256((path / "requests.jsonl").read_bytes()).hexdigest()}


def observations(path):
    samples = [json.loads(line) for line in (path / "samples.jsonl").open(encoding="utf-8")]
    ticks, thread_counts, external_names = set(), [], set()
    external_present, external_cpu_missing, external_cpu_sum = 0, 0, []
    all_cpu = defaultdict(list)
    for row in samples:
        process = row["server"]
        ticks.add(process["sources"]["stat"]["data"]["start_time_ticks"])
        assert process["identity_consistent"]
        assert process["sources"]["status"]["data"]["THP_enabled"] == 0
        assert process["sources"]["smaps_rollup"]["data"]["AnonHugePages_bytes"] == 0
        thread_counts.append(process["sources"]["status"]["data"]["Threads"])
        assert row["stats"]["available"]
        external = []
        for container in row["stats"]["data"]:
            name, cpu = container["Name"], container["CPUPerc"]
            if cpu.endswith("%"):
                all_cpu[name].append(float(cpu[:-1]))
            if name.startswith("sp-allocator-20261025-"):
                continue
            external_names.add(name)
            external.append(container)
        external_present += bool(external)
        external_cpu_missing += sum(not container["CPUPerc"].endswith("%") for container in external)
        external_cpu_sum.append(sum(float(container["CPUPerc"][:-1]) for container in external
                                    if container["CPUPerc"].endswith("%")))
    assert len(ticks) == 1
    return {"samples": len(samples), "all_sampled_thp_disabled_and_zero_huge_pages": True,
            "pid_start_ticks": next(iter(ticks)), "thread_count_min": min(thread_counts),
            "thread_count_max": max(thread_counts), "external_containers_present_samples": external_present,
            "external_distinct_container_names": len(external_names),
            "external_cpu_missing_entries": external_cpu_missing,
            "max_known_external_cpu_percent_sum": max(external_cpu_sum),
            "container_cpu": {name: {"known_samples": len(values), "mean_percent": sum(values) / len(values),
                                     "max_percent": max(values)} for name, values in all_cpu.items()}}


def env(container):
    return {key: value if separator else None
            for key, separator, value in (item.partition("=") for item in container["Config"]["Env"])}


def main():
    summaries = [json.loads((ROOT / case / "summary.json").read_text()) for case in CASES]
    assert all(summary["status"] == "COMPLETED" for summary in summaries)
    reports = []
    for case, summary in zip(CASES, summaries):
        path = ROOT / case
        assert summary["container"]["Id"] == summary["final_container"]["Id"]
        assert summary["final_container"]["RestartCount"] == 0
        report = PROGRESS["audit"](case)
        assert report["health_failure_count"] == 0 and report["active_requests"] == 0
        assert report["observed_peak_inflight"] == 4
        assert report["sample_missing"] == {}
        report["strict_ledger_audit"] = ledger_audit(path)
        report["observations"] = observations(path)
        report["container_environment"] = env(summary["container"])
        report["load_seconds"] = summary["load_seconds"]
        report["measured_request_time_interval"] = {
            "started_at": summary["load_started_at"], "finished_at": summary["load_finished_at"]}
        report["zero_restarts"] = True
        reports.append(report)
    a, b = reports
    environment_changes = {key: [a["container_environment"].get(key), b["container_environment"].get(key)]
                           for key in a["container_environment"].keys() | b["container_environment"].keys()
                           if a["container_environment"].get(key) != b["container_environment"].get(key)}
    assert environment_changes == {"MALLOC_ARENA_MAX": [None, "2"]}
    checks = {"environment_only_arena_max_differs": True,
              "same_image": a["image"] == b["image"], "same_executed_sources": a["executed_sha256"] == b["executed_sha256"],
              "same_frozen_inputs": a["input_sha256"] == b["input_sha256"],
              "same_command": summaries[0]["container"]["Config"]["Cmd"] == summaries[1]["container"]["Config"]["Cmd"],
              "distinct_container_ids": a["container_id"] != b["container_id"],
              "distinct_process_start_ticks": a["observations"]["pid_start_ticks"] != b["observations"]["pid_start_ticks"],
              "same_ordered_issued_work": a["strict_ledger_audit"]["issued_sequence_sha256"] == b["strict_ledger_audit"]["issued_sequence_sha256"],
              "same_result_ranking_model_every_group": a["strict_ledger_audit"]["group_result_ranking_version_sha256"] == b["strict_ledger_audit"]["group_result_ranking_version_sha256"]}
    assert all(checks.values())
    report = {"schema_version": 1, "case_order": CASES, "checks": checks,
              "environment_changes": environment_changes, "cases": reports,
              "interpretation": "Same-protocol A/B supports glibc arena retention as a causal contributor. "
                                "No randomized/crossover replication; background load and thread scheduling differ. "
                                "Do not attribute throughput differences or all historical one-hour RSS growth solely "
                                "to arena count. Formal final-image hour remains separate."}
    with (ROOT / "comparison-final.json").open("x", encoding="utf-8") as out:
        json.dump(report, out, indent=2)
    arena_maps = [MAPS["compare"](ROOT / CASES[1], "after_400", label, summaries[1], 10)
                  for label in MAPS["DEFAULT_TARGETS"]]
    with (ROOT / "arena2-completed-maps.json").open("x", encoding="utf-8") as out:
        json.dump(arena_maps, out, indent=2)
    print(json.dumps({"checks": checks, "cases": [{"case": r["case"], "health": r["health"],
                      "last_10_minutes": r["last_10_minutes"], "performance": r["latency_and_throughput"],
                      "checkpoints": r["checkpoints"], "observations": {k: v for k, v in r["observations"].items() if k != "container_cpu"}}
                     for r in reports]}, indent=2))


if __name__ == "__main__":
    main()
