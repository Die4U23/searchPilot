# 源码留存排查（只读结论）

本轮检查没有发现按请求无限保留结果的应用缓存。现有证据不足以把剩余增长归因于 glibc 或 MKL；以下候选需要控制实验确认。本文件保存已完成的源码检查，不代表新增运行或验证。

## 已观察到的小时曲线

证据：`artifacts/allocator-2026-10-23/hour-001/samples.jsonl`。

- PID1 load 首样本 RSS 2522.695 MiB，末样本 2630.148 MiB；最后约 10 分钟增长 7.125 MiB。
- 约 15 分钟后 RssFile 固定为 288.836 MiB，后续增长来自匿名页。
- FD 始终为 20；线程数主要在 95 / 100 之间往返，最高 106。线程总数不等于累计创建线程数，也不能说明执行推理的线程身份。
- recovery 首样本至末样本 RSS 下降约 0.867 MiB；load 末样本至 recovery 末样本下降约 0.953 MiB。这是不同端点，不能混用。

## 已确认的协议差异

`artifacts/allocator-2026-10-23/experiment.py:130-145` 每 400 / 800 个请求等待所有 worker 完成，然后采集 snapshot。`scripts/bench_concurrent.py:319-339` 则持续闭环派发 3600 秒，中途不排空。正式验证还通过 `scripts/validate_container_soak.py:326-351` 每 10 秒同时调用 live / ready；短诊断只在前后调用 ready（Docker 自带 live 探针仍存在）。因此短诊断平台不能直接外推为持续负载平台。

## 源码候选与排除边界

1. **线程调度及原生库每线程高水位。** `src/searchpilot/api/deps.py:22` 起的依赖、鉴权、搜索及健康路由均为同步函数，使用框架线程池。`src/searchpilot/search/vector_index.py:276` 只锁模型初始化，`:285` 的推理不锁。本地 AnyIO 实现使用空闲线程栈，并按 10 秒空闲期限回收线程，可能改变处理推理的线程集合。但本地依赖尚未确认与镜像版本一致，且现有线程总数采样不足以证明该机制就是本次根因。
2. **大量短命 Python 对象和分配器碎片。** `src/searchpilot/search/vector_index.py:170` 每次向量搜索生成约 65k 个 Python 整数的候选列表，再遍历候选。列表没有持久化；它是值得对照的分配压力来源，而不是已经证实的泄漏。
3. **数据库优先级较低。** 项目没有 SQLAlchemy；`src/searchpilot/db/connection.py:37-40` 使用有上限的 psycopg 连接池，默认最大 4。`src/searchpilot/db/readiness.py:17` 仅执行 `SELECT 1`。源码未发现按探针累积结果的容器。
4. **日志及请求上下文优先级较低。** `src/searchpilot/observability.py:67-70` 同步写 stderr 并 flush，没有日志队列；`src/searchpilot/api/middleware.py:72` 在 finally 中重置 request_id。源码未发现持续保存请求日志对象的列表或字典。
5. **业务状态边界。** 搜索模型、索引和字段 IDF 缓存由固定模型/语料或字段集合决定；在线查询产生的分数、候选、特征和响应局部对象没有明显持久化路径。固定边界并不排除底层库内部缓存或分配器留存。

## 最小可区分实验

1. THP 关闭，16k 连续请求，相同查询顺序、并发 4 和 10 秒健康探针，先复现正式小时的匿名 RSS 增长；不要继续用每 800 请求排空的旧协议替代。
2. 同协议只改变 `MALLOC_ARENA_MAX=2`，比较 RSS、glibc 已用/空闲字节以及 pymalloc arena/活跃字节。不能仅凭 RSS 变小认定 glibc 根因。
3. 观察实际推理线程 native TID 的累计唯一数及首次推理时刻，不缓存查询内容。如果线程更替与阶梯相关，再进行固定工作线程对照。
4. GC 和 trim 仅在负载及恢复观察结束后执行。若活跃分配稳定、glibc 空闲增长且 arena 限制抑制增长，才支持 allocator 留存；若 pymalloc arena 增长，优先对照候选列表实现；若活跃原生分配增长，则继续定位推理线程或算子缓存。

本次源码检查没有修改生产代码，没有启动服务，没有实施推测性修复。该文件按协调代理要求单独新增。
