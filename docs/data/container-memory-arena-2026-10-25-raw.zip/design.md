# Continuous THP-off allocator controls

Prepared 2026-10-25. These are diagnostic controls, not formal one-hour acceptance.

The preceding THP-off hour completed 49,692 successful measured requests, but its
last 10-minute PID RSS interval still grew 7.125 MiB. The 2026-10-23 controls drained
search at frequent checkpoints and cannot establish that uninterrupted closed-loop
traffic has the same allocation behavior. The new controls remove that confound.

## Protocol

- Own isolated Compose project `sp-allocator-20261025`, API port 18085, PostgreSQL
  port 15436. Setup refuses existing owned resources. It verifies the exact image
  used by the preceding hour, unchanged imported sources and 26 frozen inputs.
- Every case force-recreates the API container and asserts its ID changed. The
  fresh diagnostic database is reused read-only by the search and health routes.
  The same image, command, read-only diagnostic script copies, warmup and THP-off
  process policy apply in all cases. Only `MALLOC_ARENA_MAX` differs: absent versus
  `2`. Absence is asserted in Docker's actual environment; it is not the string
  `0` or an empty string. GLIBC_TUNABLES, LD_PRELOAD and PYTHONTRACEMALLOC are absent.
- 16 sequential warmups; 16,000 measured requests using a shared global index,
  four continuously issuing workers, 100 queries x four modes x 40 repetitions,
  no retries, timeout 10 seconds, limit 10. Semantic outputs are retained in the
  request ledger for comparison. Each case gets an exclusive output directory.
- At 400/4,000/8,000/12,000/16,000 completions, queue a diagnostic snapshot and raw
  `/proc/1/smaps` observation. Workers keep issuing during the first four. Only
  the final request completion naturally drains the workload. Native statistics
  and smaps are sequential, non-atomic, and may see different active requests.
  Each snapshot records actual completion/inflight counts before and after;
  each trigger records completion count, wall-clock and elapsed time.
- Docker subprocesses and large snapshot file writes run via `asyncio.to_thread`.
  Brief in-process summary serialization and per-request ledger writes remain
  synchronous, identically across both arms; this is not a zero-overhead observer.
- An independent HTTP client sends live/ready probes on a target 10-second cycle;
  it does not occupy the four search client connections. The same cycle records
  PID 1 memory/task IDs, host loadavg and all-container Docker stats. Normal
  Docker healthchecks remain enabled. Other projects are observed only; nothing
  stops, modifies, or removes their containers. Different background CPU/load
  profiles are a potential timing confound, not a controlled variable.
- After final snapshot, idle for 120 seconds with the same health observations,
  take an idle snapshot, then explicitly GC and then malloc_trim with separate
  snapshots. Neither intervention runs during measured traffic or the idle
  interval. No tracemalloc is enabled. No external LLM calls occur.

## Execution

From `E:\searchPilot`, using the repository Python and a public-only Compose
environment; no private `.env` is read:

```powershell
$env:PYTHONPATH = 'E:\searchPilot'
.venv/Scripts/python.exe artifacts/allocator-2026-10-25/setup.py
.venv/Scripts/python.exe artifacts/allocator-2026-10-25/experiment.py --case no-thp-default-01 --arena-max unset
.venv/Scripts/python.exe artifacts/allocator-2026-10-25/experiment.py --case no-thp-arena2-01 --arena-max 2
```

Run cases sequentially. A return-to-default replication can use another exclusive
case name after reviewing the first pair. Setup and experiment do not clean up
resources. Cleanup must separately verify exact ownership and preserve
`searchpilot_pgdata` and every other project's resources.

## Interpretation

Check every success denominator, observed health failure, missing sample,
semantic group fingerprint, actual image and script hash before comparing RSS.
Prefer PID RSS/anonymous pages over cgroup totals affected by observer children.
Compare native in-use/free/arena counts and pymalloc changes without adding these
overlapping scopes. Active-workload snapshots cannot be treated as idle retained
object totals. A lower RSS with arena=2 alone does not prove an application leak,
nor establish stable tail behavior or acceptable latency. Same-count traffic can
have different elapsed time and therefore different total health calls. Record
both time and request-count slopes; use a fresh final one-hour run for any adopted
production mitigation.
