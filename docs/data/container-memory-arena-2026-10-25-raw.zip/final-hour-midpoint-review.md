# 最终小时验证进行中抽查

状态：**RUNNING，尚未完成一小时验收**。本次仅离线读取 `final-hour/summary.json` 与 `final-hour/samples.jsonl` 的已完成写入内容；未调用服务、未修改源码或运行配置、未审计全文请求账本。

本记录的固定观察边界为 UTC **2026-10-25 04:11:29.409142 至 04:27:20.195499**，对应负载期前 **96 个样本**，跨度 **950.786357 秒**。文件读取时以完整换行结尾，没有半条 JSON 行。

## 完整性检查

- 96/96 个 server 样本均 available，errors 为空。
- 全部 11 个 server source（stat、status、smaps_rollup、cmdline、fd、cgroup_membership、cgroup_memory_current、cgroup_memory_peak、cgroup_memory_stat、cgroup_memory_events、stat_after）均为 96/96 available。
- 每点 server PID、stat PID、stat_after PID 均为 1；identity_consistent 均为 true；stat / stat_after 的 start_time_ticks 全部为 **316977**。
- Docker stats 96/96 available，API 容器 ID 始终为 **e9c4ba6e58d6**；客户端 memory 来源 96/96 available。
- 采样时间严格递增，相邻间隔 **9.991484–10.023369 秒**。此观察段没有漏样产生的长间隔证据。
- THP_enabled 全部为 0，AnonHugePages_bytes 全部为 0。
- FD 首个负载样本为 17，随后 95 个样本均为 20，没有持续增长。
- cgroup 的 oom、oom_kill、oom_group_kill 在全部 96 点均完整记录为 0。这里没有重新查询 Docker OOMKilled 状态，最终验收仍需核对完整运行状态及全部计数。

## 健康与曲线

- live **96/96** available、HTTP 200 且 body.status=ok。
- ready **96/96** available、HTTP 200 且 body.status=ready；search、recommend、feedback、vector_index、ltr、ctr、database 七项均明确为 true。
- PID RSS 首值 **2393.261719 MiB**，末值 **2418.972656 MiB**；此段最小值 **2393.261719 MiB**、最大值 **2419.125 MiB**。这些是采样值，不代表连续峰值，也不评价尚未发生的末 20 分钟门槛。

**结论：在上述固定观察段内，没有发现因漏样、进程身份切换、容器切换、THP 字段缺失或 OOM 计数缺失造成曲线偏低的证据。** 这不是整小时通过结论；剩余运行、恢复、重启、严格账本及最终内存门槛继续由完整证据验收。

## 追加：swap 与虚拟数据映射检查

状态仍为 **RUNNING**。本次新截止时间为 UTC **2026-10-25 04:33:40.397821**，覆盖同一负载起点以来的前 **134 个完整样本**。仅离线读已写入样本，没有服务调用。

- `smaps_rollup.Swap_bytes`、`smaps_rollup.SwapPss_bytes`、`status.VmSwap_bytes` 三项均 **134/134 有值且全部为 0**；没有将缺失当成零。当前证据不支持“RSS 平台由 swap 换出掩盖增长”的解释。
- 所有样本的 identity_consistent=true，stat 与 stat_after 的启动 tick 仍全部为 316977。
- VmData 首值 5530.253906 MiB，末值及本段最大值为 5857.488281 MiB，首末增加 327.234375 MiB。该总差值包含负载开始时的映射增长，不能单看总差值认定持续膨胀。
- VmData 在第 35 个零基索引采样（UTC 04:17:19.702531）已达到 5857.488281 MiB；其后截至本次截止点，观察到的上界没有继续升高。每 30 个点分组的最大值依次为 5857.308594、5857.488281、5857.488281、5857.488281、5857.488281 MiB。
- 最新约 10 分钟 VmData 首末仍为 +16.015625 MiB、OLS 为 +1.653149 MiB/分钟，但该区间内明显上下往返；相同上界已经在更早出现。线程数 100 时 VmData 为 5854.664063–5857.488281 MiB，95 线程时为 5813.492188–5849.488281 MiB，线程状态与映射波动有关联，不能据此把具体 VMA 归属为线程栈。
- VmSize 首末增加 323.156250 MiB，最新约 10 分钟首末增加 16.023438 MiB；这是虚拟地址空间口径，不能等同 RSS 或活跃堆分配。

追加结论：截至新时间边界，三种 swap 指标完整且为零；VmData 有显著初始增长与后续波动，但目前没有观察到约第 6 分钟之后上界持续扩大。最终验收仍应对完整小时复核这些指标，不能以当前片段代替最终无 swap / 稳定性判断。

## 追加：约第 41 分钟观察

状态仍为 **RUNNING**。此次固定截止时间为 UTC **2026-10-25 04:52:41.098625**，读取前 **248 个完整 load 样本**。读取时文件以完整换行结束，没有丢弃半行。未调用 API、修改源码或运行配置，未审计请求账本。

- 三种 swap 字段（Swap_bytes、SwapPss_bytes、VmSwap_bytes）均 248/248 有值且全部为 0。
- 所有 server 来源 available；PID=1、identity_consistent=true，stat / stat_after 启动 tick 仍恒定为 316977。
- THP_enabled 和 AnonHugePages_bytes 全部为 0；oom、oom_kill、oom_group_kill 三项均 248/248 有值且为 0。
- 相邻间隔 9.980695–10.027729 秒，无漏样长间隔。live / ready 各 248/248 完整成功，ready 七项组件明确为 true。
- FD 为 20 的样本有 246 个，初始为 17 的样本 1 个，暂时为 21 的样本 1 个；没有持续增加。

**出现了小幅新阶梯，应保留而不能继续描述成完全不变的平台。** 最新约 10 分钟的 60 点 RSS 从 2419.136719 升至 2420.609375 MiB（+1.472656 MiB），OLS 为 **+0.143343 MiB/分钟**；该段范围为 2418.898438–2420.609375 MiB。自约第 6 分钟至当前的 212 点 RSS OLS 为 +0.036580 MiB/分钟，但这个较长区间不能替代预定末 20 分钟窗口。

VmData 的观察上界由之前的 5857.488281 上升到 **5858.960938 MiB**，增长同为 1.472656 MiB；最新约 10 分钟内仍随线程状态上下波动，范围为 5801.472656–5858.960938 MiB、OLS 为 -0.041171 MiB/分钟。该数据更新了上一节较早截止时“上界未继续增加”的事实，不能将早期结论套用到新截止点。

此小幅增长不是 swap 或进程身份切换伪影，也不构成尚未完成的预定末 20 分钟门槛结论。完整小时、恢复阶段及原始证据仍待最终验收。
