"""Offline final-run input/source checks; never edits services or existing evidence."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def repository_file(name):
    path = (REPO / name).resolve()
    if not path.is_relative_to(REPO) or not path.is_file():
        raise ValueError("Invalid repository evidence path: " + name)
    return path


def main():
    output = ROOT / "final-integrity.json"
    if output.exists():
        raise FileExistsError("Refuse to overwrite final-integrity.json")
    run = json.loads((ROOT / "final-hour/summary.json").read_text(encoding="utf-8"))
    if run.get("status") != "COMPLETED":
        raise ValueError("Formal hour must be complete before final integrity verification")
    inputs = json.loads((ROOT / "inputs-sha256.json").read_text(encoding="utf-8"))
    if len(inputs) != 26:
        raise ValueError("Expected the frozen set of 26 inputs")
    names = ("validate_container_soak", "soak_memory", "bench_concurrent", "summarize_soak")
    report = {
        "inputs": {name: digest(repository_file(name)) == expected for name, expected in inputs.items()},
        "measurement_scripts": {
            name: digest(repository_file(f"scripts/{name}.py")) == digest(ROOT / f"{name}.executed.py")
            for name in names
        },
        "final_config": {
            saved: digest(ROOT / "final-config" / saved) == digest(repository_file(current))
            for saved, current in (("Dockerfile", "Dockerfile"),
                                   ("docker-compose.yml", "docker-compose.yml"),
                                   ("public-env.txt", ".env.example"))
        },
    }
    original = run["local_source_sha256"]
    if not original:
        raise ValueError("Missing startup local-source manifest")
    report["source_changes_since_run_start"] = [
        name for name, expected in original.items() if digest(repository_file(name)) != expected
    ]
    report["source_change_scope"] = "Production and measurement sources frozen throughout formal hour"
    report["container_source_files_matched_before_start"] = len(run["container_source_sha256"])
    report["installed_source_files_matched_before_start"] = len(run["imported_source"]["sha256"])
    report["passed"] = (all(report["inputs"].values())
                        and all(report["measurement_scripts"].values())
                        and all(report["final_config"].values())
                        and not report["source_changes_since_run_start"])
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
