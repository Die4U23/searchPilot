"""Derive publication tables from completed evidence; no service writes."""
import json
import math
import statistics
from collections import Counter
from datetime import datetime
from pathlib import Path


def memory_sample_errors(sample):
    """Do not accept apparently usable numbers from invalid process samples."""
    server = sample.get("server", {})
    sources = server.get("sources", {})
    before = sources.get("stat", {})
    after = sources.get("stat_after", {})
    smaps = sources.get("smaps_rollup", {})
    errors = []
    if server.get("available") is not True:
        errors.append("server_unavailable")
    if type(server.get("pid")) is not int or server["pid"] != 1:
        errors.append("server_pid_not_one")
    if server.get("identity_consistent") is not True:
        errors.append("identity_not_confirmed")
    for name, source in (("stat", before), ("stat_after", after)):
        data = source.get("data", {})
        if source.get("available") is not True:
            errors.append(name + "_unavailable")
        if type(data.get("pid")) is not int or data["pid"] != 1:
            errors.append(name + "_pid_not_one")
        ticks = data.get("start_time_ticks")
        if type(ticks) is not int or ticks < 0:
            errors.append(name + "_invalid_start_time")
    if before.get("data", {}).get("start_time_ticks") != after.get("data", {}).get("start_time_ticks"):
        errors.append("start_time_changed_during_sample")
    if smaps.get("available") is not True:
        errors.append("smaps_unavailable")
    rss = smaps.get("data", {}).get("Rss_bytes")
    if type(rss) not in (int, float) or not math.isfinite(rss) or rss < 0:
        errors.append("rss_not_finite_nonnegative")
    return errors


root = Path(__file__).resolve().parent
run = root / "final-hour"
outputs = [root / "final-hour-summary.json", root / "final-hour-memory.png"]
assert not any(p.exists() for p in outputs), "refuse to overwrite prior evidence"
bench = json.loads((run/"soak.json").read_text())
harness = json.loads((run/"summary.json").read_text())
assert bench["status"] == harness["status"] == "COMPLETED"
audit = json.loads((root/"final-hour-analysis.json").read_text())
samples = [json.loads(line) for line in (run/"samples.jsonl").read_text().splitlines()]
measured = bench["runs"][0]
start = datetime.fromisoformat(measured["started_at"])
rows = []
for sample in samples:
    elapsed = (datetime.fromisoformat(sample["at"])-start).total_seconds()
    sources = sample.get("server",{}).get("sources",{})
    smaps = sources.get("smaps_rollup",{}).get("data",{})
    cgroup = sources.get("cgroup_memory_stat",{}).get("data",{}).get("bytes",{})
    client = sample.get("client",{}).get("sources",{}).get("memory",{}).get("data",{})
    memory_errors = memory_sample_errors(sample)
    rows.append({"seconds":elapsed,"phase":sample["phase"],
                 "rss":smaps.get("Rss_bytes") if not memory_errors else None,
                 "memory_errors":memory_errors,
                 "thp":smaps.get("AnonHugePages_bytes"),
                 "thp_enabled":sources.get("status",{}).get("data",{}).get("THP_enabled"),
                 "pid_start":sources.get("stat",{}).get("data",{}).get("start_time_ticks"),
                 "anon":smaps.get("Anonymous_bytes"),"cgroup_anon":cgroup.get("anon"),
                 "cgroup_file":cgroup.get("file"),"client_rss":client.get("rss_bytes")})

windows=[]
for index in range(12):
    group = [r for r in rows if index*300 <= r["seconds"] < (index+1)*300]
    values = {k:[r[k] for r in group if r[k] is not None]
              for k in ("rss","anon","thp","cgroup_anon","cgroup_file","client_rss")}
    windows.append({"index":index,"sample_count":len(group),
                    "available_count":{k:len(v) for k,v in values.items()},
                    "missing_count":{k:len(group)-len(v) for k,v in values.items()},
                    "median_bytes":{k:statistics.median(v) if v else None for k,v in values.items()},
                    "mean_bytes":{k:statistics.mean(v) if v else None for k,v in values.items()}})

active=set()
peak=0
outcomes=Counter()
with (run/"soak.requests.jsonl").open() as stream:
    for line in stream:
        event=json.loads(line)
        if event["event"]=="pending":
            active.add(event["request_id"])
            peak=max(peak,len(active))
        else:
            active.discard(event["request_id"])
            outcomes[event["phase"]+":"+event["outcome"]]+=1

load_rows = [row for row in rows if row["phase"] == "load"]
tail_rows = [row for row in load_rows if row["seconds"] >= 3000]
recovery_rows = [row for row in rows if row["phase"] == "recovery"]
def endpoints(group):
    ordered = sorted(group, key=lambda row: row["seconds"])
    invalid = [{"seconds": row["seconds"], "reasons": row["memory_errors"]}
               for row in ordered if row["memory_errors"]]
    missing = sum(row["rss"] is None for row in ordered)
    result = {"count": len(ordered), "available": len(ordered)-len(invalid),
              "missing": missing, "invalid_count": len(invalid), "invalid_samples": invalid}
    # An invalid row invalidates this whole window. Never fit only the remaining rows.
    if invalid or missing or len(ordered) < 2:
        return {**result, "available_for_slope": False}
    valid = ordered
    xs = [row["seconds"] / 60 for row in valid]
    ys = [row["rss"] / 1048576 for row in valid]
    xmean, ymean = statistics.mean(xs), statistics.mean(ys)
    denominator = sum((x-xmean)**2 for x in xs)
    slope = sum((x-xmean)*(y-ymean) for x,y in zip(xs,ys))/denominator if denominator else None
    identities = {row["pid_start"] for row in ordered}
    return {**result, "available_for_slope": slope is not None,
            "first_seconds": valid[0]["seconds"], "last_seconds": valid[-1]["seconds"],
            "span_seconds": valid[-1]["seconds"]-valid[0]["seconds"],
            "max_interval_seconds": max(b["seconds"]-a["seconds"] for a,b in zip(valid,valid[1:])),
            "single_observed_pid": len(identities)==1 and None not in identities,
            "first_rss_bytes": valid[0]["rss"], "last_rss_bytes": valid[-1]["rss"],
            "delta_rss_bytes": valid[-1]["rss"]-valid[0]["rss"],
            "min_rss_bytes": min(row["rss"] for row in valid),
            "max_rss_bytes": max(row["rss"] for row in valid),
            "ols_mib_per_minute": slope}


def evaluate_memory_gate(last_twenty):
    coverage_ok = (last_twenty.get("available_for_slope", False)
               and last_twenty["invalid_count"] == 0
               and last_twenty["missing"] == 0 and last_twenty["count"] >= 118
               and last_twenty["span_seconds"] >= 1180
               and last_twenty["max_interval_seconds"] <= 15
               and last_twenty["single_observed_pid"])
    return {"scope": "predeclared engineering memory gate only; not whole-run acceptance or SLA",
               "window_seconds": [2400,3600], "slope_limit_mib_per_minute": 0.1,
               "growth_limit_mib": 2, "coverage_passed": coverage_ok,
               "status": "INSUFFICIENT_EVIDENCE" if not coverage_ok else
                         "PASSED" if last_twenty["ols_mib_per_minute"] <= 0.1 and
                         last_twenty["delta_rss_bytes"] <= 2*1048576 else "FAILED",
               "observed": last_twenty}


last_twenty = endpoints([row for row in load_rows if 2400 <= row["seconds"] < 3600])
memory_gate = evaluate_memory_gate(last_twenty)
doc={"schema_version":1,"harness_status":harness["status"],"ledger_status":audit["status"],
     "ledger_issues":audit["issues"],"ledger_phases":audit["phases"],
     "started_at":measured["started_at"],"finished_at":measured["finished_at"],
     "summary":measured["summary"],"by_mode":measured["by_mode"],
     "peak_in_flight_reconstructed":peak,"pending_at_end":sorted(active),
     "outcomes":dict(outcomes),"startup_seconds":harness["startup_seconds"],
     "business_checks":dict(Counter(row["status"] for row in harness["requests"])),
     "business_status_codes":dict(Counter(row.get("http_status") for row in harness["requests"])),
     "database_initial":harness["initial_counts"],"database_final":harness.get("final_counts"),
     "image":harness["image"],"packages":harness["container_packages"],
     "engine":{"cpus":harness["engine"]["NCPU"],"memory_bytes":harness["engine"]["MemTotal"]},
     "windows":windows,"resources":audit["resources"],
     "memory_endpoints":{"load":endpoints(load_rows),"last_ten_minutes":endpoints(tail_rows),
                         "recovery":endpoints(recovery_rows), "last_twenty_minutes":last_twenty},
     "memory_gate":memory_gate,
     "thp_validation":{"all_samples_count":len(rows),
                       "thp_enabled_counts":dict(Counter(str(r["thp_enabled"]) for r in rows)),
                       "anon_huge_pages_counts":dict(Counter(str(r["thp"]) for r in rows)),
                       "load_samples_count":len(load_rows),
                       "load_thp_enabled_counts":dict(Counter(str(r["thp_enabled"]) for r in load_rows)),
                       "load_anon_huge_pages_counts":dict(Counter(str(r["thp"]) for r in load_rows))},
     "health_by_phase":{phase:{kind:dict(Counter(str(s[kind].get("status")) for s in samples if s["phase"]==phase))
                               for kind in ("live","ready")} for phase in sorted({s["phase"] for s in samples})},
     "fingerprint_groups":audit["fingerprints"]["group_count"],
     "limitations":["single worker, c4 closed loop, fixed 100 query fixture, no capacity/SLA claim",
                    "sampled memory is not continuous peak or proof of absence of leaks",
                    "native allocator diagnosis is separate and does not attribute all hour growth",
                    "no tracing, gc or trim during HTTP hour; host background load uncontrolled"],
     "external_llm_calls":0}
with outputs[0].open("x", encoding="utf-8") as output:
    output.write(json.dumps(doc,indent=2)+"\n")
print(json.dumps({"harness_status":doc["harness_status"], "ledger_status":doc["ledger_status"], "summary":doc["summary"], "memory_gate":memory_gate},indent=2))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axes=plt.subplots(2,1,figsize=(10,7),sharex=True,layout="constrained")
selected=[r for r in rows if r["phase"] in ("baseline", "load", "recovery")]
recovery_start=(datetime.fromisoformat(harness["soak_finished_at"])-start).total_seconds()/60
for key,label in (("rss","API PID 1 RSS"),("anon","API anonymous"),("cgroup_anon","cgroup anonymous")):
    axes[0].plot([r["seconds"]/60 for r in selected],
                 [r[key]/1048576 if r[key] is not None else float("nan") for r in selected],label=label,linewidth=1)
for key,label in (("cgroup_file","cgroup file pages"),("client_rss","Windows load generator RSS")):
    axes[1].plot([r["seconds"]/60 for r in selected],
                 [r[key]/1048576 if r[key] is not None else float("nan") for r in selected],label=label,linewidth=1)
for axis in axes:
    axis.axvline(0,color="#888888",linestyle="--",linewidth=.8)
    axis.axvline(60,color="#888888",linestyle="--",linewidth=.8)
    axis.axvspan(recovery_start, max(r["seconds"] for r in selected)/60,
                 color="#c5e1a5",alpha=.25,label="Post-load recovery")
    axis.set_ylabel("MiB (sampled)")
    axis.grid(alpha=.2)
    axis.legend(loc="best")
axes[1].set_xlabel("Minutes since measured dispatch began; dispatch stops at 60")
axes[0].set_title("SearchPilot: one-hour c4 mixed search, separate memory scopes")
with outputs[1].open("xb") as output:
    fig.savefig(output, format="png", dpi=160)
plt.close(fig)
