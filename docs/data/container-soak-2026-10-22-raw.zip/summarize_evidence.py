import hashlib
import json
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'run-001'
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
report = load(RUN/'summary.json')
bench = load(RUN/'soak.json')
run = bench['runs'][0]
events = [json.loads(line) for line in (RUN/'soak.requests.jsonl').read_text(encoding='utf-8').splitlines()]
pending = {e['request_id']:e for e in events if e['event']=='pending'}
results = {e['request_id']:e for e in events if e['event']=='result'}
assert len(pending) == len(results) == len(events)//2
assert pending.keys() == results.keys()
assert len(pending) == len(run['requests']) + len(run['warmup'])
assert report['status']=='COMPLETED' and report['soak_exit_code']==0
assert not run['summary']['failures'] and all(r['outcome']=='success' for r in run['warmup'])
assert all(r['status']=='completed' for r in report['requests'])
snapshots = [json.loads(line) for line in (RUN/'samples.jsonl').read_text(encoding='utf-8').splitlines()]
samples = [s for s in snapshots if run['started_at'] <= s['at'] <= run['finished_at']]
assert samples and all(s.get('ready',{}).get('status')==200 and s.get('live',{}).get('status')==200 for s in samples)

def memory_bytes(value):
    amount, unit = re.fullmatch(r'([\d.]+)([A-Za-z]+)', value.split(' / ')[0]).groups()
    return float(amount) * {'B':1,'KiB':1024,'MiB':1024**2,'GiB':1024**3,'kB':1000,'MB':1000**2,'GB':1000**3}[unit]

resources = {}
for name in ('sp-soak-20261022-api-1','sp-soak-20261022-db-1'):
    stats = [r for s in samples for r in s['stats'] if r['Name']==name]
    memory = [memory_bytes(s['MemUsage']) for s in stats]
    cpu = [float(s['CPUPerc'].rstrip('%')) for s in stats]
    resources[name] = {'sample_count':len(stats),'memory_first_bytes':memory[0],'memory_last_bytes':memory[-1],'memory_min_bytes':min(memory),'memory_max_sampled_bytes':max(memory),'cpu_mean_percent':statistics.mean(cpu),'cpu_max_sampled_percent':max(cpu),'max_sampled_pids':max(int(s['PIDs']) for s in stats)}

fingerprints = defaultdict(lambda: {'ranking':set(),'result':set(),'n':0})
for row in run['requests']:
    group = fingerprints[(row['mode'],row['query'],row['model_version'])]
    group['ranking'].add(row['ranking_sha256'])
    group['result'].add(row['result_sha256'])
    group['n'] += 1

windows = []
for start in range(0,600,60):
    rows = [r for r in run['requests'] if start*1000 <= r['dispatched_ms'] < (start+60)*1000]
    latencies = sorted(r['elapsed_ms'] for r in rows)
    windows.append({'dispatch_start_seconds':start,'requests':len(rows),'outcomes':dict(Counter(r['outcome'] for r in rows)),'p95_ms':latencies[__import__('math').ceil(.95*len(rows))-1] if rows else None})

executed = ROOT/'bench_concurrent.executed.py'
assert hashlib.sha256(executed.read_bytes()).hexdigest() == bench['client_checkout_start']['benchmark_sha256']
inputs = load(ROOT/'inputs-sha256.json')
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in inputs.items())
active = peak = 0
for event in events:
    if event['phase'] != 'measured':
        continue
    active += 1 if event['event']=='pending' else -1
    peak = max(peak,active)
assert active == 0 and peak == 4
summary = {'date':'2026-10-22','base_commit':bench['client_checkout_start']['commit'],'container_image_id':report['initial_state'][0]['Image'],'startup_seconds':report['startup_seconds'],'initial_counts':report['initial_counts'],'final_counts':report['final_counts'],'summary':run['summary'],'by_mode':run['by_mode'],'dispatch_window_seconds':run['dispatch_window_seconds'],'drain_seconds':run['drain_seconds'],'last_dispatch_seconds':run['last_dispatch_seconds'],'warmup_count':len(run['warmup']),'warmup_successes':sum(r['outcome']=='success' for r in run['warmup']),'ledger_pending':len(pending),'ledger_results':len(results),'ledger_unknown':0,'max_client_inflight':peak,'business_checks':len(report['requests']),'expected_http_statuses':dict(Counter(str(r['http_status']) for r in report['requests'])),'sampled_health_count':len(samples),'sampled_health_failures':0,'resources':resources,'query_mode_groups':len(fingerprints),'ranking_drift_groups':sum(len(g['ranking'])>1 for g in fingerprints.values()),'score_or_result_drift_groups':sum(len(g['result'])>1 for g in fingerprints.values()),'windows':windows,'restart_exit_code':report['stopped_state'][0]['State']['ExitCode'],'restart_feedback_persisted':True,'external_llm_calls':0,'container_packages':report['container_packages'],'input_hashes_verified':len(inputs)}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
