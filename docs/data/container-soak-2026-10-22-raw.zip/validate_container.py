"""Local isolated Compose validation; never reads private .env."""
import asyncio
import csv
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path

import httpx
import psycopg
import pyarrow.parquet as pq
from searchpilot.recommend.history import load_user_history

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'run-001'
RUN.mkdir(exist_ok=False)
DOCKER = shutil.which('docker') or r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
ENV = {k: v for k, v in os.environ.items() if not k.startswith(('SEARCHPILOT_', 'OPENAI_', 'ARCBENCH_'))}
ENV['POSTGRES_PASSWORD'] = 'searchpilot'
COMPOSE = [DOCKER, 'compose', '--env-file', '.env.example', '-p', 'sp-soak-20261022', '-f', 'docker-compose.yml', '-f', '.tmp/compose-soak-20261022.yml']
API = 'sp-soak-20261022-api-1'
DB = 'sp-soak-20261022-db-1'
BASE = 'http://127.0.0.1:18081'
DB_URL = 'postgresql://searchpilot:searchpilot@127.0.0.1:15432/searchpilot'
report = {'status': 'RUNNING', 'started_at': datetime.now(UTC).isoformat(), 'requests': [], 'database_mode': 'isolated PostgreSQL 16 fresh named volume', 'external_llm_calls': 0}
phase = 'startup'
stop = threading.Event()

def save():
    (RUN / 'summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

def command(args, *, timeout=60):
    return subprocess.run(args, env=ENV, check=True, capture_output=True, text=True, encoding='utf-8', timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW).stdout

def state():
    raw = json.loads(command([DOCKER, 'inspect', API, DB]))
    return [{k: row[k] for k in ('Id', 'Name', 'Image', 'RestartCount', 'State')} for row in raw]

def counts():
    tables = ['schema_migrations', 'items', 'queries', 'relevance_labels', 'model_versions', 'agent_tasks', 'bids', 'experiments', 'feedback_events']
    with psycopg.connect(DB_URL, connect_timeout=5) as connection:
        return {name: connection.execute('SELECT count(*) FROM ' + name).fetchone()[0] for name in tables}

def sample():
    with (RUN / 'samples.jsonl').open('x', encoding='utf-8') as sink, httpx.Client(trust_env=False, timeout=3) as client:
        while not stop.is_set():
            before = time.perf_counter()
            row = {'at': datetime.now(UTC).isoformat(), 'phase': phase}
            try:
                row['stats'] = [json.loads(line) for line in command([DOCKER, 'stats', '--no-stream', '--format', '{{json .}}', API, DB], timeout=10).splitlines()]
                for endpoint in ('live', 'ready'):
                    started = time.perf_counter()
                    response = client.get(BASE + '/health/' + endpoint)
                    row[endpoint] = {'status': response.status_code, 'seconds': time.perf_counter()-started, 'body': response.json()}
            except Exception as exc:
                row['error'] = type(exc).__name__
            sink.write(json.dumps(row) + '\n')
            sink.flush()
            stop.wait(max(0, 10 - (time.perf_counter()-before)))

async def wait_ready(client):
    async with asyncio.timeout(240):
        while True:
            try:
                async with asyncio.timeout(2):
                    response = await client.get('/health/ready')
                if response.status_code == 200:
                    checks = response.json()['checks']
                    assert all(checks.get(k) is True for k in ('search', 'recommend', 'feedback', 'vector_index', 'ltr', 'ctr', 'database'))
                    return response.json()
            except (httpx.HTTPError, TimeoutError):
                pass
            await asyncio.sleep(0.5)

async def request(client, label, path, payload=None, expected=200, headers=None):
    row = {'label': label, 'status': 'pending', 'expected_status': expected}
    report['requests'].append(row)
    save()
    started = time.perf_counter()
    try:
        async with asyncio.timeout(30):
            response = await client.get(path, headers=headers) if payload is None else await client.post(path, json=payload, headers=headers)
            body = response.json()
        row.update(http_status=response.status_code, seconds=time.perf_counter()-started, response=body)
        assert response.status_code == expected
        row['status'] = 'completed'
        return body
    except Exception as exc:
        row.update(status='failed', error=type(exc).__name__, seconds=time.perf_counter()-started)
        raise
    finally:
        save()

async def main():
    global phase
    sampler = None
    save()
    try:
        start = time.perf_counter()
        command(COMPOSE + ['up', '-d', '--no-build', 'api'])
        async with httpx.AsyncClient(base_url=BASE, trust_env=False, timeout=30) as client:
            report['ready'] = await wait_ready(client)
            report['startup_seconds'] = time.perf_counter()-start
            report['initial_state'] = state()
            report['initial_counts'] = counts()
            expected_items = pq.ParquetFile('data/processed/d3a904f41240/items.parquet').metadata.num_rows
            with Path('data/queries/queries.csv').open(encoding='utf-8') as f:
                expected_queries = len(list(csv.DictReader(f)))
            with Path('data/queries/labels.csv').open(encoding='utf-8') as f:
                expected_labels = len(list(csv.DictReader(f)))
            assert report['initial_counts']['items'] == expected_items
            assert report['initial_counts']['queries'] == expected_queries
            assert report['initial_counts']['relevance_labels'] == expected_labels
            assert report['initial_counts']['feedback_events'] == 0
            paths = ['src/searchpilot/bootstrap.py', 'src/searchpilot/config.py', 'src/searchpilot/search/service.py', 'scripts/docker_entrypoint.py', 'scripts/docker_seed.py', 'scripts/seed_items.py', 'scripts/seed_catalog.py']
            code = 'import json,hashlib;from pathlib import Path;print(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ' + repr(paths) + '}))'
            report['container_source_sha256'] = json.loads(command([DOCKER, 'exec', API, 'python', '-c', code]))
            assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in report['container_source_sha256'].items())
            report['container_packages'] = json.loads(command([DOCKER, 'exec', API, 'python', '-c', "import json,importlib.metadata as m;print(json.dumps({n:m.version(n) for n in ['searchpilot','torch','sentence-transformers','numpy','pandas','fastapi','uvicorn','psycopg']}))"]))
            reference = {}
            for mode in ('bm25', 'vector', 'hybrid', 'ltr'):
                body = await request(client, 'initial_' + mode, '/search', {'query':'microsoft','mode':mode,'limit':5})
                assert len(body['results']) == 5
                reference[mode] = {k:v for k,v in body.items() if k != 'request_id'}
            histories = load_user_history(Path('data/processed/d3a904f41240/user_history.parquet'))
            user = next(u for u,h in histories.items() if len(h) >= 3)
            known = await request(client, 'known_recommend', '/recommend', {'user_id':user,'limit':5})
            cold = await request(client, 'cold_recommend', '/recommend', {'user_id':'container-soak-user','limit':5})
            assert known['channel'] == 'itemcf' and not known['cold_start']
            assert cold['channel'] == 'popular' and cold['cold_start']
            for body in (known, cold):
                assert len(body['results']) == 5 and len({r['item_id'] for r in body['results']}) == 5
            ctr = await request(client, 'ctr', '/ctr/score', {'user_id':user,'candidates':[{'item_id':known['results'][0]['item_id'],'bid':1.0}]})
            assert ctr['model_version'] and ctr['calibrator_version']
            assert all(math.isfinite(r[k]) and 0 <= r[k] <= 1 for r in ctr['results'] for k in ('pctr','pctr_calibrated'))
            exp = await request(client, 'experiment', '/experiments/sp-bm25')
            assert exp['source'] == 'searchpilot' and exp['metrics']
            feedback = {'idempotency_key':str(uuid.uuid4()),'request_id':'req_container_soak','item_id':'N24742','kind':'click','event_at':datetime.now(UTC).isoformat(),'user_id':'container-soak-user','position':1}
            first = await request(client, 'feedback_create', '/feedback', feedback, 201)
            replay = await request(client, 'feedback_replay', '/feedback', feedback, 201)
            assert not first['replayed'] and replay['replayed'] and first['event_id'] == replay['event_id']
            await request(client, 'feedback_conflict', '/feedback', {**feedback,'kind':'like'}, 409)
            await request(client, 'feedback_missing_item', '/feedback', {**feedback,'idempotency_key':str(uuid.uuid4()),'item_id':'missing_soak_item'}, 404)
            phase = 'soak'
            sampler = threading.Thread(target=sample, daemon=True)
            sampler.start()
            bench = [sys.executable, 'scripts/bench_concurrent.py', '--base-url', BASE, '--duration-seconds', '600', '--concurrency', '4', '--timeout', '10', '--warmup', '4', '--modes', 'bm25', 'vector', 'hybrid', 'ltr', '--data-version', 'd3a904f41240', '--server-description', 'isolated Compose PG16, CPU embedding, single worker; image/source evidence in container report', '--out', str(RUN/'soak.json')]
            report['soak_started_at'] = datetime.now(UTC).isoformat()
            save()
            with (RUN/'soak-console.txt').open('w',encoding='utf-8') as console:
                process = subprocess.Popen(bench, env=ENV, stdout=console, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
                while process.poll() is None:
                    await asyncio.sleep(1)
            report['soak_exit_code'] = process.returncode
            report['soak_finished_at'] = datetime.now(UTC).isoformat()
            phase = 'recovery'
            for mode in reference:
                body = await request(client, 'recovery_' + mode, '/search', {'query':'microsoft','mode':mode,'limit':5})
                assert {k:v for k,v in body.items() if k!='request_id'} == reference[mode]
            await asyncio.sleep(30)
            report['post_soak_ready'] = await wait_ready(client)
            report['post_soak_state'] = state()
            phase = 'restart'
            command(COMPOSE + ['stop', '-t', '30', 'api'])
            report['stopped_state'] = state()
            assert report['stopped_state'][0]['State']['ExitCode'] == 0
            command(COMPOSE + ['start', 'api'])
            report['restart_ready'] = await wait_ready(client)
            replay = await request(client, 'feedback_after_restart', '/feedback', feedback, 201)
            assert replay['replayed'] and replay['event_id'] == first['event_id']
            report['final_counts'] = counts()
            assert report['final_counts'] == {**report['initial_counts'], 'feedback_events':1}
            report['final_state'] = state()
            assert not any(r['State']['OOMKilled'] for r in report['final_state'])
            assert process.returncode == 0
            report['status'] = 'COMPLETED'
    except Exception as exc:
        report.update(status='FAILED', error=type(exc).__name__)
        raise
    finally:
        stop.set()
        if sampler:
            sampler.join(timeout=15)
        for name in (API, DB):
            try:
                output = subprocess.run([DOCKER,'logs',name],capture_output=True,encoding='utf-8',timeout=15)
                (RUN/(name+'.log')).write_text(output.stdout+output.stderr,encoding='utf-8')
            except Exception as exc:
                report['logs_error'] = type(exc).__name__
        report['finished_at'] = datetime.now(UTC).isoformat()
        save()
        print(json.dumps({k:v for k,v in report.items() if k not in ('requests','initial_state','post_soak_state','stopped_state','final_state')}, indent=2),flush=True)

asyncio.run(main())
