"""Read-only candidate evidence gates; no Docker/HTTP and no implicit qualification."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CONTROL = ROOT.parent / "arena-count-2026-10-26"
OLD = ROOT.parent / "extended-memory-2026-10-26"
PROJECT = "sp-memory-arena1-normal-20261026"
IMAGE = "sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1"
IMAGE_REFERENCE = "searchpilot-validation@" + IMAGE
QUERY_SHA = "7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def control_path(name):
    path = CONTROL / name
    require(
        not Path(name).is_absolute() and path.resolve().is_relative_to(CONTROL.resolve()),
        "Control evidence path escapes root",
    )
    require(
        not any(p.is_symlink() for p in [path, *path.parents] if p.is_relative_to(CONTROL)),
        "Symlink control evidence",
    )
    return path


def comparator():
    path = CONTROL / "compare_arena_controls.py"
    spec = importlib.util.spec_from_file_location("arena_normal_screening", path)
    require(spec is not None and spec.loader is not None, "Cannot load arena comparator")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def require_eligible(result):
    require(
        result.get("status") == "PASSED"
        and result.get("candidate_eligible") is True
        and result.get("failures") == []
        and result.get("screening", {}).get("passed") is True
        and result.get("full_semantics_equal") is True
        and result.get("common_successful_groups") == 5200
        and result.get("case_order") == ["arena2-control-01", "arena1-treatment-01"]
        and len(result.get("cases", [])) == 2
        and all(row.get("status") == "PASSED" for row in result["cases"]),
        "Complete eligible arena screening required; no freeze/build/run allowed",
    )


def require_base_image(image, referenced_image, reference=IMAGE_REFERENCE):
    require(
        reference == IMAGE_REFERENCE
        and image.get("Id") == IMAGE
        and reference in (image.get("RepoDigests") or [])
        and referenced_image.get("Id") == IMAGE,
        "Immutable base RepoDigest membership or resolved image ID differs",
    )


def screening_binding(path, *, replay):
    path = path.resolve()
    require(
        path.is_relative_to(CONTROL.resolve()) and not path.is_symlink(),
        "Comparison must be the actual control result",
    )
    result = read(path)
    require_eligible(result)
    require(set(result["root_input_sha256"]), "Screening root hashes missing")
    for name, sha in result["root_input_sha256"].items():
        require(digest(control_path(name)) == sha, "Screening root changed: " + name)
    require("compare_arena_controls.py" in result["root_input_sha256"], "Comparator hash not bound")
    tool = comparator()
    if replay:
        replayed = json.loads(json.dumps(tool.compare(CONTROL), allow_nan=False))
        require(replayed == result, "Saved screening differs from full raw re-audit")
    for row in result["cases"]:
        require(
            tool.tree_hashes(control_path(row["case"])) == row["input_sha256"],
            "Screening raw membership/hash changed: " + row["case"],
        )
    return {
        "status": "SCREENING_VERIFIED_NOT_PRODUCTION_ACCEPTANCE",
        "candidate_eligible": True,
        "comparison_path": path.relative_to(REPO).as_posix(),
        "comparison_sha256": digest(path),
        "comparator_sha256": digest(CONTROL / "compare_arena_controls.py"),
        "root_input_sha256": result["root_input_sha256"],
        "cases": {row["case"]: row["input_sha256"] for row in result["cases"]},
    }


def verify_bound_candidate(root=ROOT):
    saved = read(root / "screening-binding.json")
    require(
        digest(CONTROL / "compare_arena_controls.py") == saved["comparator_sha256"],
        "Screening comparator changed",
    )
    actual = screening_binding(REPO / saved["comparison_path"], replay=False)
    require(actual == saved, "Screening binding changed")
    require(
        digest(root / "screening-comparison.json") == saved["comparison_sha256"],
        "Local screening copy changed",
    )
    preflight = read(root / "preflight.json")
    require(
        preflight["status"] == "PASSED"
        and preflight.get("image") == IMAGE
        and preflight.get("base_image_reference") == IMAGE_REFERENCE
        and preflight["screening_binding_sha256"] == digest(root / "screening-binding.json"),
        "Preflight candidate binding differs",
    )
    for name, sha in preflight["helper_sha256"].items():
        require(digest(root / name) == sha, "Candidate execution helper changed: " + name)
    for manifest in ("inputs-sha256.json", "sources-sha256.json"):
        require(
            digest(root / manifest) == preflight["manifest_sha256"][manifest],
            "Frozen manifest changed",
        )
        for name, sha in read(root / manifest).items():
            require(digest(REPO / name) == sha, "Current frozen input/source changed: " + name)
    for name, sha in preflight["public_config_sha256"].items():
        require(digest(REPO / name) == sha, "Public production configuration changed: " + name)
        local = "public-env.txt" if name == ".env.example" else name
        require(
            digest(root / "source-config" / local) == sha, "Public configuration snapshot changed"
        )
    require(
        digest(root / "acceptance-plan.md") == preflight["plan_sha256"], "Candidate plan changed"
    )
    return saved


def compare_semantics(actual, expected):
    require(
        len(actual) == len(expected) == 5200 and actual.keys() == expected.keys(),
        "Normal/screening semantic key set incomplete",
    )
    differences = [
        {"query": q, "mode": m, "normal": actual[(q, m)], "screening": expected[(q, m)]}
        for q, m in sorted(actual)
        if actual[(q, m)] != expected[(q, m)]
    ]
    require(
        not differences,
        "Normal/screening result/ranking/model/count differs: " + str(differences[:5]),
    )
    return {"groups": 5200, "all_result_ranking_model_count_equal": True}


def verify_normal_semantics(folder):
    binding = verify_bound_candidate(folder.parent)
    tool = comparator()
    setup = tool.frozen_setup(CONTROL)
    _, _, expected = tool.audit_case(
        CONTROL, "arena1-treatment-01", 1, setup, tool.load_base(CONTROL)
    )
    actual = {}
    with (folder / "soak.requests.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("event") != "result":
                continue
            require(row.get("outcome") == "success", "Unsuccessful normal result")
            key = (row["query"], row["mode"])
            value = tuple(
                row[k] for k in ("result_sha256", "ranking_sha256", "model_version", "result_count")
            )
            require(key not in actual or actual[key] == value, "Normal group is unstable")
            actual[key] = value
    return {**compare_semantics(actual, expected), "screening_binding": binding}


def verify_pid1_runtime(folder, bench):
    from datetime import datetime

    def timestamp(value):
        at = datetime.fromisoformat(value)
        require(at.tzinfo is not None, "PID1 observation timestamp lacks timezone")
        return at.timestamp()

    start = timestamp(bench["runs"][0]["started_at"])
    probes = []
    previous_row = None
    with (folder / "background.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            row_at = timestamp(row["at"])
            require(
                previous_row is None or row_at > previous_row, "Observer rows not strictly ordered"
            )
            previous_row = row_at
            probe = row.get("pid1_runtime", {})
            began, ended = timestamp(probe["started_at"]), timestamp(probe["finished_at"])
            seconds, whole = probe.get("seconds"), row.get("observation_seconds")
            require(
                all(
                    type(v) in (int, float) and math.isfinite(v) and v >= 0
                    for v in (seconds, whole)
                )
                and row_at <= began <= ended <= row_at + whole + 1
                and abs((ended - began) - seconds) <= 1,
                "PID1 observation interval inconsistent",
            )
            elapsed = began - start
            if not 0 <= elapsed < 7200:
                continue
            require(probe.get("available") is True, "PID1 runtime probe unavailable during load")
            data = probe["data"]
            if isinstance(data, str):
                data = json.loads(data)
            expected = {
                key: None
                for key in (
                    "GLIBC_TUNABLES",
                    "LD_PRELOAD",
                    "PYTHONMALLOC",
                    "PYTHONTRACEMALLOC",
                    "OMP_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                )
            }
            expected.update(MALLOC_ARENA_MAX="1", SEARCHPILOT_DISABLE_THP="true")
            require(
                data.get("pid") == 1 and data.get("environment") == expected,
                "Actual PID1 is not arena1/THP-off with unchanged native defaults",
            )
            require(
                type(data.get("start_time_ticks")) is int and data["start_time_ticks"] >= 0,
                "PID1 probe identity missing",
            )
            require(not probes or elapsed > probes[-1][0], "PID1 probe times not strictly ordered")
            probes.append((elapsed, data["start_time_ticks"]))
    require(len(probes) >= 718, "PID1 formal coverage has fewer than 718 observations")
    gaps = [b[0] - a[0] for a, b in zip(probes, probes[1:], strict=False)]
    require(
        probes[0][0] <= 10 and probes[-1][0] >= 7190 and max(gaps) <= 15,
        "PID1 formal coverage has missing boundary or gap over 15 seconds",
    )
    require(len({value for _, value in probes}) == 1, "PID1 identity changed during formal window")
    with (folder / "samples.jsonl").open(encoding="utf-8") as stream:
        identities = {
            row["server"]["sources"]["stat"]["data"]["start_time_ticks"]
            for row in (json.loads(line) for line in stream)
            if row["phase"] == "load"
        }
    require(
        identities == {probes[0][1]}, "PID1 probes and memory samples identify different processes"
    )
    return {
        "count": len(probes),
        "first_elapsed_seconds": probes[0][0],
        "last_elapsed_seconds": probes[-1][0],
        "max_gap_seconds": max(gaps),
        "start_time_ticks": probes[0][1],
        "all_observed_pid1_environments_arena1": True,
        "window_seconds": [0, 7200],
        "minimum_count": 718,
        "boundary_tolerance_seconds": 10,
        "maximum_gap_seconds": 15,
        "time_anchor": "PID1 docker exec host started_at; strict half-open formal window",
        "scope": "Actual PID1 read occurs within recorded started_at..finished_at; "
        "host command dispatch is not an atomic container sampling timestamp",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    require(args.check, "Use --check for read-only bound candidate verification")
    print(json.dumps(verify_bound_candidate()))


if __name__ == "__main__":
    main()
