"""Build arena1 script/config layer over immutable cached image; no model/dependency rebuild."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from datetime import UTC, datetime

from candidate_gate import (
    IMAGE,
    IMAGE_REFERENCE,
    REPO,
    ROOT,
    digest,
    read,
    require,
    require_base_image,
    verify_bound_candidate,
)

sys.path.insert(0, str(REPO))
from scripts.validate_container_soak import clean_environment  # noqa: E402

DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
TAG = "searchpilot-validation:2026-10-26-arena1-normal"


def command(args):
    return subprocess.run(
        [DOCKER, *args],
        cwd=REPO,
        env=clean_environment(),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=180,
        check=True,
    ).stdout


def derived_dockerfile():
    return (
        f"FROM {IMAGE_REFERENCE}\nCOPY scripts /app/scripts\nENV MALLOC_ARENA_MAX=1\n"
        'CMD ["python", "scripts/docker_entrypoint.py"]\n'
    )


def main():
    verify_bound_candidate()
    require(
        not any((ROOT / n).exists() for n in ("image-context", "build.txt", "build-summary.json")),
        "Refuse build evidence overwrite",
    )
    require_base_image(
        json.loads(command(["image", "inspect", IMAGE]))[0],
        json.loads(command(["image", "inspect", IMAGE_REFERENCE]))[0],
    )
    context = ROOT / "image-context"
    (context / "scripts").mkdir(parents=True)
    for path in (REPO / "scripts").glob("*.py"):
        shutil.copyfile(path, context / "scripts" / path.name)
    dockerfile = derived_dockerfile()
    (context / "Dockerfile").write_text(dockerfile, encoding="utf-8")
    result = subprocess.run(
        [DOCKER, "build", "--pull=false", "-t", TAG, str(context)],
        cwd=REPO,
        env=clean_environment(),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=180,
    )
    with (ROOT / "build.txt").open("x", encoding="utf-8") as sink:
        sink.write(result.stdout + result.stderr)
    result.check_returncode()
    image = json.loads(command(["image", "inspect", TAG]))[0]
    env = dict(value.split("=", 1) for value in image["Config"]["Env"] if "=" in value)
    require(
        env["MALLOC_ARENA_MAX"] == "1"
        and env["SEARCHPILOT_DISABLE_THP"] == "true"
        and image["Config"]["Cmd"] == ["python", "scripts/docker_entrypoint.py"]
        and image["Config"].get("Entrypoint") is None,
        "Built image is not declared normal arena1",
    )
    verify_bound_candidate()
    sources = read(ROOT / "sources-sha256.json")
    require(
        all(
            digest(context / name) == sha
            for name, sha in sources.items()
            if name.startswith("scripts/")
        ),
        "Built script snapshot changed",
    )
    record = {
        "at": datetime.now(UTC).isoformat(),
        "tag": TAG,
        "image": image["Id"],
        "base_image": IMAGE,
        "base_image_reference": IMAGE_REFERENCE,
        "dependency_or_model_rebuild": False,
        "query_sha256": digest(ROOT / "fixture/queries.csv"),
        "frozen_input_count": 29,
        "source_count": len(sources),
        "native_env": {k: env[k] for k in ("MALLOC_ARENA_MAX", "SEARCHPILOT_DISABLE_THP")},
        "cmd": image["Config"]["Cmd"],
        "entrypoint": image["Config"].get("Entrypoint"),
        "derived_dockerfile": dockerfile,
        "derived_dockerfile_sha256": digest(context / "Dockerfile"),
        "preflight_sha256": digest(ROOT / "preflight.json"),
        "screening_binding_sha256": digest(ROOT / "screening-binding.json"),
    }
    with (ROOT / "build-summary.json").open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    print(json.dumps(record))


if __name__ == "__main__":
    main()
