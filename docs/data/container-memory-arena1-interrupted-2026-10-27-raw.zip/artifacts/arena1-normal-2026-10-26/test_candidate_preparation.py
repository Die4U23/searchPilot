"""Small offline gates/provenance checks; no screening replay, Docker or HTTP."""

import ast
import copy
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import candidate_gate as gate  # noqa: E402
import preflight  # noqa: E402
import run_stability as runner  # noqa: E402


def eligible():
    return {
        "status": "PASSED",
        "candidate_eligible": True,
        "failures": [],
        "screening": {"passed": True},
        "full_semantics_equal": True,
        "common_successful_groups": 5200,
        "case_order": ["arena2-control-01", "arena1-treatment-01"],
        "cases": [{"status": "PASSED"}, {"status": "PASSED"}],
    }


def test_unqualified_candidate_fails_closed():
    gate.require_eligible(eligible())
    for key, value in (
        ("candidate_eligible", False),
        ("status", "REJECTED_SCREENING"),
        ("full_semantics_equal", False),
        ("common_successful_groups", 5199),
    ):
        bad = copy.deepcopy(eligible())
        bad[key] = value
        with pytest.raises(ValueError):
            gate.require_eligible(bad)


def test_preflight_gate_before_any_command_or_freeze(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["preflight.py", "--comparison", "missing.json"])
    monkeypatch.setattr(
        preflight,
        "screening_binding",
        lambda *a, **k: (_ for _ in ()).throw(ValueError("not eligible")),
    )
    monkeypatch.setattr(preflight, "command", lambda *a: pytest.fail("Docker/git must not execute"))
    with pytest.raises(ValueError, match="not eligible"):
        preflight.main()


def test_full_semantics_not_only_ranking():
    mapping = {
        (str(i), mode): ("a" * 64, "b" * 64, "model", 10)
        for i in range(1300)
        for mode in ("bm25", "vector", "hybrid", "ltr")
    }
    assert gate.compare_semantics(mapping, mapping)["groups"] == 5200
    changed = copy.deepcopy(mapping)
    changed[("0", "vector")] = ("c" * 64, "b" * 64, "model", 10)
    with pytest.raises(ValueError, match="differs"):
        gate.compare_semantics(changed, mapping)
    changed.pop(("0", "vector"))
    with pytest.raises(ValueError, match="incomplete"):
        gate.compare_semantics(changed, mapping)


@pytest.fixture
def pid1_rows(tmp_path):
    from datetime import UTC, datetime, timedelta

    anchor = datetime(2026, 10, 26, tzinfo=UTC)
    env = {
        key: None
        for key in (
            "GLIBC_TUNABLES",
            "LD_PRELOAD",
            "PYTHONMALLOC",
            "PYTHONTRACEMALLOC",
            "OMP_NUM_THREADS",
            "MKL_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
        )
    }
    env.update(MALLOC_ARENA_MAX="1", SEARCHPILOT_DISABLE_THP="true")

    def row(seconds):
        return {
            "at": (anchor + timedelta(seconds=seconds - 0.01)).isoformat(),
            "observation_seconds": 0.2,
            "pid1_runtime": {
                "available": True,
                "started_at": (anchor + timedelta(seconds=seconds)).isoformat(),
                "finished_at": (anchor + timedelta(seconds=seconds + 0.1)).isoformat(),
                "seconds": 0.1,
                "data": {"pid": 1, "start_time_ticks": 123, "environment": dict(env)},
            },
        }

    rows = [row(5 + 10 * i) for i in range(720)]
    bench = {"runs": [{"started_at": anchor.isoformat()}]}
    (tmp_path / "samples.jsonl").write_text(
        json.dumps(
            {"phase": "load", "server": {"sources": {"stat": {"data": {"start_time_ticks": 123}}}}}
        )
        + "\n",
        encoding="utf-8",
    )

    def verify(values):
        (tmp_path / "background.jsonl").write_text(
            "".join(json.dumps(x) + "\n" for x in values), encoding="utf-8"
        )
        return gate.verify_pid1_runtime(tmp_path, bench)

    return rows, row, verify


def test_pid1_complete_formal_window_and_strict_boundaries(pid1_rows):
    rows, row, verify = pid1_rows
    for count in (718, 720):
        actual = verify([row(5 + 7190 * i / (count - 1)) for i in range(count)])
        assert actual["count"] == count and actual["max_gap_seconds"] <= 15
    outside_before, outside_after = row(-5), row(7200)
    outside_before["pid1_runtime"]["available"] = False
    outside_after["pid1_runtime"]["available"] = False
    assert verify([outside_before, *rows, outside_after])["count"] == 720


@pytest.mark.parametrize(
    "case",
    [
        "only_two",
        "missing_middle",
        "missing_first",
        "missing_last",
        "unavailable",
        "wrong_arena",
        "changed_identity",
        "reordered",
        "missing_timestamp",
        "inconsistent_interval",
    ],
)
def test_pid1_gaps_and_wrong_evidence_fail_closed(pid1_rows, case):
    original, _, verify = pid1_rows
    rows = copy.deepcopy(original)
    if case == "only_two":
        rows = [rows[0], rows[-1]]
    elif case == "missing_middle":
        rows.pop(360)
    elif case == "missing_first":
        rows.pop(0)
    elif case == "missing_last":
        rows.pop()
    elif case == "unavailable":
        rows[360]["pid1_runtime"]["available"] = False
    elif case == "wrong_arena":
        rows[360]["pid1_runtime"]["data"]["environment"]["MALLOC_ARENA_MAX"] = "2"
    elif case == "changed_identity":
        rows[360]["pid1_runtime"]["data"]["start_time_ticks"] = 456
    elif case == "reordered":
        rows[360], rows[361] = rows[361], rows[360]
    elif case == "missing_timestamp":
        del rows[360]["pid1_runtime"]["started_at"]
    else:
        rows[360]["pid1_runtime"]["seconds"] = 9
    with pytest.raises((ValueError, KeyError)):
        verify(rows)


def test_launcher_must_be_finished_and_successful(tmp_path):
    import normal_raw_evidence as raw

    good = {"status": "COMPLETED", "exit_code": 0, "observer_stopped": True, "observer_errors": []}
    raw.require_launcher_complete(good)
    for key, value in (
        ("status", "FAILED"),
        ("status", "RUNNING"),
        ("exit_code", 1),
        ("exit_code", False),
        ("observer_stopped", False),
        ("observer_errors", ["error"]),
        ("observer_errors", None),
    ):
        bad = {**good, key: value}
        with pytest.raises(ValueError, match="launcher/observer"):
            raw.require_launcher_complete(bad)
    for key in good:
        bad = dict(good)
        del bad[key]
        with pytest.raises(ValueError):
            raw.require_launcher_complete(bad)
    folder = tmp_path / "final-two-hour"
    with pytest.raises(FileNotFoundError):
        raw.verify_normal_raw(folder)
    (tmp_path / "final-two-hour-launcher.json").write_text(
        json.dumps({**good, "status": "FAILED"}), encoding="utf-8"
    )
    with pytest.raises(ValueError, match="launcher/observer"):
        raw.verify_normal_raw(folder)


def test_runner_identity_constants_and_pid_probe_compile():
    assert runner.PROJECT == gate.PROJECT
    assert (runner.DURATION, runner.BASELINE, runner.RECOVERY) == (7200, 60, 600)
    tree = ast.parse((gate.ROOT / "run_stability.py").read_text(encoding="utf-8"))
    code = next(
        ast.literal_eval(node.value)
        for node in ast.walk(tree)
        if isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "pid1_code" for t in node.targets)
    )
    compile(code, "pid1_probe", "exec")
    assert "\x00" not in code and "/proc/1/environ" in code


@pytest.fixture
def replay_case(tmp_path, monkeypatch):
    from types import SimpleNamespace

    control = tmp_path / "control"
    control.mkdir()
    comparator_path = control / "compare_arena_controls.py"
    comparator_path.write_text("# toy comparator bytes; never executed\n", encoding="utf-8")
    replay = eligible()
    replay["root_input_sha256"] = {"compare_arena_controls.py": gate.digest(comparator_path)}
    for row, name in zip(replay["cases"], replay["case_order"], strict=True):
        folder = control / name
        folder.mkdir()
        (folder / "summary.json").write_text('{"status":"COMPLETED"}', encoding="utf-8")
        row.update(
            case=name,
            input_sha256={"summary.json": gate.digest(folder / "summary.json")},
            ledger={"repeat_histogram": {4: 5200}},
        )
    path = control / "comparison.json"
    path.write_text(json.dumps(replay, allow_nan=False), encoding="utf-8")
    monkeypatch.setattr(gate, "CONTROL", control)
    monkeypatch.setattr(gate, "REPO", tmp_path)
    tool = SimpleNamespace(
        compare=lambda root: copy.deepcopy(replay),
        tree_hashes=lambda folder: {"summary.json": gate.digest(folder / "summary.json")},
    )
    monkeypatch.setattr(gate, "comparator", lambda: tool)
    return path, replay


def test_full_screening_replay_accepts_json_roundtrip_integer_histogram(replay_case):
    path, replay = replay_case
    assert replay["cases"][0]["ledger"]["repeat_histogram"] == {4: 5200}
    assert gate.read(path)["cases"][0]["ledger"]["repeat_histogram"] == {"4": 5200}
    assert gate.screening_binding(path, replay=True)["candidate_eligible"] is True


@pytest.mark.parametrize("change", ["histogram", "extra_field", "nonfinite"])
def test_json_normalization_does_not_hide_any_field_changes(replay_case, change):
    path, replay = replay_case
    if change == "histogram":
        replay["cases"][0]["ledger"]["repeat_histogram"][4] = 5199
    elif change == "extra_field":
        replay["cases"][0]["unexpected_extra_evidence"] = "must not be removed"
    else:
        replay["cases"][0]["latency"] = float("nan")
    with pytest.raises(ValueError):
        gate.screening_binding(path, replay=True)


def test_immutable_repodigest_dockerfile_and_identity():
    import build_candidate as build

    reference = gate.IMAGE_REFERENCE
    image = {"Id": gate.IMAGE, "RepoDigests": [reference]}
    resolved = {"Id": gate.IMAGE}
    gate.require_base_image(image, resolved)
    assert build.derived_dockerfile() == (
        f"FROM {reference}\nCOPY scripts /app/scripts\n"
        'ENV MALLOC_ARENA_MAX=1\nCMD ["python", "scripts/docker_entrypoint.py"]\n'
    )
    assert not build.derived_dockerfile().startswith("FROM sha256:")
    for wrong_image, wrong_resolved, wrong_reference in (
        ({**image, "RepoDigests": []}, resolved, reference),
        (image, {"Id": "sha256:" + "0" * 64}, reference),
        ({**image, "Id": "sha256:" + "0" * 64}, resolved, reference),
        (image, resolved, "other@" + gate.IMAGE),
    ):
        with pytest.raises(ValueError, match="RepoDigest"):
            gate.require_base_image(wrong_image, wrong_resolved, wrong_reference)
