"""Offline resource acceptance for declared cases, separate from strict request accounting."""

import argparse
import hashlib
import json
import math
import statistics
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

from candidate_gate import verify_normal_semantics, verify_pid1_runtime
from normal_raw_evidence import evidence_hashes, verify_normal_raw

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
CHECKS = ("search", "recommend", "feedback", "vector_index", "ltr", "ctr", "database")
SOURCES = (
    "stat",
    "stat_after",
    "status",
    "smaps_rollup",
    "cmdline",
    "fd",
    "cgroup_membership",
    "cgroup_memory_current",
    "cgroup_memory_peak",
    "cgroup_memory_stat",
    "cgroup_memory_events",
)
CASES = {"final-two-hour": (32, 7200, 12, 60, 600)}
NATIVE_KEYS = {
    "MALLOC_ARENA_MAX",
    "SEARCHPILOT_DISABLE_THP",
    "GLIBC_TUNABLES",
    "LD_PRELOAD",
    "PYTHONMALLOC",
    "PYTHONTRACEMALLOC",
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(row, name):
    envelope = row.get("server", {}).get("sources", {}).get(name, {})
    return envelope.get("data", {}) if envelope.get("available") is True else {}


def valid_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def memory_errors(row):
    server = row.get("server", {})
    before, after = source(row, "stat"), source(row, "stat_after")
    errors = []
    if server.get("available") is not True or server.get("identity_consistent") is not True:
        errors.append("server_unavailable_or_identity_unknown")
    if type(server.get("pid")) is not int or server["pid"] != 1:
        errors.append("not_pid_one")
    for name, stat in (("stat", before), ("stat_after", after)):
        if type(stat.get("pid")) is not int or stat["pid"] != 1:
            errors.append(name + "_not_pid_one")
        if type(stat.get("start_time_ticks")) is not int or stat["start_time_ticks"] < 0:
            errors.append(name + "_invalid_start")
    if before.get("start_time_ticks") != after.get("start_time_ticks"):
        errors.append("identity_changed_within_sample")
    if not valid_number(source(row, "smaps_rollup").get("Rss_bytes")):
        errors.append("invalid_rss")
    return errors


def window(rows):
    errors = [
        {"at": row["at"], "reasons": memory_errors(row)} for row in rows if memory_errors(row)
    ]
    base = {"count": len(rows), "invalid_samples": errors}
    if len(rows) < 2 or errors:
        return {**base, "available": False}
    xs = [row["elapsed_seconds"] for row in rows]
    ys = [source(row, "smaps_rollup")["Rss_bytes"] / 1048576 for row in rows]
    mean_x, mean_y = statistics.mean(xs), statistics.mean(ys)
    denominator = sum((x - mean_x) ** 2 for x in xs)
    if not denominator or any(b <= a for a, b in zip(xs, xs[1:], strict=False)):
        return {**base, "available": False, "reason": "time_not_strictly_increasing"}
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys, strict=True)) / denominator * 60
    starts = {source(row, "stat")["start_time_ticks"] for row in rows}
    return {
        **base,
        "available": True,
        "first_seconds": xs[0],
        "last_seconds": xs[-1],
        "span_seconds": xs[-1] - xs[0],
        "max_gap_seconds": max(b - a for a, b in zip(xs, xs[1:], strict=False)),
        "single_pid_start": len(starts) == 1,
        "first_rss_mib": ys[0],
        "last_rss_mib": ys[-1],
        "growth_mib": ys[-1] - ys[0],
        "min_rss_mib": min(ys),
        "max_rss_mib": max(ys),
        "median_rss_mib": statistics.median(ys),
        "ols_mib_per_minute": slope,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", choices=CASES)
    args = parser.parse_args()
    folder = ROOT / args.case
    output = folder / "acceptance.json"
    if output.exists():
        raise FileExistsError("Refuse acceptance overwrite")
    ledger, input_sha256 = verify_normal_raw(folder)
    harness, bench = [read(folder / name) for name in ("summary.json", "soak.json")]
    build = read(ROOT / "build-summary.json")
    if harness["status"] != "COMPLETED" or bench["status"] != "COMPLETED":
        raise ValueError("Complete cases required; preserve failure evidence separately")
    run = bench["runs"][0]
    start = datetime.fromisoformat(run["started_at"])
    concurrency, duration, repeats, baseline, recovery = CASES[args.case]
    samples = [
        json.loads(line)
        for line in (folder / "samples.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    for row in samples:
        row["elapsed_seconds"] = (datetime.fromisoformat(row["at"]) - start).total_seconds()
    load = [row for row in samples if row["phase"] == "load"]
    checks, details = {"launcher_complete": True}, {}
    details["screening_semantics"] = verify_normal_semantics(folder)
    checks["screening_semantics"] = True
    details["pid1_runtime"] = verify_pid1_runtime(folder, bench)
    checks["actual_pid1_arena1"] = True
    checks["planned_case"] = (
        len(bench["runs"]) == 1
        and all(
            c.get("duration_seconds") == duration and c.get("concurrency") == concurrency
            for c in (bench["config"], harness["config"])
        )
        and harness["config"].get("baseline_seconds") == baseline
        and harness["config"].get("recovery_seconds") == recovery
        and bench["config"].get("limit") == 10
        and bench["config"].get("timeout") == 10
        and bench["config"].get("warmup") == 4
        and bench["requested_modes"] == ["bm25", "vector", "hybrid", "ltr"]
        and run.get("dispatch_window_seconds") == duration
        and ledger.get("duration_seconds") == duration
        and ledger["coverage"].get("min_repeats") == repeats
        and ledger["inflight"].get("configured_concurrency") == concurrency
    )
    checks["query_metadata"] = (
        all(
            meta.get("sha256") == build["query_sha256"] and meta.get("count") == 1300
            for meta in (bench["queries"], harness["queries"])
        )
        and ledger["coverage"].get("sha256") == build["query_sha256"]
        and ledger["coverage"].get("query_count") == 1300
    )
    checks["ledger"] = ledger["status"] == "PASSED"
    checks["current_raw_ledger_replayed"] = True
    checks["query_coverage"] = (
        ledger["coverage"]["verified"] is True
        and ledger["coverage"]["expected_group_count"] == 5200
        and len(ledger["coverage"]["groups"]) == 5200
        and all(
            type(g.get("successful")) is int and g["successful"] >= repeats
            for g in ledger["coverage"]["groups"]
        )
    )
    checks["actual_client_concurrency"] = ledger["inflight"]["peak"] == concurrency
    checks["no_pending"] = ledger["inflight"]["pending_events_at_end"] == 0
    checks["warmup"] = (
        ledger["phases"]["warmup"]["success"] == 16 and ledger["phases"]["warmup"]["issued"] == 16
    )
    whole = window(load)
    checks["identity_and_rss"] = (
        whole.get("available") is True and whole.get("single_pid_start") is True
    )
    checks["health_coverage"] = (
        checks["identity_and_rss"]
        and whole["max_gap_seconds"] <= 15
        and whole["first_seconds"] <= 10
        and whole["last_seconds"] >= duration - 10
    )
    unavailable = [
        {"at": row["at"], "source": name}
        for row in load
        for name in SOURCES
        if row.get("server", {}).get("sources", {}).get(name, {}).get("available") is not True
    ]
    checks["sources_available"] = bool(load) and not unavailable
    details["unavailable_sources"] = unavailable
    details["health"] = {}
    for kind in ("live", "ready"):
        bad = []
        for row in load:
            probe = row.get(kind, {})
            good = probe.get("available") is True and probe.get("status") == 200
            if kind == "ready":
                good = good and all(
                    probe.get("body", {}).get("checks", {}).get(k) is True for k in CHECKS
                )
            if not good:
                bad.append(row["at"])
        details["health"][kind] = {
            "total": len(load),
            "success": len(load) - len(bad),
            "bad_at": bad,
        }
        checks[kind + "_all_success"] = bool(load) and not bad
    zero_fields = (
        ("smaps_rollup", "AnonHugePages_bytes"),
        ("smaps_rollup", "Swap_bytes"),
        ("smaps_rollup", "SwapPss_bytes"),
        ("status", "VmSwap_bytes"),
        ("status", "THP_enabled"),
        ("cgroup_memory_events", "oom"),
        ("cgroup_memory_events", "oom_kill"),
        ("cgroup_memory_events", "oom_group_kill"),
    )
    details["zero_fields"] = {}
    for name, key in zero_fields:
        values = [source(row, name).get(key) for row in load]
        details["zero_fields"][key] = dict(Counter(str(value) for value in values))
        checks[key + "_zero_complete"] = bool(values) and all(
            type(v) is int and v == 0 for v in values
        )
    api_states = {
        name: next(row for row in harness[name] if row["Name"].endswith("-api-1"))
        for name in ("initial_state", "post_soak_state", "stopped_state", "final_state")
    }
    checks["no_unplanned_restart_or_oom"] = all(
        row["RestartCount"] == 0 and row["State"]["OOMKilled"] is False
        for row in api_states.values()
    )
    checks["same_container"] = len({row["Id"] for row in api_states.values()}) == 1
    checks["same_load_start"] = (
        api_states["initial_state"]["State"]["StartedAt"]
        == api_states["post_soak_state"]["State"]["StartedAt"]
    )
    checks["planned_restart_observed"] = (
        api_states["final_state"]["State"]["StartedAt"]
        != api_states["post_soak_state"]["State"]["StartedAt"]
    )
    checks["clean_stop"] = api_states["stopped_state"]["State"]["ExitCode"] == 0
    runtime_ok = []
    for row in api_states.values():
        env = row.get("native_env", {})
        runtime_ok.append(
            row["Image"] == build["image"]
            and row.get("command") == ["python", "scripts/docker_entrypoint.py"]
            and "entrypoint" in row
            and row["entrypoint"] is None
            and env.keys() >= NATIVE_KEYS
            and env.get("MALLOC_ARENA_MAX") == "1"
            and env.get("SEARCHPILOT_DISABLE_THP") == "true"
            and all(
                env.get(key) is None
                for key in ("GLIBC_TUNABLES", "LD_PRELOAD", "PYTHONMALLOC", "PYTHONTRACEMALLOC")
            )
        )
    checks["runtime_config"] = all(runtime_ok)
    requests = harness["requests"]
    checks["business"] = len(requests) == 17 and all(
        row["status"] == "completed" and row["http_status"] == row["expected_status"]
        for row in requests
    )
    by_label = {row["label"]: row for row in requests}
    feedback = [
        by_label[label]["response"].get("event_id")
        for label in ("feedback_create", "feedback_replay", "feedback_after_restart")
    ]
    checks["feedback_same_id"] = bool(feedback[0]) and len(set(feedback)) == 1
    checks["feedback_persisted_once"] = (
        harness["initial_counts"]["feedback_events"] == 0
        and harness["final_counts"]["feedback_events"] == 1
    )
    checks["restart_ready"] = all(harness["restart_ready"]["checks"].get(k) is True for k in CHECKS)
    inputs = read(ROOT / "inputs-sha256.json")
    details["input_mismatch"] = [
        name for name, value in inputs.items() if digest(REPO / name) != value
    ]
    details["source_mismatch"] = [
        name
        for name, value in read(ROOT / "sources-sha256.json").items()
        if digest(REPO / name) != value
    ]
    checks["frozen_inputs_sources"] = (
        not details["input_mismatch"] and not details["source_mismatch"]
    )
    frozen_sources = read(ROOT / "sources-sha256.json")
    expected_container = {
        name: sha
        for name, sha in frozen_sources.items()
        if name.startswith("src/")
        or name
        in {
            "scripts/docker_entrypoint.py",
            "scripts/docker_seed.py",
            "scripts/seed_items.py",
            "scripts/seed_catalog.py",
        }
    }
    checks["container_and_installed_sources"] = harness[
        "container_source_sha256"
    ] == expected_container and harness["imported_source"]["sha256"] == {
        name: sha for name, sha in expected_container.items() if name.startswith("src/searchpilot/")
    }
    checks["query_bytes"] = all(
        digest(folder / name) == build["query_sha256"]
        for name in ("queries.csv", "soak.queries.csv")
    )
    strict = [row for row in load if 0 <= row["elapsed_seconds"] < duration]
    tail20 = (
        window([row for row in load if duration - 1200 <= row["elapsed_seconds"] < duration])
        if duration >= 1200
        else {"available": False, "reason": "dispatch_shorter_than_twenty_minutes"}
    )
    stability_path = folder / "stability.json"
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "scripts.audit_memory_stability",
            "--bench",
            str(folder / "soak.json"),
            "--samples",
            str(folder / "samples.jsonl"),
            "--duration-seconds",
            "7200",
            "--stable-after-seconds",
            "3600",
            "--out",
            str(stability_path),
        ],
        cwd=REPO,
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=120,
    )
    memory_gate = (
        read(stability_path)
        if stability_path.exists()
        else {
            "status": "FAILED",
            "reason": "stability auditor did not create output",
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
    checks["two_hour_memory_stability"] = (
        result.returncode == 0 and memory_gate.get("status") == "PASSED"
    )
    groups = [
        {
            key: row[key]
            for key in ("query", "mode", "result_sha256", "ranking_sha256", "model_versions")
        }
        for row in ledger["fingerprints"]["groups"]
    ]
    if evidence_hashes(folder) != input_sha256:
        raise ValueError("Evidence changed during acceptance audit")
    record = {
        "schema_version": 2,
        "input_sha256": input_sha256,
        "case": args.case,
        "status": "PASSED" if all(checks.values()) else "FAILED",
        "checks": checks,
        "details": details,
        "benchmark_summary": run["summary"],
        "concurrency": bench["config"]["concurrency"],
        "duration_seconds": duration,
        "memory_gate": memory_gate,
        "memory": {
            "phase_load": whole,
            "strict_dispatch": window(strict),
            "last_ten": window(
                [row for row in load if duration - 600 <= row["elapsed_seconds"] < duration]
            ),
            "last_twenty": tail20,
            "recovery": window([row for row in samples if row["phase"] == "recovery"]),
        },
        "windows": [
            {
                "start_seconds": left,
                **window([row for row in strict if left <= row["elapsed_seconds"] < left + 300]),
            }
            for left in range(0, int(duration), 300)
        ],
        "fingerprint_groups": len(groups),
        "semantic_sha256": hashlib.sha256(json.dumps(groups, sort_keys=True).encode()).hexdigest(),
        "group_repeat_histogram": dict(
            Counter(str(g["successful"]) for g in ledger["coverage"]["groups"])
        ),
        "inside_load_samples": len(strict),
        "outside_load_samples": len(load) - len(strict),
        "sample_phase_counts": dict(Counter(row["phase"] for row in samples)),
        "limitations": [
            "Fixed query fixture and closed-loop client concurrency; "
            "not server execution concurrency or capacity SLA.",
            "Ten-second sampled memory and finite duration do not prove absence of leaks.",
        ],
    }
    with output.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    print(
        json.dumps(
            {
                "case": args.case,
                "status": record["status"],
                "failed_checks": [k for k, v in checks.items() if not v],
                "requests": run["summary"]["total"],
                "memory_gate": memory_gate,
            }
        )
    )
    return 0 if record["status"] == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
