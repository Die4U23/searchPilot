"""Offline normal-delivery boundaries; no service calls or real destination ZIP writes."""

import copy
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cleanup_normal_owned as cleanup  # noqa: E402
import package_normal_evidence as package  # noqa: E402


def test_pinned_replay_fails_on_actual_raw_check_without_side_effects(monkeypatch, tmp_path):
    assert package.digest(package.ROOT / "audit_case.py") == package.AUDITOR_SHA256

    def reject(folder):
        assert folder == tmp_path
        raise ValueError("raw rejection reaches exact original first check")

    monkeypatch.setattr(package.original, "verify_normal_raw", reject)
    with pytest.raises(ValueError, match="raw rejection"):
        package.replay_acceptance(tmp_path, {"status": "PASSED"})
    assert list(tmp_path.iterdir()) == []


def test_failed_memory_never_reaches_acceptance_or_publication(monkeypatch):
    monkeypatch.setattr(package.gate, "verify_bound_candidate", lambda: None)
    monkeypatch.setattr(package.raw, "verify_normal_raw", lambda *a: None)
    monkeypatch.setattr(package, "read", lambda path: {"status": "FAILED"})
    monkeypatch.setattr(package.raw, "read_jsonl", lambda path: [])
    monkeypatch.setattr(package, "digest", lambda path: "a" * 64)
    failure = {"status": "FAILED", "inputs": {"bench_sha256": "a" * 64, "samples_sha256": "a" * 64}}
    monkeypatch.setattr(package, "audit_memory", lambda *a, **k: copy.deepcopy(failure))
    monkeypatch.setattr(package, "read", lambda path: copy.deepcopy(failure))
    monkeypatch.setattr(
        package, "replay_acceptance", lambda *a: pytest.fail("must stop at memory failure")
    )
    with pytest.raises(ValueError, match="memory replay failed"):
        package.validate_evidence()


def test_stale_pass_rejected_after_full_replay(monkeypatch):
    monkeypatch.setattr(package.gate, "verify_bound_candidate", lambda: None)
    monkeypatch.setattr(package.raw, "verify_normal_raw", lambda *a: None)
    monkeypatch.setattr(package.raw, "read_jsonl", lambda path: [])
    monkeypatch.setattr(package, "digest", lambda path: "a" * 64)
    memory = {"status": "PASSED", "inputs": {"bench_sha256": "a" * 64, "samples_sha256": "a" * 64}}
    old = {"status": "PASSED", "checks": {"live_all_success": True}}
    current = {"status": "FAILED", "checks": {"live_all_success": False}}
    monkeypatch.setattr(
        package,
        "read",
        lambda path: copy.deepcopy(memory if path.name == "stability.json" else old),
    )
    monkeypatch.setattr(package, "audit_memory", lambda *a, **k: copy.deepcopy(memory))
    monkeypatch.setattr(package, "replay_acceptance", lambda *a: copy.deepcopy(current))
    with pytest.raises(ValueError, match="full acceptance failed"):
        package.validate_evidence()


@pytest.fixture
def payload(tmp_path):
    source = tmp_path / "raw.jsonl"
    source.write_bytes(b'{"outcome":"success"}\n')
    paths = {"final-two-hour/raw.jsonl": source}
    manifest = {
        name: {"bytes": path.stat().st_size, "sha256": package.digest(path)}
        for name, path in paths.items()
    }
    scope = b'{"scope":"toy only"}'
    manifest["EVIDENCE-SCOPE.json"] = {
        "bytes": len(scope),
        "sha256": hashlib.sha256(scope).hexdigest(),
    }
    archive = tmp_path / "toy.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as stream:
        stream.write(source, "final-two-hour/raw.jsonl")
        stream.writestr("SHA256SUMS.json", json.dumps(manifest))
        stream.writestr("EVIDENCE-SCOPE.json", scope)
    return archive, paths, manifest, scope


def test_crc_member_and_current_source_roundtrip(payload):
    package.verify_payload(*payload)
    next(iter(payload[1].values())).write_bytes(b"changed")
    with pytest.raises(ValueError, match="current source mismatch"):
        package.verify_payload(*payload)


def test_wrong_member_hash_rejected(payload):
    archive, paths, manifest, scope = payload
    manifest = copy.deepcopy(manifest)
    next(iter(manifest.values()))["sha256"] = "0" * 64
    with pytest.raises(ValueError, match="Manifest readback"):
        package.verify_payload(archive, paths, manifest, scope)


def resources():
    ids = {cleanup.PROJECT + "-api-1": "a" * 64, cleanup.PROJECT + "-db-1": "b" * 64}
    network = {
        "Name": cleanup.NETWORK,
        "Id": "c" * 64,
        "Labels": {
            "com.docker.compose.project": cleanup.PROJECT,
            "com.docker.compose.network": "default",
        },
        "Containers": {value: {} for value in ids.values()},
    }
    volume = {
        "Name": cleanup.VOLUME,
        "Labels": {
            "com.docker.compose.project": cleanup.PROJECT,
            "com.docker.compose.volume": "pgdata",
        },
    }
    containers = []
    for name, identity in ids.items():
        role = "api" if "-api-" in name else "db"
        containers.append(
            {
                "Name": "/" + name,
                "Id": identity,
                "Image": "image",
                "Config": {
                    "Labels": {
                        "com.docker.compose.project": cleanup.PROJECT,
                        "com.docker.compose.service": role,
                        "com.docker.compose.container-number": "1",
                    }
                },
                "NetworkSettings": {"Networks": {cleanup.NETWORK: {"NetworkID": network["Id"]}}},
                "Mounts": [{"Type": "volume", "Name": cleanup.VOLUME}] if role == "db" else [],
            }
        )
    return containers, volume, network, ids, {"Name": cleanup.VOLUME}


def test_cleanup_exact_ids_labels_network_and_volume(monkeypatch):
    monkeypatch.setattr(package, "read", lambda path: {"image": "image"})
    valid = resources()
    cleanup.validate_resources(*valid)
    mutations = [
        lambda x: x[0][0].update(Id="d" * 64),
        lambda x: x[0][0]["Config"]["Labels"].update({"com.docker.compose.project": "other"}),
        lambda x: x[1].update(Name="searchpilot_pgdata"),
        lambda x: x[2]["Containers"].update({"unknown": {}}),
        lambda x: x[0][1]["Mounts"].append({"Type": "volume", "Name": "other"}),
    ]
    for mutate in mutations:
        bad = copy.deepcopy(valid)
        mutate(bad)
        with pytest.raises(ValueError):
            cleanup.validate_resources(*bad)


def test_cleanup_requires_archive_before_even_docker_reads(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["cleanup_normal_owned.py"])
    monkeypatch.setattr(
        package, "verify_archive", lambda: (_ for _ in ()).throw(ValueError("not sealed"))
    )
    monkeypatch.setattr(
        cleanup.subprocess, "run", lambda *a, **k: pytest.fail("no Docker call permitted")
    )
    with pytest.raises(ValueError, match="not sealed"):
        cleanup.main()


def test_render_copy_is_byte_identical():
    assert (package.ROOT / "render_stability.py").read_bytes() == (
        package.OLD / "render_stability.py"
    ).read_bytes()
    assert (
        hashlib.sha256((package.ROOT / "audit_case.py").read_bytes()).hexdigest()
        == package.AUDITOR_SHA256
    )


@pytest.mark.parametrize("drift", [False, True])
def test_final_gate_replay_source_drift_cannot_be_marked_verified(tmp_path, monkeypatch, drift):
    root = tmp_path / "evidence"
    root.mkdir()
    source = root / "api.log"
    source.write_bytes(b"old log\n")
    destination = tmp_path / "candidate-toy.zip"
    staging = destination.with_suffix(".zip.partial")
    record_path = root / "verification.json"
    manifest_path = root / "manifest.json"
    for name, value in (
        ("ROOT", root),
        ("REPO", tmp_path),
        ("DESTINATION", destination),
        ("STAGING", staging),
        ("RECORD", record_path),
        ("MANIFEST", manifest_path),
    ):
        monkeypatch.setattr(package, name, value)
    paths = {"final-two-hour/api.log": source}
    monkeypatch.setattr(package, "collect", lambda: (dict(paths), []))
    calls = []

    def validate():
        calls.append(True)
        if drift and len(calls) == 2:
            source.write_bytes(
                b"NEW log\n"
            )  # Same size: metadata/path checks alone cannot catch it.
        return {"status": "PASSED", "scope": "toy only"}

    monkeypatch.setattr(package, "validate_evidence", validate)
    monkeypatch.setattr(sys, "argv", ["package_normal_evidence.py"])
    if drift:
        with pytest.raises(ValueError, match="current source mismatch"):
            package.main()
        record = json.loads(record_path.read_text(encoding="utf-8"))
        assert record["status"] == "FAILED" and record.get("current_bytes_match") is not True
        assert staging.exists() and not destination.exists() and not manifest_path.exists()
    else:
        assert package.main() == 0
        assert package.verify_archive()["status"] == "VERIFIED"
        assert destination.exists() and not staging.exists()
    assert len(calls) >= 2
