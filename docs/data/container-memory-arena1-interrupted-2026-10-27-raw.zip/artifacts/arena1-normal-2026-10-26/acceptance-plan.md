# Arena1 候选正常入口两小时验证计划

状态：脚手架已准备，尚未冻结、构建或运行；筛选资格不是生产验收。

## 启动前门禁与证据隔离

- 仅当 arena-count 两组完整对照重审与保存 comparison 完全一致、candidate_eligible=true、
  两组各20800成功且全部5200组指纹一致时，才允许新 preflight/build/run。
- 原 arena2 正常运行失败证据先独立归档；此目录不复用旧 acceptance、analysis 或 raw ledger。
- 生产 Dockerfile、Compose、公开 .env.example 默认 arena1 由主线程确认资格后修改；
  本目录脚手架不代改。新冻结当前源码、29输入、公开配置和筛选根/逐case原始SHA。
- FROM 完整不可变 `searchpilot-validation@sha256:e858d8af87d05a191aae11682d8098f3285eed0b487985d2fb3edf06492a36f1`，
  preflight/build核对该ref属于原image的RepoDigests且inspect(ref).Id等于原IMAGE，
  显式 ENV MALLOC_ARENA_MAX=1，COPY 本次冻结scripts，正常CMD；
  不重建依赖或模型。继承src须与基镜像冻结源码一致，否则薄层构建拒绝。
- 实际容器 Config 和 PID1 白名单环境均需验证arena1/THP-off，OMP/MKL/OpenBLAS保持未设置；
  外部每约10秒只读PID1探针与原背景观察一起记录，PID1 start ticks须与memory samples一致。
  按每个docker exec宿主started_at对齐正式[0,7200)窗口，首末边界≤10秒、最大gap≤15秒、
  至少718条；全部正式探针可用且身份/环境一致。实际容器读取位于started_at..finished_at内，
  不将派发时刻称为原子采样。缺记录、重排或间隔不一致不能通过。
- 审计必须等待launcher记录COMPLETED、exit_code=0、observer_stopped=true且observer_errors=[]；
  harness/bench完成不能代替外层观察器成功，launcher完整字节纳入SHA绑定。
- 最终原始结果账本全部5200组的result/ranking/model/count必须与arena1筛选组逐组一致。
  完成与通过分离；任何原门槛失败均保留，不改阈值、不挑窗口。

## 最终正常入口持续验证

- 完整7200秒正式窗口，c32，同一1300条fixture字节（SHA256
  7356dc96df3a6d0d8bfc5c00d74ec284d7df22efec5bddba127b462e75be3ef6），
  四模式轮转、16预热、limit10、timeout10、闭环无重试，基线60秒、恢复600秒。
- 全新项目sp-memory-arena1-normal-20261026/API18235/PG15635/独立新卷。
  最终image ID及执行源码在运行前冻结；正常docker_entrypoint、THP-off、arena1，
  无诊断wrapper/tracing/主动GC/trim。不在最终运行期间变更生产/测量源码。
- strict ledger全部配对成功；5200组均至少成功12次、指纹稳定；peak client inflight32。
  实际服务端执行并发不据此推定。所有load live/ready成功且7组件为真；全11来源可用，
  同PID1身份、THP/swap/OOM为0、无意外restart；17业务及计划restart同反馈持久性通过。
- 总formal时长/每窗实际覆盖/末端排空分开；所需采样每10秒，边界误差不超过10秒、
  最大gap15秒、每窗最少floor(window/10)-2点。缺失不填0，身份变化/时间无效不能通过。
- 全7200秒、每5分钟、每固定20分钟、两个小时、末10/20分钟、恢复期完整报告。
  RSS/Anonymous/PSS/VmData/cgroup/客户端资源分开，缺失明确；外层/实际采样时间差保留。

### 预声明稳定性门槛

只取phase=load且严格[0,7200)数据；前3600秒按计划视作观察到平台之前的阶段，
仍完整报告，不以最终结果选择开始时刻。RSS及Anonymous分别需要全部满足：

1. 整个[3600,7200)端点增长<=2MiB，按实际时间OLS<=0.03MiB/分钟。
2. [3600,4200)与[6600,7200)中位数差<=2MiB。
3. 稳定期12个固定五分钟窗口的中位数最大-最小<=2MiB。
4. 稳定期起点3600,3900,...,6000的全部滑动20分钟窗口：端点增长<=2MiB，
   OLS<=0.1MiB/分钟，每窗采样完整。不仅检查最后一个窗口。

PSS可能受其他共享映射者退出影响，仅描述不冒充独占内存；VmData/cgroup不套同一门槛。
以上只是固定负载、有限两小时内的工程平台判据，不证明零泄漏或任意部署稳定。
任何门槛失败不得改阈值或挑窗：保留失败、定位；有服务修复则完整重跑受影响对照和
7200秒最终验证，并明确基线/修复版的实验是否匹配。


## 身份、观测与限制

新project只使用18235/15635及独立卷；原searchpilot_pgdata和其他项目保留。
外部LLM调用0，不读私有.env，不下载模型。只记录公开环境白名单。
保留原Docker stats、loadavg、Windows总CPU/可用内存观察；PID1探针为额外只读观察，
其成本属于本候选运行背景。有限固定负载筛查不等于零泄漏、容量SLA或独立因果证明。
所有输出独占创建；原arena2失败、健康超时、既往候选拒绝均不改写。
