"""Seal only independently replayed successful arena1 normal evidence. --check writes nothing."""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import os
import re
import zipfile
import zlib
from pathlib import Path

import audit_case as original
import candidate_gate as gate
import normal_raw_evidence as raw
from scripts.audit_memory_stability import audit as audit_memory

ROOT, REPO, OLD, CONTROL = gate.ROOT, gate.REPO, gate.OLD, gate.CONTROL
DESTINATION = REPO / "docs/data/container-memory-arena1-stability-2026-10-26-raw.zip"
STAGING = DESTINATION.with_suffix(".zip.partial")
RECORD = ROOT / "normal-archive-verification.json"
MANIFEST = ROOT / "normal-archive-sha256.json"
LIMIT = 90 * 1024 * 1024
CHUNK = 1024 * 1024
AUDITOR_SHA256 = "c6741127e30e2f2527c295af2039671d11c1b5ddf001996434d134dfd22576e1"
require, read, digest = raw.require, raw.read, raw.digest
spec = importlib.util.spec_from_file_location("baseline_archive_paths", OLD / "package_evidence.py")
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
REQUIRED = {
    "preflight.json",
    "build-summary.json",
    "build.txt",
    "screening-binding.json",
    "screening-comparison.json",
    "inputs-sha256.json",
    "sources-sha256.json",
    "acceptance-plan.md",
    "preflight.py",
    "build_candidate.py",
    "run_stability.py",
    "audit_case.py",
    "normal_raw_evidence.py",
    "candidate_gate.py",
    "package_normal_evidence.py",
    "cleanup_normal_owned.py",
    "render_stability.py",
    "unit-final.txt",
    "local-checks.json",
    "fixture/queries.csv",
    "fixture/manifest.json",
    "image-context/Dockerfile",
    "source-config/Dockerfile",
    "source-config/docker-compose.yml",
    "source-config/public-env.txt",
    "source-config/pyproject.toml",
    "final-two-hour-launcher.json",
    "final-two-hour-console.txt",
}
REQUIRED |= {
    "final-two-hour/" + name
    for name in (
        *raw.CASE_FILES,
        "acceptance.json",
        "stability.json",
        "compose.override.yml",
        "soak-console.txt",
        gate.PROJECT + "-api-1.log",
        gate.PROJECT + "-db-1.log",
    )
}
LINEAGE = {
    "lineage/baseline-archive-verification.json": OLD / "baseline-archive-verification.json",
    "lineage/baseline-archive-sha256.json": OLD / "baseline-archive-sha256.json",
    "lineage/baseline-reconciliation.json": OLD
    / "final-two-hour/failed-stability-reconciliation.json",
    "lineage/arena-control-archive-verification.json": CONTROL / "archive-verification.json",
    "lineage/arena-control-archive-sha256.json": CONTROL / "archive-sha256.json",
}


def replay_acceptance(folder, memory):
    """Reuse exactly the pinned CLI's check AST, removing only CLI/subprocess/output I/O."""
    require(
        digest(ROOT / "audit_case.py") == AUDITOR_SHA256,
        "Auditor changed; replay adapter needs review",
    )
    tree = ast.parse((ROOT / "audit_case.py").read_text(encoding="utf-8"))
    main = next(
        node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main"
    )

    def assigned(node, name):
        return isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name)
            and target.id == name
            or isinstance(target, ast.Tuple)
            and any(isinstance(v, ast.Name) and v.id == name for v in target.elts)
            for target in node.targets
        )

    begin = next(i for i, n in enumerate(main.body) if assigned(n, "ledger"))
    end = next(i for i, n in enumerate(main.body) if assigned(n, "record")) + 1
    body = copy.deepcopy(main.body[begin:end])
    left = next(i for i, n in enumerate(body) if assigned(n, "stability_path"))
    right = next(i for i, n in enumerate(body) if assigned(n, "groups"))
    require(right - left == 4, "Unexpected memory CLI structure")
    removed = ast.unparse(ast.Module(body=body[left:right], type_ignores=[]))
    require(
        removed.count("subprocess.run") == 1 and "two_hour_memory_stability" in removed,
        "Memory replay adapter no longer matches original",
    )
    body[left:right] = ast.parse(
        'checks["two_hour_memory_stability"] = memory_gate.get("status") == "PASSED"'
    ).body

    class CaseArgument(ast.NodeTransformer):
        def visit_Attribute(self, node):
            if isinstance(node.value, ast.Name) and node.value.id == "args" and node.attr == "case":
                return ast.copy_location(ast.Constant("final-two-hour"), node)
            return self.generic_visit(node)

    fn = ast.parse("def replay(folder,memory_gate):\n    pass\n").body[0]
    fn.body = [*body, ast.Return(ast.Name("record", ast.Load()))]
    module = ast.fix_missing_locations(CaseArgument().visit(ast.Module(body=[fn], type_ignores=[])))
    require("subprocess.run" not in ast.unparse(module), "Offline replay retained subprocess")
    namespace = dict(vars(original))
    exec(compile(module, "<pinned-acceptance-replay>", "exec"), namespace)
    return namespace["replay"](folder, memory)


def validate_lineage():
    preflight = read(ROOT / "preflight.json")
    baseline = read(LINEAGE["lineage/baseline-archive-verification.json"])
    baseline_manifest = read(LINEAGE["lineage/baseline-archive-sha256.json"])
    control = read(LINEAGE["lineage/arena-control-archive-verification.json"])
    require(
        baseline["status"] == control["status"] == "VERIFIED"
        and baseline["production_acceptance"] is False
        and control["production_acceptance"] is False
        and control["candidate_eligible"] is True
        and control["screening_status"] == "PASSED",
        "Prior failed-baseline/screening archives are not sealed",
    )
    require(
        preflight["rejected_baseline_archive"]
        == {k: baseline[k] for k in ("path", "bytes", "sha256")},
        "Baseline archive differs from preflight binding",
    )
    for record in (baseline, control):
        path = core.safe_path(REPO, record["path"])
        require(
            path.stat().st_size == record["bytes"] and digest(path) == record["sha256"],
            "Lineage archive bytes changed",
        )
    binding = read(ROOT / "screening-binding.json")
    require(
        control["comparison_sha256"] == binding["comparison_sha256"], "Screening archive differs"
    )
    rejected = read(LINEAGE["lineage/baseline-reconciliation.json"])
    require(
        rejected["status"] == "FAILED_STABILITY_RECONCILED"
        and rejected["production_acceptance"] is False
        and digest(LINEAGE["lineage/baseline-reconciliation.json"])
        == baseline_manifest["members"]["final-two-hour/failed-stability-reconciliation.json"][
            "sha256"
        ],
        "Failed baseline reconciliation changed or promoted",
    )
    return {
        "baseline": {k: baseline[k] for k in ("path", "sha256", "bytes")},
        "screening": {k: control[k] for k in ("path", "sha256", "bytes")},
    }


def validate_evidence():
    gate.verify_bound_candidate()
    folder = ROOT / "final-two-hour"
    raw.verify_normal_raw(folder, read(folder / "acceptance.json"))
    bench = read(folder / "soak.json")
    memory = audit_memory(
        bench,
        raw.read_jsonl(folder / "samples.jsonl"),
        duration_seconds=7200,
        stable_after_seconds=3600,
    )
    memory["inputs"] = {
        "bench_sha256": digest(folder / "soak.json"),
        "samples_sha256": digest(folder / "samples.jsonl"),
    }
    require(
        memory == read(folder / "stability.json") and memory["status"] == "PASSED",
        "Current memory replay failed or saved stability is stale",
    )
    acceptance = json.loads(json.dumps(replay_acceptance(folder, memory), allow_nan=False))
    require(
        acceptance == read(folder / "acceptance.json")
        and acceptance["status"] == "PASSED"
        and all(value is True for value in acceptance["checks"].values()),
        "Current full acceptance failed or saved acceptance is stale",
    )
    build = read(ROOT / "build-summary.json")
    require(
        build["base_image"] == gate.IMAGE
        and build["base_image_reference"] == gate.IMAGE_REFERENCE
        and build["native_env"] == {"MALLOC_ARENA_MAX": "1", "SEARCHPILOT_DISABLE_THP": "true"}
        and build["cmd"] == ["python", "scripts/docker_entrypoint.py"]
        and build["entrypoint"] is None
        and build["preflight_sha256"] == digest(ROOT / "preflight.json")
        and build["derived_dockerfile_sha256"] == digest(ROOT / "image-context/Dockerfile"),
        "Built normal image identity differs",
    )
    require(
        (ROOT / "image-context/Dockerfile").read_text(encoding="utf-8")
        == build["derived_dockerfile"],
        "Derived Dockerfile differs",
    )
    summary_path = ROOT / "final-two-hour-resource-summary.json"
    png_path = ROOT / "final-two-hour-memory.png"
    if summary_path.exists() or png_path.exists():
        require(
            summary_path.is_file() and png_path.is_file(), "Incomplete descriptive resource output"
        )
        descriptive = read(summary_path)
        require(
            descriptive["helper_sha256"] == digest(ROOT / "render_stability.py")
            and descriptive["stability_status"] == memory["status"]
            and all(
                digest(folder / name) == sha for name, sha in descriptive["input_sha256"].items()
            ),
            "Descriptive resource output is stale",
        )
    sources = read(ROOT / "sources-sha256.json")
    require(
        all(
            digest(ROOT / "image-context" / name) == sha
            for name, sha in sources.items()
            if name.startswith("scripts/")
        ),
        "Executed script snapshots differ",
    )
    return {
        "status": "PASSED",
        "scope": "Finite declared arena1 normal 7200-second acceptance",
        "checks": acceptance["checks"],
        "input_sha256": acceptance["input_sha256"],
        "image": build["image"],
        "lineage": validate_lineage(),
        "auditor_sha256": AUDITOR_SHA256,
    }


def collect():
    paths, excluded = {}, []
    for current, dirs, files in os.walk(ROOT, followlinks=False):
        for name in [*dirs, *files]:
            path = Path(current) / name
            member = path.relative_to(ROOT).as_posix()
            core.safe_path(ROOT, member)
            if name in dirs:
                core.permitted_name(member, archive=False)
                if name in {"__pycache__", ".pytest_cache", ".ruff_cache"}:
                    dirs.remove(name)
                    excluded.append(member + "/")
                continue
            if path in (RECORD, MANIFEST) or name.startswith("cleanup-normal-"):
                excluded.append(member)
                continue
            core.permitted_name(member, archive=False)
            if path.suffix.lower() in {".pyc", ".pyo", ".tmp"} or re.fullmatch(
                r"(?:progress|.*-progress)(?:[._-].*)?\.json", name, re.I
            ):
                excluded.append(member)
                continue
            core.permitted_name(member, archive=True)
            require(path.is_file(), "Not regular evidence: " + member)
            if path.suffix == ".diff":
                require("\x00" not in path.read_bytes().decode("utf-8"), "Binary diff")
            paths[member] = path
    require(
        paths.keys() >= REQUIRED,
        "Required normal evidence missing: " + str(sorted(REQUIRED - paths.keys())),
    )
    for name in read(ROOT / "sources-sha256.json"):
        member = "frozen-sources/" + name
        core.permitted_name(member, archive=True)
        require(member not in paths, "Duplicate source snapshot member")
        paths[member] = core.safe_path(REPO, name)
    for member, path in LINEAGE.items():
        require(member not in paths, "Duplicate lineage member")
        paths[member] = core.safe_path(REPO, path.relative_to(REPO).as_posix())
    require(len(paths) == len({name.casefold() for name in paths}), "Duplicate casefold paths")
    require(
        not {"SHA256SUMS.json", "EVIDENCE-SCOPE.json"} & paths.keys(), "Reserved archive members"
    )
    return dict(sorted(paths.items())), sorted(excluded)


def verify_payload(path, paths, manifest, scope):
    require(set(manifest) == set(paths) | {"EVIDENCE-SCOPE.json"}, "Manifest member set differs")
    require(
        manifest["EVIDENCE-SCOPE.json"]
        == {"bytes": len(scope), "sha256": hashlib.sha256(scope).hexdigest()},
        "Generated scope hash differs",
    )
    require(path.stat().st_size <= LIMIT, "Archive exceeds 90 MiB")
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "ZIP CRC failed")
        require(
            len(archive.namelist()) == len(paths) + 2
            and set(archive.namelist()) == set(paths) | {"SHA256SUMS.json", "EVIDENCE-SCOPE.json"},
            "ZIP member set differs",
        )
        require(
            json.loads(archive.read("SHA256SUMS.json")) == manifest, "Manifest readback differs"
        )
        require(archive.read("EVIDENCE-SCOPE.json") == scope, "Scope readback differs")
        for name, source in paths.items():
            with archive.open(name) as stream:
                count, hasher = 0, hashlib.sha256()
                for block in iter(lambda: stream.read(CHUNK), b""):
                    count += len(block)
                    hasher.update(block)
            require(
                manifest[name] == {"bytes": count, "sha256": hasher.hexdigest()}
                and digest(source) == manifest[name]["sha256"],
                "Archive/current source mismatch: " + name,
            )


def verify_archive():
    gates = validate_evidence()
    paths, _ = collect()
    record = read(RECORD)
    manifest = read(MANIFEST)
    require(
        record["status"] == "VERIFIED"
        and record["gates"] == gates
        and record["path"] == DESTINATION.relative_to(REPO).as_posix()
        and record["bytes"] == DESTINATION.stat().st_size
        and record["sha256"] == digest(DESTINATION),
        "Archive verification record changed/incomplete",
    )
    require(
        set(manifest) == set(paths) | {"EVIDENCE-SCOPE.json"}, "Manifest/current members differ"
    )
    scope = core.encode(record["scope"])
    verify_payload(core.safe_path(REPO, record["path"]), paths, manifest, scope)
    return {
        "status": "VERIFIED",
        "sha256": record["sha256"],
        "path": record["path"],
        "bytes": record["bytes"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    gates = validate_evidence()
    paths, excluded = collect()
    details = {name: core.describe(path) for name, path in paths.items()}
    manifest = {name: {k: data[k] for k in ("bytes", "sha256")} for name, data in details.items()}
    scope = {
        "gates": gates,
        "scope": "Finite normal arena1 acceptance; prior baseline FAILED and screening only",
        "excluded": excluded,
        "private_env_read": False,
        "private_secret_value_scan": "NOT_PERFORMED; publisher scans separately",
    }
    scope_bytes = core.encode(scope)
    manifest["EVIDENCE-SCOPE.json"] = {
        "bytes": len(scope_bytes),
        "sha256": hashlib.sha256(scope_bytes).hexdigest(),
    }
    generated = {
        "SHA256SUMS.json": core.encode(manifest),
        "EVIDENCE-SCOPE.json": scope_bytes,
    }
    estimate = sum(v["estimated_deflate_bytes"] for v in details.values()) + sum(
        len(zlib.compress(v, 9)) for v in generated.values()
    )
    estimate += sum(256 + 2 * len(n.encode()) for n in [*paths, *generated]) + 1024
    require(
        estimate <= LIMIT, "Estimated archive exceeds 90 MiB; never omit evidence automatically"
    )
    for path in (DESTINATION, STAGING, RECORD, MANIFEST):
        core.safe_path(REPO, path.relative_to(REPO).as_posix())
        require(not path.exists(), "Refuse archive/output overwrite")
    if args.check:
        print(
            json.dumps(
                {
                    "status": "READY_TO_PACKAGE",
                    "gates": gates,
                    "files": len(paths),
                    "members": manifest,
                    "estimated_zip_bytes": estimate,
                    "excluded": excluded,
                }
            )
        )
        return 0
    record = {
        "status": "RUNNING",
        "path": DESTINATION.relative_to(REPO).as_posix(),
        "gates": gates,
        "scope": scope,
    }
    with RECORD.open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    try:
        with zipfile.ZipFile(
            STAGING, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for name, source in paths.items():
                with source.open("rb") as inp, archive.open(name, "w") as out:
                    for block in iter(lambda: inp.read(CHUNK), b""):
                        out.write(block)
            for name, data in generated.items():
                archive.writestr(name, data)
        verify_payload(STAGING, paths, manifest, generated["EVIDENCE-SCOPE.json"])
        require(
            validate_evidence() == gates and collect()[0] == paths,
            "Evidence changed during archive",
        )
        # Long gate replay can race a log writer; bind the final claim to bytes read afterward.
        verify_payload(STAGING, paths, manifest, generated["EVIDENCE-SCOPE.json"])
        record.update(
            status="VERIFIED",
            bytes=STAGING.stat().st_size,
            sha256=digest(STAGING),
            crc_verified=True,
            every_member_hash_verified=True,
            current_bytes_match=True,
        )
        os.link(STAGING, DESTINATION)
        with MANIFEST.open("x", encoding="utf-8") as sink:
            json.dump(manifest, sink, indent=2)
        STAGING.unlink()
    except BaseException as exc:
        record.update(status="FAILED", error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        RECORD.write_bytes(core.encode(record))
    print(json.dumps(record))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
