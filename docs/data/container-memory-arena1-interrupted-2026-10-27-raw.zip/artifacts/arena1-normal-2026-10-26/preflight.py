"""Freeze fresh arena1 normal evidence only after complete eligible diagnostic screening."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

from candidate_gate import (
    IMAGE,
    IMAGE_REFERENCE,
    OLD,
    QUERY_SHA,
    REPO,
    ROOT,
    digest,
    read,
    require,
    require_base_image,
    screening_binding,
)

sys.path.insert(0, str(REPO))
from scripts.validate_container_soak import clean_environment  # noqa: E402

DOCKER = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
HELPERS = (
    "preflight.py",
    "build_candidate.py",
    "run_stability.py",
    "audit_case.py",
    "normal_raw_evidence.py",
    "candidate_gate.py",
)


def command(argv):
    return subprocess.run(
        argv,
        cwd=REPO,
        env=clean_environment(),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=30,
        check=True,
    ).stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison", type=Path, required=True)
    args = parser.parse_args()
    binding = screening_binding(args.comparison, replay=True)  # Before any freeze or Docker call.
    baseline_archive = read(OLD / "baseline-archive-verification.json")
    require(
        baseline_archive["status"] == "VERIFIED"
        and baseline_archive.get("production_acceptance") is False
        and baseline_archive["crc_verified"] is True
        and baseline_archive["every_member_hash_verified"] is True
        and digest(REPO / baseline_archive["path"]) == baseline_archive["sha256"],
        "Rejected baseline must be archived before candidate freeze",
    )
    require(
        not any(
            (ROOT / n).exists()
            for n in (
                "preflight.json",
                "fixture",
                "source-config",
                "inputs-sha256.json",
                "sources-sha256.json",
                "screening-binding.json",
                "screening-comparison.json",
            )
        ),
        "Refuse freeze overwrite",
    )
    require((ROOT / "acceptance-plan.md").is_file(), "New candidate acceptance plan required")
    dockerfile = (REPO / "Dockerfile").read_text(encoding="utf-8")
    compose = (REPO / "docker-compose.yml").read_text(encoding="utf-8")
    public = (REPO / ".env.example").read_text(encoding="utf-8")
    require(
        re.search(r"MALLOC_ARENA_MAX=1(?:\s|$)", dockerfile)
        and "${MALLOC_ARENA_MAX:-1}" in compose
        and re.search(r"(?m)^MALLOC_ARENA_MAX=1\s*$", public),
        "Production public defaults must be arena1 before freeze",
    )
    old_inputs = read(OLD / "inputs-sha256.json")
    inputs = {name: digest(REPO / name) for name in old_inputs}
    require(
        len(inputs) == 29 and inputs == old_inputs, "Frozen model/labels/input identities changed"
    )
    sources = {
        p.relative_to(REPO).as_posix(): digest(p)
        for pattern in ("src/**/*.py", "scripts/*.py", "tests/*.py")
        for p in sorted(REPO.glob(pattern))
    }
    base_sources = read(OLD / "sources-sha256.json")
    require(
        {k: v for k, v in sources.items() if k.startswith("src/")}
        == {k: v for k, v in base_sources.items() if k.startswith("src/")},
        "Inherited immutable image source differs; thin script build is insufficient",
    )
    require(
        digest(REPO / "pyproject.toml") == digest(OLD / "source-config/pyproject.toml"),
        "Thin build must not change dependencies",
    )
    image = json.loads(command([DOCKER, "image", "inspect", IMAGE]))[0]
    referenced_image = json.loads(command([DOCKER, "image", "inspect", IMAGE_REFERENCE]))[0]
    require_base_image(image, referenced_image)
    free = shutil.disk_usage(REPO).free
    require(free > 10 * 1024**3, "Insufficient free disk")
    original = json.loads(command([DOCKER, "volume", "inspect", "searchpilot_pgdata"]))[0]
    require(
        original == read(OLD / "preflight.json")["original_volume"],
        "Original volume metadata changed",
    )
    fixture = ROOT / "fixture"
    fixture.mkdir()
    for name in ("queries.csv", "manifest.json"):
        shutil.copyfile(OLD / "fixture" / name, fixture / name)
    require(digest(fixture / "queries.csv") == QUERY_SHA, "Unexpected fixture")
    saved = ROOT / "source-config"
    saved.mkdir()
    configs = {
        name: digest(REPO / name)
        for name in ("Dockerfile", "docker-compose.yml", ".env.example", "pyproject.toml")
    }
    for name in configs:
        shutil.copyfile(REPO / name, saved / ("public-env.txt" if name == ".env.example" else name))
    for name, value in (
        ("inputs-sha256.json", inputs),
        ("sources-sha256.json", sources),
        ("screening-binding.json", binding),
    ):
        with (ROOT / name).open("x", encoding="utf-8") as sink:
            json.dump(value, sink, indent=2)
    shutil.copyfile(args.comparison, ROOT / "screening-comparison.json")
    require(
        digest(ROOT / "screening-comparison.json") == binding["comparison_sha256"],
        "Comparison changed",
    )
    record = {
        "status": "PASSED",
        "at": datetime.now(UTC).isoformat(),
        "image": IMAGE,
        "base_image_reference": IMAGE_REFERENCE,
        "head": command(["git", "rev-parse", "HEAD"]).strip(),
        "branch": command(["git", "branch", "--show-current"]).strip(),
        "dirty_files": command(["git", "status", "--short"]).splitlines(),
        "frozen_input_count": 29,
        "source_count": len(sources),
        "disk_free_bytes": free,
        "query_sha256": QUERY_SHA,
        "plan_sha256": digest(ROOT / "acceptance-plan.md"),
        "original_volume": original,
        "private_env_read": False,
        "public_example_read": True,
        "external_llm_calls": 0,
        "production_acceptance": False,
        "rejected_baseline_archive": {k: baseline_archive[k] for k in ("path", "bytes", "sha256")},
        "screening_binding_sha256": digest(ROOT / "screening-binding.json"),
        "helper_sha256": {name: digest(ROOT / name) for name in HELPERS},
        "manifest_sha256": {
            name: digest(ROOT / name) for name in ("inputs-sha256.json", "sources-sha256.json")
        },
        "public_config_sha256": configs,
    }
    with (ROOT / "preflight.json").open("x", encoding="utf-8") as sink:
        json.dump(record, sink, indent=2)
    print(json.dumps({k: record[k] for k in ("status", "source_count", "frozen_input_count")}))


if __name__ == "__main__":
    main()
