"""Archive completed evidence without changing source records or claiming acceptance."""

import argparse
import hashlib
import json
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from verify_archive import verify

REPO = Path("E:/searchPilot")
REVIEW = Path(__file__).resolve().parent


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--case", choices=["interrupted-two-hour", "final-three-hour"], required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    if args.case == "interrupted-two-hour":
        folders = [REPO / "artifacts/arena1-normal-2026-10-26"]
        extra = [REPO / ".tmp/arena1-interrupted-status-2026-10-27.json"]
        acceptance = False
        scope = "Interrupted run retained verbatim; absent completion/recovery remains absent"
    else:
        folders = [REPO / "artifacts/agent-memory-2026-10-27", REVIEW]
        state = json.loads((folders[0] / "launcher.json").read_text(encoding="utf-8"))
        assert state["status"] != "RUNNING" and state.get("observer_stopped") is True
        assert (folders[0] / "audit-result.json").is_file()
        assert (REVIEW / "terra-supplement-result.json").is_file()
        release = REPO / "artifacts/agent-multistep-2026-10-27-release"
        extra = [
            release / name
            for name in [
                "build-summary.json",
                "build.txt",
                "Dockerfile.validation",
                "source-snapshot.json",
            ]
        ]
        acceptance = False
        scope = (
            "Complete run evidence; archive integrity alone does not grant production acceptance"
        )
    files = {
        str(f.relative_to(REPO)).replace("\\", "/"): f
        for folder in folders
        for f in folder.rglob("*")
        if f.is_file() and "__pycache__" not in f.parts and f.suffix not in {".zip", ".pyc"}
    }
    files.update({str(f.relative_to(REPO)).replace("\\", "/"): f for f in extra})
    for name in ["package_evidence.py", "verify_archive.py"]:
        files["reproduction/" + name] = REVIEW / name
    for name in files:
        assert ".env" not in Path(name).parts and ".env.local" not in Path(name).parts
    hashes = {name: sha(path) for name, path in files.items()}
    metadata = json.dumps(
        {
            "case": args.case,
            "scope": scope,
            "production_acceptance": acceptance,
            "created_at": datetime.now(UTC).isoformat(),
        },
        indent=2,
    ).encode()
    hashes["EVIDENCE-SCOPE.json"] = hashlib.sha256(metadata).hexdigest()
    with zipfile.ZipFile(args.out, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, path in files.items():
            z.write(path, name)
        z.writestr("EVIDENCE-SCOPE.json", metadata)
        z.writestr("MANIFEST-SHA256.json", json.dumps(hashes, indent=2))
    assert all(sha(path) == hashes[name] for name, path in files.items())
    digest = sha(args.out)
    result = verify(args.out, digest)
    result.update(
        archive=str(args.out), bytes=args.out.stat().st_size, current_sources_match_archive=True
    )
    record = REVIEW / (args.case + "-archive-verification.json")
    with record.open("x", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
