"""Read-only ZIP integrity verification. Does not extract or certify secret absence."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import stat
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

MANIFEST = "MANIFEST-SHA256.json"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(stream):
    return hashlib.file_digest(stream, "sha256").hexdigest()


def verify(path, expected_sha256):
    require(
        re.fullmatch(r"[0-9a-f]{64}", expected_sha256) is not None,
        "External ZIP SHA256 must be exact lowercase hex",
    )
    with Path(path).open("rb") as stream:
        require(digest(stream) == expected_sha256, "Whole ZIP SHA256 differs")
    with ZipFile(path) as archive:
        require(archive.testzip() is None, "ZIP CRC check failed")
        names, folded = set(), set()
        files = set()
        for info in archive.infolist():
            name = info.filename
            pure = PurePosixPath(name)
            require(
                name
                and not name.startswith("/")
                and "\\" not in name
                and not any(part in {".", ".."} or ":" in part for part in pure.parts)
                and str(pure) == name.rstrip("/"),
                "Noncanonical or unsafe archive path",
            )
            require(name not in names and name.casefold() not in folded, "Duplicate archive member")
            require(not stat.S_ISLNK(info.external_attr >> 16), "Symlink member is not allowed")
            names.add(name)
            folded.add(name.casefold())
            if not info.is_dir():
                files.add(name)
        require(MANIFEST in files, "SHA manifest missing")
        manifest = json.loads(archive.read(MANIFEST))
        require(
            isinstance(manifest, dict) and set(manifest) == files - {MANIFEST},
            "Manifest membership differs from archived files",
        )
        for name, expected in manifest.items():
            require(
                isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected),
                "Invalid member SHA256",
            )
            with archive.open(name) as stream:
                require(digest(stream) == expected, "Member SHA256 differs: " + name)
    return {
        "status": "VERIFIED",
        "zip_sha256": expected_sha256,
        "members": len(files),
        "scope": "whole hash, CRC, paths, membership and member hashes only",
        "secrets_absence_certified": False,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--expected-sha256", required=True)
    args = parser.parse_args(argv)
    print(json.dumps(verify(args.zip, args.expected_sha256)))


if __name__ == "__main__":
    main()
